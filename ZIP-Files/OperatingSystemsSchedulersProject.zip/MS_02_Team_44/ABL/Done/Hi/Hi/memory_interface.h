#ifndef MEMORY_INTERFACE_H
#define MEMORY_INTERFACE_H
#include "os_structs.h"

extern MemoryWord memory[MEMORY_SIZE];


void initializeMemory();
void displayMemory();
int isMemoryFull();


#endif
