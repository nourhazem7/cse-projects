#ifndef SCHEDULER_INTERFACE_H
#define SCHEDULER_INTERFACE_H
#include "os_structs.h"
#define LEVELS 4
#include <stdio.h>

extern Queue readyQueue;
extern Queue readyQueues[LEVELS];
extern int quantum;
extern Queue generalBlockedQueue;    //Queue containing all the blocked queues of all the mutexes

const char* getStateString(ProcessState state);
// ----- Queue Operations -----
// Declare the queue-related functions
void initQueue(Queue* q);
int isEmpty(Queue* q);
int isFull(Queue* q);
void enqueue(Queue* q, Process* p);
Process* dequeue(Queue* q);
Process* peek(Queue* q);
void enqueue_FCFS_RR(Process* p); 
void enqueue_MLFQ(Process* p); 
extern int clockCycle;
void checkAndCreateArrivingProcesses(int currentCycle);
extern int quantum;

extern Queue allProcesses;




//*************************************************************************************************************************************/

//----- Ready Queue Handler -----
extern void (*enqueueToReadyQueue)(Process*);

//----- Schedulers Function Signatures -----
void FCFS();
void RoundRobin();
void MLFQ(); 

typedef enum {
    FIRST_COME_FIRST_SERVE,
    ROUND_ROBIN,
    MULTI_LEVEL_FEEDBACK_QUEUE
} SchedulerType;

extern SchedulerType selectedScheduler;

//*************************************************************************************************************************************//



// Process info before it’s created
typedef struct {
    int pid;
    char filePath[100];
    int arrivalTime;
    int priority;
    int created; // 0 = not yet created, 1 = created
} ProcessMeta;

extern ProcessMeta processList[MAX_PROCESSES];
extern int processCount;




#endif
