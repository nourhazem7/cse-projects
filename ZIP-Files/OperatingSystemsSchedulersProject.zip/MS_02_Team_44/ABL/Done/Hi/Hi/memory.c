#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "os_structs.h" 
#include "interpreter_interface.h"

#define MEMORY_SIZE 60

MemoryWord memory[MEMORY_SIZE]; 

// ----- initializing the memory -----
void initializeMemory() {
    for (int i = 0; i < MEMORY_SIZE; i++) {
        memory[i].name[0] = '\0';  // Initialize name to an empty string
        memory[i].value[0] = '\0'; // Initialize value to an empty string
    }
}

// Function to free memory for a process
void freeMemory(Process* process) {
    int start = process->pcb.memoryStart;
    int end = process->pcb.memoryEnd;

    // Free the memory slots that were used for instructions, variables, and PCB
    for (int i = start; i <= end; i++) {
        if (memory[i].name[0] != '\0') {
            memory[i].name[0] = '\0';  
        }
        
        if (memory[i].value[0] != '\0') {
            memory[i].value[0] = '\0'; 
        }
    }

    printf("Memory for Process %d has been freed from slots %d to %d.\n", process->pcb.pid, start, end);
}

int isMemoryFull()
{
    int i = 1;
    while(memory[i].name[0] != '\0' && memory[i].value[0] != '\0')
    {
        i++;
    }

    if(i == MEMORY_SIZE)
        return 1;
    else
        return 0;
}

// ----- displaying the memory content -----
void displayMemory() {
    printf("\n==== Memory ====\n");
    for (int i = 0; i < MEMORY_SIZE; i++) {
        if (memory[i].name[0] != '\0')
            printf("Slot %d: %s: %s\n", i, memory[i].name, memory[i].value);
        else
            printf("Slot %d: [empty]\n", i);
    }
} 
