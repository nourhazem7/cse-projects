#ifndef OS_STRUCTS_H
#define OS_STRUCTS_H

#define MEMORY_SIZE 60
#define MAX_VARIABLES 3
#define MAX_INSTRUCTIONS 20
#define MAX_PROCESSES 10

// ---- Process State Enum ----
typedef enum {NEW, READY, RUNNING, BLOCKED, TERMINATED} ProcessState;

// ---- PCB Structure ----
typedef struct {
    int pid;                // Process ID
    ProcessState state;     // Process State
    int priority;           // Process Priority 
    int pc;                 // Program counter
    int memoryStart;        // Start index in memory
    int memoryEnd;          // End index in memory
    int arrivalTime;
    int remainingQuantum;
    int originalLevel; 
    int timeInQueue; // ⬅️ Add this field
    int startRunningTime;
} PCB;

// ---- Variable Structure ----
typedef struct {
    char name[20];
    char value[100];
} Variable;

// ---- Process Structure ----
typedef struct {
    PCB pcb;
    char* instructions[MAX_INSTRUCTIONS];  // Loaded from file
    int instructionCount;
    Variable variables[MAX_VARIABLES];
    int variableCount;
    int toBeBlocked;  // 0 = no, 1 = yes
    char blockedMutexName[20];  // For deferring mutex blocked queue enqueueing
    int currentQuantumCount;
    int wasJustUnblocked;  // 0 = no, 1 = yes
    char lastHeldMutex[20];        // To remember which mutex was held (for deferred cleanup)
} Process;

// ---- Memory Word ----
typedef struct {
    char name[50];   // example: "state", "pc", "priority", "x"
    char value[100]; // example: "RUNNING", "3", "5"
} MemoryWord;


// ---- Mutex Structure ----
typedef struct {
    int isLocked;
    int ownerPID;
    int blockedQueue[10];
    int blockedCount;
} Mutex;

// ---- Queue Structure ----
typedef struct {
    Process* items[MAX_PROCESSES];
    int front, rear,size;
} Queue;


#endif
