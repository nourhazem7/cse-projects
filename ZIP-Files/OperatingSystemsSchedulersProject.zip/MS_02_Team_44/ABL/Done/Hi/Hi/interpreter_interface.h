#ifndef INTERPRETER_INTERFACE_H
#define INTERPRETER_INTERFACE_H
#include "os_structs.h"


// ----- global mutexes -----
extern Mutex userInputMutex, userOutputMutex, fileMutex;
char* get_input_from_user(const char* variable_name);

void interpretInstruction(Process* process);

#endif