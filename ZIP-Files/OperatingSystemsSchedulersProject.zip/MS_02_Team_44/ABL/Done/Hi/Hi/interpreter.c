#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "os_structs.h"
#include "scheduler_interface.h"
#include "interpreter_interface.h" 
#include "memory_interface.h"
extern int prioritizeUnblockedProcess;
extern Queue readyQueue;       // FCFS and RR use a single ready queue
extern Queue allProcesses;     // Master list of all created processes
extern Queue generalBlockedQueue;    //Queue containing all the blocked queues of all the mutexes
extern Queue generalBlockedQueues[4];  // Needed for MLFQ unblocking
extern Mutex userInputMutexLevels[4];
extern Mutex userOutputMutexLevels[4];
extern Mutex fileMutexLevels[4];
extern Queue unblockedQueue;  // Declare external queue defined in scheduler.c
char* get_input_from_user(const char* variable_name);  // from gui.c
void log_to_gui_and_console(const char *format, ...);



char* getValueFromMemory(Process* process, const char* varName) {
    for (int i = 0; i < 3; i++) {
        int slot = process->pcb.memoryStart + 7 + i;
        if (strcmp(memory[slot].name, varName) == 0) {
            return memory[slot].value;
        }
    }
    return NULL;
}

// ----- assign command -----
void executeAssign(Process* process, const char* line) {
    char varName[20], valueToken[100];
    sscanf(line, "assign %s %s", varName, valueToken);

    char finalValue[100];

    if (strcmp(valueToken, "input") == 0) {
        char *gui_input = get_input_from_user(varName);
        if (gui_input != NULL && strlen(gui_input) > 0) {
            strncpy(finalValue, gui_input, sizeof(finalValue));
            free(gui_input);
        } else {
            strcpy(finalValue, "0");  // fallback default
        }

    } else if (strncmp(valueToken, "readFile", 8) == 0) {
        char fileVar[20];
        sscanf(line, "assign %s readFile %s", varName, fileVar);
        char* fileName = getValueFromMemory(process, fileVar);
        if (fileName == NULL) {
            log_to_gui_and_console("Error: File name variable '%s' not found.\n", fileVar);
            return;
        }

        FILE* f = fopen(fileName, "r");
        if (!f) {
            log_to_gui_and_console("Error: Failed to open file: %s\n", fileName);
            return;
        }
        fgets(finalValue, sizeof(finalValue), f);
        finalValue[strcspn(finalValue, "\n")] = 0;
        fclose(f);
    } else {
        char* sourceValue = getValueFromMemory(process, valueToken);
        if (sourceValue)
            strcpy(finalValue, sourceValue);
        else
            strcpy(finalValue, valueToken);
    }

    int varIndex = -1;
    for (int i = 0; i < process->variableCount; i++) {
        if (strcmp(process->variables[i].name, varName) == 0) {
            varIndex = i;
            break;
        }
    }

    if (varIndex == -1 && process->variableCount < 3) {
        varIndex = process->variableCount++;
        strcpy(process->variables[varIndex].name, varName);
    }

    strcpy(process->variables[varIndex].value, finalValue);

    int memVarIndex = process->pcb.memoryStart + 7 + varIndex;
    strcpy(memory[memVarIndex].name, varName);
    strcpy(memory[memVarIndex].value, finalValue);
}


// ----- print command -----
void executePrint(Process* process, const char* line) {
    char varName[20];
    sscanf(line, "print %s", varName);

    char* value = getValueFromMemory(process, varName);  // Fetch value from memory

    if (value != NULL) {
        log_to_gui_and_console("Process %d: %s = %s\n", process->pcb.pid, varName, value);
    } else {
        log_to_gui_and_console("Process %d: Error - Variable %s not found.\n", process->pcb.pid, varName);
    }
}


// ----- read file command -----
void executeReadFile(Process* process, const char* line) {
    char varName[20];   // Variable name for the file content to be assigned to
    char fileVar[20];   // Variable name containing the file name

    // Parse the readFile command: readFile variable_name
    sscanf(line, "readFile %s", varName);

    // Fetch the file path from memory (the variable holding the file name)
    char* filePath = getValueFromMemory(process, varName);  // Get the actual file name from memory

    if (filePath == NULL) {
        log_to_gui_and_console("Error: File name variable '%s' not found in process %d.\n", varName, process->pcb.pid);
        return;
    }

    // Open the file at the specified path
    FILE* file = fopen(filePath, "r");
    if (!file) {
        log_to_gui_and_console("Error: Failed to open file %s in process %d.\n", filePath, process->pcb.pid);
        return;
    }

    // Read the file's content into the value variable
    char fileContent[100];
    if (fgets(fileContent, sizeof(fileContent), file)) {
        fileContent[strcspn(fileContent, "\n")] = 0;  // Remove newline character if present

        // No need to reassign the value here, the 'assign' command will take care of it.
        // We can just print the content of the file for debug if needed
        log_to_gui_and_console("File %s content: %s\n", filePath, fileContent);
    } else {
        log_to_gui_and_console("Error: Failed to read from file %s in process %d.\n", filePath, process->pcb.pid);
    }

    fclose(file);
}


// ----- write file command -----
void executeWriteFile(Process* process, const char* line) {
    char fileVar[20];  // Variable that holds the file name
    char dataVar[20];  // Variable that holds the data to be written to the file

    // Parse the writeFile command: writeFile x y
    sscanf(line, "writeFile %s %s", fileVar, dataVar);

    // Fetch the file name from memory (the variable holding the file name)
    char* filePath = getValueFromMemory(process, fileVar);
    if (filePath == NULL) {
        log_to_gui_and_console("Error: File name variable '%s' not found in process %d.\n", fileVar, process->pcb.pid);
        return;
    }

    // Fetch the data (value) to be written to the file from memory
    char* dataToWrite = getValueFromMemory(process, dataVar);
    if (dataToWrite == NULL) {
        log_to_gui_and_console("Error: Data variable '%s' not found in process %d.\n", dataVar, process->pcb.pid);
        return;
    }

    // Open the file at the specified path for writing
    FILE* file = fopen(filePath, "w");
    if (!file) {
        log_to_gui_and_console("Error: Failed to open file %s in process %d.\n", filePath, process->pcb.pid);
        return;
    }

    // Write the content to the file
    fprintf(file, "%s\n", dataToWrite);  // Writing data to the file

    fclose(file);  // Close the file

    log_to_gui_and_console("Process %d: Successfully wrote to file %s. Data: %s\n", process->pcb.pid, filePath, dataToWrite);
}


// ----- printFromTo command -----
void executePrintFromTo(Process* process, const char* line) {
    char varName1[20], varName2[20];
    sscanf(line, "printFromTo %s %s", varName1, varName2);

    char* value1 = getValueFromMemory(process, varName1);
    char* value2 = getValueFromMemory(process, varName2);

    if (value1 != NULL && value2 != NULL) {
        int from = atoi(value1);
        int to = atoi(value2);

        log_to_gui_and_console("Process %d: Printing numbers from %d to %d:\n", process->pcb.pid, from, to);

        if (from <= to) {
            for (int i = from; i <= to; i++) {
                log_to_gui_and_console("%d ", i);
            }
        } else {
            for (int i = from; i >= to; i--) {
                log_to_gui_and_console("%d ", i);
            }
        }
        log_to_gui_and_console("\n");

    } else {
        log_to_gui_and_console("Process %d: Error - One or both variables not found.\n", process->pcb.pid);
    }
}




Mutex userInputMutex;
Mutex userOutputMutex;
Mutex fileMutex;

void executeSemWait(Process* process, const char* line) {
    char resource[20];
    sscanf(line, "semWait %s", resource);

    Mutex* m;

    if (strcmp(resource, "userInput") == 0)
        m = &userInputMutex;
    else if (strcmp(resource, "userOutput") == 0)
        m = &userOutputMutex;
    else if (strcmp(resource, "file") == 0)
        m = &fileMutex;
    else {
        log_to_gui_and_console("Unknown resource\n");
        return;
    }

    if (m->isLocked == 0) {
        m->isLocked = 1;
        m->ownerPID = process->pcb.pid;
        log_to_gui_and_console("Process %d acquired %s\n", process->pcb.pid, resource);
        process->toBeBlocked = 0;
        strcpy(process->blockedMutexName, "");
    }

    // ✅ FIX: check if process already owns it
    else if (m->ownerPID == process->pcb.pid) {
        log_to_gui_and_console("Process %d already holds %s\n", process->pcb.pid, resource);
        process->toBeBlocked = 0;
        strcpy(process->blockedMutexName, "");
    }

    else {
        log_to_gui_and_console("Process %d will be blocked on %s\n", process->pcb.pid, resource);
        process->toBeBlocked = 1;
        strcpy(process->blockedMutexName, resource);
    }
}


Process* getProcessByPID(int pid, Queue* q) {
    for (int i = q->front; i < q->rear; i++) {
        if (q->items[i]->pcb.pid == pid) {
            return q->items[i];
        }
    }
    return NULL;  // Process not found
}


// ----- sem signal command -----


void executeSemSignal(Process* process, const char* line) {
    char resource[20];
    sscanf(line, "semSignal %s", resource);
    Mutex* m;

    if (strcmp(resource, "userInput") == 0)
        m = &userInputMutex;
    else if (strcmp(resource, "userOutput") == 0)
        m = &userOutputMutex;
    else if (strcmp(resource, "file") == 0)
        m = &fileMutex;
    else {
        log_to_gui_and_console("Unknown resource\n");
        return;
    }

    if (m->ownerPID != process->pcb.pid) {
        log_to_gui_and_console("Process %d Error: Cannot release resource it does not own\n", process->pcb.pid);
        return;
    }

    if (m->blockedCount > 0) {
        int unblockedPID = m->blockedQueue[0];
        m->ownerPID = unblockedPID;

        // Shift blockedQueue and update blockedCount
        for (int i = 0; i < m->blockedCount - 1; i++) {
            m->blockedQueue[i] = m->blockedQueue[i + 1];
        }
        m->blockedCount--;

        Process* unblockedProcess = getProcessByPID(unblockedPID, &allProcesses);
        if (unblockedProcess) {
            unblockedProcess->pcb.state = READY;
            int base = unblockedProcess->pcb.memoryStart;
            strcpy(memory[base + 1].value, "Ready");
            unblockedProcess->wasJustUnblocked = 1;
            strcpy(unblockedProcess->lastHeldMutex, resource);

            if (selectedScheduler == MULTI_LEVEL_FEEDBACK_QUEUE) {
                unblockedProcess->pcb.priority = unblockedProcess->pcb.originalLevel;
                enqueue_MLFQ(unblockedProcess);
            } else {
                enqueue(&unblockedQueue, unblockedProcess);
                // Immediately remove from generalBlockedQueue
for (int i = generalBlockedQueue.front; i < generalBlockedQueue.rear; i++) {
    if (generalBlockedQueue.items[i]->pcb.pid == unblockedPID) {
        for (int j = i + 1; j < generalBlockedQueue.rear; j++)
            generalBlockedQueue.items[j - 1] = generalBlockedQueue.items[j];
        generalBlockedQueue.rear--;
        break;
    }
}
    
            }

            log_to_gui_and_console("Process %d unblocked and acquired %s\n", unblockedPID, resource);
        } else {
            log_to_gui_and_console("Error: Unblocked process %d not found in allProcesses queue.\n", unblockedPID);
        }
    } else {
        m->isLocked = 0;
        m->ownerPID = -1;
        log_to_gui_and_console("Process %d released %s\n", process->pcb.pid, resource);
    }
}
// ----- interpreter function -----
void interpretInstruction(Process* process) {
    if (process->pcb.state == TERMINATED || process->pcb.state == BLOCKED)
        return;

    

    int instructionSlot = process->pcb.memoryStart + 10 + process->pcb.pc;

    if (instructionSlot >= process->pcb.memoryEnd || memory[instructionSlot].value[0] == '\0') {
        log_to_gui_and_console("No instruction at memory slot %d. Terminating process %d.\n", instructionSlot, process->pcb.pid);
        process->pcb.state = TERMINATED;
        strcpy(memory[process->pcb.memoryStart + 1].value, "Terminated");
        return;
    }
    

    char* line = memory[instructionSlot].value;   // Fetch instructions from memory

    if (strlen(line) == 0) {
        log_to_gui_and_console("Process %d: No instruction found at PC=%d\n", process->pcb.pid, process->pcb.pc);
        return;
    }

    log_to_gui_and_console("Instruction: %s\n", line);

    if (strncmp(line, "assign", 6) == 0) {
        executeAssign(process, line);
    } else if (strncmp(line, "printFromTo", 11) == 0) {
        executePrintFromTo(process, line);
    } else if (strncmp(line, "print", 5) == 0) {
        executePrint(process, line);
    } else if (strncmp(line, "readFile", 8) == 0) {
        executeReadFile(process, line);
    } else if (strncmp(line, "writeFile", 9) == 0) {
        executeWriteFile(process, line);
    } else if (strncmp(line, "semWait", 7) == 0) {
        executeSemWait(process, line);
    } else if (strncmp(line, "semSignal", 9) == 0) {
        executeSemSignal(process, line);
    } else {
        log_to_gui_and_console("Process %d Warning: Unknown instruction \"%s\"\n", process->pcb.pid, line);
    }
}