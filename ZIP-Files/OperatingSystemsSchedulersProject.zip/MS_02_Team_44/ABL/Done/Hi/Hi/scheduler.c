#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "memory_interface.h"
#include "interpreter_interface.h"
#include "os_structs.h"
#include "scheduler_interface.h"

#define LEVELS 4
void log_to_gui_and_console(const char *format, ...);
Process* quantumExpiredLastCycle = NULL;
// ====================== GLOBAL VARIABLES ==========================
ProcessMeta processList[MAX_PROCESSES];
int processCount = 0;
SchedulerType selectedScheduler = FIRST_COME_FIRST_SERVE;
int clockCycle = 0;
int quantum;
int flag = 0;
int prioritizeUnblockedProcess = 0;
extern int clockCycle;
Queue readyQueue;
Queue readyQueues[LEVELS];
Queue allProcesses;
Queue generalBlockedQueue;
Queue generalBlockedQueues[LEVELS];
Queue unblockedQueue;
Queue blockedQueue;
Mutex userInputMutexLevels[LEVELS];
Mutex userOutputMutexLevels[LEVELS];
Mutex fileMutexLevels[LEVELS];
Process* runningProcess = NULL;
int get_pid_from_filename(const char* filename);
int levelQuantum[LEVELS] = {1, 2, 4, 8};
const char* getStateString(ProcessState state);  // declaration only

// ======================= QUEUE FUNCTIONS ==========================
void initQueue(Queue* q) { q->front = q->rear = 0; }

int isEmpty(Queue* q) { return q->front == q->rear; }

int isFull(Queue* q) { return q->rear >= MAX_PROCESSES; }

void enqueue(Queue* q, Process* p) {
    if (isFull(q)) {
        log_to_gui_and_console("Queue is full. Cannot enqueue process %d\n", p->pcb.pid);
        return;
    }
    q->items[q->rear++] = p;
}

Process* dequeue(Queue* q) {
    if (isEmpty(q)) return NULL;
    Process* p = q->items[q->front];
    for (int i = q->front + 1; i < q->rear; i++)
        q->items[i - 1] = q->items[i];
    q->rear--;
    return p;
}

Process* peek(Queue* q) {
    if (isEmpty(q)) return NULL;
    return q->items[q->front];
}

// ====================== ENQUEUE HELPERS ===========================
void enqueue_FCFS_RR(Process* p) {
    enqueue(&readyQueue, p);
}

void enqueue_MLFQ(Process* p) {
    int level = p->pcb.priority;
    if (level < 0 || level >= LEVELS) {
        log_to_gui_and_console("Invalid priority level: %d\n", level);
        return;
    }
    enqueue(&readyQueues[level], p);
}
void checkAndCreateArrivingProcesses(int currentCycle) {
    for (int i = 0; i < processCount; i++) {
        ProcessMeta* meta = &processList[i];

        if (!meta->created && meta->arrivalTime == currentCycle) {
            Process* p = malloc(sizeof(Process));
            if (!p) {
                log_to_gui_and_console("❌ Memory allocation failed.\n");
                continue;
            }

            // 🔐 Fixed PID from filename
            p->pcb.pid = get_pid_from_filename(meta->filePath);
            if (p->pcb.pid < 1 || p->pcb.pid > 3) {
                log_to_gui_and_console("❌ Invalid PID returned for file: %s\n", meta->filePath);
                free(p);
                continue;
            }
            meta->pid = p->pcb.pid;

            // 🧠 Set process metadata
            p->pcb.priority = 0;
            p->pcb.pc = 0;
            p->pcb.state = READY;
            p->pcb.arrivalTime = currentCycle;
            p->pcb.timeInQueue = 0;
            p->instructionCount = 0;
            p->variableCount = 0;
            p->wasJustUnblocked = 0;
            p->toBeBlocked = 0;
            p->pcb.originalLevel = 0;
            strcpy(p->lastHeldMutex, "");
            strcpy(p->blockedMutexName, "");

            // 🧱 Assign fixed memory
            int base = (p->pcb.pid - 1) * 20;
            if (base + 19 >= MEMORY_SIZE) {
                log_to_gui_and_console("❌ Not enough memory for Process %d\n", p->pcb.pid);
                free(p);
                continue;
            }
            p->pcb.memoryStart = base;
            p->pcb.memoryEnd = base + 19;

            // 🧾 Fill memory info section
            strcpy(memory[base + 0].name, "pid");
            sprintf(memory[base + 0].value, "%d", p->pcb.pid);
            strcpy(memory[base + 1].name, "state");
            strcpy(memory[base + 1].value, "Ready");
            strcpy(memory[base + 2].name, "priority");
            sprintf(memory[base + 2].value, "%d", p->pcb.priority);
            strcpy(memory[base + 3].name, "pc");
            sprintf(memory[base + 3].value, "%d", p->pcb.pc);
            strcpy(memory[base + 4].name, "memoryStart");
            sprintf(memory[base + 4].value, "%d", base);
            strcpy(memory[base + 5].name, "memoryEnd");
            sprintf(memory[base + 5].value, "%d", base + 19);
            strcpy(memory[base + 6].name, "arrivalTime");
            sprintf(memory[base + 6].value, "%d", p->pcb.arrivalTime);

            for (int j = 7; j < 10; j++) {
                snprintf(memory[base + j].name, sizeof(memory[base + j].name), "Variable %d", j - 7);
                strcpy(memory[base + j].value, "Uninitialized");
            }

            // 📄 Load instructions into memory
            FILE* f = fopen(meta->filePath, "r");
            if (!f) {
                log_to_gui_and_console("❌ Could not open file: %s\n", meta->filePath);
                free(p);
                continue;
            }

            char line[128];
            int instrIndex = base + 10;
            while (fgets(line, sizeof(line), f) && instrIndex <= base + 19) {
                line[strcspn(line, "\n")] = 0;
                strcpy(memory[instrIndex].name, "instruction");
                strcpy(memory[instrIndex].value, line);
                instrIndex++;
                p->instructionCount++;
            }
            fclose(f);

            // 📥 Enqueue to system queues
            enqueue(&allProcesses, p);
            if (flag == 1) {
                flag = 0;
                Process* finished = readyQueue.items[--readyQueue.rear];
                (selectedScheduler == MULTI_LEVEL_FEEDBACK_QUEUE) ? enqueue_MLFQ(p) : enqueue_FCFS_RR(p);
                enqueue_FCFS_RR(finished);
            } else {
                (selectedScheduler == MULTI_LEVEL_FEEDBACK_QUEUE) ? enqueue_MLFQ(p) : enqueue_FCFS_RR(p);
            }

            meta->created = 1;
            log_to_gui_and_console("✅ Created Process %d from '%s' at time %d", p->pcb.pid, meta->filePath, currentCycle);
        }
    }
}
// ========================= SCHEDULERS =============================

void FCFS() {
    static Process* current = NULL;

    // 1. Pick a process if CPU is idle
    if (current == NULL && !isEmpty(&readyQueue)) {
        current = dequeue(&readyQueue);
        current->pcb.state = RUNNING;
        strcpy(memory[current->pcb.memoryStart + 1].value, "Running");
        log_to_gui_and_console("🟢 FCFS Running Process %d\n", current->pcb.pid);
    }

    // 2. Execute one instruction
    while (1) {
        if (current == NULL && !isEmpty(&readyQueue)) {
            current = dequeue(&readyQueue);
            current->pcb.state = RUNNING;
            current->pcb.startRunningTime = clockCycle;
            strcpy(memory[current->pcb.memoryStart + 1].value, "Running");
            log_to_gui_and_console("🟢 FCFS Running Process %d\n", current->pcb.pid);
        }
    
        if (current == NULL) break;  // Nothing to run
    
        // ✅ Check for end of instructions before wasting a cycle
        int slot = current->pcb.memoryStart + 10 + current->pcb.pc;
        if (slot >= current->pcb.memoryEnd || memory[slot].value[0] == '\0') {
            log_to_gui_and_console("✅ FCFS: Process %d terminated (empty or out-of-bounds instruction).\n", current->pcb.pid);
            current->pcb.state = TERMINATED;
            strcpy(memory[current->pcb.memoryStart + 1].value, "Terminated");
            current = NULL;
            continue;  // Try to run next process immediately
        }
    
        // ✅ Safe to interpret the instruction
        interpretInstruction(current);
        if (current && current->pcb.state == RUNNING) {
            current->pcb.pc++;
            sprintf(memory[current->pcb.memoryStart + 3].value, "%d", current->pcb.pc);
        }
    
        break;  // Only run 1 instruction per cycle
    }
    

    // // 3. Handle deferred blocking
    // if (current != NULL && current->toBeBlocked == 1) {
    //     current->toBeBlocked = 0;
    //     current->pcb.state = BLOCKED;
    //     strcpy(memory[current->pcb.memoryStart + 1].value, "Blocked");
    //     enqueue(&generalBlockedQueue, current);
    //     log_to_gui_and_console("⛔ FCFS: Process %d blocked.\n", current->pcb.pid);
    //     current = NULL;
    // }

    // 4. Handle termination
     if (current != NULL && current->pcb.pc >= current->instructionCount) {
        current->pcb.state = TERMINATED;
        strcpy(memory[current->pcb.memoryStart + 1].value, "Terminated");
        log_to_gui_and_console("✅ FCFS: Process %d terminated.\n", current->pcb.pid);
        current = NULL;
    }
}



void RoundRobin() {
    static int rrRemainingQuantum = 0;
    static Process* pendingQuantumReturn = NULL;

    log_to_gui_and_console("🔁 Round Robin Scheduler Tick - Quantum: %d", quantum);

    // 1. Move unblocked processes back to ready queue
    while (!isEmpty(&unblockedQueue)) {
        Process* p = dequeue(&unblockedQueue);

        // Remove from generalBlockedQueue
        for (int i = generalBlockedQueue.front; i < generalBlockedQueue.rear; i++) {
            if (generalBlockedQueue.items[i]->pcb.pid == p->pcb.pid) {
                for (int j = i + 1; j < generalBlockedQueue.rear; j++) {
                    generalBlockedQueue.items[j - 1] = generalBlockedQueue.items[j];
                }
                generalBlockedQueue.rear--;
                break;
            }
        }

        // Remove from specific mutex blocked queue
        int* blockedArr = NULL;
        int* blockedCount = NULL;

        if (strcmp(p->lastHeldMutex, "userInput") == 0) {
            blockedArr = userInputMutex.blockedQueue;
            blockedCount = &userInputMutex.blockedCount;
        } else if (strcmp(p->lastHeldMutex, "userOutput") == 0) {
            blockedArr = userOutputMutex.blockedQueue;
            blockedCount = &userOutputMutex.blockedCount;
        } else if (strcmp(p->lastHeldMutex, "file") == 0) {
            blockedArr = fileMutex.blockedQueue;
            blockedCount = &fileMutex.blockedCount;
        }

        if (blockedArr && blockedCount) {
            for (int i = 0; i < *blockedCount; i++) {
                if (blockedArr[i] == p->pcb.pid) {
                    for (int j = i + 1; j < *blockedCount; j++) {
                        blockedArr[j - 1] = blockedArr[j];
                    }
                    (*blockedCount)--;
                    break;
                }
            }
        }
// Remove from generalBlockedQueue
for (int i = generalBlockedQueue.front; i < generalBlockedQueue.rear; i++) {
    if (generalBlockedQueue.items[i]->pcb.pid == p->pcb.pid) {
        for (int j = i + 1; j < generalBlockedQueue.rear; j++)
            generalBlockedQueue.items[j - 1] = generalBlockedQueue.items[j];
        generalBlockedQueue.rear--;
        break;
    }
}

        p->wasJustUnblocked = 0;
        p->pcb.timeInQueue = 0;  // ✅ reset timeInQueue
        enqueue_FCFS_RR(p);
        log_to_gui_and_console("🔓 Process %d re-added to Ready Queue after unblock", p->pcb.pid);
    }

    // 2. Handle new arrivals
    checkAndCreateArrivingProcesses(clockCycle);

    // 3. Return process from expired quantum
    if (pendingQuantumReturn) {
        enqueue_FCFS_RR(pendingQuantumReturn);
        log_to_gui_and_console("⏩ Quantum expired: Process %d requeued", pendingQuantumReturn->pcb.pid);
        pendingQuantumReturn = NULL;
    }

    // 4. Pick process to run if CPU is idle
    if (!runningProcess && !isEmpty(&readyQueue)) {
        runningProcess = dequeue(&readyQueue);
        runningProcess->pcb.state = RUNNING;
        rrRemainingQuantum = quantum;
        strcpy(memory[runningProcess->pcb.memoryStart + 1].value, "Running");
        log_to_gui_and_console("🟢 Running Process %d for up to %d instructions", runningProcess->pcb.pid, quantum);
    }

    // 5. Execute one instruction
    if (runningProcess && runningProcess->pcb.state == RUNNING) {
        
        interpretInstruction(runningProcess);
        rrRemainingQuantum--;

        if (runningProcess->pcb.state == RUNNING) {
            runningProcess->pcb.pc++;
            sprintf(memory[runningProcess->pcb.memoryStart + 3].value, "%d", runningProcess->pcb.pc);
        }
    }

    // 6. Post-instruction outcome
    if (runningProcess) {
        // a. BLOCK
        if (runningProcess->toBeBlocked) {
            log_to_gui_and_console("⛔ Process %d blocked on %s", runningProcess->pcb.pid, runningProcess->blockedMutexName);
        
            runningProcess->pcb.state = BLOCKED;
            runningProcess->toBeBlocked = 0;
            strcpy(memory[runningProcess->pcb.memoryStart + 1].value, "Blocked");
        
            if (strcmp(runningProcess->blockedMutexName, "userInput") == 0)
                userInputMutex.blockedQueue[userInputMutex.blockedCount++] = runningProcess->pcb.pid;
            else if (strcmp(runningProcess->blockedMutexName, "userOutput") == 0)
                userOutputMutex.blockedQueue[userOutputMutex.blockedCount++] = runningProcess->pcb.pid;
            else if (strcmp(runningProcess->blockedMutexName, "file") == 0)
                fileMutex.blockedQueue[fileMutex.blockedCount++] = runningProcess->pcb.pid;
        
            strcpy(runningProcess->lastHeldMutex, runningProcess->blockedMutexName); // copy AFTER logging
            strcpy(runningProcess->blockedMutexName, "");  // clear AFTER copying
            runningProcess->pcb.timeInQueue = 0;  // ✅ Reset when entering blocked state
            enqueue(&generalBlockedQueue, runningProcess);
            runningProcess = NULL;
        }
        

        // b. TERMINATE
        else if (runningProcess->pcb.pc >= runningProcess->instructionCount) {
            runningProcess->pcb.state = TERMINATED;
            strcpy(memory[runningProcess->pcb.memoryStart + 1].value, "Terminated");
            log_to_gui_and_console("✅ Process %d terminated", runningProcess->pcb.pid);
            runningProcess = NULL;
        }

        // c. QUANTUM EXPIRED
        else if (rrRemainingQuantum == 0 && runningProcess->pcb.state == RUNNING) {
            runningProcess->pcb.state = READY;
            strcpy(memory[runningProcess->pcb.memoryStart + 1].value, "Ready");
            pendingQuantumReturn = runningProcess;
            runningProcess = NULL;
        }
    }
}


// ========================== MLFQ Scheduler with GUI & Logging Enhancements ==========================

// ========================== MLFQ Scheduler with GUI & Logging Enhancements ==========================

void MLFQ() {
    static Process* current = NULL;
    static int currentLevel = -1;
    static int quantumLeft = 0;

    // 🕒 Clock tick banner
    char header[64];
    snprintf(header, sizeof(header), "\n==== Clock Cycle: %d ====", clockCycle);
    log_to_gui_and_console("%s", header);

    // 1. Increment waiting time for all levels
    for (int i = 0; i < LEVELS; i++) {
        for (int j = readyQueues[i].front; j < readyQueues[i].rear; j++) {
            readyQueues[i].items[j]->pcb.timeInQueue++;
        }
    }

    // 2. If CPU is idle, fetch from highest-priority non-empty queue
    if (!current) {
        for (int i = 0; i < LEVELS; i++) {
            if (!isEmpty(&readyQueues[i])) {
                current = dequeue(&readyQueues[i]);
                currentLevel = i;
                quantumLeft = levelQuantum[i];
                current->pcb.state = RUNNING;
                strcpy(memory[current->pcb.memoryStart + 1].value, "Running");
                log_to_gui_and_console("🟢 Running P%d from Level %d (Quantum %d)", current->pcb.pid, i + 1, quantumLeft);
                break;
            }
        }
    }

    // 3. Execute one instruction if running
    if (current && current->pcb.state == RUNNING) {
        interpretInstruction(current);
        quantumLeft--;

        if (current->pcb.state == RUNNING) {
            current->pcb.pc++;
            sprintf(memory[current->pcb.memoryStart + 3].value, "%d", current->pcb.pc);
        }
    }

    // 4. Handle blocking
    if (current && current->toBeBlocked) {
        int blockLevel = (quantumLeft > 0) ? currentLevel : (currentLevel < LEVELS - 1 ? currentLevel + 1 : currentLevel);

        current->pcb.state = BLOCKED;
        current->toBeBlocked = 0;
        current->pcb.originalLevel = blockLevel;
        current->pcb.timeInQueue = 0;

        enqueue(&generalBlockedQueues[blockLevel], current);
        enqueue(&generalBlockedQueue, current);

        // Add to specific mutex queue
        if (strcmp(current->blockedMutexName, "userInput") == 0) {
            userInputMutex.blockedQueue[userInputMutex.blockedCount++] = current->pcb.pid;
            userInputMutexLevels[blockLevel].blockedQueue[userInputMutexLevels[blockLevel].blockedCount++] = current->pcb.pid;
        } else if (strcmp(current->blockedMutexName, "userOutput") == 0) {
            userOutputMutex.blockedQueue[userOutputMutex.blockedCount++] = current->pcb.pid;
            userOutputMutexLevels[blockLevel].blockedQueue[userOutputMutexLevels[blockLevel].blockedCount++] = current->pcb.pid;
        } else if (strcmp(current->blockedMutexName, "file") == 0) {
            fileMutex.blockedQueue[fileMutex.blockedCount++] = current->pcb.pid;
            fileMutexLevels[blockLevel].blockedQueue[fileMutexLevels[blockLevel].blockedCount++] = current->pcb.pid;
        }

        strcpy(current->lastHeldMutex, current->blockedMutexName);
        current->blockedMutexName[0] = '\0';

        log_to_gui_and_console("⛔ P%d BLOCKED on %s at Level %d", current->pcb.pid, current->lastHeldMutex, blockLevel + 1);
        current = NULL;
    }

    // 5. Handle termination
    else if (current && current->pcb.pc >= current->instructionCount) {
        current->pcb.state = TERMINATED;
        strcpy(memory[current->pcb.memoryStart + 1].value, "Terminated");
        log_to_gui_and_console("✅ P%d TERMINATED", current->pcb.pid);
        current = NULL;
    }

    // 6. Handle quantum expiration
    else if (current && current->pcb.state == RUNNING && quantumLeft == 0) {
        int nextLevel = (currentLevel < LEVELS - 1) ? currentLevel + 1 : currentLevel;
        current->pcb.state = READY;
        current->pcb.priority = nextLevel;
        current->pcb.timeInQueue = 0;
        strcpy(memory[current->pcb.memoryStart + 1].value, "Ready");

        enqueue(&readyQueues[nextLevel], current);
        log_to_gui_and_console("⏩ P%d: Quantum expired, moved to Level %d", current->pcb.pid, nextLevel + 1);
        current = NULL;
    }

    // 7. Handle unblocking
    while (!isEmpty(&unblockedQueue)) {
        Process* p = dequeue(&unblockedQueue);
        p->pcb.state = READY;
        p->pcb.priority = p->pcb.originalLevel;
        p->pcb.timeInQueue = 0;
        p->wasJustUnblocked = 0;
    
        // Remove from generalBlockedQueue
        for (int i = generalBlockedQueue.front; i < generalBlockedQueue.rear; i++) {
            if (generalBlockedQueue.items[i]->pcb.pid == p->pcb.pid) {
                for (int j = i; j < generalBlockedQueue.rear - 1; j++) {
                    generalBlockedQueue.items[j] = generalBlockedQueue.items[j + 1];
                }
                generalBlockedQueue.rear--;
                break;
            }
        }
    
        // Remove from generalBlockedQueues[level]
        int level = p->pcb.originalLevel;
        for (int i = generalBlockedQueues[level].front; i < generalBlockedQueues[level].rear; i++) {
            if (generalBlockedQueues[level].items[i]->pcb.pid == p->pcb.pid) {
                for (int j = i; j < generalBlockedQueues[level].rear - 1; j++) {
                    generalBlockedQueues[level].items[j] = generalBlockedQueues[level].items[j + 1];
                }
                generalBlockedQueues[level].rear--;
                break;
            }
        }
    
        enqueue(&readyQueues[p->pcb.priority], p);
        log_to_gui_and_console("🔓 P%d unblocked, returned to Level %d with fresh quantum", p->pcb.pid, p->pcb.priority + 1);
    }
}