#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "memory_interface.h"
#include "scheduler_interface.h"
#include "os_structs.h"
#include <stdarg.h>

extern int levelQuantum[4];
extern Queue allProcesses;
extern Queue readyQueue;
extern Queue readyQueues[4];
extern Queue blockedQueue;
extern Queue unblockedQueue;
extern Queue generalBlockedQueue;
extern int clockCycle;
extern SchedulerType selectedScheduler;
extern int quantum;
extern int processCount;
extern ProcessMeta processList[MAX_PROCESSES];
extern Mutex userInputMutex, userOutputMutex, fileMutex;
extern Mutex userInputMutexLevels[4];
extern Mutex userOutputMutexLevels[4];
extern Mutex fileMutexLevels[4];
extern Process* getProcessByPID(int pid, Queue* q);
extern Process* runningProcess;
extern Queue unblockedQueue;
extern Process* runningProcess;
extern Process* quantumExpiredLastCycle;

GtkWidget *log_view;
GtkTextBuffer *log_buffer;
GtkWidget *memory_grid;
GtkWidget *output_view;
GtkTextBuffer *output_buffer;
GtkWidget *quantum_entry;
GtkWidget *overview_label;
GtkWidget *process_list_view;
GtkListStore *process_list_store;
GtkWidget *file_chooser;
GtkWidget *arrival_entry;
GtkWidget *priority_entry;
GtkWidget *mutex_status_label;
GtkWidget *auto_exec_button;
GtkWidget *reset_button;
GtkWidget *start_button;
GtkWidget *step_button;
GtkWidget *scheduler_dropdown;
GtkWidget *queue_status_label;

static gboolean is_auto_executing = FALSE;
static gboolean simulation_terminated = FALSE;

const char* getStateString(ProcessState state) {
    switch (state) {
        case NEW: return "New";
        case READY: return "Ready";
        case RUNNING: return "Running";
        case BLOCKED: return "Blocked";
        case TERMINATED: return "Terminated";
        default: return "UNKNOWN";
    }
}

void refresh_overview() {
    char info[200];
    snprintf(info, sizeof(info), "Clock: %d | Processes: %d | Scheduler: %s",
             clockCycle, allProcesses.rear,
             selectedScheduler == FIRST_COME_FIRST_SERVE ? "FCFS" :
             selectedScheduler == ROUND_ROBIN ? "RR" : "MLFQ");
    if (GTK_IS_LABEL(overview_label))
        gtk_label_set_text(GTK_LABEL(overview_label), info);
}

void refresh_memory_display() {
    if (!GTK_IS_GRID(memory_grid)) return;
    gtk_container_foreach(GTK_CONTAINER(memory_grid), (GtkCallback)gtk_widget_destroy, NULL);
    for (int i = 0; i < 60; i++) {
        char label_text[200];
        snprintf(label_text, sizeof(label_text), "%02d - %s: %s", i, memory[i].name, memory[i].value);
        GtkWidget *label = gtk_label_new(label_text);
        gtk_grid_attach(GTK_GRID(memory_grid), label, i % 6, i / 6, 1, 1);
    }
    gtk_widget_show_all(memory_grid);
}

void refresh_process_list() {
    if (!GTK_IS_LIST_STORE(process_list_store)) return;
    gtk_list_store_clear(process_list_store);
    for (int i = allProcesses.front; i < allProcesses.rear; i++) {
        Process *p = allProcesses.items[i];
        GtkTreeIter iter;
        gtk_list_store_append(process_list_store, &iter);
        gtk_list_store_set(process_list_store, &iter,
                           0, p->pcb.pid,
                           1, getStateString(p->pcb.state),
                           2, p->pcb.priority,
                           3, p->pcb.memoryStart,
                           4, p->pcb.memoryEnd,
                           5, p->pcb.pc,
                           -1);
    }
}

void refresh_mutex_status() {
    if (!GTK_IS_LABEL(mutex_status_label)) return;
    char status[300];
    snprintf(status, sizeof(status),
             "Mutex Status\nUserInput: %s\nUserOutput: %s\nFile: %s",
             userInputMutex.isLocked ? "Locked" : "Free",
             userOutputMutex.isLocked ? "Locked" : "Free",
             fileMutex.isLocked ? "Locked" : "Free");
    gtk_label_set_text(GTK_LABEL(mutex_status_label), status);
}

void refresh_queue_display() {
    char buffer[4096] = "";
    if (selectedScheduler == MULTI_LEVEL_FEEDBACK_QUEUE) {
        for (int i = 0; i < LEVELS; i++) {
            char line[1024] = "";
            char temp[256];
            snprintf(temp, sizeof(temp), "Level %d: ", i + 1);
            strncat(line, temp, sizeof(line) - strlen(line) - 1);
            strncat(line, "    ", sizeof(line) - strlen(line) - 1);
            snprintf(temp, sizeof(temp), "Ready Queue: ");
            strncat(line, temp, sizeof(line) - strlen(line) - 1);
            
            // Show running process if it belongs to this level, enclosed in brackets
            if (runningProcess && runningProcess->pcb.priority == i && runningProcess->pcb.state == RUNNING) {
                snprintf(temp, sizeof(temp), "[P%d(%d)] ", runningProcess->pcb.pid, runningProcess->pcb.timeInQueue);
                strncat(line, temp, sizeof(line) - strlen(line) - 1);
            }
            
            // Show all processes in ready queue
            for (int j = readyQueues[i].front; j < readyQueues[i].rear; j++) {
                Process* p = readyQueues[i].items[j];
                snprintf(temp, sizeof(temp), "P%d(%d) ", p->pcb.pid, p->pcb.timeInQueue);
                strncat(line, temp, sizeof(line) - strlen(line) - 1);
            }
            
            if (readyQueues[i].front == readyQueues[i].rear && !(runningProcess && runningProcess->pcb.priority == i && runningProcess->pcb.state == RUNNING)) {
                strncat(line, "Empty", sizeof(line) - strlen(line) - 1);
            }
            
            int current_length = strlen(line);
            for (int k = current_length; k < 50; k++)
                strncat(line, " ", sizeof(line) - strlen(line) - 1);
                
            snprintf(temp, sizeof(temp), "UserInput Blocked: ");
            strncat(line, temp, sizeof(line) - strlen(line) - 1);
            int* blockedArr = userInputMutexLevels[i].blockedQueue;
            int count = userInputMutexLevels[i].blockedCount;
            for (int j = 0; j < count; j++) {
                int pid = blockedArr[j];
                Process* p = getProcessByPID(pid, &allProcesses);
                if (p) {
                    snprintf(temp, sizeof(temp), "P%d(%d) ", pid, p->pcb.timeInQueue);
                    strncat(line, temp, sizeof(line) - strlen(line) - 1);
                }
            }
            if (count == 0)
                strncat(line, "Empty", sizeof(line) - strlen(line) - 1);
                
            current_length = strlen(line);
            for (int k = current_length; k < 100; k++)
                strncat(line, " ", sizeof(line) - strlen(line) - 1);
                
            snprintf(temp, sizeof(temp), "UserOutput Blocked: ");
            strncat(line, temp, sizeof(line) - strlen(line) - 1);
            blockedArr = userOutputMutexLevels[i].blockedQueue;
            count = userOutputMutexLevels[i].blockedCount;
            for (int j = 0; j < count; j++) {
                int pid = blockedArr[j];
                Process* p = getProcessByPID(pid, &allProcesses);
                if (p) {
                    snprintf(temp, sizeof(temp), "P%d(%d) ", pid, p->pcb.timeInQueue);
                    strncat(line, temp, sizeof(line) - strlen(line) - 1);
                }
            }
            if (count == 0)
                strncat(line, "Empty", sizeof(line) - strlen(line) - 1);
                
            current_length = strlen(line);
            for (int k = current_length; k < 150; k++)
                strncat(line, " ", sizeof(line) - strlen(line) - 1);
                
            snprintf(temp, sizeof(temp), "File Blocked: ");
            strncat(line, temp, sizeof(line) - strlen(line) - 1);
            blockedArr = fileMutexLevels[i].blockedQueue;
            count = fileMutexLevels[i].blockedCount;
            for (int j = 0; j < count; j++) {
                int pid = blockedArr[j];
                Process* p = getProcessByPID(pid, &allProcesses);
                if (p) {
                    snprintf(temp, sizeof(temp), "P%d(%d) ", pid, p->pcb.timeInQueue);
                    strncat(line, temp, sizeof(line) - strlen(line) - 1);
                }
            }
            if (count == 0)
                strncat(line, "Empty", sizeof(line) - strlen(line) - 1);
                
            strncat(line, "\n", sizeof(line) - strlen(line) - 1);
            strncat(buffer, line, sizeof(buffer) - strlen(buffer) - 1);
        }
    } else {
        char line[1024] = "";
        char temp[256];
        snprintf(temp, sizeof(temp), "Ready Queue: ");
        strncat(line, temp, sizeof(line) - strlen(line) - 1);
        
        // Check for a running process (for FCFS or Round Robin)
        Process* currentRunning = NULL;
        if (selectedScheduler == ROUND_ROBIN && runningProcess && runningProcess->pcb.state == RUNNING) {
            currentRunning = runningProcess;
        } else if (selectedScheduler == FIRST_COME_FIRST_SERVE) {
            for (int i = allProcesses.front; i < allProcesses.rear; i++) {
                if (allProcesses.items[i]->pcb.state == RUNNING) {
                    currentRunning = allProcesses.items[i];
                    break;
                }
            }
        }
        
        // Show running process in brackets if it exists
        if (currentRunning) {
            if (selectedScheduler == FIRST_COME_FIRST_SERVE) {
                snprintf(temp, sizeof(temp), "[P%d(%d)] ", currentRunning->pcb.pid, clockCycle - currentRunning->pcb.startRunningTime);
            } else {
                snprintf(temp, sizeof(temp), "[P%d(%d)] ", currentRunning->pcb.pid, currentRunning->pcb.timeInQueue);
            }
            strncat(line, temp, sizeof(line) - strlen(line) - 1);
        }
        
        // Show all processes in ready queue
        for (int j = readyQueue.front; j < readyQueue.rear; j++) {
            Process* p = readyQueue.items[j];
            snprintf(temp, sizeof(temp), "P%d(%d) ", p->pcb.pid, p->pcb.timeInQueue);
            strncat(line, temp, sizeof(line) - strlen(line) - 1);
        }
        
        if (readyQueue.front == readyQueue.rear && !currentRunning) {
            strncat(line, "Empty", sizeof(line) - strlen(line) - 1);
        }
        
        strncat(line, "\n", sizeof(line) - strlen(line) - 1);
        
        snprintf(temp, sizeof(temp), "UserInput Blocked Queue: ");
        strncat(line, temp, sizeof(line) - strlen(line) - 1);
        int* blockedArr = userInputMutex.blockedQueue;
        int count = userInputMutex.blockedCount;
        for (int j = 0; j < count; j++) {
            int pid = blockedArr[j];
            Process* p = getProcessByPID(pid, &allProcesses);
            if (p) {
                snprintf(temp, sizeof(temp), "P%d(%d) ", pid, p->pcb.timeInQueue);
                strncat(line, temp, sizeof(line) - strlen(line) - 1);
            }
        }
        if (count == 0)
            strncat(line, "Empty", sizeof(line) - strlen(line) - 1);
            
        strncat(line, "\n", sizeof(line) - strlen(line) - 1);
        
        snprintf(temp, sizeof(temp), "UserOutput Blocked Queue: ");
        strncat(line, temp, sizeof(line) - strlen(line) - 1);
        blockedArr = userOutputMutex.blockedQueue;
        count = userOutputMutex.blockedCount;
        for (int j = 0; j < count; j++) {
            int pid = blockedArr[j];
            Process* p = getProcessByPID(pid, &allProcesses);
            if (p) {
                snprintf(temp, sizeof(temp), "P%d(%d) ", pid, p->pcb.timeInQueue);
                strncat(line, temp, sizeof(line) - strlen(line) - 1);
            }
        }
        if (count == 0)
            strncat(line, "Empty", sizeof(line) - strlen(line) - 1);
            
        strncat(line, "\n", sizeof(line) - strlen(line) - 1);
        
        snprintf(temp, sizeof(temp), "File Blocked Queue: ");
        strncat(line, temp, sizeof(line) - strlen(line) - 1);
        blockedArr = fileMutex.blockedQueue;
        count = fileMutex.blockedCount;
        for (int j = 0; j < count; j++) {
            int pid = blockedArr[j];
            Process* p = getProcessByPID(pid, &allProcesses);
            if (p) {
                snprintf(temp, sizeof(temp), "P%d(%d) ", pid, p->pcb.timeInQueue);
                strncat(line, temp, sizeof(line) - strlen(line) - 1);
            }
        }
        if (count == 0)
            strncat(line, "Empty", sizeof(line) - strlen(line) - 1);
            
        strncat(line, "\n", sizeof(line) - strlen(line) - 1);
        
        snprintf(temp, sizeof(temp), "General Blocked Queue: ");
        strncat(line, temp, sizeof(line) - strlen(line) - 1);
        for (int i = generalBlockedQueue.front; i < generalBlockedQueue.rear; i++) {
            Process* p = generalBlockedQueue.items[i];
            snprintf(temp, sizeof(temp), "P%d(%d) ", p->pcb.pid, p->pcb.timeInQueue);
            strncat(line, temp, sizeof(line) - strlen(line) - 1);
        }
        if (generalBlockedQueue.front == generalBlockedQueue.rear)
            strncat(line, "Empty", sizeof(line) - strlen(line) - 1);
            
        strncat(line, "\n", sizeof(line) - strlen(line) - 1);
        strncat(buffer, line, sizeof(buffer) - strlen(buffer) - 1);
    }
    gtk_label_set_text(GTK_LABEL(queue_status_label), buffer);
}



char* get_input_from_user(const char* variable_name) {
    GtkWidget *dialog = gtk_dialog_new_with_buttons("User Input", NULL, GTK_DIALOG_MODAL, "_OK", GTK_RESPONSE_OK, NULL);
    GtkWidget *content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    GtkWidget *entry = gtk_entry_new();
    char prompt[100];
    snprintf(prompt, sizeof(prompt), "Enter value for %s:", variable_name);
    GtkWidget *label = gtk_label_new(prompt);
    gtk_box_pack_start(GTK_BOX(content_area), label, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(content_area), entry, FALSE, FALSE, 5);
    gtk_widget_show_all(dialog);
    char *result = NULL;
    if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_OK) {
        const gchar *text = gtk_entry_get_text(GTK_ENTRY(entry));
        result = strdup(text && strlen(text) > 0 ? text : "0");
    }
    gtk_widget_destroy(dialog);
    while (gtk_events_pending()) gtk_main_iteration();
    return result;
}

void append_to_log(const char *message) {
    GtkTextIter end;
    gtk_text_buffer_get_end_iter(log_buffer, &end);
    gtk_text_buffer_insert(log_buffer, &end, message, -1);
    gtk_text_buffer_insert(log_buffer, &end, "\n", -1);
    gtk_text_buffer_get_end_iter(log_buffer, &end);
    GtkTextMark *mark = gtk_text_buffer_create_mark(log_buffer, NULL, &end, FALSE);
    gtk_text_view_scroll_to_mark(GTK_TEXT_VIEW(log_view), mark, 0.0, TRUE, 0.0, 1.0);
    gtk_text_buffer_delete_mark(log_buffer, mark);
}

int get_pid_from_filename(const char* filename) {
    if (strstr(filename, "Program_1")) return 1;
    if (strstr(filename, "Program_2")) return 2;
    if (strstr(filename, "Program_3")) return 3;
    return -1;
}

void on_add_process_clicked(GtkButton *button, gpointer user_data) {
    const gchar *filepath = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(file_chooser));
    const gchar *arrival = gtk_entry_get_text(GTK_ENTRY(arrival_entry));
    const gchar *priority = gtk_entry_get_text(GTK_ENTRY(priority_entry));
    if (!filepath || !strlen(filepath) || !strlen(arrival) || !strlen(priority)) {
        append_to_log("Error: Fill all fields before adding process.");
        return;
    }
    ProcessMeta meta;
    meta.pid = get_pid_from_filename(filepath);
    meta.arrivalTime = atoi(arrival);
    meta.priority = atoi(priority);
    strncpy(meta.filePath, filepath, sizeof(meta.filePath));
    meta.created = 0;
    processList[processCount++] = meta;
    char log_msg[300];
    snprintf(log_msg, sizeof(log_msg), "Process added: %s | Arrival: %d | Priority: %d",
             filepath, meta.arrivalTime, meta.priority);
    append_to_log(log_msg);
}

void log_to_gui_and_console(const char *format, ...) {
    char buffer[512];
    va_list args;
    va_start(args, format);
    vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);
    printf("%s\n", buffer);
    append_to_log(buffer);
}

int compare_arrival(const void* a, const void* b) {
    const ProcessMeta* p1 = (const ProcessMeta*)a;
    const ProcessMeta* p2 = (const ProcessMeta*)b;
    return p1->arrivalTime - p2->arrivalTime;
}

void simulate_one_cycle() {
    static int sorted = 0;
    if (simulation_terminated) {
        append_to_log("Simulation has already terminated. Reset to start a new simulation.");
        return;
    }

    // Sort processes once before starting
    if (!sorted) {
        qsort(processList, processCount, sizeof(ProcessMeta), compare_arrival);
        sorted = 1;
    }

    // Parse quantum input if using Round Robin
    if (selectedScheduler == ROUND_ROBIN) {
        const gchar *quantum_text = gtk_entry_get_text(GTK_ENTRY(quantum_entry));
        quantum = atoi(quantum_text);
        if (quantum <= 0) {
            log_to_gui_and_console("⚠️ Invalid or zero quantum. Round Robin skipped.");
            return;
        }
    }

    // Increment timeInQueue for processes in READY and BLOCKED queues
    for (int i = readyQueue.front; i < readyQueue.rear; i++)
        readyQueue.items[i]->pcb.timeInQueue++;

    for (int i = 0; i < LEVELS; i++)
        for (int j = readyQueues[i].front; j < readyQueues[i].rear; j++)
            readyQueues[i].items[j]->pcb.timeInQueue++;

            for (int i = generalBlockedQueue.front; i < generalBlockedQueue.rear; i++) {
                Process* p = generalBlockedQueue.items[i];
                if (!p->wasJustUnblocked)  // ✅ Skip incrementing ghosted ones
                    p->pcb.timeInQueue++;
            }


    for (int level = 0; level < LEVELS; level++) {
        for (int i = 0; i < userInputMutexLevels[level].blockedCount; i++) {
            Process* p = getProcessByPID(userInputMutexLevels[level].blockedQueue[i], &allProcesses);
            if (p) p->pcb.timeInQueue++;
        }
        for (int i = 0; i < userOutputMutexLevels[level].blockedCount; i++) {
            Process* p = getProcessByPID(userOutputMutexLevels[level].blockedQueue[i], &allProcesses);
            if (p) p->pcb.timeInQueue++;
        }
        for (int i = 0; i < fileMutexLevels[level].blockedCount; i++) {
            Process* p = getProcessByPID(fileMutexLevels[level].blockedQueue[i], &allProcesses);
            if (p) p->pcb.timeInQueue++;
        }
    }

    // ✅ Add time to currently running process in FCFS or RR
    if (selectedScheduler == FIRST_COME_FIRST_SERVE || selectedScheduler == ROUND_ROBIN) {
        for (int i = allProcesses.front; i < allProcesses.rear; i++) {
            Process* p = allProcesses.items[i];
            if (p->pcb.state == RUNNING) {
                p->pcb.timeInQueue++;
                break;
            }
        }
    }

    // ✅ Show snapshot of queues BEFORE scheduler runs

    // ✅ Check new arrivals
    checkAndCreateArrivingProcesses(clockCycle);

    // ✅ Run one scheduler tick
    if (selectedScheduler == ROUND_ROBIN && quantum > 0)
        RoundRobin();
    else if (selectedScheduler == MULTI_LEVEL_FEEDBACK_QUEUE)
        MLFQ();
    else
        FCFS();

    // ✅ Update GUI views
    refresh_overview();
    refresh_memory_display();
    refresh_process_list();
    refresh_mutex_status();
    refresh_queue_display();

    // ✅ Log cycle done
    char msg[100];
    snprintf(msg, sizeof(msg), "🕒 Clock Cycle %d completed.", clockCycle);
    log_to_gui_and_console("%s", msg);

    // ✅ Advance clock
    clockCycle++;

    // ✅ Check for global termination
    int allTerminated = 1;
    for (int i = allProcesses.front; i < allProcesses.rear; i++) {
        Process *p = allProcesses.items[i];
        if (p->pcb.state != TERMINATED) {
            allTerminated = 0;
            break;
        }
    }

    if (allTerminated && allProcesses.rear > allProcesses.front)  {
        log_to_gui_and_console("✅ All processes have terminated. Simulation halted.");
        log_to_gui_and_console("=== Final Process Summary ===");
        for (int i = allProcesses.front; i < allProcesses.rear; i++) {
            Process *p = allProcesses.items[i];
            log_to_gui_and_console("Process %d - Final State: %s", p->pcb.pid, getStateString(p->pcb.state));
        }
        is_auto_executing = FALSE;
        gtk_button_set_label(GTK_BUTTON(auto_exec_button), "Auto");
        simulation_terminated = TRUE;
        gtk_widget_set_sensitive(step_button, FALSE);
        gtk_widget_set_sensitive(auto_exec_button, FALSE);
    }
}


void on_step_clicked(GtkButton *button, gpointer user_data) {
    if (!simulation_terminated)
        simulate_one_cycle();
}

void on_auto_exec_clicked(GtkButton *button, gpointer user_data) {
    if (simulation_terminated) {
        append_to_log("Simulation has already terminated. Reset to start a new simulation.");
        return;
    }
    is_auto_executing = !is_auto_executing;
    if (is_auto_executing) {
        gtk_button_set_label(GTK_BUTTON(auto_exec_button), "Stop Auto");
        while (is_auto_executing) {
            simulate_one_cycle();
            while (gtk_events_pending()) gtk_main_iteration();
            usleep(500000);
        }
    } else {
        gtk_button_set_label(GTK_BUTTON(auto_exec_button), "Auto");
    }
}

void on_reset_clicked(GtkButton *button, gpointer user_data) {
    processCount = 0;
    clockCycle = 0;
    initQueue(&allProcesses);
    initQueue(&readyQueue);
    initQueue(&blockedQueue);
    initQueue(&unblockedQueue);
    initQueue(&generalBlockedQueue);
    for (int i = 0; i < LEVELS; i++) {
        initQueue(&readyQueues[i]);
        userInputMutexLevels[i].blockedCount = 0;
        userOutputMutexLevels[i].blockedCount = 0;
        fileMutexLevels[i].blockedCount = 0;
    }
    userInputMutex.blockedCount = 0;
    userOutputMutex.blockedCount = 0;
    fileMutex.blockedCount = 0;
    userInputMutex.isLocked = 0;
    userOutputMutex.isLocked = 0;
    fileMutex.isLocked = 0;
    initializeMemory();
    gtk_list_store_clear(process_list_store);
    gtk_text_buffer_set_text(output_buffer, "", -1);
    refresh_overview();
    refresh_memory_display();
    refresh_mutex_status();
    refresh_queue_display();
    append_to_log("Simulation reset.");
    simulation_terminated = FALSE;
    gtk_widget_set_sensitive(step_button, TRUE);
    gtk_widget_set_sensitive(auto_exec_button, TRUE);
}

void on_scheduler_changed(GtkComboBoxText *combo, gpointer user_data) {
    const gchar *selected = gtk_combo_box_text_get_active_text(combo);
    if (strcmp(selected, "FCFS") == 0) {
        selectedScheduler = FIRST_COME_FIRST_SERVE;
        gtk_widget_set_sensitive(quantum_entry, FALSE);
    } else if (strcmp(selected, "Round Robin") == 0) {
        selectedScheduler = ROUND_ROBIN;
        gtk_widget_set_sensitive(quantum_entry, TRUE);
    } else if (strcmp(selected, "MLFQ") == 0) {
        selectedScheduler = MULTI_LEVEL_FEEDBACK_QUEUE;
        gtk_widget_set_sensitive(quantum_entry, FALSE);
    }
    refresh_overview();
    refresh_queue_display();
}

void setup_controls(GtkWidget *container) {
    GtkWidget *control_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    file_chooser = gtk_file_chooser_button_new("Select a Program", GTK_FILE_CHOOSER_ACTION_OPEN);
    gtk_box_pack_start(GTK_BOX(control_box), file_chooser, FALSE, FALSE, 5);
    arrival_entry = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(arrival_entry), "Arrival Time");
    gtk_box_pack_start(GTK_BOX(control_box), arrival_entry, FALSE, FALSE, 5);
    priority_entry = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(priority_entry), "Priority");
    gtk_box_pack_start(GTK_BOX(control_box), priority_entry, FALSE, FALSE, 5);
    GtkWidget *add_button = gtk_button_new_with_label("Add Process");
    g_signal_connect(add_button, "clicked", G_CALLBACK(on_add_process_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(control_box), add_button, FALSE, FALSE, 5);
    step_button = gtk_button_new_with_label("Step");
    g_signal_connect(step_button, "clicked", G_CALLBACK(on_step_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(control_box), step_button, FALSE, FALSE, 5);
    auto_exec_button = gtk_button_new_with_label("Auto");
    g_signal_connect(auto_exec_button, "clicked", G_CALLBACK(on_auto_exec_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(control_box), auto_exec_button, FALSE, FALSE, 5);
    reset_button = gtk_button_new_with_label("Reset");
    g_signal_connect(reset_button, "clicked", G_CALLBACK(on_reset_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(control_box), reset_button, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(container), control_box, FALSE, FALSE, 5);
}

void setup_main_layout(GtkWidget *container) {
    overview_label = gtk_label_new("System Overview");
    gtk_box_pack_start(GTK_BOX(container), overview_label, FALSE, FALSE, 5);
    GtkWidget *sched_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    scheduler_dropdown = gtk_combo_box_text_new();
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(scheduler_dropdown), "FCFS");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(scheduler_dropdown), "Round Robin");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(scheduler_dropdown), "MLFQ");
    gtk_combo_box_set_active(GTK_COMBO_BOX(scheduler_dropdown), 0);
    g_signal_connect(scheduler_dropdown, "changed", G_CALLBACK(on_scheduler_changed), NULL);
    gtk_box_pack_start(GTK_BOX(sched_box), scheduler_dropdown, FALSE, FALSE, 5);
    quantum_entry = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(quantum_entry), "Quantum");
    gtk_widget_set_sensitive(quantum_entry, FALSE);
    gtk_box_pack_start(GTK_BOX(sched_box), quantum_entry, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(container), sched_box, FALSE, FALSE, 5);
    mutex_status_label = gtk_label_new("Mutex Status\nUserInput: --\nUserOutput: --\nFile: --");
    gtk_box_pack_start(GTK_BOX(container), mutex_status_label, FALSE, FALSE, 5);
    queue_status_label = gtk_label_new("");
    gtk_label_set_xalign(GTK_LABEL(queue_status_label), 0.0);
    GtkWidget *queue_scroll = gtk_scrolled_window_new(NULL, NULL);
    gtk_container_add(GTK_CONTAINER(queue_scroll), queue_status_label);
    gtk_widget_set_size_request(queue_scroll, 800, 100);
    gtk_box_pack_start(GTK_BOX(container), queue_scroll, FALSE, FALSE, 5);
    memory_grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(memory_grid), 2);
    gtk_grid_set_column_spacing(GTK_GRID(memory_grid), 10);
    gtk_box_pack_start(GTK_BOX(container), memory_grid, FALSE, FALSE, 5);
    process_list_store = gtk_list_store_new(6, G_TYPE_INT, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);
    process_list_view = gtk_tree_view_new_with_model(GTK_TREE_MODEL(process_list_store));
    const char *columns[] = {"PID", "State", "Priority", "Start", "End", "PC"};
    for (int i = 0; i < 6; i++) {
        GtkCellRenderer *renderer = gtk_cell_renderer_text_new();
        GtkTreeViewColumn *col = gtk_tree_view_column_new_with_attributes(columns[i], renderer, "text", i, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(process_list_view), col);
    }
    GtkWidget *process_scroll = gtk_scrolled_window_new(NULL, NULL);
    gtk_container_add(GTK_CONTAINER(process_scroll), process_list_view);
    gtk_widget_set_size_request(process_scroll, 800, 100);
    gtk_box_pack_start(GTK_BOX(container), process_scroll, FALSE, FALSE, 5);
    output_view = gtk_text_view_new();
    gtk_text_view_set_editable(GTK_TEXT_VIEW(output_view), FALSE);
    output_buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(output_view));
    log_view = output_view;
    log_buffer = output_buffer;
    GtkWidget *log_scroll = gtk_scrolled_window_new(NULL, NULL);
    gtk_container_add(GTK_CONTAINER(log_scroll), output_view);
    gtk_widget_set_size_request(log_scroll, 800, 200);
    gtk_box_pack_start(GTK_BOX(container), log_scroll, FALSE, FALSE, 5);
}

void on_app_activate(GtkApplication *app, gpointer user_data) {
    GtkWidget *window = gtk_application_window_new(app);
    gtk_window_set_title(GTK_WINDOW(window), "Scheduler Simulation GUI");
    gtk_window_set_default_size(GTK_WINDOW(window), 1000, 800);
    GtkWidget *main_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_container_add(GTK_CONTAINER(window), main_box);
    setup_controls(main_box);
    setup_main_layout(main_box);
    gtk_widget_show_all(window);
}

int main(int argc, char *argv[]) {
    GtkApplication *app = gtk_application_new("com.scheduler.gui", G_APPLICATION_DEFAULT_FLAGS);
    g_signal_connect(app, "activate", G_CALLBACK(on_app_activate), NULL);
    int status = g_application_run(G_APPLICATION(app), argc, argv);
    g_object_unref(app);
    return status;
}