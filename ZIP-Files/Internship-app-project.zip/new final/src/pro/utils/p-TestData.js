export const initializeTestData = () => {
  // Add test internships data
  const testInternships = [
    {
      id: 1,
      companyName: "Tech Corp",
      jobTitle: "Software Engineer Intern",
      status: "completed",
      startDate: "2024-01-01",
      endDate: "2024-02-01",  // 1 month
    },
    {
      id: 2,
      companyName: "Digital Solutions",
      jobTitle: "Frontend Developer Intern",
      status: "completed",
      startDate: "2024-02-02",
      endDate: "2024-04-02",  // 2 months
    },
    {
      id: 3,
      companyName: "Innovation Labs",
      jobTitle: "Full Stack Developer Intern",
      status: "completed",
      startDate: "2024-04-03",
      endDate: "2024-05-03",  // 1 month
    }
  ];

  // Store the test data in localStorage
  localStorage.setItem('internships', JSON.stringify(testInternships));
  
  // Reset PRO status to ensure dialog shows each time
  localStorage.removeItem('proStatus');
}; 