// This would normally be handled by the backend
// For now, we'll use localStorage to simulate the functionality

export const checkProEligibility = () => {
  const internships = JSON.parse(localStorage.getItem('internships') || '[]');
  
  // Calculate total internship duration in months
  const totalDuration = internships.reduce((total, internship) => {
    if (internship.status === 'completed') {
      const startDate = new Date(internship.startDate);
      const endDate = new Date(internship.endDate);
      const months = (endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24 * 30);
      return total + months;
    }
    return total;
  }, 0);

  return totalDuration >= 3;
};

export const getProStatus = () => {
  return localStorage.getItem('proStatus') === 'true';
};

export const setProStatus = (status) => {
  localStorage.setItem('proStatus', status);
};

// Check and update PRO status
export const updateProStatus = () => {
  const isEligible = checkProEligibility();
  if (isEligible) {
    setProStatus(true);
    return true;
  }
  setProStatus(false);
  return false;
}; 