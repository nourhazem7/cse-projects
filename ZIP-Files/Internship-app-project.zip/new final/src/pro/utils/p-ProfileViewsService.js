import { getProStatus } from './p-ProStatusService';

// Mock API delay
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Mock data - in a real app, this would come from an API
const mockProfileViews = [
  {
    id: 1,
    companyName: 'Tech Innovations Inc.',
    companyLogo: 'https://via.placeholder.com/40',
    industry: 'Technology',
    viewDate: '2024-04-15T10:30:00Z',
    viewCount: 5,
    jobsAvailable: 3,
    isBookmarked: false,
  },
  // ... (rest of the mock data from the component)
];

// Analytics data
const mockAnalytics = {
  totalViews: 19,
  uniqueCompanies: 5,
  mostActiveIndustry: 'Technology',
  averageViewsPerCompany: 3.8,
  weeklyChange: 15,
};

export const getProfileViews = async (page = 1, pageSize = 10, sortBy = 'viewDate', sortOrder = 'desc') => {
  // Verify PRO status
  if (!getProStatus()) {
    throw new Error('PRO status required to access profile views');
  }

  // Simulate API delay
  await delay(1000);

  // Sort the data
  const sortedData = [...mockProfileViews].sort((a, b) => {
    const aValue = a[sortBy];
    const bValue = b[sortBy];
    
    if (sortOrder === 'asc') {
      return aValue > bValue ? 1 : -1;
    }
    return aValue < bValue ? 1 : -1;
  });

  // Calculate pagination
  const startIndex = (page - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const paginatedData = sortedData.slice(startIndex, endIndex);

  return {
    data: paginatedData,
    total: mockProfileViews.length,
    page,
    pageSize,
    totalPages: Math.ceil(mockProfileViews.length / pageSize),
  };
};

export const getProfileViewsAnalytics = async () => {
  // Verify PRO status
  if (!getProStatus()) {
    throw new Error('PRO status required to access profile views analytics');
  }

  // Simulate API delay
  await delay(800);

  return mockAnalytics;
};

export const toggleBookmark = async (viewId) => {
  // Verify PRO status
  if (!getProStatus()) {
    throw new Error('PRO status required to bookmark companies');
  }

  // Simulate API delay
  await delay(500);

  // Find and update the bookmark status
  const viewIndex = mockProfileViews.findIndex(view => view.id === viewId);
  if (viewIndex === -1) {
    throw new Error('Profile view not found');
  }

  mockProfileViews[viewIndex].isBookmarked = !mockProfileViews[viewIndex].isBookmarked;
  return mockProfileViews[viewIndex];
}; 