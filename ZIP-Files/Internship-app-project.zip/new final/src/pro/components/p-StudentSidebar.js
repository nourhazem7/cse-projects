import React from 'react';
import {
  Box,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Drawer,
  Typography,
  ListSubheader,
  Toolbar,
} from '@mui/material';
import {
  Dashboard as DashboardIcon,
  School as SchoolIcon,
  Work as WorkIcon,
  Business as BusinessIcon,
  Assignment as AssignmentIcon,
  CheckCircle as CheckCircleIcon,
  ManageAccounts as ManageAccountsIcon,
  Download as DownloadIcon,
  Person as PersonIcon,
  Assessment as AssessmentIcon,
  AccessTime as AccessTimeIcon,
  PlayCircleOutline as PlayCircleOutlineIcon,
  Description as DescriptionIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

const navyBlue = '#0A1929';
const lightNavyBlue = '#1A2B3C';

const StudentSidebar = ({ open }) => {
  const navigate = useNavigate();

  const menuItems = [
    {
      type: 'section',
      items: [
        { text: 'Dashboard', icon: <DashboardIcon />, path: '/pro/dashboard' }
      ]
    },
    {
      type: 'section',
      title: 'Find Internships',
      items: [
        { text: 'Browse All Internships', icon: <WorkIcon />, path: '/pro/internships' },
        { text: 'Suggested Companies', icon: <BusinessIcon />, path: '/pro/suggested-companies' },
        { text: 'Internship Management', icon: <ManageAccountsIcon />, path: '/pro/internship-management' },
        { text: 'Requirements Videos', icon: <PlayCircleOutlineIcon />, path: '/pro/internship-requirements' },
      ]
    },
    {
      type: 'section',
      title: 'My Applications',
      items: [
        { text: 'Application Status', icon: <AssignmentIcon />, path: '/pro/application-status' },
        { text: 'Past Applications', icon: <CheckCircleIcon />, path: '/pro/past-applications' },
      ]
    },
    {
      type: 'section',
      title: 'Reports',
      items: [
        { text: 'SCAD Reports', icon: <DescriptionIcon />, path: '/pro/scad-reports' },
        { text: 'Download Files', icon: <DownloadIcon />, path: '/pro/downloads' },
      ]
    },
    {
      type: 'section',
      title: 'PRO Features',
      items: [
        { text: 'Request Appointment', icon: <AccessTimeIcon />, path: '/pro/request-appointment' },
        { text: 'Profile Views & Assessments', icon: <PersonIcon />, path: '/pro/profile-views' },
        { text: 'Workshops', icon: <WorkIcon />, path: '/pro/workshops' },
      ]
    }
  ];

  return (
    <Drawer
      variant="permanent"
      sx={{
        width: open ? 240 : 70,
        transition: 'width 0.3s',
        '& .MuiDrawer-paper': {
          width: open ? 240 : 70,
          transition: 'width 0.3s',
          backgroundColor: navyBlue,
          color: 'white',
          overflowX: 'hidden',
          height: '100vh',
          overflowY: 'auto',
        },
      }}
    >
      <Toolbar sx={{ 
        bgcolor: lightNavyBlue, 
        display: 'flex', 
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '64px !important',
        borderBottom: '1px solid rgba(255, 255, 255, 0.12)'
      }}>
        <Box sx={{ 
          display: 'flex', 
          flexDirection: 'column', 
          alignItems: 'center',
          opacity: open ? 1 : 0,
          transition: 'opacity 0.3s'
        }}>
          <Typography variant="h6" sx={{ 
            fontWeight: 'bold',
            letterSpacing: '0.5px',
            fontSize: '1.2rem',
            color: '#fff'
          }}>
            GUC SYSTEM
          </Typography>
          <Typography variant="subtitle2" sx={{ 
            color: 'rgba(255, 255, 255, 0.7)',
            fontSize: '0.75rem',
            marginTop: '4px'
          }}>
            Student Portal
          </Typography>
        </Box>
      </Toolbar>

      <List>
        {menuItems.map((section, sectionIndex) => (
          <React.Fragment key={section.title || sectionIndex}>
            {section.title && open && (
              <ListSubheader
                sx={{
                  bgcolor: 'transparent',
                  color: 'rgba(255, 255, 255, 0.7)',
                  lineHeight: '30px',
                  mt: sectionIndex === 0 ? 0 : 2,
                }}
              >
                {section.title}
              </ListSubheader>
            )}
            {section.items.map((item) => (
              <ListItem
                button
                key={item.text}
                onClick={() => navigate(item.path)}
                sx={{
                  '&:hover': {
                    bgcolor: lightNavyBlue,
                  },
                  px: open ? 2 : 1.5,
                  justifyContent: open ? 'initial' : 'center',
                  minHeight: 48,
                }}
              >
                <ListItemIcon 
                  sx={{ 
                    color: 'white', 
                    minWidth: open ? 40 : 'auto',
                    mr: open ? 2 : 'auto',
                  }}
                >
                  {item.icon}
                </ListItemIcon>
                {open && <ListItemText primary={item.text} />}
              </ListItem>
            ))}
          </React.Fragment>
        ))}
      </List>
    </Drawer>
  );
};

export default StudentSidebar;