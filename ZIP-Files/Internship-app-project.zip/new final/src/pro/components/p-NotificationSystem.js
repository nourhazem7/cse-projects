import React, { useState, useEffect } from 'react';
import { 
    Box,
    Typography,
    IconButton,
    List,
    ListItem,
    ListItemText,
    ListItemIcon,
    Button,
    Badge,
    Snackbar,
    Alert,
    Menu
} from '@mui/material';
import { 
    Work as WorkIcon,
    NotificationsActive as NotificationIcon,
    Event as EventIcon,
    Description as DescriptionIcon,
    Notifications as BellIcon,
    Close as CloseIcon
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

const NotificationSystem = () => {
    const [notifications, setNotifications] = useState([]);
    const [anchorEl, setAnchorEl] = useState(null);
    const [showCycleNotification, setShowCycleNotification] = useState(true);
    const navigate = useNavigate();

    // Calculate unread count
    const unreadCount = notifications.filter(notification => !notification.read).length;

    useEffect(() => {
        // Initial notifications including the cycle notification
        const initialNotifications = [
            {
                id: 5,
                title: "SCAD Report Status Update",
                message: "Your SCAD report for Tech Corp has been approved. Click to view details.",
                type: "report",
                icon: <DescriptionIcon sx={{ color: '#4caf50' }} />,
                timestamp: "Just now",
                read: false
            },
            {
                id: 4,
                title: "Internship Cycle Update",
                message: "The next internship cycle will begin in 2 weeks",
                type: "warning",
                icon: <NotificationIcon sx={{ color: '#ff9800' }} />,
                timestamp: "30 minutes ago",
                read: false
            },
            {
                id: 1,
                title: "New Internship Opportunity",
                message: "A new internship position has been posted in your field.",
                type: "opportunity",
                icon: <WorkIcon sx={{ color: '#4caf50' }} />,
                timestamp: "2 hours ago",
                read: false
            },
            {
                id: 2,
                title: "Application Status Update",
                message: "Your application for Company XYZ has been reviewed.",
                type: "status",
                icon: <DescriptionIcon sx={{ color: '#2196f3' }} />,
                timestamp: "1 day ago",
                read: false
            },
            {
                id: 3,
                title: "Deadline Reminder",
                message: "The application deadline for ABC Corp internship is tomorrow.",
                type: "deadline",
                icon: <EventIcon sx={{ color: '#f44336' }} />,
                timestamp: "3 days ago",
                read: false
            },
            {
                id: 6,
                title: "Upcoming Workshop Reminder",
                message: "You have an upcoming workshop: 'Ace Your Online Interview' on 2024-07-10 at 16:00.",
                type: "workshop",
                icon: <EventIcon sx={{ color: '#1976d2' }} />, 
                timestamp: "Just now",
                read: false
            }
        ];

        setNotifications(initialNotifications);
    }, []);

    const handleNotificationClick = (notification) => {
        // Mark the notification as read without closing the menu
        setNotifications(prevNotifications =>
            prevNotifications.map(n =>
                n.id === notification.id ? { ...n, read: true } : n
            )
        );

        // Navigate based on type
        switch (notification.type) {
            case 'opportunity':
                navigate('/pro/internships');
                break;
            case 'status':
                navigate('/pro/application-status');
                break;
            case 'deadline':
                navigate('/pro/internships');
                break;
            case 'report':
                navigate('/pro/scad-reports');
                break;
            default:
                navigate('/pro/dashboard');
        }
    };

    const handleDeleteAll = () => {
        setNotifications([]); // Delete all notifications
        setShowCycleNotification(false);
        handleClose();
    };

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    const handleCycleNotificationClose = () => {
        setShowCycleNotification(false);
        // Mark the cycle notification as read when closed
        setNotifications(prevNotifications =>
            prevNotifications.map(n =>
                n.id === 4 ? { ...n, read: true } : n
            )
        );
    };

    return (
        <>
            {/* Bell Icon */}
            <IconButton 
                onClick={handleClick}
                sx={{ color: 'white' }}
                size="large"
            >
                <Badge badgeContent={unreadCount} color="error">
                    <BellIcon />
                </Badge>
            </IconButton>

            {/* Notification Menu */}
            <Menu
                anchorEl={anchorEl}
                open={Boolean(anchorEl)}
                onClose={handleClose}
                PaperProps={{
                    sx: {
                        width: '400px',
                        maxHeight: '500px',
                        backgroundColor: '#1e2a38',
                        color: 'white',
                    }
                }}
                transformOrigin={{ horizontal: 'right', vertical: 'top' }}
                anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
            >
                <Box sx={{ p: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Typography variant="h6">Notifications</Typography>
                    {notifications.length > 0 && (
                        <Button 
                            color="error"
                            onClick={handleDeleteAll}
                            sx={{ 
                                textTransform: 'none',
                                '&:hover': {
                                    backgroundColor: 'rgba(211, 47, 47, 0.1)'
                                }
                            }}
                        >
                            Delete all
                        </Button>
                    )}
                </Box>
                <List sx={{ maxHeight: '400px', overflow: 'auto' }}>
                    {notifications.length === 0 ? (
                        <ListItem>
                            <ListItemText 
                                primary={
                                    <Typography sx={{ color: 'rgba(255,255,255,0.7)' }}>
                                        No notifications
                                    </Typography>
                                }
                            />
                        </ListItem>
                    ) : (
                        notifications.map((notification) => (
                            <ListItem
                                key={notification.id}
                                button
                                onClick={() => handleNotificationClick(notification)}
                                sx={{
                                    borderBottom: '1px solid rgba(255,255,255,0.1)',
                                    bgcolor: notification.read ? 'transparent' : 'rgba(255, 255, 255, 0.08)',
                                    '&:hover': {
                                        backgroundColor: 'rgba(255,255,255,0.1)'
                                    }
                                }}
                            >
                                <ListItemIcon>
                                    {notification.icon}
                                </ListItemIcon>
                                <ListItemText
                                    primary={
                                        <Typography
                                            sx={{
                                                fontWeight: notification.read ? 'normal' : 'bold',
                                                color: 'white'
                                            }}
                                        >
                                            {notification.title}
                                        </Typography>
                                    }
                                    secondary={
                                        <React.Fragment>
                                            <Typography
                                                component="span"
                                                variant="body2"
                                                sx={{ color: 'rgba(255,255,255,0.7)' }}
                                            >
                                                {notification.message}
                                            </Typography>
                                            <br />
                                            <Typography
                                                component="span"
                                                variant="caption"
                                                sx={{ color: 'rgba(255,255,255,0.5)' }}
                                            >
                                                {notification.timestamp}
                                            </Typography>
                                        </React.Fragment>
                                    }
                                />
                            </ListItem>
                        ))
                    )}
                </List>
            </Menu>

            {/* Internship Cycle Pop-out Notification */}
            <Snackbar
                open={showCycleNotification}
                anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
            >
                <Alert
                    severity="warning"
                    sx={{ width: '100%' }}
                    action={
                        <IconButton
                            size="small"
                            color="inherit"
                            onClick={handleCycleNotificationClose}
                        >
                            <CloseIcon fontSize="small" />
                        </IconButton>
                    }
                >
                    The next internship cycle will begin in 2 weeks
                </Alert>
            </Snackbar>
        </>
    );
};

export default NotificationSystem; 