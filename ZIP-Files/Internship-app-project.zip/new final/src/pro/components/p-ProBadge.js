import React from 'react';
import { Chip, Tooltip } from '@mui/material';
import WorkspacePremiumIcon from '@mui/icons-material/WorkspacePremium';

const ProBadge = ({ size = 'medium' }) => {
  return (
    <Tooltip title="PRO Student - Completed 3 months of internships">
      <Chip
        icon={<WorkspacePremiumIcon />}
        label="PRO"
        color="primary"
        size={size}
        sx={{
          backgroundColor: '#0A1929',
          color: '#fff',
          '& .MuiChip-icon': {
            color: '#FFD700', // Gold color for the icon
          },
          fontWeight: 'bold',
          border: '2px solid #FFD700',
        }}
      />
    </Tooltip>
  );
};

export default ProBadge; 