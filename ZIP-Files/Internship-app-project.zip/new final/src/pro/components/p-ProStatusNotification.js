import React from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Box,
} from '@mui/material';
import WorkspacePremiumIcon from '@mui/icons-material/WorkspacePremium';

const ProStatusNotification = ({ open, onClose }) => {
  return (
    <Dialog 
      open={open} 
      onClose={onClose} 
      maxWidth="sm" 
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 2,
          overflow: 'hidden'
        }
      }}
    >
      <DialogTitle 
        sx={{ 
          textAlign: 'center', 
          bgcolor: '#0A1929', 
          color: 'white',
          py: 3
        }}
      >
        <Typography variant="h4" component="div">
          Congratulations! 🎉
        </Typography>
      </DialogTitle>
      <DialogContent>
        <Box sx={{ textAlign: 'center', py: 4 }}>
          <WorkspacePremiumIcon 
            sx={{ 
              fontSize: 80, 
              color: '#FFD700', 
              mb: 3 
            }} 
          />
          <Typography variant="h5" gutterBottom>
            You've Achieved PRO Status!
          </Typography>
          <Typography color="text.secondary" sx={{ mb: 3 }}>
            You have successfully completed 3 months of internships and unlocked PRO features:
          </Typography>
          <Box sx={{ 
            mt: 2, 
            textAlign: 'left', 
            pl: 2,
            bgcolor: '#f5f5f5',
            p: 2,
            borderRadius: 2
          }}>
            <Typography component="ul" sx={{ listStyleType: 'none', m: 0, p: 0 }}>
              {[
                'View companies that viewed your profile',
                'Request career guidance calls',
                'Access to online self-assessment tests',
                'Access to career development workshops'
              ].map((feature, index) => (
                <Typography 
                  component="li" 
                  key={index}
                  sx={{ 
                    py: 1,
                    display: 'flex',
                    alignItems: 'center',
                    '&:before': {
                      content: '"✓"',
                      color: '#4CAF50',
                      fontWeight: 'bold',
                      marginRight: 2
                    }
                  }}
                >
                  {feature}
                </Typography>
              ))}
            </Typography>
          </Box>
        </Box>
      </DialogContent>
      <DialogActions sx={{ justifyContent: 'center', pb: 4 }}>
        <Button 
          variant="contained" 
          onClick={onClose}
          sx={{ 
            bgcolor: '#0A1929',
            px: 4,
            py: 1,
            '&:hover': {
              bgcolor: '#1A2B3C'
            }
          }}
        >
          Explore PRO Features
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ProStatusNotification; 