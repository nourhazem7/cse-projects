/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from 'react';
import {
  AppBar,
  Box,
  Drawer,
  IconButton,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Typography,
  Menu,
  MenuItem,
  Avatar,
  Badge,
  Divider,
  ListSubheader,
  Chip,
  TextField,
  Button,
  Paper,
} from '@mui/material';
import DashboardIcon from '@mui/icons-material/Dashboard';
import WorkIcon from '@mui/icons-material/Work';
import PersonIcon from '@mui/icons-material/Person';
import SchoolIcon from '@mui/icons-material/School';
import LogoutIcon from '@mui/icons-material/Logout';
import EmailIcon from '@mui/icons-material/Email';
import MenuIcon from '@mui/icons-material/Menu';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import BusinessIcon from '@mui/icons-material/Business';
import NewReleasesIcon from '@mui/icons-material/NewReleases';
import DescriptionIcon from '@mui/icons-material/Description';
import WorkHistoryIcon from '@mui/icons-material/WorkHistory';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import PendingIcon from '@mui/icons-material/Pending';
import DownloadIcon from '@mui/icons-material/Download';
import AssessmentIcon from '@mui/icons-material/Assessment';
import PlayCircleOutlineIcon from '@mui/icons-material/PlayCircleOutline';
import NotificationsIcon from '@mui/icons-material/Notifications';
import VideoCallIcon from '@mui/icons-material/VideoCall';
import NoteIcon from '@mui/icons-material/Note';
import WorkspacePremiumIcon from '@mui/icons-material/WorkspacePremium';
import { useNavigate, Outlet } from 'react-router-dom';

// Pro Components
import NotificationSystem from './p-NotificationSystem';
import ProBadge from './p-ProBadge';
import ProStudentSidebar from './p-StudentSidebar';

// Pro Utils
import { getProStatus } from '../utils/p-ProStatusService';

const drawerWidth = 240;
const navyBlue = '#0A1929';
const lightNavyBlue = '#1A2B3C';

// Updated dummy notifications
const initialNotifications = [
  {
    id: 101,
    title: 'Upcoming Internship Deadline',
    message: 'Application for Tech Corp closes tomorrow.',
    read: false,
    time: '2 hours ago',
    type: 'deadline'
  },
  {
    id: 102,
    title: 'Evaluation Complete',
    message: 'Your internship performance evaluation is available.',
    read: false,
    time: '1 day ago',
    type: 'evaluation'
  },
  {
    id: 103,
    title: 'SCAD Office Hours',
    message: 'New office hours posted for next week.',
    read: false,
    time: '2 days ago',
    type: 'announcement'
  },
  {
    id: 104,
    title: 'Appointment Accepted',
    message: 'SCAD Officer has accepted your appointment request for career guidance.',
    read: false,
    time: '30 minutes ago',
    type: 'appointment'
  },
  {
    id: 105,
    title: 'Internship Report Reminder',
    message: 'Final report due in 5 days.',
    read: true,
    time: '3 days ago',
    type: 'reminder'
  },
  {
    id: 106,
    title: 'Upcoming Workshop Reminder',
    message: "You have an upcoming workshop: 'Ace Your Online Interview' on 2024-07-10 at 16:00.",
    read: false,
    time: 'Just now',
    type: 'announcement'
  }
];

// Updated dummy email notifications with types
const initialEmails = [
  {
    id: 1,
    title: 'Interview Invitation',
    message: 'You have been invited for an interview at Tech Corp.',
    read: false,
    time: '1 hour ago',
    type: 'interview'
  },
  {
    id: 2,
    title: 'Application Received',
    message: 'Your internship application has been received by Innovation Labs.',
    read: false,
    time: '3 hours ago',
    type: 'application'
  },
  {
    id: 3,
    title: 'Document Request',
    message: 'Please submit your updated resume for the Data Science position.',
    read: false,
    time: '1 day ago',
    type: 'document'
  }
];

const PRO_STUDENT_EMAIL = 'pro@guc.edu.eg';

function StudentLayout() {
  const [isDrawerOpen, setIsDrawerOpen] = useState(true);
  const [profileAnchorEl, setProfileAnchorEl] = useState(null);
  const [emailAnchorEl, setEmailAnchorEl] = useState(null);
  const [notificationAnchorEl, setNotificationAnchorEl] = useState(null);
  const [notesAnchorEl, setNotesAnchorEl] = useState(null);
  const [notes, setNotes] = useState('');
  const [emails, setEmails] = useState(initialEmails);
  const [notifications, setNotifications] = useState(initialNotifications);
  const [notificationBadgeCount, setNotificationBadgeCount] = useState(6);
  const [emailBadgeCount, setEmailBadgeCount] = useState(3);
  const navigate = useNavigate();
  const [isProUser, setIsProUser] = useState(false);

  const unreadEmailCount = emails.filter(email => !email.read).length;
  const unreadNotificationCount = notifications.filter(notif => !notif.read).length;

  // Add localStorage persistence for drawer state
  useEffect(() => {
    const savedDrawerState = localStorage.getItem('drawerOpen');
    if (savedDrawerState !== null) {
      setIsDrawerOpen(savedDrawerState === 'true');
    }
  }, []);

  useEffect(() => {
    setIsProUser(getProStatus());
    
    // Set initial notification and email badge counts based on unread items
    const unreadNotifs = notifications.filter(notif => !notif.read).length;
    const unreadMails = emails.filter(email => !email.read).length;
    setNotificationBadgeCount(unreadNotifs);
    setEmailBadgeCount(unreadMails);
  }, []);

  const handleDrawerToggle = () => {
    const newState = !isDrawerOpen;
    setIsDrawerOpen(newState);
    localStorage.setItem('drawerOpen', newState.toString());
  };

  const handleProfileMenuOpen = (event) => {
    setProfileAnchorEl(event.currentTarget);
  };

  const handleProfileMenuClose = () => {
    setProfileAnchorEl(null);
  };

  const handleEmailMenuOpen = (event) => {
    setEmailAnchorEl(event.currentTarget);
  };

  const handleEmailMenuClose = () => {
    setEmailAnchorEl(null);
  };

  const handleNotificationMenuOpen = (event) => {
    setNotificationAnchorEl(event.currentTarget);
  };

  const handleNotificationMenuClose = () => {
    setNotificationAnchorEl(null);
  };

  const handleLogout = () => {
    handleProfileMenuClose();
    // Add logout logic here
    navigate('/');
  };

  const handleProfile = () => {
    handleProfileMenuClose();
    navigate('/pro/profile');
  };

  const handleEmailClick = (emailId) => {
    // Mark the email as read
    setEmails(emails.map(email =>
      email.id === emailId ? { ...email, read: true } : email
    ));
    
    // Decrement badge count if it's greater than 0
    if (emailBadgeCount > 0) {
      setEmailBadgeCount(prevCount => prevCount - 1);
    }
    // Don't close automatically - let the user decide when to close
  };

  const handleMarkAllEmailsRead = () => {
    setEmails(emails.map(email => ({ ...email, read: true })));
    setEmailBadgeCount(0);
    handleEmailMenuClose();
  };

  const handleNotificationClick = (notifId) => {
    // Mark the notification as read
    setNotifications(notifications.map(notif =>
      notif.id === notifId ? { ...notif, read: true } : notif
    ));
    
    // Decrement badge count if it's greater than 0
    if (notificationBadgeCount > 0) {
      setNotificationBadgeCount(prevCount => prevCount - 1);
    }
    // Don't close automatically - let the user decide when to close
  };

  const handleMarkAllNotificationsRead = () => {
    setNotifications(notifications.map(notif => ({ ...notif, read: true })));
    setNotificationBadgeCount(0);
    handleNotificationMenuClose();
  };

  const handleNotesMenuOpen = (event) => {
    setNotesAnchorEl(event.currentTarget);
  };

  const handleNotesMenuClose = () => {
    setNotesAnchorEl(null);
  };

  const handleNotesChange = (event) => {
    setNotes(event.target.value);
    // Save notes to localStorage
    localStorage.setItem('workshopNotes', event.target.value);
  };

  // Load saved notes from localStorage
  useEffect(() => {
    const savedNotes = localStorage.getItem('workshopNotes');
    if (savedNotes) {
      setNotes(savedNotes);
    }
  }, []);

  // Function to get email icon based on type
  const getEmailIcon = (type) => {
    switch (type) {
      case 'interview':
        return <BusinessIcon sx={{ color: '#1976d2' }} />;
      case 'application':
        return <DescriptionIcon sx={{ color: '#2196F3' }} />;
      case 'document':
        return <NewReleasesIcon sx={{ color: '#f44336' }} />;
      default:
        return <EmailIcon sx={{ color: '#757575' }} />;
    }
  };

  // Function to get notification icon based on type
  const getNotificationIcon = (type) => {
    switch (type) {
      case 'deadline':
        return <AccessTimeIcon sx={{ color: '#f44336' }} />;
      case 'evaluation':
        return <AssessmentIcon sx={{ color: '#4CAF50' }} />;
      case 'announcement':
        return <NotificationsIcon sx={{ color: '#1976d2' }} />;
      case 'appointment':
        return <VideoCallIcon sx={{ color: '#673ab7' }} />;
      case 'reminder':
        return <PendingIcon sx={{ color: '#ff9800' }} />;
      default:
        return <NotificationsIcon sx={{ color: '#757575' }} />;
    }
  };

  // Common paper props for dropdowns with white background
  const whitePaperProps = {
    sx: { 
      width: 320, 
      maxHeight: 440, 
      overflow: 'auto',
      backgroundColor: 'white',
      boxShadow: '0px 5px 15px rgba(0, 0, 0, 0.2)',
      borderRadius: '8px',
      '& .MuiDivider-root': {
        borderColor: 'rgba(0, 0, 0, 0.12)'
      }
    }
  };

  // Navy header style for dropdowns
  const navyHeaderStyle = {
    p: 2,
    display: 'flex', 
    justifyContent: 'space-between', 
    alignItems: 'center',
    background: navyBlue,
    color: 'white',
    borderTopLeftRadius: '8px',
    borderTopRightRadius: '8px'
  };

  return (
    <Box sx={{ display: 'flex' }}>
      {/* Sidebar */}
      <ProStudentSidebar open={isDrawerOpen} onToggle={handleDrawerToggle} />

      {/* Main content */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: 3,
          width: { sm: `calc(100% - ${isDrawerOpen ? drawerWidth : 64}px)` },
          transition: 'width 0.3s, margin-left 0.3s',
        }}
      >
        {/* AppBar Header */}
        <AppBar 
          position="fixed" 
          sx={{ 
            backgroundColor: navyBlue,
            width: { sm: `calc(100% - ${isDrawerOpen ? drawerWidth : 64}px)` }, 
            ml: { sm: `${isDrawerOpen ? drawerWidth : 64}px` },
            transition: 'width 0.3s, margin-left 0.3s',
          }}
        >
          <Toolbar>
            <IconButton 
              color="inherit"
              onClick={handleDrawerToggle}
              edge="start"
              sx={{ mr: 2 }}
            >
              <MenuIcon />
            </IconButton>
            <Typography variant="h6" component="div">
              Pro Student Portal
                </Typography>
            <Box sx={{ 
              display: 'flex', 
              alignItems: 'center', 
              ml: 'auto',
              gap: 2
            }}>
              <IconButton
                size="large"
                color="inherit"
                onClick={handleNotificationMenuOpen}
                sx={{ 
                  p: 1,
                  '&:hover': { backgroundColor: 'rgba(255, 255, 255, 0.1)' }
                }}
              >
                <Badge badgeContent={unreadNotificationCount} color="error">
                  <NotificationsIcon />
                </Badge>
              </IconButton>
            <IconButton 
              size="large" 
              color="inherit" 
              onClick={handleEmailMenuOpen}
                sx={{ 
                  p: 1,
                  '&:hover': { backgroundColor: 'rgba(255, 255, 255, 0.1)' }
                }}
            >
                <Badge badgeContent={unreadEmailCount} color="error">
                <EmailIcon />
              </Badge>
            </IconButton>
              <IconButton
                size="large"
                color="inherit"
                onClick={handleProfileMenuOpen}
                sx={{ 
                  p: 1,
                  '&:hover': { backgroundColor: 'rgba(255, 255, 255, 0.1)' }
                }}
              >
                <Avatar sx={{ width: 32, height: 32 }} />
              </IconButton>
            </Box>
 
            {/* Email Menu */}
            <Menu
              anchorReference="anchorPosition"
              anchorPosition={emailAnchorEl ? { top: 64, left: window.innerWidth - 24 } : undefined}
              open={Boolean(emailAnchorEl)}
              onClose={handleEmailMenuClose}
              PaperProps={{
                sx: {
                  width: 320,
                  maxHeight: 440,
                  overflow: 'auto',
                  backgroundColor: 'white',
                  boxShadow: '0px 5px 15px rgba(0, 0, 0, 0.2)',
                  borderRadius: '8px',
                  '& .MuiDivider-root': {
                    borderColor: 'rgba(0, 0, 0, 0.12)'
                  }
                }
              }}
              transformOrigin={{ horizontal: 'right', vertical: 'top' }}
            >
              {/* Header */}
              <Box sx={{
                p: 2,
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                background: navyBlue,
                color: 'white',
                borderTopLeftRadius: '8px',
                borderTopRightRadius: '8px'
              }}>
                <Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: 'white' }}>
                  Email Notifications
                </Typography>
                <Chip 
                  label={`${unreadEmailCount} new`} 
                  size="small" 
                  color="error" 
                  sx={{ display: unreadEmailCount ? 'flex' : 'none' }}
                />
              </Box>
              <Divider />
              <List dense sx={{ p: 0, bgcolor: 'white' }}>
                {emails.length === 0 ? (
                  <ListItem>
                    <ListItemText 
                      primary="No notifications" 
                      primaryTypographyProps={{ color: navyBlue }} 
                    />
                  </ListItem>
                ) : (
                  emails.map((email) => (
                    <ListItem 
                      key={email.id} 
                      button 
                      onClick={() => handleEmailClick(email.id)}
                      sx={{ 
                        py: 1.5,
                        px: 2,
                        borderBottom: '1px solid rgba(0, 0, 0, 0.08)',
                        backgroundColor: email.read ? 'white' : 'rgba(25, 118, 210, 0.05)',
                        '&:hover': {
                          backgroundColor: email.read ? 'rgba(0, 0, 0, 0.04)' : 'rgba(25, 118, 210, 0.1)',
                        }
                      }}
                    >
                      <ListItemIcon sx={{ minWidth: '40px' }}>
                        {getEmailIcon(email.type)}
                      </ListItemIcon>
                      <ListItemText 
                        primary={email.title} 
                        secondary={email.message}
                        primaryTypographyProps={{ 
                          color: navyBlue,
                          fontWeight: email.read ? 'normal' : 'bold',
                          fontSize: '0.95rem'
                        }}
                        secondaryTypographyProps={{ 
                          color: 'text.secondary',
                          fontSize: '0.85rem' 
                        }}
                        sx={{ mr: 1 }}
                      />
                      <Typography 
                        variant="caption" 
                        sx={{ 
                          color: 'text.secondary', 
                          alignSelf: 'flex-start',
                          whiteSpace: 'nowrap'
                        }}
                      >
                        {email.time}
                      </Typography>
                    </ListItem>
                  ))
                )}
              </List>
              <Box 
                sx={{ 
                  display: 'flex', 
                  justifyContent: 'center', 
                  p: 1.5,
                  borderTop: '1px solid rgba(0, 0, 0, 0.08)',
                  backgroundColor: 'white'
                }}
              >
                <Typography 
                  variant="body2" 
                  sx={{ 
                    cursor: 'pointer', 
                    color: navyBlue,
                    fontWeight: 500,
                    display: unreadEmailCount ? 'block' : 'none',
                    '&:hover': {
                      textDecoration: 'underline'
                    }
                  }} 
                  onClick={handleMarkAllEmailsRead}
                >
                  Mark all as read
                </Typography>
              </Box>
            </Menu>

            {/* Notification Menu */}
            <Menu
              anchorReference="anchorPosition"
              anchorPosition={notificationAnchorEl ? { top: 64, left: window.innerWidth - 24 } : undefined}
              open={Boolean(notificationAnchorEl)}
              onClose={handleNotificationMenuClose}
              PaperProps={{
                sx: {
                  width: 320,
                  maxHeight: 440,
                  overflow: 'auto',
                  backgroundColor: 'white',
                  boxShadow: '0px 5px 15px rgba(0, 0, 0, 0.2)',
                  borderRadius: '8px',
                  '& .MuiDivider-root': {
                    borderColor: 'rgba(0, 0, 0, 0.12)'
                  }
                }
              }}
              transformOrigin={{ horizontal: 'right', vertical: 'top' }}
            >
              {/* Header */}
              <Box sx={{
                p: 2,
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                background: navyBlue,
                color: 'white',
                borderTopLeftRadius: '8px',
                borderTopRightRadius: '8px'
              }}>
                <Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: 'white' }}>
                  System Notifications
                </Typography>
                <Chip
                  label={`${unreadNotificationCount} new`}
                  size="small"
                  color="error"
                  sx={{ display: unreadNotificationCount ? 'flex' : 'none' }}
                />
              </Box>
              <Divider />
              <List dense sx={{ p: 0, bgcolor: 'white' }}>
                {notifications.length === 0 ? (
                  <ListItem>
                    <ListItemText 
                      primary="No notifications" 
                      primaryTypographyProps={{ color: navyBlue }} 
                    />
                  </ListItem>
                ) : (
                  notifications.map((notif) => (
                    <ListItem 
                      key={notif.id} 
                      button 
                      onClick={() => handleNotificationClick(notif.id)}
                      sx={{ 
                        py: 1.5,
                        px: 2,
                        borderBottom: '1px solid rgba(0, 0, 0, 0.08)',
                        backgroundColor: notif.read ? 'white' : 'rgba(25, 118, 210, 0.05)',
                        '&:hover': {
                          backgroundColor: notif.read ? 'rgba(0, 0, 0, 0.04)' : 'rgba(25, 118, 210, 0.1)',
                        }
                      }}
                    >
                      <ListItemIcon sx={{ minWidth: '40px' }}>
                        {getNotificationIcon(notif.type)}
                      </ListItemIcon>
                      <ListItemText 
                        primary={notif.title} 
                        secondary={notif.message}
                        primaryTypographyProps={{ 
                          color: navyBlue,
                          fontWeight: notif.read ? 'normal' : 'bold',
                          fontSize: '0.95rem'
                        }}
                        secondaryTypographyProps={{ 
                          color: 'text.secondary',
                          fontSize: '0.85rem' 
                        }}
                        sx={{ mr: 1 }}
                      />
                      <Typography 
                        variant="caption" 
                        sx={{ 
                          color: 'text.secondary', 
                          alignSelf: 'flex-start',
                          whiteSpace: 'nowrap'
                        }}
                      >
                        {notif.time}
                      </Typography>
                    </ListItem>
                  ))
                )}
              </List>
              <Box 
                sx={{ 
                  display: 'flex', 
                  justifyContent: 'center', 
                  p: 1.5,
                  borderTop: '1px solid rgba(0, 0, 0, 0.08)',
                  backgroundColor: 'white'
                }}
              >
                <Typography 
                  variant="body2" 
                  sx={{ 
                    cursor: 'pointer', 
                    color: navyBlue,
                    fontWeight: 500,
                    display: unreadNotificationCount ? 'block' : 'none',
                    '&:hover': {
                      textDecoration: 'underline'
                    }
                  }} 
                  onClick={handleMarkAllNotificationsRead}
                >
                  Mark all as read
                </Typography>
              </Box>
            </Menu>
            
            {/* Profile Menu */}
            <Menu
              anchorEl={profileAnchorEl}
              open={Boolean(profileAnchorEl)}
              onClose={handleProfileMenuClose}
              PaperProps={{
                elevation: 0,
                sx: {
                  overflow: 'visible',
                  filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
                  mt: 1.5,
                  bgcolor: 'background.paper',
                  color: 'text.primary',
                  borderRadius: 3,
                  minWidth: 340,
                  p: 0,
                },
              }}
              transformOrigin={{ horizontal: 'right', vertical: 'top' }}
              anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
            >
              {/* Header */}
              <Box sx={{ bgcolor: navyBlue, color: 'white', px: 3, py: 2, borderTopLeftRadius: 12, borderTopRightRadius: 12 }}>
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  Profile Options
                </Typography>
              </Box>
              <Divider />
              <MenuItem onClick={handleProfile} sx={{ py: 2, px: 3 }}>
                <ListItemIcon>
                  <PersonIcon fontSize="medium" sx={{ color: '#1976d2' }} />
                </ListItemIcon>
                <Typography sx={{ fontWeight: 500, fontSize: '1.1rem' }}>Profile</Typography>
              </MenuItem>
              <Divider />
              <MenuItem onClick={handleLogout} sx={{ py: 2, px: 3 }}>
                <ListItemIcon>
                  <LogoutIcon fontSize="medium" sx={{ color: '#d32f2f' }} />
                </ListItemIcon>
                <Typography sx={{ fontWeight: 500, fontSize: '1.1rem', color: '#d32f2f' }}>Logout</Typography>
              </MenuItem>
            </Menu>
          </Toolbar>
        </AppBar>
        <Toolbar />
        <Outlet />
      </Box>
    </Box>
  );
}

export default StudentLayout; 