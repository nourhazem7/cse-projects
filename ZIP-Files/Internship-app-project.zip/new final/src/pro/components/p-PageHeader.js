import React from 'react';
import { Box, Typography } from '@mui/material';

// Theme colors
const navyBlue = '#0A1929';

function PageHeader({ title, subtitle }) {
  return (
    <Box sx={{ 
      mb: 4,
      p: 3,
      bgcolor: navyBlue,
      borderRadius: 2,
      color: 'white'
    }}>
      <Typography variant="h4" gutterBottom>
        {title}
      </Typography>
      {subtitle && (
        <Typography variant="subtitle1">
          {subtitle}
        </Typography>
      )}
    </Box>
  );
}

export default PageHeader; 