// Mock data for demonstration - replace with actual API call
export const mockApplications = [
  {
    id: 1,
    companyName: 'Tech Corp',
    position: 'Software Engineering Intern',
    applicationDate: '2024-02-15',
    status: 'Completed',
    feedback: 'Strong technical skills and great cultural fit.',
    documents: ['Resume', 'Cover Letter', 'Transcript'],
    interviewDate: '2024-02-28',
    startDate: '2024-06-01',
    endDate: '2024-08-31',
    evaluation: {
      rating: 4.5,
      review: 'Great learning environment and supportive team.',
      recommendToOthers: true,
      courses: ['CS101', 'CS202', 'CS303'],
    },
    report: {
      title: 'Summer Internship at Tech Corp',
      introduction: 'Overview of my experience...',
      body: 'Detailed description of projects and learnings...',
      status: 'Submitted',
    }
  },
  {
    id: 2,
    companyName: 'Innovation Labs',
    position: 'Data Science Intern',
    applicationDate: '2024-02-10',
    status: 'Rejected',
    feedback: 'Position requires more experience with machine learning frameworks.',
    documents: ['Resume', 'Portfolio'],
    interviewDate: null,
  },
  {
    id: 3,
    companyName: 'Global Solutions',
    position: 'Full Stack Developer Intern',
    applicationDate: '2024-01-20',
    status: 'Current',
    feedback: 'Currently interning.',
    documents: ['Resume', 'Cover Letter', 'GitHub Portfolio'],
    interviewDate: '2024-02-01',
    startDate: '2024-02-15',
    endDate: '2024-04-15',
    evaluation: null,
    report: {
      title: 'Ongoing Internship Experience',
      introduction: 'Initial weeks overview...',
      body: 'Current projects and responsibilities...',
      status: 'Draft',
    }
  },
];

// Available courses mock data
export const availableCourses = [
  { code: 'CS101', name: 'Introduction to Programming' },
  { code: 'CS202', name: 'Data Structures' },
  { code: 'CS303', name: 'Software Engineering' },
  { code: 'CS404', name: 'Database Systems' },
  { code: 'CS505', name: 'Web Development' },
];

document.getElementById('shareScreenBtn').addEventListener('click', async () => {
  try {
    const screenStream = await navigator.mediaDevices.getDisplayMedia({
      video: true,
      audio: false // set to true if you want to share audio too
    });

    // Example: Attach the stream to a video element for local preview
    const videoElem = document.getElementById('localVideo');
    if (videoElem) {
      videoElem.srcObject = screenStream;
    }

    // TODO: Send this stream to the remote peer via your WebRTC connection
    // Example: peerConnection.addTrack(screenStream.getVideoTracks()[0], screenStream);

    screenStream.getVideoTracks()[0].addEventListener('ended', () => {
      // Revert to webcam or notify user
    });

  } catch (err) {
    console.error('Error sharing screen:', err);
    alert('Screen sharing failed: ' + err.message);
  }
}); 