import React from 'react';

const Assessments = () => (
  <div style={{ padding: 32 }}>
    <h2>Assessments (PRO Feature)</h2>
    <p>This is the Assessments page. Here, PRO students will be able to take and view online assessments.</p>
  </div>
);

export default Assessments; 