import React, { useState } from 'react';
import {
  Box,
  Typography,
  Grid,
  Paper,
  TextField,
  InputAdornment,
  Button,
  Card,
  CardContent,
  CardActions,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  IconButton,
  // eslint-disable-next-line no-unused-vars
  Dialog,
  useTheme,
  useMediaQuery,
  Drawer,
  // eslint-disable-next-line no-unused-vars
  List,
  // eslint-disable-next-line no-unused-vars
  ListItem,
  // eslint-disable-next-line no-unused-vars
  ListItemText,
  Slider,
  Switch,
  FormControlLabel,
  // eslint-disable-next-line no-unused-vars
  Divider,
} from '@mui/material';
import {
  Search as SearchIcon,
  FilterList as FilterListIcon,
  LocationOn as LocationIcon,
  Business as BusinessIcon,
  AttachMoney as MoneyIcon,
  AccessTime as TimeIcon,
  BookmarkBorder as BookmarkIcon,
  Bookmark as BookmarkFilledIcon,
  Sort as SortIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

// Theme colors
const navyBlue = '#0A1929';
// eslint-disable-next-line no-unused-vars
const lightNavyBlue = '#132F4C';

// Filter options
const industries = ['All', 'Technology', 'Marketing', 'Data Science', 'Finance', 'Healthcare'];
const locations = ['All', 'Cairo', 'Giza', 'Alexandria', 'Remote'];
const durations = ['All', '1-3 months', '3-6 months', '6+ months'];

// Dummy data for internships
const dummyInternships = [
  {
    id: 1,
    title: 'Software Engineering Intern',
    company: 'Tech Solutions Inc.',
    location: 'Cairo, Egypt',
    type: 'Full-time',
    duration: '3 months',
    isPaid: true,
    salary: '5000 EGP/month',
    description: 'Join our dynamic team to work on cutting-edge web applications using modern technologies.',
    requirements: [
      'Currently enrolled in Computer Science or related field',
      'Strong knowledge of JavaScript and React',
      'Good problem-solving skills',
    ],
    industry: 'Technology',
    postedDate: '2024-03-15',
    deadline: '2024-04-15',
  },
  {
    id: 2,
    title: 'Marketing Intern',
    company: 'Digital Marketing Pro',
    location: 'Giza, Egypt',
    type: 'Part-time',
    duration: '6 months',
    isPaid: true,
    salary: '3000 EGP/month',
    description: 'Assist in developing and implementing digital marketing strategies.',
    requirements: [
      'Marketing or Business Administration student',
      'Strong communication skills',
      'Creative mindset',
    ],
    industry: 'Marketing',
    postedDate: '2024-03-10',
    deadline: '2024-04-20',
  },
  {
    id: 3,
    title: 'Data Science Intern',
    company: 'Analytics Corp',
    location: 'Remote',
    type: 'Full-time',
    duration: '4 months',
    isPaid: true,
    salary: '6000 EGP/month',
    description: 'Work on real-world data analysis projects using machine learning.',
    requirements: [
      'Strong background in statistics and mathematics',
      'Experience with Python and data analysis libraries',
      'Knowledge of machine learning concepts',
    ],
    industry: 'Data Science',
    postedDate: '2024-03-17',
    deadline: '2024-04-30',
  },
];

function Internships() {
  const theme = useTheme();
  const navigate = useNavigate();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIndustry, setSelectedIndustry] = useState('All');
  const [selectedLocation, setSelectedLocation] = useState('All');
  const [selectedDuration, setSelectedDuration] = useState('All');
  const [showPaidOnly, setShowPaidOnly] = useState(false);
  const [salaryRange, setSalaryRange] = useState([0, 10000]);
  const [sortBy, setSortBy] = useState('deadline');
  const [filterDrawerOpen, setFilterDrawerOpen] = useState(false);
  const [bookmarkedInternships, setBookmarkedInternships] = useState([]);

  // Filter internships based on search and filters
  const filteredInternships = dummyInternships.filter((internship) => {
    const matchesSearch = 
      internship.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      internship.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      internship.description.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesIndustry = 
      selectedIndustry === 'All' || internship.industry === selectedIndustry;

    const matchesLocation =
      selectedLocation === 'All' || internship.location.includes(selectedLocation);

    const matchesDuration =
      selectedDuration === 'All' ||
      (selectedDuration === '1-3 months' && parseInt(internship.duration) <= 3) ||
      (selectedDuration === '3-6 months' && parseInt(internship.duration) > 3 && parseInt(internship.duration) <= 6) ||
      (selectedDuration === '6+ months' && parseInt(internship.duration) > 6);

    const matchesPaidFilter = !showPaidOnly || internship.isPaid;

    const matchesSalary = 
      !internship.isPaid ||
      (parseInt(internship.salary) >= salaryRange[0] && parseInt(internship.salary) <= salaryRange[1]);

    return (
      matchesSearch &&
      matchesIndustry &&
      matchesLocation &&
      matchesDuration &&
      matchesPaidFilter &&
      matchesSalary
    );
  });

  // Sort internships
  const sortedInternships = [...filteredInternships].sort((a, b) => {
    switch (sortBy) {
      case 'deadline':
        return new Date(a.deadline) - new Date(b.deadline);
      case 'posted':
        return new Date(b.postedDate) - new Date(a.postedDate);
      case 'salary':
        return (parseInt(b.salary) || 0) - (parseInt(a.salary) || 0);
      default:
        return 0;
    }
  });

  const toggleBookmark = (internshipId) => {
    setBookmarkedInternships((prev) =>
      prev.includes(internshipId)
        ? prev.filter((id) => id !== internshipId)
        : [...prev, internshipId]
    );
  };

  const handleApply = (internshipId) => {
    navigate(`/pro/apply/${internshipId}`);
  };

  const filterDrawerContent = (
    <Box sx={{ width: 250, p: 3 }}>
      <Typography variant="h6" gutterBottom>
        Filters
      </Typography>
      <FormControl fullWidth sx={{ mb: 2 }}>
        <InputLabel>Industry</InputLabel>
        <Select
          value={selectedIndustry}
          onChange={(e) => setSelectedIndustry(e.target.value)}
          label="Industry"
        >
          {industries.map((industry) => (
            <MenuItem key={industry} value={industry}>
              {industry}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <FormControl fullWidth sx={{ mb: 2 }}>
        <InputLabel>Location</InputLabel>
        <Select
          value={selectedLocation}
          onChange={(e) => setSelectedLocation(e.target.value)}
          label="Location"
        >
          {locations.map((location) => (
            <MenuItem key={location} value={location}>
              {location}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <FormControl fullWidth sx={{ mb: 2 }}>
        <InputLabel>Duration</InputLabel>
        <Select
          value={selectedDuration}
          onChange={(e) => setSelectedDuration(e.target.value)}
          label="Duration"
        >
          {durations.map((duration) => (
            <MenuItem key={duration} value={duration}>
              {duration}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <FormControlLabel
        control={
          <Switch
            checked={showPaidOnly}
            onChange={(e) => setShowPaidOnly(e.target.checked)}
          />
        }
        label="Paid Internships Only"
        sx={{ mb: 2 }}
      />
      <Typography gutterBottom>Salary Range (EGP/month)</Typography>
      <Slider
        value={salaryRange}
        onChange={(e, newValue) => setSalaryRange(newValue)}
        valueLabelDisplay="auto"
        min={0}
        max={10000}
        step={500}
      />
      <Button
        variant="outlined"
        fullWidth
        onClick={() => {
          setSelectedIndustry('All');
          setSelectedLocation('All');
          setSelectedDuration('All');
          setShowPaidOnly(false);
          setSalaryRange([0, 10000]);
        }}
        sx={{ mt: 2 }}
      >
        Reset Filters
      </Button>
    </Box>
  );

  return (
    <Box sx={{ flexGrow: 1 }}>
      {/* Header Section */}
      <Box sx={{ 
        mb: 4,
        p: 3,
        bgcolor: navyBlue,
        borderRadius: 2,
        color: 'white'
      }}>
        <Typography variant="h4" gutterBottom>
          Browse Internships
        </Typography>
        <Typography variant="subtitle1">
          Find the perfect internship opportunity to kickstart your career
        </Typography>
      </Box>

      {/* Search and Filter Bar */}
      <Paper sx={{ p: 2, mb: 3 }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              placeholder="Search internships..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
            />
          </Grid>
          <Grid item xs={6} md={3}>
            <FormControl fullWidth>
              <InputLabel>Sort By</InputLabel>
              <Select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                label="Sort By"
                startAdornment={
                  <InputAdornment position="start">
                    <SortIcon />
                  </InputAdornment>
                }
              >
                <MenuItem value="deadline">Application Deadline</MenuItem>
                <MenuItem value="posted">Posted Date</MenuItem>
                <MenuItem value="salary">Salary</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={6} md={3}>
            <Button
              fullWidth
              variant="outlined"
              startIcon={<FilterListIcon />}
              onClick={() => setFilterDrawerOpen(true)}
            >
              Filters
            </Button>
          </Grid>
        </Grid>
      </Paper>

      {/* Internship Cards */}
      <Grid container spacing={3}>
        {sortedInternships.map((internship) => (
          <Grid item xs={12} md={6} lg={4} key={internship.id}>
            <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
              <CardContent sx={{ flexGrow: 1 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <Typography variant="h6" gutterBottom>
                    {internship.title}
                  </Typography>
                  <IconButton onClick={() => toggleBookmark(internship.id)}>
                    {bookmarkedInternships.includes(internship.id) ? (
                      <BookmarkFilledIcon color="primary" />
                    ) : (
                      <BookmarkIcon />
                    )}
                  </IconButton>
                </Box>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <BusinessIcon sx={{ mr: 1, color: 'text.secondary' }} />
                  <Typography color="text.secondary">
                    {internship.company}
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <LocationIcon sx={{ mr: 1, color: 'text.secondary' }} />
                  <Typography color="text.secondary">
                    {internship.location}
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <TimeIcon sx={{ mr: 1, color: 'text.secondary' }} />
                  <Typography color="text.secondary">
                    {internship.duration}
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', gap: 1, mb: 2, flexWrap: 'wrap' }}>
                  <Chip
                    label={internship.type}
                    size="small"
                    color="primary"
                    variant="outlined"
                  />
                  <Chip
                    label={internship.industry}
                    size="small"
                    color="primary"
                    variant="outlined"
                  />
                  {internship.isPaid && (
                    <Chip
                      icon={<MoneyIcon />}
                      label={internship.salary}
                      size="small"
                      color="success"
                    />
                  )}
                </Box>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                  {internship.description.length > 150
                    ? `${internship.description.substring(0, 150)}...`
                    : internship.description}
                </Typography>
                <Typography variant="caption" color="error">
                  Application Deadline: {internship.deadline}
                </Typography>
              </CardContent>
              <CardActions>
                <Button
                  fullWidth
                  variant="contained"
                  onClick={() => handleApply(internship.id)}
                  sx={{
                    bgcolor: '#0A1929',
                    color: 'white',
                    '&:hover': {
                      bgcolor: '#16243a',
                    },
                  }}
                >
                  APPLY NOW
                </Button>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Filter Drawer */}
      <Drawer
        anchor={isMobile ? 'bottom' : 'right'}
        open={filterDrawerOpen}
        onClose={() => setFilterDrawerOpen(false)}
      >
        {filterDrawerContent}
      </Drawer>
    </Box>
  );
}

export default Internships; 