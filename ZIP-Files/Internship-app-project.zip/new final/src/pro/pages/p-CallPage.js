import React, { useRef, useState } from 'react';
import { Box, Button, IconButton, Typography, Paper } from '@mui/material';
import VideocamIcon from '@mui/icons-material/Videocam';
import VideocamOffIcon from '@mui/icons-material/VideocamOff';
import MicIcon from '@mui/icons-material/Mic';
import MicOffIcon from '@mui/icons-material/MicOff';
import CallEndIcon from '@mui/icons-material/CallEnd';
import ScreenShareIcon from '@mui/icons-material/ScreenShare';
import { useNavigate } from 'react-router-dom';
import Snackbar from '@mui/material/Snackbar';
import Alert from '@mui/material/Alert';

const navyBlue = '#0A1929';

const CallPage = () => {
  const videoRef = useRef(null);
  const [cameraOn, setCameraOn] = useState(true);
  const [micOn, setMicOn] = useState(true);
  const [stream, setStream] = useState(null);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const cameraStreamRef = useRef(null);
  const navigate = useNavigate();
  const [scadLeft, setScadLeft] = useState(false);

  React.useEffect(() => {
    // Try to get user media
    if (cameraOn || micOn) {
      navigator.mediaDevices.getUserMedia({ video: cameraOn, audio: micOn })
        .then((mediaStream) => {
          setStream(mediaStream);
          if (videoRef.current && cameraOn) {
            videoRef.current.srcObject = mediaStream;
          }
        })
        .catch(() => {
          setStream(null);
        });
    } else {
      // Stop all tracks if both are off
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
        setStream(null);
      }
    }
    // Cleanup on unmount
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
    // eslint-disable-next-line
  }, [cameraOn, micOn]);

  // Show SCAD left notification 30 seconds after joining
  React.useEffect(() => {
    const timer = setTimeout(() => {
      setScadLeft(true);
    }, 30000); // 30 seconds
    return () => clearTimeout(timer);
  }, []);

  const handleToggleCamera = () => {
    setCameraOn((prev) => !prev);
  };

  const handleToggleMic = () => {
    setMicOn((prev) => !prev);
  };

  const handleShareScreen = async () => {
    try {
      const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
      setIsScreenSharing(true);
      cameraStreamRef.current = stream; // Save the current camera stream
      setStream(screenStream);
      if (videoRef.current) {
        videoRef.current.srcObject = screenStream;
      }
      // When screen sharing ends, revert to camera
      screenStream.getVideoTracks()[0].addEventListener('ended', () => {
        setIsScreenSharing(false);
        if (cameraStreamRef.current) {
          setStream(cameraStreamRef.current);
          if (videoRef.current) {
            videoRef.current.srcObject = cameraStreamRef.current;
          }
        }
      });
    } catch (err) {
      // User cancelled or error
    }
  };

  const handleLeave = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
    }
    navigate('/pro/request-appointment');
  };

  return (
    <Box sx={{ minHeight: '100vh', bgcolor: navyBlue, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
      <Paper sx={{ p: 4, borderRadius: 3, bgcolor: '#16243a', color: 'white', minWidth: 350, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <Typography variant="h5" sx={{ mb: 2 }}>Video Call</Typography>
        <Box sx={{ width: 320, height: 240, bgcolor: '#222', borderRadius: 2, mb: 2, display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
          {cameraOn && stream ? (
            <video ref={videoRef} autoPlay playsInline style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          ) : (
            <Box sx={{ color: '#888', fontSize: 18 }}>Camera is Off</Box>
          )}
        </Box>
        <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
          <IconButton onClick={handleToggleCamera} color={cameraOn ? 'primary' : 'default'} sx={{ bgcolor: cameraOn ? '#1976d2' : '#555', color: 'white' }}>
            {cameraOn ? <VideocamIcon /> : <VideocamOffIcon />}
          </IconButton>
          <IconButton onClick={handleToggleMic} color={micOn ? 'primary' : 'default'} sx={{ bgcolor: micOn ? '#43a047' : '#555', color: 'white' }}>
            {micOn ? <MicIcon /> : <MicOffIcon />}
          </IconButton>
          <IconButton onClick={handleShareScreen} color={isScreenSharing ? 'secondary' : 'default'} sx={{ bgcolor: isScreenSharing ? '#ff9800' : '#555', color: 'white' }}>
            <ScreenShareIcon />
          </IconButton>
          <IconButton onClick={handleLeave} sx={{ bgcolor: '#d32f2f', color: 'white' }}>
            <CallEndIcon />
          </IconButton>
        </Box>
        <Typography variant="body2" color="#bbb">You can mute/unmute or turn your camera on/off during the call.</Typography>
      </Paper>
      {/* Snackbar notification for SCAD leaving */}
      <Snackbar open={scadLeft} autoHideDuration={4000} onClose={() => setScadLeft(false)} anchorOrigin={{ vertical: 'top', horizontal: 'center' }}>
        <Alert onClose={() => setScadLeft(false)} severity="info" sx={{ width: '100%' }}>
          SCAD has left the call.
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default CallPage; 