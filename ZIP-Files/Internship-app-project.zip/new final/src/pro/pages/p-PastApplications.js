import React, { useState } from 'react';
import {
  Box,
  Typography,
  Paper,
  List,
  ListItem,
  ListItemText,
  Chip,
  Tabs,
  Tab,
  Tooltip,
} from '@mui/material';

// Theme colors
const navyBlue = '#0A1929';

// Dummy data - replace with actual API calls
const pastApplications = [
  {
    id: 1,
    formType: 'Academic Training Form',
    submissionDate: '2024-03-01',
    status: 'pending',
  },
  {
    id: 2,
    formType: 'Industrial Training Form',
    submissionDate: '2024-02-15',
    status: 'finalized',
  },
  {
    id: 3,
    formType: 'Academic Training Form',
    submissionDate: '2024-01-20',
    status: 'accepted',
  },
  {
    id: 4,
    formType: 'Industrial Training Form',
    submissionDate: '2024-01-10',
    status: 'rejected',
  },
];

function PastApplications() {
  const [tabValue, setTabValue] = useState(0);

  // Function to get status chip color
  const getStatusColor = (status) => {
    switch (status) {
      case 'pending':
        return 'warning';
      case 'finalized':
        return 'info';
      case 'accepted':
        return 'success';
      case 'rejected':
        return 'error';
      default:
        return 'default';
    }
  };

  // Function to get status tooltip text
  const getStatusTooltip = (status) => {
    switch (status) {
      case 'pending':
        return 'Not yet seen';
      case 'finalized':
        return 'Not yet accepted but one of the top applicants';
      case 'accepted':
        return 'Application accepted';
      case 'rejected':
        return 'Application rejected';
      default:
        return '';
    }
  };

  // Filter applications based on tab
  const getFilteredApplications = () => {
    if (tabValue === 0) {
      // Show all applications
      return pastApplications;
    } else {
      // Show applications by status
      const statusMap = {
        1: 'pending',
        2: 'finalized',
        3: 'accepted',
        4: 'rejected',
      };
      return pastApplications.filter(app => app.status === statusMap[tabValue]);
    }
  };

  return (
    <Box sx={{ flexGrow: 1 }}>
      {/* Header Section */}
      <Box sx={{ 
        mb: 4,
        p: 3,
        bgcolor: navyBlue,
        borderRadius: 2,
        color: 'white'
      }}>
        <Typography variant="h4" gutterBottom>
          Past Applications
        </Typography>
        <Typography variant="subtitle1">
          View all your submitted application forms and their current status
        </Typography>
      </Box>

      {/* Status Tabs */}
      <Paper sx={{ mb: 2 }}>
        <Tabs
          value={tabValue}
          onChange={(e, newValue) => setTabValue(newValue)}
          variant="scrollable"
          scrollButtons="auto"
        >
          <Tab label="All Applications" />
          <Tab label="Pending" />
          <Tab label="Finalized" />
          <Tab label="Accepted" />
          <Tab label="Rejected" />
        </Tabs>
      </Paper>

      {/* Applications List */}
      <List>
        {getFilteredApplications().map((application) => (
          <Paper key={application.id} sx={{ mb: 2 }}>
            <ListItem sx={{ display: 'flex', justifyContent: 'space-between' }}>
              <Box>
                <ListItemText
                  primary={application.formType}
                  secondary={`Submitted on: ${application.submissionDate}`}
                />
              </Box>
              <Box>
                <Tooltip title={getStatusTooltip(application.status)} arrow>
                  <Chip
                    label={application.status.charAt(0).toUpperCase() + application.status.slice(1)}
                    color={getStatusColor(application.status)}
                    sx={{ ml: 1 }}
                  />
                </Tooltip>
              </Box>
            </ListItem>
          </Paper>
        ))}
        {getFilteredApplications().length === 0 && (
          <Paper sx={{ p: 2, textAlign: 'center' }}>
            <Typography color="text.secondary">
              No applications found with the selected status
            </Typography>
          </Paper>
        )}
      </List>
    </Box>
  );
}

export default PastApplications; 