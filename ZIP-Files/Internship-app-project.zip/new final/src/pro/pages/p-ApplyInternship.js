import React, { useState } from 'react';
import {
  Box,
  Typography,
  Paper,
  Grid,
  TextField,
  Button,
  Stepper,
  Step,
  StepLabel,
  FormControlLabel,
  Checkbox,
  Alert,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  IconButton,
  Chip,
} from '@mui/material';
import {
  Description as DescriptionIcon,
  CloudUpload as CloudUploadIcon,
  Delete as DeleteIcon,
  CheckCircle as CheckCircleIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

// Theme colors
const navyBlue = '#0A1929';

// Application steps
const steps = ['Personal Information', 'Documents', 'Review & Submit'];

function ApplyInternship() {
  const navigate = useNavigate();
  const [activeStep, setActiveStep] = useState(0);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    coverLetter: '',
    availability: '',
    expectedGraduation: '',
    agreeToTerms: false,
  });

  const [documents, setDocuments] = useState([]);
  const [errors, setErrors] = useState({});

  const requiredDocuments = [
    { type: 'resume', label: 'Resume/CV', required: true },
    { type: 'transcript', label: 'Academic Transcript', required: true },
    { type: 'certificates', label: 'Certificates (Optional)', required: false },
  ];

  const handleInputChange = (field) => (event) => {
    setFormData({
      ...formData,
      [field]: event.target.value,
    });
    // Clear error when user types
    if (errors[field]) {
      setErrors({
        ...errors,
        [field]: '',
      });
    }
  };

  const handleFileUpload = (type) => (event) => {
    const file = event.target.files[0];
    if (file) {
      const newDocument = {
        id: Date.now(),
        type,
        name: file.name,
        file,
        uploadDate: new Date().toISOString(),
      };
      setDocuments([...documents.filter(doc => doc.type !== type), newDocument]);
    }
  };

  const handleDeleteDocument = (documentId) => {
    setDocuments(documents.filter((doc) => doc.id !== documentId));
  };

  const validateStep = () => {
    const newErrors = {};

    if (activeStep === 0) {
      if (!formData.firstName) newErrors.firstName = 'First name is required';
      if (!formData.lastName) newErrors.lastName = 'Last name is required';
      if (!formData.email) newErrors.email = 'Email is required';
      if (!formData.phone) newErrors.phone = 'Phone number is required';
      if (!formData.availability) newErrors.availability = 'Availability is required';
      if (!formData.expectedGraduation) newErrors.expectedGraduation = 'Expected graduation date is required';
    } else if (activeStep === 1) {
      const missingRequired = requiredDocuments
        .filter(doc => doc.required)
        .filter(doc => !documents.find(d => d.type === doc.type));
      
      if (missingRequired.length > 0) {
        newErrors.documents = `Missing required documents: ${missingRequired.map(d => d.label).join(', ')}`;
      }
    } else if (activeStep === 2) {
      if (!formData.agreeToTerms) {
        newErrors.terms = 'You must agree to the terms and conditions';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep()) {
      if (activeStep === steps.length - 1) {
        handleSubmit();
      } else {
        setActiveStep((prevStep) => prevStep + 1);
      }
    }
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };

  const handleSubmit = () => {
    // Here you would typically submit the application to your backend
    console.log('Submitting application:', { formData, documents });
    navigate('/pro/application-status');
  };

  const renderStepContent = () => {
    switch (activeStep) {
      case 0:
        return (
          <Grid container spacing={3}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="First Name"
                value={formData.firstName}
                onChange={handleInputChange('firstName')}
                error={!!errors.firstName}
                helperText={errors.firstName}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Last Name"
                value={formData.lastName}
                onChange={handleInputChange('lastName')}
                error={!!errors.lastName}
                helperText={errors.lastName}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Email"
                type="email"
                value={formData.email}
                onChange={handleInputChange('email')}
                error={!!errors.email}
                helperText={errors.email}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Phone Number"
                value={formData.phone}
                onChange={handleInputChange('phone')}
                error={!!errors.phone}
                helperText={errors.phone}
                required
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Cover Letter"
                multiline
                rows={6}
                value={formData.coverLetter}
                onChange={handleInputChange('coverLetter')}
                placeholder="Tell us why you're interested in this position..."
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Availability"
                value={formData.availability}
                onChange={handleInputChange('availability')}
                error={!!errors.availability}
                helperText={errors.availability}
                placeholder="e.g., Available from June 2024"
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Expected Graduation Date"
                type="month"
                value={formData.expectedGraduation}
                onChange={handleInputChange('expectedGraduation')}
                error={!!errors.expectedGraduation}
                helperText={errors.expectedGraduation}
                required
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
          </Grid>
        );

      case 1:
        return (
          <Box>
            {errors.documents && (
              <Alert severity="error" sx={{ mb: 2 }}>
                {errors.documents}
              </Alert>
            )}
            <List>
              {requiredDocuments.map((docType) => {
                const uploadedDoc = documents.find(doc => doc.type === docType.type);
                return (
                  <ListItem
                    key={docType.type}
                    secondaryAction={
                      uploadedDoc && (
                        <IconButton
                          edge="end"
                          aria-label="delete"
                          onClick={() => handleDeleteDocument(uploadedDoc.id)}
                        >
                          <DeleteIcon />
                        </IconButton>
                      )
                    }
                  >
                    <ListItemIcon>
                      {uploadedDoc ? <CheckCircleIcon color="success" /> : <DescriptionIcon />}
                    </ListItemIcon>
                    <ListItemText
                      primary={docType.label}
                      secondary={
                        uploadedDoc ? (
                          <>
                            {uploadedDoc.name}
                            <Chip
                              size="small"
                              label="Uploaded"
                              color="success"
                              sx={{ ml: 1 }}
                            />
                          </>
                        ) : (
                          <Button
                            component="label"
                            startIcon={<CloudUploadIcon />}
                            size="small"
                          >
                            Upload {docType.required ? '(Required)' : '(Optional)'}
                            <input
                              type="file"
                              hidden
                              accept=".pdf,.doc,.docx"
                              onChange={handleFileUpload(docType.type)}
                            />
                          </Button>
                        )
                      }
                    />
                  </ListItem>
                );
              })}
            </List>
          </Box>
        );

      case 2:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>
              Review Your Application
            </Typography>
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Paper sx={{ p: 2 }}>
                  <Typography variant="subtitle1" gutterBottom>
                    Personal Information
                  </Typography>
                  <Typography>
                    Name: {formData.firstName} {formData.lastName}
                  </Typography>
                  <Typography>Email: {formData.email}</Typography>
                  <Typography>Phone: {formData.phone}</Typography>
                  <Typography>Availability: {formData.availability}</Typography>
                  <Typography>
                    Expected Graduation: {formData.expectedGraduation}
                  </Typography>
                </Paper>
              </Grid>
              <Grid item xs={12} md={6}>
                <Paper sx={{ p: 2 }}>
                  <Typography variant="subtitle1" gutterBottom>
                    Uploaded Documents
                  </Typography>
                  <List>
                    {documents.map((doc) => (
                      <ListItem key={doc.id}>
                        <ListItemIcon>
                          <DescriptionIcon />
                        </ListItemIcon>
                        <ListItemText primary={doc.name} />
                      </ListItem>
                    ))}
                  </List>
                </Paper>
              </Grid>
              {formData.coverLetter && (
                <Grid item xs={12}>
                  <Paper sx={{ p: 2 }}>
                    <Typography variant="subtitle1" gutterBottom>
                      Cover Letter
                    </Typography>
                    <Typography>{formData.coverLetter}</Typography>
                  </Paper>
                </Grid>
              )}
              <Grid item xs={12}>
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={formData.agreeToTerms}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          agreeToTerms: e.target.checked,
                        })
                      }
                    />
                  }
                  label="I confirm that all the information provided is accurate and complete"
                />
                {errors.terms && (
                  <Typography color="error" variant="caption" display="block">
                    {errors.terms}
                  </Typography>
                )}
              </Grid>
            </Grid>
          </Box>
        );

      default:
        return null;
    }
  };

  return (
    <Box sx={{ flexGrow: 1 }}>
      {/* Header Section */}
      <Box sx={{ 
        mb: 4,
        p: 3,
        bgcolor: navyBlue,
        borderRadius: 2,
        color: 'white'
      }}>
        <Typography variant="h4" gutterBottom>
          Internship Application
        </Typography>
        <Typography variant="subtitle1">
          Please complete all required information to submit your application
        </Typography>
      </Box>

      {/* Application Form */}
      <Paper sx={{ p: 3 }}>
        <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>

        {renderStepContent()}

        <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 3 }}>
          {activeStep > 0 && (
            <Button onClick={handleBack} sx={{ mr: 1 }}>
              Back
            </Button>
          )}
          <Button
            variant="contained"
            onClick={handleNext}
          >
            {activeStep === steps.length - 1 ? 'Submit Application' : 'Next'}
          </Button>
        </Box>
      </Paper>
    </Box>
  );
}

export default ApplyInternship; 