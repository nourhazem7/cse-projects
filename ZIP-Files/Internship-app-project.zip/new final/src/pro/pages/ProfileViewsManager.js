import React, { useState } from 'react';
import {
  Box, Typography, Button, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Paper, Dialog, DialogTitle, DialogContent, DialogActions, TextField
} from '@mui/material';

const initialData = [
  { id: 1, company: 'Tech Corp', date: '2024-04-20', time: '10:00' },
  { id: 2, company: 'Digital Solutions', date: '2024-04-21', time: '14:30' },
];

export default function ProfileViewsManager() {
  const [rows, setRows] = useState(initialData);
  const [open, setOpen] = useState(false);
  const [editIndex, setEditIndex] = useState(null);
  const [form, setForm] = useState({ id: '', company: '', date: '', time: '' });

  const handleOpen = (row, idx) => {
    setEditIndex(idx);
    setForm(row || { id: '', company: '', date: '', time: '' });
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setEditIndex(null);
    setForm({ id: '', company: '', date: '', time: '' });
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSave = () => {
    if (editIndex !== null) {
      // Edit
      const updated = [...rows];
      updated[editIndex] = form;
      setRows(updated);
    } else {
      // Add
      setRows([...rows, { ...form, id: rows.length ? Math.max(...rows.map(r => Number(r.id))) + 1 : 1 }]);
    }
    handleClose();
  };

  const handleDelete = (idx) => {
    setRows(rows.filter((_, i) => i !== idx));
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h5" gutterBottom>Profile Views Manager</Typography>
      <Button variant="contained" color="primary" onClick={() => handleOpen(null, null)} sx={{ mb: 2 }}>
        Add
      </Button>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Reference ID</TableCell>
              <TableCell>Company</TableCell>
              <TableCell>Date</TableCell>
              <TableCell>Time</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row, idx) => (
              <TableRow key={row.id}>
                <TableCell>{row.id}</TableCell>
                <TableCell>{row.company}</TableCell>
                <TableCell>{row.date}</TableCell>
                <TableCell>{row.time}</TableCell>
                <TableCell>
                  <Button size="small" onClick={() => handleOpen(row, idx)}>Edit</Button>
                  <Button size="small" color="error" onClick={() => handleDelete(idx)}>Delete</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>{editIndex !== null ? 'Edit' : 'Add'} Profile View</DialogTitle>
        <DialogContent>
          <TextField
            margin="dense"
            label="Reference ID"
            name="id"
            value={form.id}
            onChange={handleChange}
            fullWidth
            disabled={editIndex !== null}
          />
          <TextField
            margin="dense"
            label="Company"
            name="company"
            value={form.company}
            onChange={handleChange}
            fullWidth
          />
          <TextField
            margin="dense"
            label="Date"
            name="date"
            type="date"
            value={form.date}
            onChange={handleChange}
            fullWidth
            InputLabelProps={{ shrink: true }}
          />
          <TextField
            margin="dense"
            label="Time"
            name="time"
            type="time"
            value={form.time}
            onChange={handleChange}
            fullWidth
            InputLabelProps={{ shrink: true }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={handleSave} variant="contained">Save</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
} 