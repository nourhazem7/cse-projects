import React from 'react';

const CareerGuidance = () => (
  <div style={{ padding: 32 }}>
    <h2>Career Guidance (PRO Feature)</h2>
    <p>This is the Career Guidance page. Here, PRO students will be able to request and manage career guidance sessions.</p>
  </div>
);

export default CareerGuidance; 