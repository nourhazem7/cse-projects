import React, { useState } from 'react';
import { Box, Typography, Paper, Card, CardContent, List, ListItem, ListItemText, Button, Dialog, DialogTitle, DialogContent, DialogActions, TextField, Divider, Chip, Grid, Avatar, Alert } from '@mui/material';
import BusinessIcon from '@mui/icons-material/Business';
import AssessmentIcon from '@mui/icons-material/Assessment';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import VisibilityIcon from '@mui/icons-material/Visibility';
import DateRangeIcon from '@mui/icons-material/DateRange';
import AssignmentTurnedInIcon from '@mui/icons-material/AssignmentTurnedIn';
import Snackbar from '@mui/material/Snackbar';

// Dummy data
const companiesViewed = [
  { name: 'Tech Corp', industry: 'Software', viewedAt: '2024-06-01 10:30', logo: '' },
  { name: 'Global Solutions', industry: 'Consulting', viewedAt: '2024-06-02 14:15', logo: '' },
  { name: 'Innovation Labs', industry: 'R&D', viewedAt: '2024-06-03 09:45', logo: '' },
];

const assessments = [
  { id: 1, title: 'React Fundamentals', questions: [
    { q: 'What is a React component?', a: '' },
    { q: 'How do you manage state in React?', a: '' },
  ]},
  { id: 2, title: 'JavaScript Basics', questions: [
    { q: 'What is a closure?', a: '' },
    { q: 'Explain let vs var vs const.', a: '' },
  ]},
];

const navyBlue = '#0A1929';

const ProfileViews = () => {
  const [openAssessment, setOpenAssessment] = useState(null);
  const [answers, setAnswers] = useState([]);
  const [submitted, setSubmitted] = useState(false);
  const [score, setScore] = useState(null);
  const [assessmentScores, setAssessmentScores] = useState({}); // Track scores per assessment
  const [snackbarOpen, setSnackbarOpen] = useState(false); // For add score notification

  // Stats
  const totalCompanies = companiesViewed.length;
  const mostRecentView = companiesViewed.length ? companiesViewed[0].viewedAt : 'N/A';
  const totalAssessmentsTaken = 0; // Dummy, can be updated to count completed

  const handleOpenAssessment = (assessment) => {
    setOpenAssessment(assessment);
    setAnswers(Array(assessment.questions.length).fill(''));
    setSubmitted(false);
    setScore(assessmentScores[assessment.id] || null); // Show previous score if exists
  };

  const handleCloseAssessment = () => {
    setOpenAssessment(null);
    setAnswers([]);
    setSubmitted(false);
    setScore(null);
  };

  const handleAnswerChange = (idx, value) => {
    const newAnswers = [...answers];
    newAnswers[idx] = value;
    setAnswers(newAnswers);
  };

  const handleSubmitAssessment = () => {
    // Dummy scoring: give 50% if all answered, 100% if all answers > 10 chars
    const allAnswered = answers.every(a => a.trim() !== '');
    const allDetailed = answers.every(a => a.trim().length > 10);
    const newScore = allDetailed ? 100 : allAnswered ? 50 : 0;
    setScore(newScore);
    setAssessmentScores(prev => ({ ...prev, [openAssessment.id]: newScore }));
    setSubmitted(true);
  };

  const handleAddScoreToProfile = () => {
    setSnackbarOpen(true);
  };

  return (
    <Box sx={{ p: { xs: 2, md: 4 }, maxWidth: 1100, mx: 'auto', bgcolor: '#f7fafd', minHeight: '100vh' }}>
      {/* Header Section */}
      <Box sx={{ mb: 4, p: 3, bgcolor: navyBlue, borderRadius: 2, color: 'white' }}>
        <Typography variant="h4" sx={{ fontWeight: 700, mb: 1, color: 'white' }}>
          Profile Views & Assessments
        </Typography>
        <Typography variant="subtitle1" sx={{ color: 'white' }}>
          See which companies viewed your profile and test your skills with online assessments
        </Typography>
      </Box>
      {/* Stats Section */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={4}>
          <Paper elevation={2} sx={{ p: 3, display: 'flex', alignItems: 'center', gap: 2, borderRadius: 3 }}>
            <VisibilityIcon sx={{ fontSize: 40, color: '#0A1929' }} />
            <Box>
              <Typography variant="h6">Total Companies</Typography>
              <Typography variant="h4" sx={{ fontWeight: 700 }}>{totalCompanies}</Typography>
            </Box>
          </Paper>
        </Grid>
        <Grid item xs={12} md={4}>
          <Paper elevation={2} sx={{ p: 3, display: 'flex', alignItems: 'center', gap: 2, borderRadius: 3 }}>
            <DateRangeIcon sx={{ fontSize: 40, color: '#0A1929' }} />
            <Box>
              <Typography variant="h6">Most Recent View</Typography>
              <Typography variant="h5">{mostRecentView}</Typography>
            </Box>
          </Paper>
        </Grid>
        <Grid item xs={12} md={4}>
          <Paper elevation={2} sx={{ p: 3, display: 'flex', alignItems: 'center', gap: 2, borderRadius: 3 }}>
            <AssignmentTurnedInIcon sx={{ fontSize: 40, color: '#0A1929' }} />
            <Box>
              <Typography variant="h6">Assessments Taken</Typography>
              <Typography variant="h4" sx={{ fontWeight: 700 }}>{totalAssessmentsTaken}</Typography>
            </Box>
          </Paper>
        </Grid>
      </Grid>

      {/* Companies List Section */}
      <Typography variant="h5" sx={{ fontWeight: 600, mb: 2, color: '#222' }}>
        Companies That Viewed Your Profile
      </Typography>
      <Grid container spacing={3} sx={{ mb: 5 }}>
        {companiesViewed.map((c, idx) => (
          <Grid item xs={12} sm={6} md={4} key={idx}>
            <Card elevation={3} sx={{ borderRadius: 3, p: 2, display: 'flex', alignItems: 'center', gap: 2, bgcolor: '#fff' }}>
              <Avatar sx={{ width: 56, height: 56, bgcolor: '#e3e6f0', color: '#0A1929', fontWeight: 700, fontSize: 28 }}>
                {c.name.split(' ').map(w => w[0]).join('').substring(0, 2)}
              </Avatar>
              <Box sx={{ flex: 1 }}>
                <Typography variant="h6" sx={{ fontWeight: 600 }}>{c.name}</Typography>
                <Typography variant="body2" color="text.secondary">{c.industry}</Typography>
                <Typography variant="caption" color="primary">Viewed at: {c.viewedAt}</Typography>
              </Box>
            </Card>
          </Grid>
        ))}
        {companiesViewed.length === 0 && (
          <Grid item xs={12}>
            <Paper sx={{ p: 4, textAlign: 'center', color: '#888' }}>
              No companies have viewed your profile yet.
            </Paper>
          </Grid>
        )}
      </Grid>

      {/* Assessments Section */}
      <Divider sx={{ my: 4 }}>
        <Chip label="Online Assessments" sx={{ bgcolor: '#0A1929', color: 'white', fontWeight: 600 }} icon={<AssessmentIcon sx={{ color: 'white' }} />} />
      </Divider>
      <Box>
        <Typography variant="h5" sx={{ mb: 2, fontWeight: 600, color: '#222' }}>
          Take an Assessment
        </Typography>
        <List>
          {assessments.map((a) => (
            <ListItem key={a.id} sx={{ mb: 2, bgcolor: '#f5f7fa', borderRadius: 2, boxShadow: 1 }}
              secondaryAction={
                <Box sx={{ display: 'flex', gap: 1 }}>
                  <Button variant="contained" color="primary" onClick={() => handleOpenAssessment(a)}
                    sx={{
                      bgcolor: '#0A1929',
                      color: 'white',
                      '&:hover': {
                        bgcolor: '#16243a',
                      },
                    }}
                  >
                    Take Assessment
                  </Button>
                  <Button variant="outlined" color="success" disabled>
                    Score: {assessmentScores[a.id] !== undefined ? assessmentScores[a.id] : '--'}
                  </Button>
                  <Button
                    variant="contained"
                    color="success"
                    onClick={handleAddScoreToProfile}
                    disabled={assessmentScores[a.id] === undefined}
                  >
                    Add Score to Profile
                  </Button>
                </Box>
              }
            >
              <ListItemText
                primary={<span style={{ fontWeight: 500 }}>{a.title}</span>}
                secondary="Test your knowledge and get instant feedback."
              />
            </ListItem>
          ))}
        </List>
      </Box>

      {/* Assessment Dialog */}
      <Dialog open={!!openAssessment} onClose={handleCloseAssessment} maxWidth="sm" fullWidth>
        <DialogTitle>
          <AssessmentIcon sx={{ mr: 1, color: 'primary.main' }} />
          {openAssessment?.title}
        </DialogTitle>
        <DialogContent dividers>
          {!submitted ? (
            <Box>
              {openAssessment?.questions.map((q, idx) => (
                <Box key={idx} sx={{ mb: 3 }}>
                  <Typography variant="subtitle1" sx={{ mb: 1 }}>{q.q}</Typography>
                  <TextField
                    fullWidth
                    multiline
                    minRows={2}
                    value={answers[idx] || ''}
                    onChange={e => handleAnswerChange(idx, e.target.value)}
                    placeholder="Type your answer..."
                  />
                </Box>
              ))}
            </Box>
          ) : (
            <Alert severity={score === 100 ? 'success' : score === 50 ? 'warning' : 'error'} sx={{ mb: 2 }}>
              {score === 100 && <><CheckCircleIcon sx={{ verticalAlign: 'middle', mr: 1 }} />Excellent! You scored 100%.</>}
              {score === 50 && <>Good effort! You scored 50%. Try to provide more detailed answers next time.</>}
              {score === 0 && <>Please answer all questions to get a score.</>}
            </Alert>
          )}
        </DialogContent>
        <DialogActions>
          {!submitted ? (
            <Button onClick={handleSubmitAssessment} variant="contained" color="success">
              Submit Assessment
            </Button>
          ) : (
            <Button onClick={handleCloseAssessment} variant="outlined" color="primary">
              Close
            </Button>
          )}
        </DialogActions>
      </Dialog>

      <Snackbar
        open={snackbarOpen}
        autoHideDuration={3000}
        onClose={() => setSnackbarOpen(false)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert onClose={() => setSnackbarOpen(false)} severity="success" sx={{ width: '100%' }}>
          Score added to your profile!
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default ProfileViews; 