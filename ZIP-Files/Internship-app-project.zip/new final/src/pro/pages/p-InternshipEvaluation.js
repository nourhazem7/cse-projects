import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import {
  Box,
  Typography,
  Paper,
  TextField,
  Grid,
  Button,
  Rating,
  FormControlLabel,
  Switch,
  Divider,
  IconButton,
  Snackbar,
  Alert,
} from '@mui/material';
import {
  ArrowBack as ArrowBackIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
} from '@mui/icons-material';

// Theme colors
const navyBlue = '#0A1929';

// This would come from your API in a real application
const getInternshipById = (id) => {
  // Load internship from localStorage
  const internships = JSON.parse(localStorage.getItem('internships') || '[]');
  const internship = internships.find(i => i.id === parseInt(id));
  
  if (!internship) {
    return null;
  }

  // Add the status getter
  return {
    ...internship,
    get status() {
      return getInternshipStatus(this.startDate, this.endDate);
    }
  };
};

// Helper function to determine internship status
const getInternshipStatus = (startDate, endDate) => {
  const today = new Date();
  const end = new Date(endDate);

  if (today > end) {
    return 'completed';
  } else {
    return 'current';
  }
};

function InternshipEvaluation() {
  const { internshipId } = useParams();
  const [searchParams] = useSearchParams();
  const isEditMode = searchParams.get('mode') === 'edit';
  const navigate = useNavigate();
  const [internship, setInternship] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [evaluation, setEvaluation] = useState({
    rating: 0,
    review: '',
    recommendToOthers: false,
    courses: '',
    createdAt: null
  });
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'error' });

  useEffect(() => {
    // Remove restriction for deleted evaluations so user can always create a new one
    // const deletedEvaluations = JSON.parse(localStorage.getItem('deletedEvaluations') || '[]');
    // if (deletedEvaluations.includes(parseInt(internshipId))) {
    //   alert('This evaluation has been deleted and cannot be accessed.');
    //   navigate('/pro/internship-management');
    //   return;
    // }

    // Rest of your existing useEffect code...
    const fetchedInternship = getInternshipById(internshipId);
    
    // Check for existing evaluation in localStorage
    const savedEvaluations = JSON.parse(localStorage.getItem('internshipEvaluations') || '{}');
    const savedEvaluation = savedEvaluations[internshipId];
    
    if (savedEvaluation) {
      fetchedInternship.evaluation = savedEvaluation;
    }
    
    setInternship(fetchedInternship);
    if (fetchedInternship.evaluation) {
      setEvaluation(fetchedInternship.evaluation);
      setIsEditing(false); // Start in view mode
    } else {
      setIsEditing(true); // Start in edit mode for new evaluations
    }
  }, [internshipId, navigate]);

  const handleSave = () => {
    if (!validateEvaluation()) {
      return;
    }

    const updatedEvaluation = {
      ...evaluation,
      createdAt: evaluation.createdAt || new Date().toISOString()
    };

    // Save evaluation to localStorage
    const savedEvaluations = JSON.parse(localStorage.getItem('internshipEvaluations') || '{}');
    savedEvaluations[internshipId] = updatedEvaluation;
    localStorage.setItem('internshipEvaluations', JSON.stringify(savedEvaluations));

    // Update internship state
    setInternship(prev => ({
      ...prev,
      evaluation: updatedEvaluation
    }));
    setEvaluation(updatedEvaluation);
    setIsEditing(false);

    // Navigate back to management page after saving
    navigate('/pro/internship-management');
  };

  const handleDelete = () => {
    // Remove evaluation from localStorage
    const savedEvaluations = JSON.parse(localStorage.getItem('internshipEvaluations') || '{}');
    delete savedEvaluations[internshipId];
    localStorage.setItem('internshipEvaluations', JSON.stringify(savedEvaluations));

    // Navigate back to management page
    navigate('/pro/internship-management');
  };

  const validateEvaluation = () => {
    if (evaluation.rating === 0) {
      setSnackbar({ open: true, message: 'Please provide a rating', severity: 'error' });
      return false;
    }
    if (evaluation.review.trim().length < 50) {
      setSnackbar({ open: true, message: 'Please provide a review with at least 50 characters', severity: 'error' });
      return false;
    }
    if (!evaluation.courses.trim()) {
      setSnackbar({ open: true, message: 'Please specify at least one helpful course', severity: 'error' });
      return false;
    }
    return true;
  };

  if (!internship) {
    return <Typography>Loading...</Typography>;
  }

  return (
    <Box sx={{ flexGrow: 1 }}>
      {/* Header Section */}
      <Box sx={{ 
        mb: 4,
        p: 3,
        bgcolor: navyBlue,
        borderRadius: 2,
        color: 'white',
        display: 'flex',
        alignItems: 'center',
        gap: 2
      }}>
        <IconButton color="inherit" onClick={() => navigate('/pro/internship-management')}>
          <ArrowBackIcon />
        </IconButton>
        <Box>
          <Typography variant="h4" gutterBottom>
            {isEditMode ? 'Edit Evaluation' : (internship.evaluation ? 'View Evaluation' : 'Create Evaluation')}
          </Typography>
          <Typography variant="subtitle1">
            {internship.companyName} - {internship.jobTitle}
          </Typography>
        </Box>
      </Box>

      <Paper sx={{ p: 3 }}>
        {isEditing ? (
          // Evaluation Form
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <Typography component="legend">Rating *</Typography>
              <Rating
                value={evaluation.rating}
                onChange={(event, newValue) => {
                  setEvaluation(prev => ({ ...prev, rating: newValue }));
                }}
                size="large"
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                multiline
                rows={4}
                label="Review"
                value={evaluation.review}
                onChange={(e) => setEvaluation(prev => ({ ...prev, review: e.target.value }))}
                helperText="Minimum 50 characters required"
              />
            </Grid>
            <Grid item xs={12}>
              <FormControlLabel
                control={
                  <Switch
                    checked={evaluation.recommendToOthers}
                    onChange={(e) => setEvaluation(prev => ({ ...prev, recommendToOthers: e.target.checked }))}
                  />
                }
                label="Recommend to other students"
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                label="Helpful Courses"
                placeholder="Enter course codes separated by commas (e.g., CS101, CS202)"
                value={evaluation.courses}
                onChange={(e) => setEvaluation(prev => ({ ...prev, courses: e.target.value }))}
                helperText="List the courses that helped you during this internship"
              />
            </Grid>
            <Grid item xs={12} sx={{ display: 'flex', gap: 2 }}>
              <Button variant="outlined" onClick={() => navigate('/pro/internship-management')}>
                Cancel
              </Button>
              <Button variant="contained" onClick={handleSave}>
                Save Evaluation
              </Button>
            </Grid>
          </Grid>
        ) : (
          // Evaluation Display
          <Box>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1, mb: 2 }}>
              <Button
                startIcon={<EditIcon />}
                onClick={() => setIsEditing(true)}
                variant="outlined"
              >
                Edit
              </Button>
              <Button
                startIcon={<DeleteIcon />}
                onClick={handleDelete}
                variant="contained"
                color="error"
              >
                Delete
              </Button>
            </Box>
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <Typography component="legend">Rating</Typography>
                <Rating value={evaluation.rating} readOnly size="large" />
              </Grid>
              <Grid item xs={12}>
                <Typography variant="h6" gutterBottom>Review</Typography>
                <Typography paragraph>{evaluation.review}</Typography>
              </Grid>
              <Grid item xs={12}>
                <Typography variant="h6" gutterBottom>Recommendation</Typography>
                <Typography>{evaluation.recommendToOthers ? 'Recommends this internship' : 'Does not recommend this internship'}</Typography>
              </Grid>
              <Grid item xs={12}>
                <Typography variant="h6" gutterBottom>Helpful Courses</Typography>
                <Typography>{evaluation.courses}</Typography>
              </Grid>
              <Grid item xs={12}>
                <Divider />
                <Typography variant="caption" color="text.secondary" sx={{ mt: 2, display: 'block' }}>
                  Created on: {new Date(evaluation.createdAt).toLocaleString()}
                </Typography>
              </Grid>
            </Grid>
          </Box>
        )}
      </Paper>
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        <Alert elevation={6} variant="filled" severity={snackbar.severity} onClose={() => setSnackbar({ ...snackbar, open: false })}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}

export default InternshipEvaluation; 