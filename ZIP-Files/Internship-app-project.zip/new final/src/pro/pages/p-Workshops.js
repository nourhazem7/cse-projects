import React, { useState, useEffect } from 'react';
import { Box, Typography, Card, CardContent, CardActions, Button, Grid, Dialog, DialogTitle, DialogContent, DialogActions, Snackbar, Alert, Chip, Avatar, Badge, LinearProgress, TextField, IconButton, Rating, FormControlLabel, Switch } from '@mui/material';
import EventIcon from '@mui/icons-material/Event';
import InfoIcon from '@mui/icons-material/Info';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import VideoCallIcon from '@mui/icons-material/VideoCall';
import PlayCircleOutlineIcon from '@mui/icons-material/PlayCircleOutline';
import NoteIcon from '@mui/icons-material/Note';
import { useNavigate } from 'react-router-dom';
import WorkshopCall from './p-WorkshopCall'; // for shared dialog code if needed
import EmojiEventsIcon from '@mui/icons-material/EmojiEvents';

// Dummy data for workshops
const workshops = [
  {
    id: 1,
    title: 'Ace Your Online Interview',
    date: '2024-07-10',
    time: '16:00 - 17:30',
    description: 'Learn the best practices for online interviews, including technical setup, communication skills, and follow-up strategies.',
    presenter: 'Jane Doe, Career Coach',
    image: '',
    isLive: true,
    status: 'live', // live, upcoming, completed
    participants: 12
  },
  {
    id: 2,
    title: 'Building a Standout LinkedIn Profile',
    date: '2024-07-15',
    time: '14:00 - 15:00',
    description: 'Tips and tricks to optimize your LinkedIn profile and attract recruiters.',
    presenter: 'John Smith, HR Specialist',
    image: '',
    isLive: false,
    status: 'upcoming',
    participants: 0
  },
  {
    id: 3,
    title: 'Networking in the Digital Age',
    date: '2024-07-20',
    time: '18:00 - 19:30',
    description: 'Master the art of online networking and build valuable professional connections.',
    presenter: 'Emily Lee, Networking Expert',
    image: '',
    isLive: false,
    status: 'upcoming',
    participants: 0
  },
  {
    id: 4,
    title: 'Resume Writing Masterclass',
    date: '2024-06-01',
    time: '60 min',
    description: 'Learn how to create a compelling resume that stands out to employers.',
    presenter: 'Sarah Johnson, HR Director',
    image: 'https://img.youtube.com/vi/dQw4w9WgXcQ/maxresdefault.jpg',
    isLive: false,
    status: 'prerecorded',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '60:00'
  },
  {
    id: 5,
    title: 'Interview Preparation Guide',
    date: '2024-06-05',
    time: '45 min',
    description: 'Comprehensive guide to prepare for technical and behavioral interviews.',
    presenter: 'Michael Chen, Tech Recruiter',
    image: 'https://img.youtube.com/vi/dQw4w9WgXcQ/maxresdefault.jpg',
    isLive: false,
    status: 'prerecorded',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '45:00'
  },
  {
    id: 6,
    title: 'Career Development Strategies',
    date: '2024-06-10',
    time: '90 min',
    description: 'Long-term career planning and development strategies for tech professionals.',
    presenter: 'Lisa Wong, Career Coach',
    image: 'https://img.youtube.com/vi/dQw4w9WgXcQ/maxresdefault.jpg',
    isLive: false,
    status: 'prerecorded',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '90:00'
  }
];

const Workshops = () => {
  const [openDialog, setOpenDialog] = useState(null);
  const [registered, setRegistered] = useState({});
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMsg, setSnackbarMsg] = useState('');
  const [videoProgress, setVideoProgress] = useState({});
  const [workshopNotes, setWorkshopNotes] = useState({});
  const [showCertificate, setShowCertificate] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [feedback, setFeedback] = useState({
    rating: 0,
    review: '',
    recommendToOthers: true,
    helpfulTopics: ''
  });
  const [lastClosedWorkshop, setLastClosedWorkshop] = useState(null);
  const navigate = useNavigate();

  const handleViewDetails = (workshop) => {
    setOpenDialog(workshop);
    // Initialize video progress if it's a prerecorded workshop
    if (workshop.status === 'prerecorded' && !videoProgress[workshop.id]) {
      setVideoProgress(prev => ({
        ...prev,
        [workshop.id]: 0
      }));
    }
  };

  const handleCloseDialog = () => {
    if (openDialog?.status === 'prerecorded') {
      setLastClosedWorkshop(openDialog);
      setShowCertificate(true);
    }
    setOpenDialog(null);
  };

  const handleCloseCertificate = () => {
    setShowCertificate(false);
    setShowFeedback(true);
  };

  const handleCloseFeedback = () => {
    setShowFeedback(false);
    // Save feedback to localStorage
    const savedFeedback = JSON.parse(localStorage.getItem('workshopFeedback') || '{}');
    savedFeedback[new Date().toISOString()] = feedback;
    localStorage.setItem('workshopFeedback', JSON.stringify(savedFeedback));
  };

  const handleFeedbackChange = (field, value) => {
    setFeedback(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleRegister = (id) => {
    setRegistered(prev => ({ ...prev, [id]: true }));
    setSnackbarMsg('Successfully registered for the workshop!');
    setSnackbarOpen(true);
  };

  const handleJoinWorkshop = (workshop) => {
    if (workshop.isLive) {
      navigate('/pro/workshop-call');
    } else {
      setSnackbarMsg('This workshop is not live yet. Please wait for the scheduled time.');
      setSnackbarOpen(true);
    }
  };

  const handleVideoProgress = (workshopId, progress) => {
    setVideoProgress(prev => ({
      ...prev,
      [workshopId]: progress
    }));
  };

  const handleNotesChange = (workshopId, event) => {
    const newNotes = event.target.value;
    setWorkshopNotes(prev => ({
      ...prev,
      [workshopId]: newNotes
    }));
    // Save to localStorage
    localStorage.setItem(`workshopNotes_${workshopId}`, newNotes);
  };

  // Load saved notes when opening a workshop
  useEffect(() => {
    if (openDialog?.status === 'prerecorded') {
      const savedNotes = localStorage.getItem(`workshopNotes_${openDialog.id}`);
      if (savedNotes) {
        setWorkshopNotes(prev => ({
          ...prev,
          [openDialog.id]: savedNotes
        }));
      }
    }
  }, [openDialog]);

  // Find the next upcoming registered workshop
  useEffect(() => {
    const now = new Date();
    const registeredWorkshops = workshops.filter(w => registered[w.id]);
    if (registeredWorkshops.length > 0) {
      // Sort by date ascending
      registeredWorkshops.sort((a, b) => new Date(a.date) - new Date(b.date));
      const nextWorkshop = registeredWorkshops[0];
      setSnackbarMsg(`Receive a notification of an upcoming workshop you are registered in: ${nextWorkshop.title} on ${nextWorkshop.date} at ${nextWorkshop.time}`);
      setSnackbarOpen(true);
    }
    // Only show once per page load
    // eslint-disable-next-line
  }, []);

  const navyBlue = '#0A1929';
  const navyHover = '#16243a';
  const disabledGrey = '#e0e0e0';

  return (
    <Box sx={{ p: { xs: 2, md: 4 }, maxWidth: 1100, mx: 'auto', bgcolor: '#f7fafd', minHeight: '100vh' }}>
      <Box sx={{ mb: 4, p: 3, bgcolor: '#0A1929', borderRadius: 2, color: 'white' }}>
        <Typography variant="h4" sx={{ fontWeight: 700, mb: 1, color: 'white' }}>
          Upcoming Online Career Workshops
        </Typography>
        <Typography variant="subtitle1" sx={{ color: 'white' }}>
          Explore and register for upcoming workshops to boost your career skills
        </Typography>
        <Typography variant="subtitle2" sx={{ color: 'white', mt: 2 }}>
          You are registered for {Object.values(registered).filter(Boolean).length} workshop{Object.values(registered).filter(Boolean).length !== 1 ? 's' : ''}.
        </Typography>
      </Box>
      <Grid container spacing={3}>
        {workshops.map((w) => (
          <Grid item xs={12} sm={6} md={4} key={w.id}>
            <Card elevation={3} sx={{ borderRadius: 3, p: 2, bgcolor: '#fff', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Avatar sx={{ bgcolor: w.isLive ? '#4CAF50' : w.status === 'prerecorded' ? '#9c27b0' : '#1976d2', mr: 2 }}>
                    {w.isLive ? <VideoCallIcon /> : w.status === 'prerecorded' ? <PlayCircleOutlineIcon /> : <EventIcon />}
                  </Avatar>
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>{w.title}</Typography>
                </Box>
                <Box sx={{ display: 'flex', gap: 1, mb: 2, flexWrap: 'wrap' }}>
                  <Chip 
                    icon={<EventIcon />} 
                    label={w.date} 
                    sx={{ mb: 1 }} 
                  />
                  <Chip 
                    icon={<InfoIcon />} 
                    label={w.time} 
                    sx={{ mb: 1 }} 
                  />
                  {w.isLive && (
                    <Chip 
                      label="LIVE" 
                      color="success" 
                      sx={{ mb: 1 }}
                    />
                  )}
                  {w.status === 'prerecorded' && (
                    <Chip 
                      label="PRERECORDED" 
                      color="secondary" 
                      sx={{ mb: 1 }}
                    />
                  )}
                </Box>
                <Typography variant="body2" sx={{ mt: 2, mb: 1, color: '#444' }}>
                  {w.description.substring(0, 70)}{w.description.length > 70 ? '...' : ''}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  Presenter: {w.presenter}
                </Typography>
                {w.isLive && (
                  <Typography variant="caption" color="success" sx={{ display: 'block', mt: 1 }}>
                    {w.participants} participants currently in the workshop
                  </Typography>
                )}
                {w.status === 'prerecorded' && videoProgress[w.id] > 0 && (
                  <Box sx={{ mt: 1 }}>
                    <Typography variant="caption" color="text.secondary">
                      Progress: {Math.round(videoProgress[w.id] * 100)}%
                    </Typography>
                    <LinearProgress 
                      variant="determinate" 
                      value={videoProgress[w.id] * 100} 
                      sx={{ mt: 0.5 }}
                    />
                  </Box>
                )}
              </CardContent>
              <CardActions sx={{ justifyContent: 'space-between', mt: 1 }}>
                <Button 
                  size="small" 
                  variant="outlined"
                  onClick={() => handleViewDetails(w)}
                  sx={{
                    borderColor: navyBlue,
                    color: navyBlue,
                    fontWeight: 600,
                    borderRadius: 2,
                    textTransform: 'none',
                    '&:hover': { bgcolor: '#f5f7fa', borderColor: navyHover, color: navyHover },
                  }}
                >
                  View Details
                </Button>
                {w.isLive ? (
                  <Button
                    size="small"
                    variant="contained"
                    startIcon={<VideoCallIcon />}
                    onClick={() => handleJoinWorkshop(w)}
                    sx={{
                      bgcolor: navyBlue,
                      color: 'white',
                      fontWeight: 600,
                      borderRadius: 2,
                      textTransform: 'none',
                      boxShadow: 'none',
                      '&:hover': { bgcolor: navyHover },
                    }}
                  >
                    Join Now
                  </Button>
                ) : w.status === 'prerecorded' ? (
                  <Button
                    size="small"
                    variant="contained"
                    startIcon={<PlayCircleOutlineIcon />}
                    onClick={() => handleViewDetails(w)}
                    sx={{
                      bgcolor: navyBlue,
                      color: 'white',
                      fontWeight: 600,
                      borderRadius: 2,
                      textTransform: 'none',
                      boxShadow: 'none',
                      '&:hover': { bgcolor: navyHover },
                    }}
                  >
                    Watch Now
                  </Button>
                ) : (
                  <Button
                    size="small"
                    variant={registered[w.id] ? 'outlined' : 'contained'}
                    startIcon={registered[w.id] ? <CheckCircleIcon /> : null}
                    onClick={() => handleRegister(w.id)}
                    disabled={registered[w.id]}
                    sx={{
                      bgcolor: registered[w.id] ? 'transparent' : navyBlue,
                      color: registered[w.id] ? navyBlue : 'white',
                      borderColor: navyBlue,
                      fontWeight: 600,
                      borderRadius: 2,
                      textTransform: 'none',
                      boxShadow: 'none',
                      '&:hover': {
                        bgcolor: registered[w.id] ? '#f5f7fa' : navyHover,
                        color: navyHover,
                        borderColor: navyHover,
                      },
                    }}
                  >
                    {registered[w.id] ? 'Registered' : 'Register'}
                  </Button>
                )}
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>
      {/* Workshop Details Dialog */}
      <Dialog open={!!openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            {openDialog?.isLive ? (
              <>
                <VideoCallIcon color="success" />
                <Typography variant="h6">{openDialog?.title}</Typography>
                <Chip label="LIVE" color="success" size="small" />
              </>
            ) : openDialog?.status === 'prerecorded' ? (
              <>
                <PlayCircleOutlineIcon color="secondary" />
                <Typography variant="h6">{openDialog?.title}</Typography>
                <Chip label="PRERECORDED" color="secondary" size="small" />
              </>
            ) : (
              <>
                <EventIcon color="primary" />
                <Typography variant="h6">{openDialog?.title}</Typography>
              </>
            )}
          </Box>
        </DialogTitle>
        <DialogContent dividers>
          {openDialog?.status === 'prerecorded' ? (
            <Grid container spacing={2}>
              <Grid item xs={12} md={8}>
                <Box sx={{ width: '100%', mb: 2 }}>
                  <Box sx={{ position: 'relative', width: '100%', paddingTop: '56.25%' }}>
                    <iframe
                      style={{
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        width: '100%',
                        height: '100%',
                        border: 'none'
                      }}
                      src={`${openDialog.videoUrl}?autoplay=1`}
                      title={openDialog.title}
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                      onTimeUpdate={(e) => {
                        const video = e.target;
                        const progress = video.currentTime / video.duration;
                        handleVideoProgress(openDialog.id, progress);
                      }}
                    />
                  </Box>
                  {videoProgress[openDialog.id] > 0 && (
                    <Box sx={{ mt: 2 }}>
                      <Typography variant="body2" color="text.secondary">
                        Progress: {Math.round(videoProgress[openDialog.id] * 100)}%
                      </Typography>
                      <LinearProgress 
                        variant="determinate" 
                        value={videoProgress[openDialog.id] * 100} 
                        sx={{ mt: 0.5 }}
                      />
                    </Box>
                  )}
                </Box>
              </Grid>
              <Grid item xs={12} md={4}>
                <Box sx={{ 
                  p: 2, 
                  bgcolor: '#f5f5f5', 
                  borderRadius: 2,
                  height: '100%',
                  display: 'flex',
                  flexDirection: 'column'
                }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <NoteIcon sx={{ mr: 1, color: '#1976d2' }} />
                    <Typography variant="h6">Workshop Notes</Typography>
                  </Box>
                  <TextField
                    fullWidth
                    multiline
                    rows={12}
                    value={workshopNotes[openDialog.id] || ''}
                    onChange={(e) => handleNotesChange(openDialog.id, e)}
                    placeholder="Take notes during the workshop..."
                    variant="outlined"
                    sx={{
                      flexGrow: 1,
                      '& .MuiOutlinedInput-root': {
                        bgcolor: 'white',
                        '& fieldset': {
                          borderColor: 'rgba(0, 0, 0, 0.12)',
                        },
                        '&:hover fieldset': {
                          borderColor: 'rgba(0, 0, 0, 0.24)',
                        },
                        '&.Mui-focused fieldset': {
                          borderColor: '#1976d2',
                        },
                      },
                    }}
                  />
                </Box>
              </Grid>
            </Grid>
          ) : (
            <>
              <Typography variant="subtitle1" sx={{ mb: 2 }}>
                <EventIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
                {openDialog?.date} | {openDialog?.time}
              </Typography>
              <Typography variant="body1" sx={{ mb: 2 }}>{openDialog?.description}</Typography>
              <Typography variant="body2" color="text.secondary">
                Presenter: {openDialog?.presenter}
              </Typography>
              {openDialog?.isLive && (
                <Typography variant="body2" color="success" sx={{ mt: 2 }}>
                  {openDialog?.participants} participants currently in the workshop
                </Typography>
              )}
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} 
            variant="outlined"
            sx={{
              borderColor: navyBlue,
              color: navyBlue,
              fontWeight: 600,
              borderRadius: 2,
              textTransform: 'none',
              '&:hover': { bgcolor: '#f5f7fa', borderColor: navyHover, color: navyHover },
            }}
          >
            Close
          </Button>
          {openDialog?.isLive ? (
            <Button
              variant="contained"
              startIcon={<VideoCallIcon />}
              onClick={() => handleJoinWorkshop(openDialog)}
              sx={{
                bgcolor: navyBlue,
                color: 'white',
                fontWeight: 600,
                borderRadius: 2,
                textTransform: 'none',
                boxShadow: 'none',
                '&:hover': { bgcolor: navyHover },
              }}
            >
              Join Workshop
            </Button>
          ) : openDialog?.status === 'prerecorded' ? null : (
            <Button
              variant={registered[openDialog?.id] ? 'outlined' : 'contained'}
              startIcon={registered[openDialog?.id] ? <CheckCircleIcon /> : null}
              onClick={() => handleRegister(openDialog?.id)}
              disabled={registered[openDialog?.id]}
              sx={{
                bgcolor: registered[openDialog?.id] ? 'transparent' : navyBlue,
                color: registered[openDialog?.id] ? navyBlue : 'white',
                borderColor: navyBlue,
                fontWeight: 600,
                borderRadius: 2,
                textTransform: 'none',
                boxShadow: 'none',
                '&:hover': {
                  bgcolor: registered[openDialog?.id] ? '#f5f7fa' : navyHover,
                  color: navyHover,
                  borderColor: navyHover,
                },
              }}
            >
              {registered[openDialog?.id] ? 'Registered' : 'Register'}
            </Button>
          )}
        </DialogActions>
      </Dialog>
      {/* Certificate Dialog */}
      <Dialog 
        open={showCertificate} 
        onClose={handleCloseCertificate}
        maxWidth="sm"
        fullWidth
        PaperProps={{ sx: { borderRadius: 3, overflow: 'hidden', p: 0 } }}
      >
        <Box sx={{ bgcolor: '#0A1929', py: 3, textAlign: 'center' }}>
          <Typography variant="h4" sx={{ color: 'white', fontWeight: 700 }}>
            Congratulations! <span role="img" aria-label="party">🎉</span>
          </Typography>
        </Box>
        <DialogContent sx={{ textAlign: 'center', pt: 4, pb: 2 }}>
          <EmojiEventsIcon sx={{ fontSize: 60, color: '#FFD700', mb: 2 }} />
          <Typography variant="h5" sx={{ fontWeight: 'bold', mb: 1 }}>
            Certificate of Attendance
          </Typography>
          <Typography variant="subtitle1" sx={{ color: 'grey.700', mb: 3 }}>
            You have successfully attended this workshop as a <b>PRO</b> student.
          </Typography>
          <Box sx={{ bgcolor: '#f7fafd', borderRadius: 2, p: 3, mb: 3, display: 'inline-block', textAlign: 'left', mx: 'auto', minWidth: 280 }}>
            <Typography sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <span style={{ color: '#43a047', fontWeight: 'bold', marginRight: 8 }}>✓</span>
              <b>Workshop:</b> {lastClosedWorkshop?.title || '[Workshop Title]'}
            </Typography>
            <Typography sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <span style={{ color: '#43a047', fontWeight: 'bold', marginRight: 8 }}>✓</span>
              <b>Date:</b> {lastClosedWorkshop?.date || new Date().toLocaleDateString()}
            </Typography>
            <Typography sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <span style={{ color: '#43a047', fontWeight: 'bold', marginRight: 8 }}>✓</span>
              <b>Duration:</b> {lastClosedWorkshop?.duration || '2 hours'}
            </Typography>
            <Typography sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <span style={{ color: '#43a047', fontWeight: 'bold', marginRight: 8 }}>✓</span>
              <b>Presenter:</b> {lastClosedWorkshop?.presenter || '[Presenter Name]'}
            </Typography>
          </Box>
        </DialogContent>
        <DialogActions sx={{ justifyContent: 'center', pb: 4 }}>
          <Button 
            variant="contained" 
            onClick={handleCloseCertificate}
            sx={{ 
              bgcolor: '#0A1929', 
              color: 'white',
              fontWeight: 'bold',
              fontSize: '1.1rem',
              px: 5,
              py: 1.5,
              borderRadius: 2,
              '&:hover': { bgcolor: '#16243a' }
            }}
          >
            Continue to Feedback
          </Button>
        </DialogActions>
      </Dialog>
      {/* Feedback Dialog */}
      <Dialog 
        open={showFeedback} 
        onClose={handleCloseFeedback}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>
          <Typography variant="h5" sx={{ fontWeight: 'bold' }}>
            Workshop Feedback
          </Typography>
        </DialogTitle>
        <DialogContent>
          <Box sx={{ py: 2 }}>
            <Typography component="legend" sx={{ mb: 1 }}>How would you rate this workshop?</Typography>
            <Rating
              value={feedback.rating}
              onChange={(event, newValue) => handleFeedbackChange('rating', newValue)}
              size="large"
              sx={{ mb: 3 }}
            />
            <TextField
              fullWidth
              multiline
              rows={4}
              label="Your Review"
              value={feedback.review}
              onChange={(e) => handleFeedbackChange('review', e.target.value)}
              placeholder="Share your experience and what you learned..."
              sx={{ mb: 3 }}
            />
            <TextField
              fullWidth
              label="Most Helpful Topics"
              value={feedback.helpfulTopics}
              onChange={(e) => handleFeedbackChange('helpfulTopics', e.target.value)}
              placeholder="What topics or aspects of the workshop were most valuable to you?"
              sx={{ mb: 3 }}
            />
            <FormControlLabel
              control={
                <Switch
                  checked={feedback.recommendToOthers}
                  onChange={(e) => handleFeedbackChange('recommendToOthers', e.target.checked)}
                />
              }
              label="I would recommend this workshop to others"
              sx={{ mb: 2 }}
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button 
            onClick={handleCloseFeedback} 
            variant="contained"
            sx={{ 
              bgcolor: '#0A1929', 
              color: 'white',
              fontWeight: 'bold',
              px: 4,
              borderRadius: 2,
              '&:hover': { bgcolor: '#16243a' }
            }}
          >
            Submit Feedback
          </Button>
        </DialogActions>
      </Dialog>
      {/* Snackbar for notifications */}
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={3000}
        onClose={() => setSnackbarOpen(false)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert onClose={() => setSnackbarOpen(false)} severity="success" sx={{ width: '100%' }}>
          {snackbarMsg}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default Workshops; 