import React from 'react';
import {
  Box,
  Typography,
  Paper,
  List,
  ListItem,
  ListItemText,
  Chip,
  Stepper,
  Step,
  StepLabel,
} from '@mui/material';

// Theme colors
const navyBlue = '#0A1929';

// Dummy data for applications
const applications = [
  {
    id: 1,
    company: 'Tech Solutions Inc.',
    position: 'Software Engineering Intern',
    status: 'Under Review',
    appliedDate: '2024-03-20',
    currentStep: 1,
    steps: ['Applied', 'Under Review', 'Interview', 'Decision'],
  },
  {
    id: 2,
    company: 'Digital Marketing Pro',
    position: 'Marketing Intern',
    status: 'Interview Scheduled',
    appliedDate: '2024-03-15',
    currentStep: 2,
    steps: ['Applied', 'Under Review', 'Interview', 'Decision'],
  },
];

function ApplicationStatus() {
  return (
    <Box sx={{ flexGrow: 1 }}>
      {/* Header Section */}
      <Box sx={{ 
        mb: 4,
        p: 3,
        bgcolor: navyBlue,
        borderRadius: 2,
        color: 'white'
      }}>
        <Typography variant="h4" gutterBottom>
          Application Status
        </Typography>
        <Typography variant="subtitle1">
          Track the progress of your internship applications
        </Typography>
      </Box>

      {/* Applications List */}
      <List>
        {applications.map((application) => (
          <Paper key={application.id} sx={{ mb: 2 }}>
            <ListItem sx={{ flexDirection: 'column', alignItems: 'stretch' }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%', mb: 2 }}>
                <ListItemText
                  primary={application.position}
                  secondary={application.company}
                />
                <Box>
                  <Chip
                    label={application.status}
                    color={
                      application.status === 'Under Review'
                        ? 'warning'
                        : application.status === 'Interview Scheduled'
                        ? 'info'
                        : 'default'
                    }
                    sx={{ ml: 1 }}
                  />
                </Box>
              </Box>
              <Box sx={{ width: '100%', mb: 2 }}>
                <Typography variant="caption" color="text.secondary">
                  Applied on: {application.appliedDate}
                </Typography>
              </Box>
              <Box sx={{ width: '100%' }}>
                <Stepper activeStep={application.currentStep} alternativeLabel>
                  {application.steps.map((label) => (
                    <Step key={label}>
                      <StepLabel>{label}</StepLabel>
                    </Step>
                  ))}
                </Stepper>
              </Box>
            </ListItem>
          </Paper>
        ))}
      </List>
    </Box>
  );
}

export default ApplicationStatus; 