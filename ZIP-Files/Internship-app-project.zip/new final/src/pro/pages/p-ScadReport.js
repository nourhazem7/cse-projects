import React, { useState } from 'react';
import {
    Box,
    Typography,
    Button,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    TextField,
    Grid,
    Card,
    CardContent,
    CardActions,
    Chip,
    Alert,
    Divider,
} from '@mui/material';
import {
    Download as DownloadIcon,
    Preview as PreviewIcon,
    Flag as FlagIcon,
    Warning as WarningIcon,
    Check as CheckIcon,
    Description as DescriptionIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

// Theme colors
const navyBlue = '#0A1929';
const navyHover = '#16243a';
const disabledGrey = '#e0e0e0';

const ScadReport = () => {
    const navigate = useNavigate();
    const [openPreview, setOpenPreview] = useState(false);
    const [selectedReport, setSelectedReport] = useState(null);
    const [openAppeal, setOpenAppeal] = useState(false);
    const [appealMessage, setAppealMessage] = useState('');
    const [finishedInternships, setFinishedInternships] = useState([
        {
            id: 1,
            companyName: "Tech Corp",
            position: "Software Engineer Intern",
            duration: "3 months",
            startDate: "2023-06-01",
            endDate: "2023-08-31",
            status: "Completed",
            reportStatus: "Approved",
            reportGenerated: true,
            supervisor: "John Smith",
            department: "Software Development",
            workHours: "40 hours/week",
            tasks: [
                "Developed frontend features using React",
                "Implemented REST APIs",
                "Participated in code reviews"
            ],
            skills: ["React", "Node.js", "Git"],
            evaluation: {
                performance: 90,
                attendance: 95,
                teamwork: 88
            }
        },
        {
            id: 2,
            companyName: "Innovation Labs",
            position: "Data Science Intern",
            duration: "2 months",
            startDate: "2023-09-01",
            endDate: "2023-10-31",
            status: "Completed",
            reportStatus: "Flagged",
            reportGenerated: true,
            supervisor: "Sarah Johnson",
            department: "Data Analytics",
            workHours: "35 hours/week",
            tasks: [
                "Analyzed large datasets",
                "Created ML models",
                "Presented findings to stakeholders"
            ],
            skills: ["Python", "Machine Learning", "SQL"],
            evaluation: {
                performance: 85,
                attendance: 92,
                teamwork: 90
            },
            flagReason: "Insufficient documentation of daily tasks",
            hasAppealed: false
        },
        {
            id: 3,
            companyName: "Digital Solutions Inc",
            position: "Frontend Developer Intern",
            duration: "4 months",
            startDate: "2023-07-01",
            endDate: "2023-10-31",
            status: "Completed",
            reportStatus: "Rejected",
            reportGenerated: true,
            supervisor: "Mike Wilson",
            department: "Web Development",
            workHours: "40 hours/week",
            tasks: [
                "Built responsive web interfaces",
                "Optimized application performance",
                "Fixed UI/UX issues"
            ],
            skills: ["React", "CSS", "JavaScript"],
            evaluation: {
                performance: 65,
                attendance: 70,
                teamwork: 75
            },
            flagReason: "Poor performance and attendance issues",
            hasAppealed: false
        },
        {
            id: 4,
            companyName: "Cloud Systems Ltd",
            position: "Cloud Engineer Intern",
            duration: "3 months",
            startDate: "2023-08-01",
            endDate: "2023-10-31",
            status: "Completed",
            reportStatus: "Flagged",
            reportGenerated: true,
            supervisor: "Emma Brown",
            department: "Cloud Infrastructure",
            workHours: "35 hours/week",
            tasks: [
                "Managed cloud resources",
                "Implemented security protocols",
                "Automated deployment processes"
            ],
            skills: ["AWS", "Docker", "Kubernetes"],
            evaluation: {
                performance: 82,
                attendance: 88,
                teamwork: 85
            },
            flagReason: "Missing project documentation",
            hasAppealed: false
        }
    ]);

    // eslint-disable-next-line no-unused-vars
    const filteredInternships = finishedInternships;

    const handleDownloadReport = (internshipId) => {
        const internship = finishedInternships.find(i => i.id === internshipId);
        if (!internship) return;

        // Create report content
        const reportContent = `
SCAD Internship Report
----------------------
Company: ${internship.companyName}
Position: ${internship.position}
Duration: ${internship.duration}
Period: ${internship.startDate} to ${internship.endDate}
Department: ${internship.department}
Supervisor: ${internship.supervisor}

Work Details
-----------
Hours: ${internship.workHours}

Tasks & Responsibilities:
${internship.tasks.map(task => `- ${task}`).join('\n')}

Skills Developed:
${internship.skills.map(skill => `- ${skill}`).join('\n')}

Evaluation Scores
----------------
Performance: ${internship.evaluation.performance}%
Attendance: ${internship.evaluation.attendance}%
Teamwork: ${internship.evaluation.teamwork}%

Status: ${internship.reportStatus}
        `;

        // Create blob and download
        const blob = new Blob([reportContent], { type: 'text/plain' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `SCAD_Report_${internship.companyName.replace(/\s+/g, '_')}_${internship.id}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    };

    const handlePreviewReport = (internship) => {
        setSelectedReport(internship);
        setOpenPreview(true);
    };

    const handleClosePreview = () => {
        setOpenPreview(false);
    };

    const handleOpenAppeal = (internship) => {
        setSelectedReport(internship);
        setOpenAppeal(true);
    };

    const handleCloseAppeal = () => {
        setOpenAppeal(false);
        setAppealMessage('');
    };

    const handleSubmitAppeal = () => {
        setFinishedInternships(prevInternships =>
            prevInternships.map(internship =>
                internship.id === selectedReport.id
                    ? { ...internship, hasAppealed: true }
                    : internship
            )
        );
        handleCloseAppeal();
    };

    const getStatusChip = (status) => {
        let color;
        let icon;
        switch (status) {
            case 'Approved':
                color = 'success';
                icon = <CheckIcon />;
                break;
            case 'Flagged':
                color = 'warning';
                icon = <WarningIcon />;
                break;
            case 'Rejected':
                color = 'error';
                icon = <FlagIcon />;
                break;
            default:
                color = 'default';
                icon = null;
        }
        return (
            <Chip
                icon={icon}
                label={status}
                color={color}
                size="small"
                sx={{ fontWeight: 500 }}
            />
        );
    };

    // eslint-disable-next-line no-unused-vars
    const addStatusNotification = (report) => {
        const existingNotifications = JSON.parse(localStorage.getItem('notifications') || '[]');
        const newNotification = {
            id: Date.now(),
            title: "SCAD Report Status Update",
            message: `Your SCAD report for ${report.companyName} has been ${report.reportStatus.toLowerCase()}.`,
            type: "report",
            icon: report.reportStatus === 'Approved' ? <CheckIcon sx={{ color: '#4caf50' }} /> :
                  report.reportStatus === 'Flagged' ? <FlagIcon sx={{ color: '#ff9800' }} /> :
                  <WarningIcon sx={{ color: '#f44336' }} />,
            timestamp: "Just now",
            read: false,
            onClick: () => navigate('/pro/scad-reports')
        };
        
        const updatedNotifications = [newNotification, ...existingNotifications];
        localStorage.setItem('notifications', JSON.stringify(updatedNotifications));
    };

    return (
        <Box sx={{ flexGrow: 1 }}>
            {/* Header Section */}
            <Box sx={{ 
                mb: 4,
                p: 3,
                bgcolor: navyBlue,
                borderRadius: 2,
                color: 'white'
            }}>
                <Typography variant="h4" gutterBottom>
                    SCAD Reports
                </Typography>
                <Typography variant="subtitle1">
                    Generate and manage SCAD reports for your completed internships
                </Typography>
            </Box>

            {/* Reports Grid */}
            <Grid container spacing={3}>
                {finishedInternships.map((internship) => (
                    <Grid item xs={12} md={6} lg={4} key={internship.id}>
                        <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
                            <CardContent sx={{ flexGrow: 1 }}>
                                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                                    <Typography variant="h6" component="div">
                                        {internship.position}
                                    </Typography>
                                    {getStatusChip(internship.reportStatus)}
                                </Box>
                                
                                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                                    <DescriptionIcon sx={{ mr: 1, color: 'text.secondary' }} />
                                    <Typography color="text.secondary">
                                        {internship.companyName}
                                    </Typography>
                                </Box>

                                <Grid container spacing={2} sx={{ mb: 2 }}>
                                    <Grid item xs={6}>
                                        <Typography variant="body2" color="text.secondary">
                                            Start: {new Date(internship.startDate).toLocaleDateString()}
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <Typography variant="body2" color="text.secondary">
                                            End: {new Date(internship.endDate).toLocaleDateString()}
                                        </Typography>
                                    </Grid>
                                </Grid>

                                <Box sx={{ display: 'flex', gap: 1, mb: 2, flexWrap: 'wrap' }}>
                                    <Chip
                                        label={`${internship.workHours}`}
                                        size="small"
                                        color="primary"
                                        variant="outlined"
                                    />
                                    <Chip
                                        label={internship.department}
                                        size="small"
                                        color="primary"
                                        variant="outlined"
                                    />
                                </Box>

                                {internship.reportStatus === 'Flagged' && (
                                    <Alert severity="warning" sx={{ mb: 2 }}>
                                        {internship.flagReason}
                                    </Alert>
                                )}
                            </CardContent>
                            <CardActions sx={{ justifyContent: 'flex-end', p: 2, gap: 1 }}>
                                <Button
                                    size="small"
                                    startIcon={<PreviewIcon />}
                                    onClick={() => handlePreviewReport(internship)}
                                    variant="contained"
                                    sx={{
                                        bgcolor: navyBlue,
                                        color: 'white',
                                        fontWeight: 600,
                                        borderRadius: 2,
                                        px: 2.5,
                                        '&:hover': { bgcolor: navyHover },
                                        boxShadow: 'none',
                                        textTransform: 'none',
                                    }}
                                >
                                    Preview
                                </Button>
                                <Button
                                    size="small"
                                    startIcon={<DownloadIcon />}
                                    onClick={() => handleDownloadReport(internship.id)}
                                    variant="outlined"
                                    sx={{
                                        borderColor: navyBlue,
                                        color: navyBlue,
                                        fontWeight: 600,
                                        borderRadius: 2,
                                        px: 2.5,
                                        '&:hover': { bgcolor: '#f5f7fa', borderColor: navyHover, color: navyHover },
                                        textTransform: 'none',
                                    }}
                                >
                                    Download
                                </Button>
                                {(internship.reportStatus === 'Flagged' || internship.reportStatus === 'Rejected') && (
                                    <Button
                                        size="small"
                                        onClick={() => handleOpenAppeal(internship)}
                                        variant="contained"
                                        disabled={internship.hasAppealed}
                                        sx={{
                                            bgcolor: internship.hasAppealed ? disabledGrey : navyBlue,
                                            color: internship.hasAppealed ? '#888' : 'white',
                                            fontWeight: 600,
                                            borderRadius: 2,
                                            px: 2.5,
                                            '&:hover': {
                                                bgcolor: internship.hasAppealed ? disabledGrey : navyHover,
                                            },
                                            textTransform: 'none',
                                        }}
                                    >
                                        {internship.hasAppealed ? 'Appealed' : 'Appeal'}
                                    </Button>
                                )}
                            </CardActions>
                        </Card>
                    </Grid>
                ))}
            </Grid>

            {/* Preview Dialog */}
            <Dialog
                open={openPreview}
                onClose={handleClosePreview}
                maxWidth="md"
                fullWidth
            >
                <DialogTitle>
                    SCAD Report Preview
                </DialogTitle>
                <DialogContent dividers>
                    {selectedReport && (
                        <Box sx={{ p: 2 }}>
                            <Typography variant="h5" gutterBottom>
                                {selectedReport.companyName}
                            </Typography>
                            <Divider sx={{ my: 2 }} />
                            
                            <Grid container spacing={3}>
                                <Grid item xs={12} md={6}>
                                    <Typography variant="subtitle1" gutterBottom>
                                        Internship Details
                                    </Typography>
                                    <Typography variant="body2" paragraph>
                                        Position: {selectedReport.position}
                                    </Typography>
                                    <Typography variant="body2" paragraph>
                                        Department: {selectedReport.department}
                                    </Typography>
                                    <Typography variant="body2" paragraph>
                                        Duration: {selectedReport.duration}
                                    </Typography>
                                    <Typography variant="body2" paragraph>
                                        Period: {selectedReport.startDate} to {selectedReport.endDate}
                                    </Typography>
                                    <Typography variant="body2" paragraph>
                                        Work Hours: {selectedReport.workHours}
                                    </Typography>
                                </Grid>
                                
                                <Grid item xs={12} md={6}>
                                    <Typography variant="subtitle1" gutterBottom>
                                        Evaluation Scores
                                    </Typography>
                                    <Typography variant="body2" paragraph>
                                        Performance: {selectedReport.evaluation.performance}%
                                    </Typography>
                                    <Typography variant="body2" paragraph>
                                        Attendance: {selectedReport.evaluation.attendance}%
                                    </Typography>
                                    <Typography variant="body2" paragraph>
                                        Teamwork: {selectedReport.evaluation.teamwork}%
                                    </Typography>
                                </Grid>

                                <Grid item xs={12}>
                                    <Typography variant="subtitle1" gutterBottom>
                                        Tasks & Responsibilities
                                    </Typography>
                                    <ul>
                                        {selectedReport.tasks.map((task, index) => (
                                            <li key={index}>
                                                <Typography variant="body2">{task}</Typography>
                                            </li>
                                        ))}
                                    </ul>
                                </Grid>

                                <Grid item xs={12}>
                                    <Typography variant="subtitle1" gutterBottom>
                                        Skills Developed
                                    </Typography>
                                    <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                                        {selectedReport.skills.map((skill, index) => (
                                            <Chip key={index} label={skill} size="small" />
                                        ))}
                                    </Box>
                                </Grid>
                            </Grid>
                        </Box>
                    )}
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleClosePreview}>Close</Button>
                    <Button
                        variant="contained"
                        onClick={() => selectedReport && handleDownloadReport(selectedReport.id)}
                    >
                        Download
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Appeal Dialog */}
            <Dialog
                open={openAppeal}
                onClose={handleCloseAppeal}
                maxWidth="sm"
                fullWidth
            >
                <DialogTitle>
                    Submit Appeal
                </DialogTitle>
                <DialogContent dividers>
                    <Typography variant="body2" color="text.secondary" paragraph>
                        Please provide a detailed explanation for your appeal request.
                    </Typography>
                    {selectedReport?.flagReason && (
                        <Alert severity="info" sx={{ mb: 2 }}>
                            Reason for flag: {selectedReport.flagReason}
                        </Alert>
                    )}
                    <TextField
                        fullWidth
                        multiline
                        rows={4}
                        variant="outlined"
                        placeholder="Enter your appeal message here..."
                        value={appealMessage}
                        onChange={(e) => setAppealMessage(e.target.value)}
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseAppeal}>Cancel</Button>
                    <Button
                        variant="contained"
                        onClick={handleSubmitAppeal}
                        disabled={!appealMessage.trim()}
                    >
                        Submit Appeal
                    </Button>
                </DialogActions>
            </Dialog>
        </Box>
    );
};

export default ScadReport; 