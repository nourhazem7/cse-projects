import React, { useState } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  CardActions,
  Grid,
  Chip,
  Rating,
  Button,
  IconButton,
} from '@mui/material';
import {
  Business as BusinessIcon,
  BookmarkBorder as BookmarkBorderIcon,
  Bookmark as BookmarkIcon,
  People as PeopleIcon,
  Category as CategoryIcon,
  Percent as PercentIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

// Theme colors
const navyBlue = '#0A1929';

// Dummy data for companies (in a real app, this would come from an API)
const suggestedCompanies = [
  {
    id: 1,
    name: 'Tech Solutions Inc.',
    industry: 'Software Development',
    rating: 4.5,
    pastInterns: 12,
    interests: ['Web Development', 'AI/ML', 'Cloud Computing'],
    description: 'Leading software development company specializing in enterprise solutions.',
    matchScore: 95,
    isSaved: false
  },
  {
    id: 2,
    name: 'Digital Innovations',
    industry: 'Digital Marketing',
    rating: 4.2,
    pastInterns: 8,
    interests: ['Digital Marketing', 'Social Media', 'Content Creation'],
    description: 'Creative digital marketing agency working with global brands.',
    matchScore: 88,
    isSaved: false
  },
  {
    id: 3,
    name: 'DataTech Analytics',
    industry: 'Data Science',
    rating: 4.8,
    pastInterns: 15,
    interests: ['Data Science', 'Machine Learning', 'Big Data'],
    description: 'Data analytics firm providing insights for Fortune 500 companies.',
    matchScore: 92,
    isSaved: false
  }
];

function SuggestedCompanies() {
  const [savedCompanies, setSavedCompanies] = useState(
    suggestedCompanies.map(company => company.isSaved)
  );
  const navigate = useNavigate();

  const handleToggleSave = (index) => {
    setSavedCompanies(prev => {
      const newSaved = [...prev];
      newSaved[index] = !newSaved[index];
      return newSaved;
    });
  };

  return (
    <Box sx={{ flexGrow: 1 }}>
      {/* Header Section */}
      <Box sx={{ 
        mb: 4,
        p: 3,
        bgcolor: navyBlue,
        borderRadius: 2,
        color: 'white'
      }}>
        <Typography variant="h4" gutterBottom>
          Suggested Companies
        </Typography>
        <Typography variant="subtitle1">
          Find companies that match your interests and skills
        </Typography>
      </Box>

      <Typography variant="body1" color="text.secondary" sx={{ mb: 4 }}>
        Based on your interests and past intern recommendations
      </Typography>

      {/* Companies Grid */}
      <Grid container spacing={3}>
        {suggestedCompanies.map((company, index) => (
          <Grid item xs={12} md={6} lg={4} key={company.id}>
            <Card sx={{ 
              height: '100%',
              display: 'flex',
              flexDirection: 'column',
              position: 'relative',
              '&:hover': {
                boxShadow: 6,
              }
            }}>
              <CardContent sx={{ flexGrow: 1 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <BusinessIcon color="primary" />
                    <Typography variant="h6">
                      {company.name}
                    </Typography>
                  </Box>
                  <IconButton 
                    onClick={() => handleToggleSave(index)}
                    color="primary"
                    sx={{ p: 0.5 }}
                  >
                    {savedCompanies[index] ? <BookmarkIcon /> : <BookmarkBorderIcon />}
                  </IconButton>
                </Box>

                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <CategoryIcon sx={{ mr: 1, color: 'text.secondary', fontSize: '1rem' }} />
                  <Typography variant="body2" color="text.secondary">
                    {company.industry}
                  </Typography>
                </Box>

                <Typography variant="body2" color="text.secondary" paragraph>
                  {company.description}
                </Typography>

                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                  <Rating value={company.rating} precision={0.1} readOnly size="small" />
                  <Typography variant="body2" color="text.secondary">
                    ({company.rating})
                  </Typography>
                </Box>

                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <PeopleIcon sx={{ mr: 1, color: 'text.secondary', fontSize: '1rem' }} />
                  <Typography variant="body2" color="text.secondary">
                    {company.pastInterns} past interns
                  </Typography>
                </Box>

                <Box sx={{ mb: 2 }}>
                  <Typography variant="body2" color="text.secondary" gutterBottom>
                    Relevant to your interests:
                  </Typography>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                    {company.interests.map((interest, i) => (
                      <Chip
                        key={i}
                        label={interest}
                        size="small"
                        color="primary"
                        variant="outlined"
                      />
                    ))}
                  </Box>
                </Box>

                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <PercentIcon sx={{ color: 'success.main', fontSize: '1rem' }} />
                  <Typography variant="body2" color="success.main" sx={{ fontWeight: 'medium' }}>
                    {company.matchScore}% Match
                  </Typography>
                </Box>
              </CardContent>
              <CardActions sx={{ p: 2 }}>
                <Button
                  variant="contained"
                  fullWidth
                  sx={{ 
                    bgcolor: navyBlue,
                    '&:hover': {
                      bgcolor: 'rgba(10, 25, 41, 0.8)',
                    }
                  }}
                  onClick={() => navigate(`/pro/apply/${company.id}`)}
                >
                  Apply
                </Button>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}

export default SuggestedCompanies; 