import React, { useRef, useState, useEffect } from 'react';
import { Box, Button, IconButton, Typography, Paper, Grid, TextField, Tabs, Tab, List, ListItem, ListItemText, Divider, Dialog, DialogTitle, DialogContent, DialogActions, Rating, FormControlLabel, Switch } from '@mui/material';
import VideocamIcon from '@mui/icons-material/Videocam';
import VideocamOffIcon from '@mui/icons-material/VideocamOff';
import MicIcon from '@mui/icons-material/Mic';
import MicOffIcon from '@mui/icons-material/MicOff';
import CallEndIcon from '@mui/icons-material/CallEnd';
import ScreenShareIcon from '@mui/icons-material/ScreenShare';
import NoteIcon from '@mui/icons-material/Note';
import ChatIcon from '@mui/icons-material/Chat';
import MessageIcon from '@mui/icons-material/Message';
import EmojiEventsIcon from '@mui/icons-material/EmojiEvents';
import { useNavigate } from 'react-router-dom';
import Snackbar from '@mui/material/Snackbar';
import Alert from '@mui/material/Alert';
import Badge from '@mui/material/Badge';

const navyBlue = '#0A1929';

// Dummy attendees for simulation
const dummyAttendees = [
  { id: 1, name: 'John Doe' },
  { id: 2, name: 'Jane Smith' },
  { id: 3, name: 'Mike Johnson' },
  { id: 4, name: 'Sarah Williams' }
];

const WorkshopCall = () => {
  const videoRef = useRef(null);
  const [cameraOn, setCameraOn] = useState(true);
  const [micOn, setMicOn] = useState(true);
  const [stream, setStream] = useState(null);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const cameraStreamRef = useRef(null);
  const navigate = useNavigate();
  const [notes, setNotes] = useState('');
  const [tab, setTab] = useState(0);
  const [chatMessages, setChatMessages] = useState([]);
  const [chatInput, setChatInput] = useState('');
  const [showMessageNotification, setShowMessageNotification] = useState(false);
  const [messageNotification, setMessageNotification] = useState(null);
  const [unreadAttendeeMessages, setUnreadAttendeeMessages] = useState(0);
  const [showCertificate, setShowCertificate] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [feedback, setFeedback] = useState({
    rating: 0,
    review: '',
    recommendToOthers: true,
    helpfulTopics: ''
  });

  useEffect(() => {
    // Load notes from localStorage
    const savedNotes = localStorage.getItem('workshopCallNotes');
    if (savedNotes) setNotes(savedNotes);
    // Load chat from localStorage
    const savedChat = localStorage.getItem('workshopCallChat');
    if (savedChat) setChatMessages(JSON.parse(savedChat));
  }, []);

  useEffect(() => {
    // Save notes to localStorage
    localStorage.setItem('workshopCallNotes', notes);
  }, [notes]);

  useEffect(() => {
    // Save chat to localStorage
    localStorage.setItem('workshopCallChat', JSON.stringify(chatMessages));
  }, [chatMessages]);

  useEffect(() => {
    // Interval to add a simulated attendee message every 30 seconds
    const interval = setInterval(() => {
      const randomAttendee = dummyAttendees[Math.floor(Math.random() * dummyAttendees.length)];
      const attendeeMessage = {
        text: `This is a simulated message from ${randomAttendee.name}`,
        time: new Date().toLocaleTimeString(),
        sender: randomAttendee.name
      };
      setChatMessages(prev => [...prev, attendeeMessage]);
      setUnreadAttendeeMessages(prev => prev + 1);
      setMessageNotification({ sender: randomAttendee.name, message: attendeeMessage.text });
      setShowMessageNotification(false); // Reset in case it's already open
      setTimeout(() => setShowMessageNotification(true), 50); // Ensure Snackbar reopens
    }, 30000); // 30 seconds
    return () => clearInterval(interval);
  }, []);

  React.useEffect(() => {
    // Try to get user media
    if (cameraOn || micOn) {
      navigator.mediaDevices.getUserMedia({ video: cameraOn, audio: micOn })
        .then((mediaStream) => {
          setStream(mediaStream);
          if (videoRef.current && cameraOn) {
            videoRef.current.srcObject = mediaStream;
          }
        })
        .catch(() => {
          setStream(null);
        });
    } else {
      // Stop all tracks if both are off
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
        setStream(null);
      }
    }
    // Cleanup on unmount
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
    // eslint-disable-next-line
  }, [cameraOn, micOn]);

  const handleToggleCamera = () => {
    setCameraOn((prev) => !prev);
  };

  const handleToggleMic = () => {
    setMicOn((prev) => !prev);
  };

  const handleShareScreen = async () => {
    try {
      const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
      setIsScreenSharing(true);
      cameraStreamRef.current = stream; // Save the current camera stream
      setStream(screenStream);
      if (videoRef.current) {
        videoRef.current.srcObject = screenStream;
      }
      // When screen sharing ends, revert to camera
      screenStream.getVideoTracks()[0].addEventListener('ended', () => {
        setIsScreenSharing(false);
        if (cameraStreamRef.current) {
          setStream(cameraStreamRef.current);
          if (videoRef.current) {
            videoRef.current.srcObject = cameraStreamRef.current;
          }
        }
      });
    } catch (err) {
      // User cancelled or error
    }
  };

  const handleLeave = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
    }
    setShowCertificate(true);
  };

  const handleCloseCertificate = () => {
    setShowCertificate(false);
    setShowFeedback(true);
  };

  const handleCloseFeedback = () => {
    setShowFeedback(false);
    // Save feedback to localStorage
    const savedFeedback = JSON.parse(localStorage.getItem('workshopFeedback') || '{}');
    savedFeedback[new Date().toISOString()] = feedback;
    localStorage.setItem('workshopFeedback', JSON.stringify(savedFeedback));
    navigate('/pro/workshops');
  };

  const handleFeedbackChange = (field, value) => {
    setFeedback(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleTabChange = (event, newValue) => {
    setTab(newValue);
  };

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (chatInput.trim() === '') return;
    
    const newMessage = {
      text: chatInput,
      time: new Date().toLocaleTimeString(),
      sender: 'You'
    };
    
    setChatMessages([...chatMessages, newMessage]);
    setChatInput('');
    
    // Simulate receiving a message from a random attendee after a short delay
    setTimeout(() => {
      const randomAttendee = dummyAttendees[Math.floor(Math.random() * dummyAttendees.length)];
      const attendeeMessage = {
        text: `This is a simulated message from ${randomAttendee.name}`,
        time: new Date().toLocaleTimeString(),
        sender: randomAttendee.name
      };
      
      setChatMessages(prev => [...prev, attendeeMessage]);
      
      // Always show notification if user is not on the chat tab
      if (tab !== 1) {
        setMessageNotification({
          sender: randomAttendee.name,
          message: attendeeMessage.text
        });
        setShowMessageNotification(false); // Reset in case it's already open
        setTimeout(() => setShowMessageNotification(true), 50); // Ensure Snackbar reopens
        setUnreadAttendeeMessages(prev => prev + 1);
      }
    }, Math.random() * 5000 + 2000); // Random delay between 2-7 seconds
  };

  const handleCloseMessageNotification = () => {
    setShowMessageNotification(false);
  };

  return (
    <Box sx={{ minHeight: '100vh', bgcolor: navyBlue, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
      <Grid container spacing={3} sx={{ maxWidth: 1100, width: '100%' }}>
        <Grid item xs={12} md={7}>
          <Paper sx={{ p: 4, borderRadius: 3, bgcolor: '#16243a', color: 'white', minWidth: 320, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <Typography variant="h5" sx={{ mb: 2 }}>Workshop Live Call</Typography>
            <Box sx={{ width: 320, height: 240, bgcolor: '#222', borderRadius: 2, mb: 2, display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
              {cameraOn && stream ? (
                <video ref={videoRef} autoPlay playsInline style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              ) : (
                <Box sx={{ color: '#888', fontSize: 18 }}>Camera is Off</Box>
              )}
            </Box>
            <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
              <IconButton onClick={handleToggleCamera} color={cameraOn ? 'primary' : 'default'} sx={{ bgcolor: cameraOn ? '#1976d2' : '#555', color: 'white' }}>
                {cameraOn ? <VideocamIcon /> : <VideocamOffIcon />}
              </IconButton>
              <IconButton onClick={handleToggleMic} color={micOn ? 'primary' : 'default'} sx={{ bgcolor: micOn ? '#43a047' : '#555', color: 'white' }}>
                {micOn ? <MicIcon /> : <MicOffIcon />}
              </IconButton>
              <IconButton onClick={handleShareScreen} color={isScreenSharing ? 'secondary' : 'default'} sx={{ bgcolor: isScreenSharing ? '#ff9800' : '#555', color: 'white' }}>
                <ScreenShareIcon />
              </IconButton>
              <IconButton onClick={handleLeave} sx={{ bgcolor: '#d32f2f', color: 'white' }}>
                <CallEndIcon />
              </IconButton>
            </Box>
            <Typography variant="body2" color="#bbb">You can mute/unmute or turn your camera on/off during the call.</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} md={5}>
          <Paper sx={{ p: 0, borderRadius: 3, bgcolor: '#f5f5f5', minHeight: 320, display: 'flex', flexDirection: 'column', height: '100%' }}>
            <Tabs value={tab} onChange={handleTabChange} variant="fullWidth" sx={{ borderBottom: 1, borderColor: 'divider', bgcolor: 'white', borderTopLeftRadius: 3, borderTopRightRadius: 3 }}>
              <Tab icon={<NoteIcon />} label="Notes" />
              <Tab icon={
                <Badge color="error" variant="dot" invisible={unreadAttendeeMessages === 0}>
                  <ChatIcon />
                </Badge>
              } label="Chat" />
            </Tabs>
            {tab === 0 && (
              <Box sx={{ p: 3, flexGrow: 1, display: 'flex', flexDirection: 'column', height: '100%' }}>
                <Typography variant="h6" color="#0A1929" sx={{ mb: 2, display: 'flex', alignItems: 'center' }}>
                  <NoteIcon sx={{ mr: 1, color: '#1976d2' }} /> Workshop Notes
                </Typography>
                <TextField
                  fullWidth
                  multiline
                  rows={12}
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  placeholder="Take notes during the workshop call..."
                  variant="outlined"
                  sx={{
                    flexGrow: 1,
                    bgcolor: 'white',
                    '& .MuiOutlinedInput-root': {
                      bgcolor: 'white',
                      '& fieldset': {
                        borderColor: 'rgba(0, 0, 0, 0.12)',
                      },
                      '&:hover fieldset': {
                        borderColor: 'rgba(0, 0, 0, 0.24)',
                      },
                      '&.Mui-focused fieldset': {
                        borderColor: '#1976d2',
                      },
                    },
                  }}
                />
              </Box>
            )}
            {tab === 1 && (
              <Box sx={{ p: 3, flexGrow: 1, display: 'flex', flexDirection: 'column', height: '100%' }}>
                <Typography variant="h6" color="#0A1929" sx={{ mb: 2, display: 'flex', alignItems: 'center' }}>
                  <ChatIcon sx={{ mr: 1, color: '#1976d2' }} /> Chat
                </Typography>
                <Paper sx={{ flexGrow: 1, mb: 2, p: 1, bgcolor: 'white', maxHeight: 260, overflowY: 'auto' }} variant="outlined">
                  <List dense>
                    {chatMessages.length === 0 ? (
                      <ListItem>
                        <ListItemText primary={<Typography color="text.secondary">No messages yet. Start the conversation!</Typography>} />
                      </ListItem>
                    ) : (
                      chatMessages.map((msg, idx) => (
                        <ListItem key={idx} alignItems="flex-start">
                          <ListItemText
                            primary={msg.text}
                            secondary={<Typography variant="caption" color="text.secondary">{msg.time}</Typography>}
                          />
                        </ListItem>
                      ))
                    )}
                  </List>
                </Paper>
                <form onSubmit={handleSendMessage} style={{ display: 'flex', gap: 8 }}>
                  <TextField
                    value={chatInput}
                    onChange={e => setChatInput(e.target.value)}
                    placeholder="Type a message..."
                    size="small"
                    fullWidth
                  />
                  <Button type="submit" variant="contained" color="primary">Send</Button>
                </form>
              </Box>
            )}
          </Paper>
        </Grid>
      </Grid>
      {/* Message Notification Snackbar */}
      <Snackbar
        open={showMessageNotification}
        autoHideDuration={6000}
        onClose={handleCloseMessageNotification}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <Alert
          onClose={handleCloseMessageNotification}
          severity="info"
          sx={{ width: '100%' }}
          icon={<MessageIcon />}
        >
          <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>
            New message from {messageNotification?.sender}
          </Typography>
          <Typography variant="body2">
            {messageNotification?.message}
          </Typography>
        </Alert>
      </Snackbar>

      {/* Certificate Dialog */}
      <Dialog 
        open={showCertificate} 
        onClose={handleCloseCertificate}
        maxWidth="sm"
        fullWidth
        PaperProps={{
          sx: { borderRadius: 3, overflow: 'hidden', p: 0 }
        }}
      >
        {/* Navy Header */}
        <Box sx={{ bgcolor: '#0A1929', py: 3, textAlign: 'center' }}>
          <Typography variant="h4" sx={{ color: 'white', fontWeight: 700 }}>
            Congratulations! <span role="img" aria-label="party">🎉</span>
          </Typography>
        </Box>
        <DialogContent sx={{ textAlign: 'center', pt: 4, pb: 2 }}>
          {/* Gold Badge */}
          <EmojiEventsIcon sx={{ fontSize: 60, color: '#FFD700', mb: 2 }} />
          {/* Headline */}
          <Typography variant="h5" sx={{ fontWeight: 'bold', mb: 1 }}>
            Certificate of Attendance
          </Typography>
          {/* Subheadline */}
          <Typography variant="subtitle1" sx={{ color: 'grey.700', mb: 3 }}>
            You have successfully attended this workshop as a <b>PRO</b> student.
          </Typography>
          {/* Checklist Card */}
          <Box sx={{ bgcolor: '#f7fafd', borderRadius: 2, p: 3, mb: 3, display: 'inline-block', textAlign: 'left', mx: 'auto', minWidth: 280 }}>
            <Typography sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <span style={{ color: '#43a047', fontWeight: 'bold', marginRight: 8 }}>✓</span>
              <b>Workshop:</b> [Workshop Title]
            </Typography>
            <Typography sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <span style={{ color: '#43a047', fontWeight: 'bold', marginRight: 8 }}>✓</span>
              <b>Date:</b> {new Date().toLocaleDateString()}
            </Typography>
            <Typography sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <span style={{ color: '#43a047', fontWeight: 'bold', marginRight: 8 }}>✓</span>
              <b>Duration:</b> 2 hours
            </Typography>
            <Typography sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <span style={{ color: '#43a047', fontWeight: 'bold', marginRight: 8 }}>✓</span>
              <b>Presenter:</b> [Presenter Name]
            </Typography>
          </Box>
        </DialogContent>
        <DialogActions sx={{ justifyContent: 'center', pb: 4 }}>
          <Button 
            variant="contained" 
            onClick={handleCloseCertificate}
            sx={{ 
              bgcolor: '#0A1929', 
              color: 'white',
              fontWeight: 'bold',
              fontSize: '1.1rem',
              px: 5,
              py: 1.5,
              borderRadius: 2,
              '&:hover': {
                bgcolor: '#16243a'
              }
            }}
          >
            Continue to Feedback
          </Button>
        </DialogActions>
      </Dialog>

      {/* Feedback Dialog */}
      <Dialog 
        open={showFeedback} 
        onClose={handleCloseFeedback}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>
          <Typography variant="h5" sx={{ fontWeight: 'bold' }}>
            Workshop Feedback
          </Typography>
        </DialogTitle>
        <DialogContent>
          <Box sx={{ py: 2 }}>
            <Typography component="legend" sx={{ mb: 1 }}>How would you rate this workshop?</Typography>
            <Rating
              value={feedback.rating}
              onChange={(event, newValue) => handleFeedbackChange('rating', newValue)}
              size="large"
              sx={{ mb: 3 }}
            />
            <TextField
              fullWidth
              multiline
              rows={4}
              label="Your Review"
              value={feedback.review}
              onChange={(e) => handleFeedbackChange('review', e.target.value)}
              placeholder="Share your experience and what you learned..."
              sx={{ mb: 3 }}
            />
            <FormControlLabel
              control={
                <Switch
                  checked={feedback.recommendToOthers}
                  onChange={(e) => handleFeedbackChange('recommendToOthers', e.target.checked)}
                />
              }
              label="I would recommend this workshop to others"
              sx={{ mb: 3 }}
            />
            <TextField
              fullWidth
              label="Most Helpful Topics"
              value={feedback.helpfulTopics}
              onChange={(e) => handleFeedbackChange('helpfulTopics', e.target.value)}
              placeholder="What topics or aspects of the workshop were most valuable to you?"
              sx={{ mb: 2 }}
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseFeedback} color="primary">
            Submit Feedback
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default WorkshopCall; 