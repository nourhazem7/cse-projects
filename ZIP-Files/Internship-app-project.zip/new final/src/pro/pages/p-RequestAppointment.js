import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Paper,
  TextField,
  Button,
  MenuItem,
  Select,
  InputLabel,
  FormControl,
  Snackbar,
  Alert,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Tabs,
  Tab,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  IconButton,
  Badge,
} from '@mui/material';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import {
  AccessTime as AccessTimeIcon,
  VideoCall as VideoCallIcon,
  Check as CheckIcon,
  Close as CloseIcon,
  InfoOutlined as InfoIcon,
  Notifications as NotificationsIcon,
  Call as CallIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

const navyBlue = '#0A1929';
const navyHover = '#16243a';
const disabledGrey = '#e0e0e0';
const appointmentTypes = [
  'Career Guidance',
  'Report Clarification'
];

// Student-initiated appointments
const DUMMY_MY_APPOINTMENTS = [
  {
    id: 2,
    type: 'Report Clarification',
    dateTime: new Date(Date.now() + 2 * 86400000).toString(),
    notes: 'Clarify section 3.2 of the internship report requirements',
    status: 'Accepted',
    initiatedBy: 'student',
    scadStatus: 'offline'
  },
  {
    id: 1,
    type: 'Career Guidance',
    dateTime: new Date(Date.now() + 86400000).toString(),
    notes: 'Discuss internship options and career path after graduation',
    status: 'Pending',
    initiatedBy: 'student',
    scadStatus: 'online'
  },
  {
    id: 4,
    type: 'Report Clarification',
    dateTime: new Date(Date.now() - 1 * 86400000).toString(),
    notes: 'Need help with formatting of the final report',
    status: 'Accepted',
    initiatedBy: 'student',
    scadStatus: 'offline'
  },
  {
    id: 3,
    type: 'Career Guidance',
    dateTime: new Date(Date.now() + 3 * 86400000).toString(),
    notes: 'Need guidance on which companies to apply to for my major',
    status: 'Rejected',
    initiatedBy: 'student',
    rejectionReason: 'No available time slots on that day. Please request a different date.',
    scadStatus: 'online'
  }
];

// SCAD-initiated appointments
const DUMMY_SCAD_APPOINTMENTS = [
  {
    id: 102,
    type: 'Career Guidance',
    dateTime: new Date(Date.now() + 7 * 86400000).toString(),
    notes: 'Mandatory career guidance session for all final year students',
    status: 'Accepted',
    initiatedBy: 'scad',
    scadStatus: 'online'
  },
  {
    id: 101,
    type: 'Report Clarification',
    dateTime: new Date(Date.now() + 5 * 86400000).toString(),
    notes: 'Clarification needed on your last internship report (section 3.2)',
    status: 'Pending',
    initiatedBy: 'scad',
    scadStatus: 'online'
  },
  {
    id: 104,
    type: 'Career Guidance',
    dateTime: new Date(Date.now() + 5 * 86400000).toString(),
    notes: 'Discussion about your internship performance feedback',
    status: 'Pending',
    initiatedBy: 'scad',
    scadStatus: 'online'
  },
  {
    id: 103,
    type: 'Report Clarification',
    dateTime: new Date(Date.now() + 10 * 86400000).toString(),
    notes: 'Follow-up on your internship progress report',
    status: 'Rejected',
    initiatedBy: 'scad',
    rejectionReason: 'I have a class at this time',
    scadStatus: 'offline'
  }
];

const getAppointments = () => {
  const stored = localStorage.getItem('pro_appointments');
  if (!stored) {
    const combined = [...DUMMY_MY_APPOINTMENTS, ...DUMMY_SCAD_APPOINTMENTS];
    localStorage.setItem('pro_appointments', JSON.stringify(combined));
    return combined;
  }
  return JSON.parse(stored);
};

const saveAppointments = (appointments) => {
  localStorage.setItem('pro_appointments', JSON.stringify(appointments));
};

const RequestAppointment = () => {
  const [type, setType] = useState('Career Guidance');
  const [dateTime, setDateTime] = useState(null);
  const [notes, setNotes] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [appointments, setAppointments] = useState([]);
  const [tabValue, setTabValue] = useState(0);
  const [selectedAppointment, setSelectedAppointment] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');
  const [actionSuccess, setActionSuccess] = useState({ open: false, message: '', type: 'success' });
  const [incomingCall, setIncomingCall] = useState(null);
  const [showCallNotification, setShowCallNotification] = useState(false);
  const [hasShownNotification, setHasShownNotification] = useState(false);
  const navigate = useNavigate();

  // Initialize with dummy data on first render
  useEffect(() => {
    // Always use dummy data for demonstration purposes
    const dummyData = [...DUMMY_MY_APPOINTMENTS, ...DUMMY_SCAD_APPOINTMENTS];
    
    // Save to localStorage and state
    localStorage.setItem('pro_appointments', JSON.stringify(dummyData));
    setAppointments(dummyData);
  }, []);

  // Simulate incoming call once after 2 minutes
  useEffect(() => {
    if (!hasShownNotification) {
      const timer = setTimeout(() => {
        const randomAppointment = appointments.find(appt => 
          appt.status === 'Accepted' && 
          appt.initiatedBy === 'scad' && 
          appt.scadStatus === 'online'
        );

        if (randomAppointment) {
          setIncomingCall(randomAppointment);
          setShowCallNotification(true);
          setHasShownNotification(true);
        }
      }, 120000); // 2 minutes = 120000 milliseconds

      return () => clearTimeout(timer);
    }
  }, [appointments, hasShownNotification]);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newAppointment = {
      id: Date.now(),
      type,
      dateTime: dateTime ? dateTime.toString() : '',
      notes,
      status: 'Pending',
      initiatedBy: 'student',
      scadStatus: 'online' // Default to online for new appointments
    };
    const updated = [newAppointment, ...appointments];
    setAppointments(updated);
    saveAppointments(updated);
    setSubmitted(true);
    setType('Career Guidance');
    setDateTime(null);
    setNotes('');
  };

  const handleAction = (appt, action) => {
    if (action === 'view') {
      setSelectedAppointment(appt);
      setDialogOpen(true);
      return;
    }

    if (action === 'join') {
      // Redirect to the call page
      navigate('/pro/call');
      return;
    }

    // For accept/reject
    if (action === 'reject' && !rejectionReason) {
      setSelectedAppointment(appt);
      setDialogOpen(true);
      return;
    }

    const updated = appointments.map(item => {
      if (item.id === appt.id) {
        return {
          ...item,
          status: action === 'accept' ? 'Accepted' : 'Rejected',
          rejectionReason: action === 'reject' ? rejectionReason : undefined
        };
      }
      return item;
    });

    setAppointments(updated);
    saveAppointments(updated);
    
    setActionSuccess({
      open: true,
      message: `Appointment ${action === 'accept' ? 'accepted' : 'rejected'} successfully!`,
      type: 'success'
    });
    
    if (dialogOpen) {
      setDialogOpen(false);
      setRejectionReason('');
    }
  };

  const handleAcceptCall = () => {
    if (incomingCall) {
      setShowCallNotification(false);
      handleAction(incomingCall, 'join');
    }
  };

  const handleRejectCall = () => {
    setShowCallNotification(false);
    setIncomingCall(null);
  };

  // Filter appointments based on tab
  const studentInitiatedAppointments = appointments.filter(appt => appt.initiatedBy === 'student');
  const scadInitiatedAppointments = appointments.filter(appt => appt.initiatedBy === 'scad');

  // Count appointments by status
  const getAppointmentCounts = (appointments) => {
    return appointments.reduce((acc, appt) => {
      acc[appt.status] = (acc[appt.status] || 0) + 1;
      return acc;
    }, {});
  };

  const studentAppointmentCounts = getAppointmentCounts(studentInitiatedAppointments);
  const scadAppointmentCounts = getAppointmentCounts(scadInitiatedAppointments);

  // Add appointment counts to the tab labels
  const getTabLabel = (label, counts) => {
    const total = Object.values(counts).reduce((sum, count) => sum + count, 0);
    return `${label} (${total})`;
  };

  const getStatusChip = (status) => {
    if (status === 'Pending') {
      return <Chip size="small" icon={<AccessTimeIcon />} label="Pending" color="warning" />;
    } else if (status === 'Accepted') {
      return <Chip size="small" icon={<CheckIcon />} label="Accepted" color="success" />;
    } else if (status === 'Completed') {
      return <Chip size="small" icon={<CheckIcon />} label="Completed" color="info" />;
    } else {
      return <Chip size="small" icon={<CloseIcon />} label="Rejected" color="error" />;
    }
  };

  const getScadStatusChip = (status) => {
    if (status === 'online') {
      return <Chip size="small" label="SCAD Online" color="success" />;
    } else {
      return <Chip size="small" label="SCAD Offline" color="default" />;
    }
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      {/* Header Section */}
      <Box sx={{ mb: 4, p: 3, bgcolor: navyBlue, borderRadius: 2, color: 'white' }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Box>
            <Typography variant="h4" gutterBottom>
              Appointment Management
            </Typography>
            <Typography variant="subtitle1">
              Request, manage, and join appointments for career guidance and other services (PRO Feature)
            </Typography>
          </Box>
          <Badge badgeContent={incomingCall ? 1 : 0} color="error">
            <NotificationsIcon sx={{ fontSize: 30 }} />
          </Badge>
        </Box>
      </Box>

      {/* Tabs for switching between My Requests and SCAD Requests */}
      <Paper sx={{ mb: 4, borderRadius: 2 }}>
        <Tabs 
          value={tabValue} 
          onChange={handleTabChange}
          variant="fullWidth"
          sx={{ borderBottom: 1, borderColor: 'divider' }}
        >
          <Tab label={getTabLabel("My Appointment Requests", studentAppointmentCounts)} />
          <Tab label={getTabLabel("SCAD Appointment Requests", scadAppointmentCounts)} />
        </Tabs>
      </Paper>

      {/* Tab Content */}
      <Box sx={{ display: tabValue === 0 ? 'block' : 'none' }}>
        {/* Form Section - Only shown in the first tab */}
        <Paper sx={{ maxWidth: 600, mx: 'auto', p: 4, borderRadius: 2, boxShadow: 2, mb: 4 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
            <VideoCallIcon sx={{ mr: 1, color: '#0A1929', fontSize: 32 }} />
            <Typography variant="h5" sx={{ color: '#0A1929', fontWeight: 700, letterSpacing: 0.5 }}>
              Request a New Appointment
            </Typography>
          </Box>
          <form onSubmit={handleSubmit}>
            <FormControl fullWidth margin="normal">
              <InputLabel id="appointment-type-label">Appointment Type</InputLabel>
              <Select
                labelId="appointment-type-label"
                value={type}
                label="Appointment Type"
                onChange={e => setType(e.target.value)}
                required
              >
                {appointmentTypes.map(option => (
                  <MenuItem key={option} value={option}>{option}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl fullWidth margin="normal">
              <DateTimePicker
                label="Preferred Date & Time"
                value={dateTime}
                onChange={setDateTime}
                renderInput={(params) => <TextField {...params} required />}
              />
            </FormControl>
            <TextField
              label="Additional Notes"
              placeholder="Explain what you would like to discuss in this appointment..."
              multiline
              minRows={3}
              fullWidth
              margin="normal"
              value={notes}
              onChange={e => setNotes(e.target.value)}
            />
            <Button 
              type="submit" 
              variant="contained" 
              size="large"
              fullWidth 
              sx={{ 
                mt: 2, 
                py: 1.5,
                bgcolor: navyBlue,
                color: 'white',
                fontWeight: 600,
                borderRadius: 2,
                boxShadow: 'none',
                textTransform: 'none',
                '&:hover': { bgcolor: navyHover },
              }}
            >
              Submit Request
            </Button>
          </form>
        </Paper>

        {/* My Appointments Table */}
        <Paper sx={{ maxWidth: 1000, mx: 'auto', p: 3, borderRadius: 2, boxShadow: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
            <AccessTimeIcon sx={{ mr: 1, color: 'primary.main' }} />
            <Typography variant="h6">My Appointment Requests</Typography>
          </Box>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow sx={{ bgcolor: 'rgba(10, 25, 41, 0.05)' }}>
                  <TableCell>Type</TableCell>
                  <TableCell>Date & Time</TableCell>
                  <TableCell>Notes</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>SCAD Status</TableCell>
                  <TableCell align="center">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {studentInitiatedAppointments.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} align="center">No appointments yet.</TableCell>
                  </TableRow>
                )}
                {studentInitiatedAppointments.map((appt, index) => (
                  <TableRow 
                    key={appt.id} 
                    sx={{ '&:hover': { bgcolor: 'rgba(10, 25, 41, 0.02)' } }}
                  >
                    <TableCell><b>{appt.type}</b></TableCell>
                    <TableCell>{appt.dateTime ? new Date(appt.dateTime).toLocaleString() : ''}</TableCell>
                    <TableCell>{appt.notes.substring(0, 50)}{appt.notes.length > 50 ? '...' : ''}</TableCell>
                    <TableCell>{getStatusChip(appt.status)}</TableCell>
                    <TableCell>{getScadStatusChip(appt.scadStatus)}</TableCell>
                    <TableCell align="center">
                      <Box sx={{ display: 'flex', justifyContent: 'center', gap: 1 }}>
                        <Button
                          variant="contained"
                          size="small"
                          startIcon={<VideoCallIcon />}
                          disabled={studentInitiatedAppointments[index % 2 === 0 ? index + 1 : index - 1]?.status !== 'Accepted'}
                          onClick={() => handleAction(studentInitiatedAppointments[index % 2 === 0 ? index + 1 : index - 1], 'join')}
                          sx={{
                            minWidth: '100px',
                            bgcolor: studentInitiatedAppointments[index % 2 === 0 ? index + 1 : index - 1]?.status !== 'Accepted' ? disabledGrey : navyBlue,
                            color: studentInitiatedAppointments[index % 2 === 0 ? index + 1 : index - 1]?.status !== 'Accepted' ? '#888' : 'white',
                            fontWeight: 600,
                            borderRadius: 2,
                            boxShadow: 'none',
                            textTransform: 'none',
                            '&:hover': {
                              bgcolor: studentInitiatedAppointments[index % 2 === 0 ? index + 1 : index - 1]?.status !== 'Accepted' ? disabledGrey : navyHover,
                            },
                          }}
                        >
                          Join Call
                        </Button>
                        <IconButton 
                          color="info" 
                          size="small" 
                          onClick={() => handleAction(appt, 'view')}
                        >
                          <InfoIcon />
                        </IconButton>
                      </Box>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      </Box>

      {/* SCAD Appointments Tab */}
      <Box sx={{ display: tabValue === 1 ? 'block' : 'none' }}>
        <Paper sx={{ maxWidth: 1000, mx: 'auto', p: 3, borderRadius: 2, boxShadow: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
            <AccessTimeIcon sx={{ mr: 1, color: 'primary.main' }} />
            <Typography variant="h6">Requests from SCAD Office</Typography>
          </Box>
          <Typography variant="body2" color="text.secondary" paragraph>
            SCAD office may request appointments with you for various reasons such as clarifying report details, career guidance, or follow-up on your internship progress. You can accept or reject these requests.
          </Typography>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow sx={{ bgcolor: 'rgba(10, 25, 41, 0.05)' }}>
                  <TableCell>Type</TableCell>
                  <TableCell>Date & Time</TableCell>
                  <TableCell>Notes</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>SCAD Status</TableCell>
                  <TableCell align="center">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {scadInitiatedAppointments.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} align="center">No SCAD appointments yet.</TableCell>
                  </TableRow>
                )}
                {scadInitiatedAppointments.map((appt, index) => (
                  <TableRow 
                    key={appt.id}
                    sx={{ '&:hover': { bgcolor: 'rgba(10, 25, 41, 0.02)' } }}
                  >
                    <TableCell><b>{appt.type}</b></TableCell>
                    <TableCell>{appt.dateTime ? new Date(appt.dateTime).toLocaleString() : ''}</TableCell>
                    <TableCell>{appt.notes.substring(0, 50)}{appt.notes.length > 50 ? '...' : ''}</TableCell>
                    <TableCell>{getStatusChip(appt.status)}</TableCell>
                    <TableCell>{getScadStatusChip(appt.scadStatus)}</TableCell>
                    <TableCell align="center">
                      <Box sx={{ display: 'flex', justifyContent: 'center', gap: 1 }}>
                        {appt.status === 'Pending' ? (
                          <>
                            <Button
                              variant="contained"
                              size="small"
                              startIcon={<CheckIcon />}
                              onClick={() => handleAction(scadInitiatedAppointments[index % 2 === 0 ? index + 1 : index - 1], 'accept')}
                              sx={{
                                bgcolor: navyBlue,
                                color: 'white',
                                fontWeight: 600,
                                borderRadius: 2,
                                boxShadow: 'none',
                                textTransform: 'none',
                                '&:hover': { bgcolor: navyHover },
                              }}
                            >
                              Accept
                            </Button>
                            <Button
                              variant="outlined"
                              size="small"
                              startIcon={<CloseIcon />}
                              onClick={() => handleAction(scadInitiatedAppointments[index % 2 === 0 ? index + 1 : index - 1], 'reject')}
                              sx={{
                                borderColor: navyBlue,
                                color: navyBlue,
                                fontWeight: 600,
                                borderRadius: 2,
                                textTransform: 'none',
                                '&:hover': { bgcolor: '#f5f7fa', borderColor: navyHover, color: navyHover },
                              }}
                            >
                              Reject
                            </Button>
                          </>
                        ) : appt.status === 'Accepted' ? (
                          <Button
                            variant="contained"
                            color="success"
                            size="small"
                            startIcon={<VideoCallIcon />}
                            onClick={() => handleAction(scadInitiatedAppointments[index % 2 === 0 ? index + 1 : index - 1], 'join')}
                            sx={{
                              bgcolor: navyBlue,
                              color: 'white',
                              fontWeight: 600,
                              borderRadius: 2,
                              boxShadow: 'none',
                              textTransform: 'none',
                              '&:hover': { bgcolor: navyHover },
                            }}
                          >
                            Join Call
                          </Button>
                        ) : (
                          <Button
                            variant="outlined"
                            size="small"
                            onClick={() => handleAction(appt, 'view')}
                            sx={{
                              borderColor: navyBlue,
                              color: navyBlue,
                              fontWeight: 600,
                              borderRadius: 2,
                              textTransform: 'none',
                              '&:hover': { bgcolor: '#f5f7fa', borderColor: navyHover, color: navyHover },
                            }}
                          >
                            View Details
                          </Button>
                        )}
                      </Box>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      </Box>

      {/* Appointment Details/Rejection Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)}>
        {selectedAppointment && (
          <>
            <DialogTitle>
              {selectedAppointment.status === 'Rejected' ? 'Appointment Details' : 'Reject Appointment'}
            </DialogTitle>
            <DialogContent>
              {selectedAppointment.status === 'Rejected' ? (
                <>
                  <DialogContentText component="div">
                    <Box sx={{ mb: 2 }}>
                      <Typography variant="h6" gutterBottom>{selectedAppointment.type}</Typography>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        <b>Date & Time:</b> {new Date(selectedAppointment.dateTime).toLocaleString()}
                      </Typography>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        <b>Notes:</b> {selectedAppointment.notes}
                      </Typography>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        <b>Status:</b> {getStatusChip(selectedAppointment.status)}
                      </Typography>
                      {selectedAppointment.rejectionReason && (
                        <Box sx={{ mt: 2, p: 2, bgcolor: 'error.lighter', borderRadius: 1 }}>
                          <Typography variant="body2" color="error.main">
                            <b>Reason for rejection:</b> {selectedAppointment.rejectionReason}
                          </Typography>
                        </Box>
                      )}
                    </Box>
                  </DialogContentText>
                </>
              ) : (
                <>
                  <DialogContentText>
                    Please provide a reason for rejecting this appointment request.
                  </DialogContentText>
                  <TextField
                    autoFocus
                    margin="dense"
                    label="Reason for Rejection"
                    fullWidth
                    multiline
                    rows={3}
                    value={rejectionReason}
                    onChange={(e) => setRejectionReason(e.target.value)}
                    variant="outlined"
                  />
                </>
              )}
            </DialogContent>
            <DialogActions>
              <Button
                onClick={() => setDialogOpen(false)}
                sx={{
                  color: navyBlue,
                  fontWeight: 600,
                  borderRadius: 2,
                  textTransform: 'none',
                  '&:hover': { bgcolor: '#f5f7fa', color: navyHover },
                }}
              >
                {selectedAppointment && selectedAppointment.status === 'Rejected' ? 'Close' : 'Cancel'}
              </Button>
              {selectedAppointment.status !== 'Rejected' && (
                <Button
                  onClick={() => handleAction(selectedAppointment, 'reject')}
                  variant="contained"
                  disabled={!rejectionReason.trim()}
                  sx={{
                    bgcolor: !rejectionReason.trim() ? disabledGrey : navyBlue,
                    color: !rejectionReason.trim() ? '#888' : 'white',
                    fontWeight: 600,
                    borderRadius: 2,
                    boxShadow: 'none',
                    textTransform: 'none',
                    '&:hover': {
                      bgcolor: !rejectionReason.trim() ? disabledGrey : navyHover,
                    },
                  }}
                >
                  Submit Rejection
                </Button>
              )}
            </DialogActions>
          </>
        )}
      </Dialog>

      {/* Incoming Call Notification Dialog */}
      <Dialog 
        open={showCallNotification} 
        onClose={handleRejectCall}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle sx={{ bgcolor: 'primary.main', color: 'white' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <CallIcon />
            <Typography variant="h6">Incoming Call</Typography>
          </Box>
        </DialogTitle>
        <DialogContent sx={{ mt: 2 }}>
          {incomingCall && (
            <Box>
              <Typography variant="h6" gutterBottom>
                {incomingCall.type} Appointment
              </Typography>
              <Typography variant="body1" gutterBottom>
                SCAD is calling for your scheduled appointment
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Date & Time: {new Date(incomingCall.dateTime).toLocaleString()}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Notes: {incomingCall.notes}
              </Typography>
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ p: 2, gap: 1 }}>
          <Button
            variant="outlined"
            onClick={handleRejectCall}
            startIcon={<CloseIcon />}
          >
            Reject Call
          </Button>
          <Button
            variant="contained"
            color="success"
            onClick={handleAcceptCall}
            startIcon={<VideoCallIcon />}
          >
            Accept Call
          </Button>
        </DialogActions>
      </Dialog>

      {/* Success/Info Snackbar */}
      <Snackbar 
        open={submitted || actionSuccess.open} 
        autoHideDuration={4000} 
        onClose={() => {
          setSubmitted(false);
          setActionSuccess({ ...actionSuccess, open: false });
        }}
      >
        <Alert 
          onClose={() => {
            setSubmitted(false);
            setActionSuccess({ ...actionSuccess, open: false });
          }} 
          severity={actionSuccess.open ? actionSuccess.type : 'success'} 
          sx={{ width: '100%' }}
        >
          {actionSuccess.open ? actionSuccess.message : 'Appointment request submitted successfully!'}
        </Alert>
      </Snackbar>
    </LocalizationProvider>
  );
};

export default RequestAppointment; 