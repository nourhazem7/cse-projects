import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Checkbox,
  Button,
  Alert,
} from '@mui/material';
import PageHeader from '../components/p-PageHeader';

// Mock data for courses
const mockCourses = [
  { id: 1, code: 'CSEN401', name: 'Computer Programming', credits: 3, semester: 1 },
  { id: 2, code: 'CSEN402', name: 'Database Systems', credits: 3, semester: 2 },
  { id: 3, code: 'CSEN403', name: 'Software Engineering', credits: 3, semester: 3 },
  { id: 4, code: 'CSEN404', name: 'Web Development', credits: 3, semester: 4 },
  { id: 5, code: 'CSEN405', name: 'Mobile Development', credits: 3, semester: 5 },
  { id: 6, code: 'CSEN406', name: 'Cloud Computing', credits: 3, semester: 6 },
  { id: 7, code: 'CSEN407', name: 'Artificial Intelligence', credits: 3, semester: 7 },
  { id: 8, code: 'CSEN408', name: 'Machine Learning', credits: 3, semester: 8 },
];

function CourseSelection() {
  const [selectedCourses, setSelectedCourses] = useState([]);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  // Load saved selections if they exist
  useEffect(() => {
    const savedSelections = localStorage.getItem('selectedCourses');
    if (savedSelections) {
      setSelectedCourses(JSON.parse(savedSelections));
    }
  }, []);

  const handleToggleCourse = (courseId) => {
    setSelectedCourses(prev => {
      if (prev.includes(courseId)) {
        return prev.filter(id => id !== courseId);
      } else {
        return [...prev, courseId];
      }
    });
  };

  const handleSubmit = () => {
    if (selectedCourses.length === 0) {
      setError('Please select at least one course');
      return;
    }

    // In a real app, you would save to backend
    localStorage.setItem('selectedCourses', JSON.stringify(selectedCourses));
    setSuccess('Your course selections have been saved successfully!');
    setError('');
  };

  return (
    <Box sx={{ flexGrow: 1 }}>
      <PageHeader
        title="Course Selection"
        subtitle="Select courses that were relevant to your internship"
      />

      <Paper sx={{ p: 3 }}>
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
        {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}

        <Typography variant="body1" sx={{ mb: 3 }}>
          Please select the courses that helped you during your internship. This information will help future students in their course selection.
        </Typography>

        <TableContainer>
          <Table>
            <TableHead>
              <TableRow sx={{ bgcolor: '#0A1929' }}>
                <TableCell sx={{ color: 'white' }}>Select</TableCell>
                <TableCell sx={{ color: 'white' }}>Course Code</TableCell>
                <TableCell sx={{ color: 'white' }}>Course Name</TableCell>
                <TableCell sx={{ color: 'white' }}>Credits</TableCell>
                <TableCell sx={{ color: 'white' }}>Semester</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {mockCourses.map((course) => (
                <TableRow
                  key={course.id}
                  sx={{ '&:hover': { bgcolor: 'rgba(10, 25, 41, 0.04)' } }}
                >
                  <TableCell padding="checkbox">
                    <Checkbox
                      checked={selectedCourses.includes(course.id)}
                      onChange={() => handleToggleCourse(course.id)}
                    />
                  </TableCell>
                  <TableCell>{course.code}</TableCell>
                  <TableCell>{course.name}</TableCell>
                  <TableCell>{course.credits}</TableCell>
                  <TableCell>{course.semester}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        <Box sx={{ mt: 3, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="body2" color="text.secondary">
            Selected courses: {selectedCourses.length}
          </Typography>
          <Button
            variant="contained"
            onClick={handleSubmit}
            disabled={selectedCourses.length === 0}
          >
            Save Selected Courses
          </Button>
        </Box>
      </Paper>
    </Box>
  );
}

export default CourseSelection; 