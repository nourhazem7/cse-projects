import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function CompanyDocumentsUpload() {
  const [showSuccess, setShowSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const [files, setFiles] = useState({
    offerForm: null,
    jobDescription: null,
    responsibilities: null,
    timeline: null,
    taxDocument: null,
  });

  const handleFileChange = (e, field) => {
    setFiles({ ...files, [field]: e.target.files[0] });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 800));
    
    console.log('Uploaded files:', files);
    setShowSuccess(true);
    
    // Redirect to login after 2 seconds
    setTimeout(() => {
      navigate('/');
    }, 2000);
  };

  return (
    <div style={{ 
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px',
      backgroundColor: '#f8f9fa'
    }}>
      <div style={{
        backgroundColor: 'white',
        borderRadius: '12px',
        boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
        padding: '40px',
        width: '100%',
        maxWidth: '500px',
        position: 'relative'
      }}>
        <div style={{
          textAlign: 'center',
          marginBottom: '32px'
        }}>
          <h1 style={{ 
            color: '#0A1929',
            fontSize: '32px',
            fontWeight: '700',
            marginBottom: '8px',
            letterSpacing: '-0.5px'
          }}>Upload Internship Documents</h1>
          <p style={{ 
            color: '#666',
            fontSize: '15px',
            margin: 0
          }}>Please upload all required documents to complete your registration</p>
        </div>

        <form
          onSubmit={handleSubmit}
          style={{ 
            display: "flex", 
            flexDirection: "column", 
            gap: "20px"
          }}
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <label 
              htmlFor="offerForm" 
              style={{ 
                fontSize: '14px', 
                fontWeight: '500',
                color: '#444'
              }}
            >
              Internship Offer Form
            </label>
            <input 
              id="offerForm"
              type="file" 
              onChange={(e) => handleFileChange(e, 'offerForm')}
              required
              style={{
                padding: '12px 16px',
                border: '1px solid #dfe1e5',
                borderRadius: '8px',
                fontSize: '15px',
                width: '100%',
                transition: 'border-color 0.2s',
                outline: 'none',
                boxSizing: 'border-box'
              }}
              onFocus={(e) => e.target.style.borderColor = '#0A1929'}
              onBlur={(e) => e.target.style.borderColor = '#dfe1e5'}
            />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <label 
              htmlFor="jobDescription" 
              style={{ 
                fontSize: '14px', 
                fontWeight: '500',
                color: '#444'
              }}
            >
              Job Description
            </label>
            <input 
              id="jobDescription"
              type="file" 
              onChange={(e) => handleFileChange(e, 'jobDescription')}
              required
              style={{
                padding: '12px 16px',
                border: '1px solid #dfe1e5',
                borderRadius: '8px',
                fontSize: '15px',
                width: '100%',
                transition: 'border-color 0.2s',
                outline: 'none',
                boxSizing: 'border-box'
              }}
              onFocus={(e) => e.target.style.borderColor = '#0A1929'}
              onBlur={(e) => e.target.style.borderColor = '#dfe1e5'}
            />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <label 
              htmlFor="responsibilities" 
              style={{ 
                fontSize: '14px', 
                fontWeight: '500',
                color: '#444'
              }}
            >
              Responsibilities Outline
            </label>
            <input 
              id="responsibilities"
              type="file" 
              onChange={(e) => handleFileChange(e, 'responsibilities')}
              required
              style={{
                padding: '12px 16px',
                border: '1px solid #dfe1e5',
                borderRadius: '8px',
                fontSize: '15px',
                width: '100%',
                transition: 'border-color 0.2s',
                outline: 'none',
                boxSizing: 'border-box'
              }}
              onFocus={(e) => e.target.style.borderColor = '#0A1929'}
              onBlur={(e) => e.target.style.borderColor = '#dfe1e5'}
            />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <label 
              htmlFor="timeline" 
              style={{ 
                fontSize: '14px', 
                fontWeight: '500',
                color: '#444'
              }}
            >
              Timeline or Contract Document
            </label>
            <input 
              id="timeline"
              type="file" 
              onChange={(e) => handleFileChange(e, 'timeline')}
              required
              style={{
                padding: '12px 16px',
                border: '1px solid #dfe1e5',
                borderRadius: '8px',
                fontSize: '15px',
                width: '100%',
                transition: 'border-color 0.2s',
                outline: 'none',
                boxSizing: 'border-box'
              }}
              onFocus={(e) => e.target.style.borderColor = '#0A1929'}
              onBlur={(e) => e.target.style.borderColor = '#dfe1e5'}
            />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <label 
              htmlFor="taxDocument" 
              style={{ 
                fontSize: '14px', 
                fontWeight: '500',
                color: '#444'
              }}
            >
              Company Tax Document
            </label>
            <input 
              id="taxDocument"
              type="file" 
              accept=".pdf,.jpg,.png"
              onChange={(e) => handleFileChange(e, 'taxDocument')}
              required
              style={{
                padding: '12px 16px',
                border: '1px solid #dfe1e5',
                borderRadius: '8px',
                fontSize: '15px',
                width: '100%',
                transition: 'border-color 0.2s',
                outline: 'none',
                boxSizing: 'border-box'
              }}
              onFocus={(e) => e.target.style.borderColor = '#0A1929'}
              onBlur={(e) => e.target.style.borderColor = '#dfe1e5'}
            />
            <span style={{ 
              fontSize: '12px', 
              color: '#666',
              marginTop: '4px' 
            }}>
              Accepted formats: PDF, JPG, PNG
            </span>
          </div>

          {error && (
            <div style={{
              color: '#dc3545',
              backgroundColor: '#f8d7da',
              padding: '12px 16px',
              borderRadius: '8px',
              fontSize: '14px',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm-1-7v2h2v-2h-2zm0-8v6h2V7h-2z" fill="currentColor"/>
              </svg>
              {error}
            </div>
          )}

          {showSuccess && (
            <div style={{
              color: '#0f5132',
              backgroundColor: '#d1e7dd',
              padding: '12px 16px',
              borderRadius: '8px',
              fontSize: '14px',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z" fill="currentColor"/>
              </svg>
              Documents submitted successfully! Redirecting to login...
            </div>
          )}

          <button 
            type="submit"
            disabled={isLoading}
            style={{
              padding: '14px 24px',
              backgroundColor: '#0A1929',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              cursor: isLoading ? 'default' : 'pointer',
              fontSize: '15px',
              fontWeight: '500',
              transition: 'all 0.2s',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px',
              opacity: isLoading ? 0.7 : 1,
              marginTop: '8px'
            }}
            onMouseEnter={(e) => !isLoading && (e.currentTarget.style.backgroundColor = '#1a2a3a')}
            onMouseLeave={(e) => !isLoading && (e.currentTarget.style.backgroundColor = '#0A1929')}
          >
            {isLoading ? (
              <>
                <svg 
                  width="20" 
                  height="20" 
                  viewBox="0 0 24 24"
                  style={{
                    animation: 'spin 1s linear infinite',
                    '@keyframes spin': {
                      '0%': { transform: 'rotate(0deg)' },
                      '100%': { transform: 'rotate(360deg)' }
                    }
                  }}
                >
                  <path d="M12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2ZM4 12C4 7.58172 7.58172 4 12 4V12H20C20 16.4183 16.4183 20 12 20C7.58172 20 4 16.4183 4 12Z" fill="currentColor"/>
                </svg>
                Submitting Documents...
              </>
            ) : (
              'Submit Documents'
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
