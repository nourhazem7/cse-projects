import React, { useState } from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
  IconButton,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  Paper,
  Chip,
  Tooltip,
  Divider,
} from '@mui/material';
import VisibilityIcon from '@mui/icons-material/Visibility';
import PersonIcon from '@mui/icons-material/Person';
import BusinessIcon from '@mui/icons-material/Business';
import SupervisorAccountIcon from '@mui/icons-material/SupervisorAccount';
import DateRangeIcon from '@mui/icons-material/DateRange';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import jsPDF from 'jspdf';
import { format } from 'date-fns';

const mockEvaluations = [
  {
    id: 1,
    student: 'Ali Ahmed',
    studentId: '58-4367',
    company: 'AgroTech Ltd.',
    supervisor: 'Eng. Amr Khaled',
    startDate: '2025-06-01',
    endDate: '2025-08-30',
    status: 'Completed'
  },
  {
    id: 2,
    student: 'Sara Hassan',
    studentId: '59-4412',
    company: 'GreenFuture Inc.',
    supervisor: 'Dr. Laila Mansour',
    startDate: '2025-07-01',
    endDate: '2025-09-15',
    status: 'In Progress'
  },
];

export default function EvaluationReportList() {
  const [selectedEvaluation, setSelectedEvaluation] = useState(null);

  const downloadPdf = (evaluation) => {
    try {
      const doc = new jsPDF();
      
      // Add company logo or header
      doc.setFontSize(20);
      doc.setTextColor(40, 40, 40);
      doc.text('Internship Evaluation Report', 20, 20);
      
      // Add a line
      doc.setLineWidth(0.5);
      doc.line(20, 25, 190, 25);
      
      // Add content
      doc.setFontSize(12);
      doc.setTextColor(60, 60, 60);
      
      const content = [
        ['Student', evaluation.student],
        ['Student ID', evaluation.studentId],
        ['Company', evaluation.company],
        ['Supervisor', evaluation.supervisor],
        ['Start Date', format(new Date(evaluation.startDate), 'PP')],
        ['End Date', format(new Date(evaluation.endDate), 'PP')],
        ['Status', evaluation.status]
      ];
      
      let y = 40;
      content.forEach(([label, value]) => {
        doc.setFont(undefined, 'bold');
        doc.text(`${label}:`, 20, y);
        doc.setFont(undefined, 'normal');
        doc.text(value, 70, y);
        y += 10;
      });
      
      // Add footer
      doc.setFontSize(10);
      doc.setTextColor(100, 100, 100);
      doc.text(`Generated on ${format(new Date(), 'PPpp')}`, 20, 280);
      
      doc.save(`${evaluation.student}-EvaluationReport.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
    }
  };

  const getStatusChipProps = (status) => {
    switch (status) {
      case 'Completed':
        return { 
          color: 'success',
          variant: 'outlined'
        };
      case 'In Progress':
        return { 
          color: 'primary',
          variant: 'outlined'
        };
      default:
        return { 
          color: 'default',
          variant: 'outlined'
        };
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Stack spacing={3}>
        {/* Table */}
        <TableContainer component={Paper} sx={{ 
          boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
          borderRadius: 2,
          overflow: 'hidden'
        }}>
          <Table>
            <TableHead>
              <TableRow sx={{ backgroundColor: '#f8f9fa' }}>
                <TableCell sx={{ fontWeight: 600 }}>Student</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Student ID</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Company</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Supervisor</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Duration</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Status</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {mockEvaluations.map((evaluation) => (
                <TableRow 
                  key={evaluation.id}
                  sx={{ '&:hover': { backgroundColor: '#f8f9fa' } }}
                >
                  <TableCell>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <PersonIcon color="action" fontSize="small" />
                      <Typography>{evaluation.student}</Typography>
                    </Stack>
                  </TableCell>
                  <TableCell>{evaluation.studentId}</TableCell>
                  <TableCell>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <BusinessIcon color="action" fontSize="small" />
                      <Typography>{evaluation.company}</Typography>
                    </Stack>
                  </TableCell>
                  <TableCell>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <SupervisorAccountIcon color="action" fontSize="small" />
                      <Typography>{evaluation.supervisor}</Typography>
                    </Stack>
                  </TableCell>
                  <TableCell>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <DateRangeIcon color="action" fontSize="small" />
                      <Stack>
                        <Typography variant="body2">
                          {format(new Date(evaluation.startDate), 'PP')}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          to {format(new Date(evaluation.endDate), 'PP')}
                        </Typography>
                      </Stack>
                    </Stack>
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={evaluation.status}
                      size="small"
                      {...getStatusChipProps(evaluation.status)}
                    />
                  </TableCell>
                  <TableCell>
                    <Stack direction="row" spacing={1}>
                      <Tooltip title="View Details">
                        <IconButton
                          size="small"
                          onClick={() => setSelectedEvaluation(evaluation)}
                          sx={{ color: 'primary.main' }}
                        >
                          <VisibilityIcon />
                        </IconButton>
                      </Tooltip>
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        {/* Details Dialog */}
        <Dialog
          open={Boolean(selectedEvaluation)}
          onClose={() => setSelectedEvaluation(null)}
          maxWidth="sm"
          fullWidth
        >
          {selectedEvaluation && (
            <>
              <DialogTitle sx={{ px: 3, py: 2, bgcolor: 'primary.main', color: 'white' }}>
                <Stack direction="row" alignItems="center" spacing={2}>
                  <PersonIcon />
                  <Box>
                    <Typography variant="h6">
                      Evaluation Report Details
                    </Typography>
                    <Typography variant="caption" sx={{ color: 'primary.lighter' }}>
                      {selectedEvaluation.student} - {selectedEvaluation.studentId}
                    </Typography>
                  </Box>
                </Stack>
              </DialogTitle>
              <DialogContent sx={{ p: 3 }}>
                <Stack spacing={3}>
                  <Card variant="outlined">
                    <CardContent>
                      <Grid container spacing={2}>
                        <Grid item xs={12}>
                          <Stack spacing={2}>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                              <BusinessIcon color="action" fontSize="small" />
                              <Typography variant="body2">
                                Company: {selectedEvaluation.company}
                              </Typography>
                            </Box>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                              <SupervisorAccountIcon color="action" fontSize="small" />
                              <Typography variant="body2">
                                Supervisor: {selectedEvaluation.supervisor}
                              </Typography>
                            </Box>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                              <DateRangeIcon color="action" fontSize="small" />
                              <Stack>
                                <Typography variant="body2">
                                  Start Date: {format(new Date(selectedEvaluation.startDate), 'PPp')}
                                </Typography>
                                <Typography variant="body2">
                                  End Date: {format(new Date(selectedEvaluation.endDate), 'PPp')}
                                </Typography>
                              </Stack>
                            </Box>
                          </Stack>
                        </Grid>
                      </Grid>
                    </CardContent>
                  </Card>
                  
                  <Divider />
                  
                  <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                    <Button
                      variant="outlined"
                      startIcon={<PictureAsPdfIcon />}
                      onClick={() => downloadPdf(selectedEvaluation)}
                      sx={{ width: '100%' }}
                    >
                      Download Evaluation Report
                    </Button>
                  </Box>
                </Stack>
              </DialogContent>
              <DialogActions sx={{ p: 2, bgcolor: 'grey.50' }}>
                <Button onClick={() => setSelectedEvaluation(null)}>
                  Close
                </Button>
              </DialogActions>
            </>
          )}
        </Dialog>
      </Stack>
    </Box>
  );
}
