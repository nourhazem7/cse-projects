import React, { useState } from 'react';
import {
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  IconButton,
  Button,
  TextField,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  Stack,
  Grid,
  Card,
  CardContent,
  Avatar,
  Tooltip,
  InputAdornment,
  Tabs,
  Tab,
  Badge,
  LinearProgress,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import VisibilityIcon from '@mui/icons-material/Visibility';
import FilterListIcon from '@mui/icons-material/FilterList';
import PersonIcon from '@mui/icons-material/Person';
import EmailIcon from '@mui/icons-material/Email';
import PhoneIcon from '@mui/icons-material/Phone';
import SchoolIcon from '@mui/icons-material/School';
import AssignmentIcon from '@mui/icons-material/Assignment';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import PendingIcon from '@mui/icons-material/Pending';
import BusinessIcon from '@mui/icons-material/Business';

const initialStudents = [
  { 
    id: 1, 
    name: 'Laila Hassan', 
    email: 'laila@student.guc.edu.eg', 
    idNumber: '58-4367', 
    status: 'In Progress', 
    major: 'CS', 
    phone: '01011223344',
    gpa: 3.7,
    company: 'TechCorp',
    supervisor: 'Dr. Ahmed Mohamed',
    startDate: '2024-02-15',
    endDate: '2024-07-15',
    completedHours: 180,
    totalHours: 280,
    reports: [
      { id: 1, title: 'Week 1 Report', status: 'Approved' },
      { id: 2, title: 'Week 2 Report', status: 'Pending' }
    ]
  },
  { 
    id: 2, 
    name: 'Omar Adel', 
    email: 'omar@student.guc.edu.eg', 
    idNumber: '56-3254', 
    status: 'Not Started', 
    major: 'ENG', 
    phone: '01055667788',
    gpa: 3.2,
    reports: []
  },
  { 
    id: 3, 
    name: 'Mariam Said', 
    email: 'mariam@student.guc.edu.eg', 
    idNumber: '59-1123', 
    status: 'Completed', 
    major: 'ARCH', 
    phone: '01112345678',
    gpa: 3.9,
    company: 'ArchDesign',
    supervisor: 'Dr. Sarah Ahmed',
    startDate: '2023-09-01',
    endDate: '2024-02-01',
    completedHours: 280,
    totalHours: 280,
    reports: [
      { id: 1, title: 'Week 1 Report', status: 'Approved' },
      { id: 2, title: 'Week 2 Report', status: 'Approved' },
      { id: 3, title: 'Final Report', status: 'Approved' }
    ]
  },
  { 
    id: 4, 
    name: 'Kareem Nabil', 
    email: 'kareem@student.guc.edu.eg', 
    idNumber: '60-2387', 
    status: 'In Progress', 
    major: 'CS', 
    phone: '01233445566',
    gpa: 3.5,
    company: 'SoftwareInc',
    supervisor: 'Dr. Mohamed Ali',
    startDate: '2024-01-15',
    endDate: '2024-06-15',
    completedHours: 120,
    totalHours: 280,
    reports: [
      { id: 1, title: 'Week 1 Report', status: 'Approved' },
      { id: 2, title: 'Week 2 Report', status: 'Pending' }
    ]
  }
];

const statusFilters = ['All', 'In Progress', 'Completed', 'Not Started'];
const majorFilters = ['All', 'CS', 'ENG', 'ARCH'];

export default function StudentList() {
  const [statusFilter, setStatusFilter] = useState('All');
  const [majorFilter, setMajorFilter] = useState('All');
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState(0);

  const getStatusChipProps = (status) => {
    switch (status) {
      case 'Completed':
        return { 
          color: 'success',
          icon: <CheckCircleIcon />,
          variant: 'outlined'
        };
      case 'In Progress':
        return { 
          color: 'warning',
          variant: 'outlined'
        };
      case 'Not Started':
        return { 
          color: 'default',
          variant: 'outlined',
          sx: { bgcolor: '#e0e0e0', color: '#616161' }
        };
      default:
        return { 
          color: 'default',
          variant: 'outlined'
        };
    }
  };

  const getReportStatusChip = (status) => {
    switch (status) {
      case 'Approved':
        return <Chip size="small" color="success" label="Approved" />;
      case 'Pending':
        return <Chip size="small" color="warning" label="Pending Review" />;
      default:
        return <Chip size="small" color="default" label={status} />;
    }
  };

  const filteredStudents = initialStudents.filter(student => {
    const matchesStatus = statusFilter === 'All' || student.status === statusFilter;
    const matchesMajor = majorFilter === 'All' || student.major === majorFilter;
    const matchesSearch = 
      student.name.toLowerCase().includes(search.toLowerCase()) ||
                         student.email.toLowerCase().includes(search.toLowerCase()) ||
                         student.idNumber.toLowerCase().includes(search.toLowerCase());
    return matchesStatus && matchesMajor && matchesSearch;
  });

  return (
    <Box sx={{ p: 3 }}>
      <Stack spacing={3}>
        {/* Filters Section */}
        <Card>
          <CardContent>
            <Stack spacing={2}>
              <Typography variant="subtitle2" color="text.secondary">
                Filters
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={4}>
                  <TextField
                    fullWidth
                    placeholder="Search students..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <SearchIcon />
                        </InputAdornment>
                      ),
                    }}
                  />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <FormControl fullWidth>
                    <InputLabel>Status</InputLabel>
                    <Select
                      value={statusFilter}
                      label="Status"
                      onChange={(e) => setStatusFilter(e.target.value)}
                    >
                      {statusFilters.map((status) => (
                        <MenuItem key={status} value={status}>
                          {status}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={4}>
                  <FormControl fullWidth>
                    <InputLabel>Major</InputLabel>
                    <Select
                      value={majorFilter}
                      label="Major"
                      onChange={(e) => setMajorFilter(e.target.value)}
                    >
                      {majorFilters.map((major) => (
                        <MenuItem key={major} value={major}>
                          {major}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
              </Grid>
            </Stack>
          </CardContent>
        </Card>

        {/* Students Table */}
        <TableContainer component={Paper} sx={{ 
          boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
          borderRadius: 2,
        overflow: 'hidden'
      }}>
          <Table>
            <TableHead>
              <TableRow sx={{ backgroundColor: '#f8f9fa' }}>
                <TableCell sx={{ fontWeight: 600 }}>Student</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>ID</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Major</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Status</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredStudents.map((student) => (
                <TableRow 
                  key={student.id}
                  sx={{ '&:hover': { backgroundColor: '#f8f9fa' } }}
                >
                  <TableCell>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <PersonIcon color="action" fontSize="small" />
                      <Box>
                        <Typography variant="body1" sx={{ fontWeight: 500 }}>
                          {student.name}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {student.email}
                        </Typography>
                      </Box>
                    </Stack>
                  </TableCell>
                  <TableCell>{student.idNumber}</TableCell>
                  <TableCell>
                    <Chip 
                      label={student.major}
                      size="small"
                      color="primary"
                      variant="outlined"
                    />
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={student.status}
                      size="small"
                      {...getStatusChipProps(student.status)}
                    />
                  </TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex', gap: 1 }}>
                      <IconButton
                        size="small"
                    onClick={() => setSelectedStudent(student)}
                        sx={{ color: '#0A1929' }}
                      >
                        <VisibilityIcon />
                      </IconButton>
                    </Box>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Stack>

      {/* Student Details Dialog */}
      <Dialog
        open={Boolean(selectedStudent)}
        onClose={() => setSelectedStudent(null)}
        maxWidth="md"
        fullWidth
      >
      {selectedStudent && (
          <>
            <DialogTitle sx={{ px: 3, py: 2, bgcolor: 'primary.main', color: 'white' }}>
              <Stack direction="row" alignItems="center" spacing={2}>
                <Avatar sx={{ bgcolor: 'white', color: 'primary.main' }}>
                  {selectedStudent.name.charAt(0)}
                </Avatar>
                <Box>
                  <Typography variant="h6">
                    {selectedStudent.name}
                  </Typography>
                  <Typography variant="caption" sx={{ color: 'primary.lighter' }}>
                    {selectedStudent.idNumber}
                  </Typography>
                </Box>
              </Stack>
            </DialogTitle>
            <DialogContent sx={{ p: 0 }}>
              <Box>
                <Tabs
                  value={activeTab}
                  onChange={(e, newValue) => setActiveTab(newValue)}
                  variant="fullWidth"
                >
                  <Tab label="Overview" />
                  <Tab 
                    label={
                      <Badge 
                        badgeContent={selectedStudent.reports.filter(r => r.status === 'Pending').length} 
                        color="warning"
                      >
                        Reports
                      </Badge>
                    } 
                  />
                </Tabs>

                <Box sx={{ p: 3 }}>
                  {activeTab === 0 ? (
                    <Grid container spacing={3}>
                      <Grid item xs={12} md={6}>
                        <Stack spacing={2}>
                          <Box>
                            <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                              Personal Information
                            </Typography>
                            <Stack spacing={2}>
                              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                <EmailIcon color="action" fontSize="small" />
                                <Typography variant="body2">
                                  {selectedStudent.email}
                                </Typography>
                              </Box>
                              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                <PhoneIcon color="action" fontSize="small" />
                                <Typography variant="body2">
                                  {selectedStudent.phone}
                                </Typography>
                              </Box>
                              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                <SchoolIcon color="action" fontSize="small" />
                                <Typography variant="body2">
                                  Major: {selectedStudent.major}
                                </Typography>
                              </Box>
                              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                <AssignmentIcon color="action" fontSize="small" />
                                <Typography variant="body2">
                                  GPA: {selectedStudent.gpa}
                                </Typography>
                              </Box>
                            </Stack>
                          </Box>

                          {selectedStudent.status !== 'Not Started' && (
                            <Box>
                              <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                                Internship Details
                              </Typography>
                              <Stack spacing={2}>
                                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                  <BusinessIcon color="action" fontSize="small" />
                                  <Typography variant="body2">
                                    Company: {selectedStudent.company}
                                  </Typography>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                  <PersonIcon color="action" fontSize="small" />
                                  <Typography variant="body2">
                                    Supervisor: {selectedStudent.supervisor}
                                  </Typography>
                                </Box>
                                <Box>
                                  <Typography variant="caption" color="text.secondary">
                                    Duration
                                  </Typography>
                                  <Typography variant="body2">
                                    {selectedStudent.startDate} to {selectedStudent.endDate}
                                  </Typography>
                                </Box>
                                {selectedStudent.completedHours && (
                                  <Box>
                                    <Typography variant="caption" color="text.secondary">
                                      Progress
                                    </Typography>
                                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                      <Typography variant="body2" color="primary">
                                        {selectedStudent.completedHours} / {selectedStudent.totalHours} hours
                                      </Typography>
                                      <LinearProgress 
                                        variant="determinate" 
                                        value={(selectedStudent.completedHours / selectedStudent.totalHours) * 100}
                                        sx={{ 
                                          flex: 1,
                                          height: 6,
                                          borderRadius: 3
                                        }}
                                      />
                                    </Box>
                                  </Box>
                                )}
                              </Stack>
                            </Box>
                          )}
                        </Stack>
                      </Grid>

                      <Grid item xs={12} md={6}>
                        <Box>
                          <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                            Status Overview
                          </Typography>
                          <Card variant="outlined">
                            <CardContent>
                              <Stack spacing={2}>
                                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                  <Chip
                                    label={selectedStudent.status}
                                    {...getStatusChipProps(selectedStudent.status)}
                                  />
                                </Box>
                                {selectedStudent.status === 'In Progress' && (
                                  <>
                                    <Typography variant="body2" color="text.secondary">
                                      Current Phase
                                    </Typography>
                                    <Box sx={{ 
                                      p: 2, 
                                      bgcolor: 'primary.lighter', 
                                      borderRadius: 1,
                                      border: '1px solid',
                                      borderColor: 'primary.light'
                                    }}>
                                      <Typography variant="body2">
                                        Currently in internship period at {selectedStudent.company}
                                      </Typography>
                                    </Box>
                                  </>
                                )}
                              </Stack>
                            </CardContent>
                          </Card>
                        </Box>
                      </Grid>
                    </Grid>
                  ) : (
                    <Stack spacing={2}>
                      {selectedStudent.reports.map((report) => (
                        <Card key={report.id} variant="outlined">
                          <CardContent sx={{ 
          display: 'flex',
          alignItems: 'center',
                            justifyContent: 'space-between'
                          }}>
                            <Stack direction="row" spacing={2} alignItems="center">
                              <AssignmentIcon color="action" />
                              <Box>
                                <Typography variant="subtitle2">
                                  {report.title}
                                </Typography>
                              </Box>
                            </Stack>
                            {getReportStatusChip(report.status)}
                          </CardContent>
                        </Card>
                      ))}
                      {selectedStudent.reports.length === 0 && (
                        <Box sx={{ textAlign: 'center', py: 4 }}>
                          <Typography color="text.secondary">
                            No reports submitted yet
                          </Typography>
                        </Box>
      )}
                    </Stack>
                  )}
                </Box>
              </Box>
            </DialogContent>
          </>
        )}
      </Dialog>
    </Box>
  );
}
