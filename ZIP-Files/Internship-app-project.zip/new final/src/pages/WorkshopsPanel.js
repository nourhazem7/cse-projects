import React, { useState } from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
  IconButton,
  Stack,
  TextField,
  Typography,
  Chip,
  Divider,
  Alert,
  Snackbar,
  Paper,
} from '@mui/material';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import EventIcon from '@mui/icons-material/Event';
import PersonIcon from '@mui/icons-material/Person';
import ScheduleIcon from '@mui/icons-material/Schedule';
import DescriptionIcon from '@mui/icons-material/Description';
import { format } from 'date-fns';

const initialForm = {
  name: '',
  description: '',
  speaker: '',
  agenda: '',
  start: null,
  end: null
};

export default function WorkshopsPanel() {
  const [workshops, setWorkshops] = useState([]);
  const [form, setForm] = useState(initialForm);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

  const handleSubmit = () => {
    if (!form.name || !form.description || !form.speaker || !form.agenda || !form.start || !form.end) {
      setSnackbar({
        open: true,
        message: 'Please fill in all fields',
        severity: 'error'
      });
      return;
    }

    if (form.end < form.start) {
      setSnackbar({
        open: true,
        message: 'End time cannot be before start time',
        severity: 'error'
      });
      return;
    }

    if (editingId !== null) {
      setWorkshops(workshops.map(w => w.id === editingId ? { ...form, id: editingId } : w));
      setSnackbar({
        open: true,
        message: 'Workshop updated successfully',
        severity: 'success'
      });
    } else {
      setWorkshops([...workshops, { ...form, id: Date.now() }]);
      setSnackbar({
        open: true,
        message: 'Workshop added successfully',
        severity: 'success'
      });
    }
    
    handleCloseDialog();
  };

  const handleEdit = (workshop) => {
    setForm(workshop);
    setEditingId(workshop.id);
    setIsDialogOpen(true);
  };

  const handleDelete = (id) => {
    setWorkshops(workshops.filter(w => w.id !== id));
    setSnackbar({
      open: true,
      message: 'Workshop deleted successfully',
      severity: 'success'
    });
  };

  const handleCloseDialog = () => {
    setForm(initialForm);
    setEditingId(null);
    setIsDialogOpen(false);
  };

  const now = new Date();
  const upcoming = workshops.filter(w => new Date(w.start) > now);
  const past = workshops.filter(w => new Date(w.start) <= now);

  const WorkshopCard = ({ workshop, showActions = false }) => (
    <Card variant="outlined" sx={{ height: '100%' }}>
      <CardContent>
        <Stack spacing={2}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <Typography variant="h6" gutterBottom>
              {workshop.name}
            </Typography>
            {showActions && (
              <Stack direction="row" spacing={1}>
                <IconButton
                  size="small"
                  onClick={() => handleEdit(workshop)}
                  sx={{ color: 'primary.main' }}
                >
                  <EditIcon />
                </IconButton>
                <IconButton
                  size="small"
                  onClick={() => handleDelete(workshop.id)}
                  sx={{ color: 'error.main' }}
                >
                  <DeleteIcon />
                </IconButton>
              </Stack>
            )}
          </Box>

          <Stack spacing={1.5}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <PersonIcon color="action" fontSize="small" />
              <Typography variant="body2" color="text.secondary">
                Speaker: {workshop.speaker}
              </Typography>
            </Box>

            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <ScheduleIcon color="action" fontSize="small" />
              <Stack>
                <Typography variant="body2" color="text.secondary">
                  Start: {workshop.start ? format(new Date(workshop.start), 'PPp') : ''}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  End: {workshop.end ? format(new Date(workshop.end), 'PPp') : ''}
                </Typography>
              </Stack>
            </Box>

            <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1 }}>
              <DescriptionIcon color="action" fontSize="small" sx={{ mt: 0.5 }} />
              <Stack spacing={0.5}>
                <Typography variant="body2" color="text.secondary">
                  Description: {workshop.description}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Agenda: {workshop.agenda}
                </Typography>
              </Stack>
            </Box>
          </Stack>

          <Box sx={{ display: 'flex', gap: 1, mt: 1 }}>
            <Chip
              size="small"
              color={new Date(workshop.start) > now ? 'primary' : 'default'}
              label={new Date(workshop.start) > now ? 'Upcoming' : 'Past'}
              variant="outlined"
            />
          </Box>
        </Stack>
      </CardContent>
    </Card>
  );

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Box sx={{ p: 3 }}>
        <Stack spacing={3}>
          {/* Header */}
          <Box sx={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center' }}>
            <Button
              variant="contained"
              startIcon={<AddIcon />}
              onClick={() => setIsDialogOpen(true)}
            >
              Add Workshop
            </Button>
          </Box>

          {/* Upcoming Workshops */}
          <Box>
            <Typography variant="h6" gutterBottom sx={{ color: 'text.secondary' }}>
              Upcoming Workshops
            </Typography>
            <Grid container spacing={2}>
              {upcoming.length === 0 ? (
                <Grid item xs={12}>
                  <Paper sx={{ p: 3, textAlign: 'center', bgcolor: 'grey.50' }}>
                    <Typography color="text.secondary">
                      No upcoming workshops
                    </Typography>
                  </Paper>
                </Grid>
              ) : (
                upcoming.map(workshop => (
                  <Grid item xs={12} md={6} lg={4} key={workshop.id}>
                    <WorkshopCard workshop={workshop} showActions />
                  </Grid>
                ))
              )}
            </Grid>
          </Box>

          {/* Past Workshops */}
          {past.length > 0 && (
            <Box>
              <Typography variant="h6" gutterBottom sx={{ color: 'text.secondary' }}>
                Past Workshops
              </Typography>
              <Grid container spacing={2}>
                {past.map(workshop => (
                  <Grid item xs={12} md={6} lg={4} key={workshop.id}>
                    <WorkshopCard workshop={workshop} showActions />
                  </Grid>
                ))}
              </Grid>
            </Box>
          )}
        </Stack>

        {/* Add/Edit Workshop Dialog */}
        <Dialog
          open={isDialogOpen}
          onClose={handleCloseDialog}
          maxWidth="sm"
          fullWidth
        >
          <DialogTitle>
            {editingId !== null ? 'Edit Workshop' : 'Add New Workshop'}
          </DialogTitle>
          <DialogContent>
            <Stack spacing={2} sx={{ mt: 1 }}>
              <TextField
                label="Workshop Name"
                fullWidth
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
              <TextField
                label="Description"
                fullWidth
                multiline
                rows={2}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
              />
              <TextField
                label="Speaker"
                fullWidth
                value={form.speaker}
                onChange={(e) => setForm({ ...form, speaker: e.target.value })}
              />
              <TextField
                label="Agenda"
                fullWidth
                multiline
                rows={3}
                value={form.agenda}
                onChange={(e) => setForm({ ...form, agenda: e.target.value })}
              />
              <DateTimePicker
                label="Start Date and Time"
                value={form.start}
                onChange={(newValue) => setForm({ ...form, start: newValue })}
                renderInput={(params) => <TextField {...params} fullWidth />}
              />
              <DateTimePicker
                label="End Date and Time"
                value={form.end}
                onChange={(newValue) => setForm({ ...form, end: newValue })}
                renderInput={(params) => <TextField {...params} fullWidth />}
                minDateTime={form.start}
              />
            </Stack>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseDialog}>Cancel</Button>
            <Button variant="contained" onClick={handleSubmit}>
              {editingId !== null ? 'Update' : 'Add'} Workshop
            </Button>
          </DialogActions>
        </Dialog>

        {/* Snackbar for notifications */}
        <Snackbar
          open={snackbar.open}
          autoHideDuration={4000}
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        >
          <Alert
            onClose={() => setSnackbar({ ...snackbar, open: false })}
            severity={snackbar.severity}
            variant="filled"
            sx={{ width: '100%' }}
          >
            {snackbar.message}
          </Alert>
        </Snackbar>
      </Box>
    </LocalizationProvider>
  );
}
