import React from 'react';

export default function VideoCallWindow({ user, onLeave, controls, toggleControl }) {
  return (
    <div style={{
      position: 'fixed',
      bottom: '30px',
      right: '30px',
      width: '340px',
      height: '420px',
      backgroundColor: '#f0f0f0',
      border: '2px solid #0a3d62',
      borderRadius: '12px',
      boxShadow: '0 0 10px rgba(0,0,0,0.2)',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
      zIndex: 9999
    }}>
      <div style={{
        backgroundColor: '#0a3d62',
        color: 'white',
        padding: '10px',
        textAlign: 'center'
      }}>
        🟢 In call with {user.to}
      </div>

      <div style={{
        flex: 1,
        backgroundColor: '#333',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: 'white',
        fontSize: '14px'
      }}>
        {controls.video ? '📹 Video On' : '🚫 Video Off'}
      </div>

      <div style={{
        display: 'flex',
        flexDirection: 'column',
        gap: '8px',
        padding: '12px',
        backgroundColor: '#fff'
      }}>
        <button onClick={() => toggleControl('video')}>
          {controls.video ? '📷 Turn Off Video' : '📷 Turn On Video'}
        </button>
        <button onClick={() => toggleControl('mic')}>
          {controls.mic ? '🎤 Mute Mic' : '🎤 Unmute Mic'}
        </button>
        <button onClick={() => toggleControl('screenShared')}>
          {controls.screenShared ? '🛑 Stop Sharing Screen' : '🖥️ Share Screen'}
        </button>
        <button onClick={onLeave} style={{ backgroundColor: '#dc3545', color: 'white' }}>
          🔚 Leave Call
        </button>
      </div>
    </div>
  );
}
