import React, { useState } from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  IconButton,
  Stack,
  TextField,
  Typography,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  InputAdornment,
  Tooltip,
  Divider,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import VisibilityIcon from '@mui/icons-material/Visibility';
import BusinessIcon from '@mui/icons-material/Business';
import WorkIcon from '@mui/icons-material/Work';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import CategoryIcon from '@mui/icons-material/Category';
import DescriptionIcon from '@mui/icons-material/Description';
import CodeIcon from '@mui/icons-material/Code';

const initialInternships = [
  {
    id: 1,
    title: 'Frontend Developer',
    company: 'TechSpark',
    industry: 'Software',
    duration: '3 months',
    paid: true,
    salary: '$1000/month',
    skills: ['React', 'CSS', 'HTML'],
    description: 'Assist in developing UI components and styling the application.',
    status: 'Open'
  },
  {
    id: 2,
    title: 'Agricultural Analyst',
    company: 'GreenAgro',
    industry: 'Agriculture',
    duration: '6 months',
    paid: false,
    salary: null,
    skills: ['Data Analysis', 'Excel', 'Report Writing'],
    description: 'Analyze crop performance data and help in sustainable strategy planning.',
    status: 'Open'
  },
  {
    id: 3,
    title: 'Marketing Intern',
    company: 'Nestlé',
    industry: 'Food & Beverage',
    duration: '2 months',
    paid: true,
    salary: '$800/month',
    skills: ['SEO', 'Social Media', 'Content Creation'],
    description: 'Support digital marketing campaigns and content creation.',
    status: 'Filled'
  }
];

const industries = ['Software', 'Agriculture', 'Food & Beverage'];
const durations = ['2 months', '3 months', '6 months'];

export default function InternshipList() {
  const [search, setSearch] = useState('');
  const [industryFilter, setIndustryFilter] = useState('All');
  const [durationFilter, setDurationFilter] = useState('All');
  const [paidFilter, setPaidFilter] = useState('All');
  const [selectedInternship, setSelectedInternship] = useState(null);

  const filteredInternships = initialInternships.filter((item) => {
    const matchSearch = 
      item.title.toLowerCase().includes(search.toLowerCase()) ||
      item.company.toLowerCase().includes(search.toLowerCase()) ||
      item.description.toLowerCase().includes(search.toLowerCase());

    const matchIndustry = industryFilter === 'All' || item.industry === industryFilter;
    const matchDuration = durationFilter === 'All' || item.duration === durationFilter;
    const matchPaid = paidFilter === 'All' ||
      (paidFilter === 'Paid' && item.paid) ||
      (paidFilter === 'Unpaid' && !item.paid);

    return matchSearch && matchIndustry && matchDuration && matchPaid;
  });

  const getStatusChipProps = (status) => {
    switch (status) {
      case 'Open':
        return { 
          color: 'success',
          variant: 'outlined'
        };
      case 'Filled':
        return { 
          color: 'primary',
          variant: 'outlined'
        };
      default:
        return { 
          color: 'default',
          variant: 'outlined'
        };
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Stack spacing={3}>
        {/* Filters */}
        <Card>
          <CardContent>
            <Stack spacing={2}>
              <Typography variant="subtitle2" color="text.secondary">
                Filters
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    placeholder="Search internships..."
          value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <SearchIcon />
                        </InputAdornment>
                      ),
                    }}
        />
                </Grid>
                <Grid item xs={12} md={2}>
                  <FormControl fullWidth>
                    <InputLabel>Industry</InputLabel>
                    <Select
                      value={industryFilter}
                      label="Industry"
                      onChange={(e) => setIndustryFilter(e.target.value)}
                    >
                      <MenuItem value="All">All Industries</MenuItem>
                      {industries.map((industry) => (
                        <MenuItem key={industry} value={industry}>{industry}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} md={2}>
                  <FormControl fullWidth>
                    <InputLabel>Duration</InputLabel>
                    <Select
                      value={durationFilter}
                      label="Duration"
                      onChange={(e) => setDurationFilter(e.target.value)}
                    >
                      <MenuItem value="All">All Durations</MenuItem>
                      {durations.map((duration) => (
                        <MenuItem key={duration} value={duration}>{duration}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} md={2}>
                  <FormControl fullWidth>
                    <InputLabel>Payment</InputLabel>
                    <Select
                      value={paidFilter}
                      label="Payment"
                      onChange={(e) => setPaidFilter(e.target.value)}
                    >
                      <MenuItem value="All">All Types</MenuItem>
                      <MenuItem value="Paid">Paid</MenuItem>
                      <MenuItem value="Unpaid">Unpaid</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
              </Grid>
            </Stack>
          </CardContent>
        </Card>

        {/* Internships Table */}
        <TableContainer component={Paper} sx={{ 
          boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
          borderRadius: 2,
          overflow: 'hidden'
        }}>
          <Table>
            <TableHead>
              <TableRow sx={{ backgroundColor: '#f8f9fa' }}>
                <TableCell sx={{ fontWeight: 600 }}>Position</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Company</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Industry</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Duration</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Status</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Payment</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
          {filteredInternships.map((internship) => (
                <TableRow 
                  key={internship.id}
                  sx={{ '&:hover': { backgroundColor: '#f8f9fa' } }}
                >
                  <TableCell>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <WorkIcon color="action" fontSize="small" />
                      <Typography>{internship.title}</Typography>
                    </Stack>
                  </TableCell>
                  <TableCell>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <BusinessIcon color="action" fontSize="small" />
                      <Typography>{internship.company}</Typography>
                    </Stack>
                  </TableCell>
                  <TableCell>
                    <Chip 
                      label={internship.industry}
                      size="small"
                      color="primary"
                      variant="outlined"
                    />
                  </TableCell>
                  <TableCell>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <AccessTimeIcon color="action" fontSize="small" />
                      <Typography>{internship.duration}</Typography>
                    </Stack>
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={internship.status}
                      size="small"
                      {...getStatusChipProps(internship.status)}
                    />
                  </TableCell>
                  <TableCell>
                    <Chip
                      icon={internship.paid ? <AttachMoneyIcon /> : undefined}
                      label={internship.paid ? 'Paid' : 'Unpaid'}
                      size="small"
                      color={internship.paid ? 'success' : 'default'}
                      variant="outlined"
                    />
                  </TableCell>
                  <TableCell>
                    <Tooltip title="View Details">
                      <IconButton
                        size="small"
                        onClick={() => setSelectedInternship(internship)}
                        sx={{ color: 'primary.main' }}
                      >
                        <VisibilityIcon />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
          ))}
            </TableBody>
          </Table>
        </TableContainer>

        {/* Internship Details Dialog */}
        <Dialog
          open={Boolean(selectedInternship)}
          onClose={() => setSelectedInternship(null)}
          maxWidth="md"
          fullWidth
        >
          {selectedInternship && (
            <>
              <DialogTitle sx={{ px: 3, py: 2, bgcolor: 'primary.main', color: 'white' }}>
                <Stack direction="row" alignItems="center" spacing={2}>
                  <WorkIcon />
                  <Box>
                    <Typography variant="h6">
                      {selectedInternship.title}
                    </Typography>
                    <Typography variant="caption" sx={{ color: 'primary.lighter' }}>
                      {selectedInternship.company}
                    </Typography>
                  </Box>
                </Stack>
              </DialogTitle>
              <DialogContent sx={{ p: 3 }}>
                <Grid container spacing={3}>
                  <Grid item xs={12} md={6}>
                    <Stack spacing={3}>
                      <Box>
                        <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                          Basic Information
                        </Typography>
                        <Stack spacing={2}>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <BusinessIcon color="action" fontSize="small" />
                            <Typography variant="body2">
                              Company: {selectedInternship.company}
                            </Typography>
                          </Box>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <CategoryIcon color="action" fontSize="small" />
                            <Typography variant="body2">
                              Industry: {selectedInternship.industry}
                            </Typography>
                          </Box>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <AccessTimeIcon color="action" fontSize="small" />
                            <Typography variant="body2">
                              Duration: {selectedInternship.duration}
                            </Typography>
                          </Box>
                          {selectedInternship.paid && (
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                              <AttachMoneyIcon color="action" fontSize="small" />
                              <Typography variant="body2">
                                Salary: {selectedInternship.salary}
                              </Typography>
                            </Box>
                          )}
                        </Stack>
                      </Box>
                    </Stack>
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <Box>
                      <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                        Required Skills
                      </Typography>
                      <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                        {selectedInternship.skills.map((skill) => (
                          <Chip
                            key={skill}
                            label={skill}
                            size="small"
                            icon={<CodeIcon />}
                            variant="outlined"
                          />
                        ))}
                      </Stack>
                    </Box>
                  </Grid>
                  <Grid item xs={12}>
                    <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                      Description
                    </Typography>
                    <Card variant="outlined">
                      <CardContent>
                        <Stack spacing={2}>
                          <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1 }}>
                            <DescriptionIcon color="action" fontSize="small" sx={{ mt: 0.5 }} />
                            <Typography variant="body2">
                              {selectedInternship.description}
                            </Typography>
                          </Box>
                        </Stack>
                      </CardContent>
                    </Card>
                  </Grid>
                </Grid>
              </DialogContent>
              <DialogActions sx={{ p: 2, bgcolor: 'grey.50' }}>
                <Button onClick={() => setSelectedInternship(null)}>
                  Close
                </Button>
              </DialogActions>
            </>
          )}
        </Dialog>
      </Stack>
    </Box>
  );
}