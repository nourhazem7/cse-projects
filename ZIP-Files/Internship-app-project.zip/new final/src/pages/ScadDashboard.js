import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  AppBar,
  Box,
  Drawer,
  IconButton,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Typography,
  Menu,
  MenuItem,
  Avatar,
  Badge,
  Divider,
  ListSubheader,
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import NotificationsIcon from '@mui/icons-material/Notifications';
import PersonIcon from '@mui/icons-material/Person';
import LogoutIcon from '@mui/icons-material/Logout';
import EmailIcon from '@mui/icons-material/Email';
import BusinessIcon from '@mui/icons-material/Business';
import EventNoteIcon from '@mui/icons-material/EventNote';
import PeopleIcon from '@mui/icons-material/People';
import AssignmentIcon from '@mui/icons-material/Assignment';
import GroupsIcon from '@mui/icons-material/Groups';
import AssessmentIcon from '@mui/icons-material/Assessment';
import WorkIcon from '@mui/icons-material/Work';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import EventIcon from '@mui/icons-material/Event';

import CompanyList from './CompanyList';
import InternshipCycle from './InternshipCycle';
import StudentList from './StudentList';
import ReportList from './ReportList';
import WorkshopsPanel from './WorkshopsPanel';
import StatisticsPanel from './StatisticsPanel';
import InternshipList from './InternshipList';
import EvaluationReportList from './EvaluationReportList';
import AppointmentsPanel from './AppointmentsPanel';

const drawerWidth = 240;
const navyBlue = '#0A1929';
const lightNavyBlue = '#1A2B3C';

export default function ScadDashboard() {
  const [activeTab, setActiveTab] = useState('companies');
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [isSidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [notificationAnchorEl, setNotificationAnchorEl] = useState(null);
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      type: 'company_registration',
      message: 'New company registration: Tech Solutions Inc.',
      time: '5 minutes ago',
      isRead: false,
      icon: '🏢'
    },
    {
      id: 2,
      type: 'student_report',
      message: 'New internship report submitted by Ahmed Hassan',
      time: '1 hour ago',
      isRead: false,
      icon: '📄'
    },
    {
      id: 3,
      type: 'workshop_update',
      message: 'Upcoming workshop: "Career Development" needs approval',
      time: '2 hours ago',
      isRead: false,
      icon: '👥'
    }
  ]);

  // SCAD email constant
  const SCAD_EMAIL = 'scad@guc.edu.eg';

  // Handle marking all notifications as read
  const handleMarkAllAsRead = () => {
    setNotifications([]);
    setShowNotifications(false);
  };

  // Handle marking a single notification as read
  const handleMarkAsRead = (notificationId) => {
    setNotifications(prevNotifications => 
      prevNotifications.filter(notification => notification.id !== notificationId)
    );
  };

  // Handle notification button click
  const handleNotificationClick = (event) => {
    setNotificationAnchorEl(event.currentTarget);
    setShowNotifications(true);
    setShowProfileMenu(false);
  };

  // Handle notification menu close
  const handleNotificationClose = () => {
    setNotificationAnchorEl(null);
    setShowNotifications(false);
  };

  const menuItems = [
    {
      type: 'section',
      title: 'Management',
      items: [
        { text: 'Manage Companies', icon: <BusinessIcon />, onClick: () => setActiveTab('companies') },
        { text: 'Internship Cycle', icon: <EventNoteIcon />, onClick: () => setActiveTab('cycle') },
        { text: 'View Students', icon: <PeopleIcon />, onClick: () => setActiveTab('students') },
        { text: 'Internship Reports', icon: <AssignmentIcon />, onClick: () => setActiveTab('reports') }
      ]
    },
    {
      type: 'section',
      title: 'Activities',
      items: [
        { text: 'Workshops', icon: <GroupsIcon />, onClick: () => setActiveTab('workshops') },
        { text: 'Statistics', icon: <AssessmentIcon />, onClick: () => setActiveTab('statistics') },
        { text: 'Internship List', icon: <WorkIcon />, onClick: () => setActiveTab('internships') },
        { text: 'Evaluation Reports', icon: <CheckCircleIcon />, onClick: () => setActiveTab('evaluations') },
        { text: 'Appointments', icon: <EventIcon />, onClick: () => setActiveTab('appointments') }
      ]
    }
  ];

  return (
    <Box sx={{ display: 'flex' }}>
      {/* Sidebar */}
      <Drawer
        variant="permanent"
        sx={{
          width: isSidebarCollapsed ? 70 : drawerWidth,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: isSidebarCollapsed ? 70 : drawerWidth,
            boxSizing: 'border-box',
            backgroundColor: navyBlue,
            color: 'white',
            transition: 'width 0.3s',
            overflowX: 'hidden',
          },
        }}
      >
        <Toolbar sx={{ 
          bgcolor: lightNavyBlue, 
          display: 'flex', 
          justifyContent: 'center',
          alignItems: 'center',
          minHeight: '64px !important',
          borderBottom: '1px solid rgba(255, 255, 255, 0.12)'
        }}>
          <Box sx={{ 
            display: 'flex', 
            flexDirection: 'column', 
            alignItems: 'center',
            opacity: !isSidebarCollapsed ? 1 : 0,
            transition: 'opacity 0.3s'
          }}>
            <Typography variant="h6" sx={{ 
              fontWeight: 'bold',
              letterSpacing: '0.5px',
              fontSize: '1.2rem',
              color: '#fff'
            }}>
              GUC SYSTEM
            </Typography>
            <Typography variant="subtitle2" sx={{ 
              color: 'rgba(255, 255, 255, 0.7)',
              fontSize: '0.75rem',
              marginTop: '4px'
            }}>
              SCAD Portal
            </Typography>
          </Box>
        </Toolbar>

        <List>
          {menuItems.map((section, sectionIndex) => (
            <React.Fragment key={section.title || sectionIndex}>
              {section.title && !isSidebarCollapsed && (
                <ListSubheader
                  sx={{
                    bgcolor: 'transparent',
                    color: 'rgba(255, 255, 255, 0.7)',
                    lineHeight: '30px',
                    mt: sectionIndex === 0 ? 0 : 2,
                  }}
                >
                  {section.title}
                </ListSubheader>
              )}
              {section.items.map((item) => (
                <ListItem
                  button
                  key={item.text}
                  onClick={item.onClick}
                  sx={{
                    '&:hover': {
                      bgcolor: lightNavyBlue,
                    },
                    px: !isSidebarCollapsed ? 2 : 1.5,
                    justifyContent: !isSidebarCollapsed ? 'initial' : 'center',
                    minHeight: 48,
                  }}
                >
                  <ListItemIcon 
                    sx={{ 
                      color: 'white', 
                      minWidth: !isSidebarCollapsed ? 40 : 'auto',
                      mr: !isSidebarCollapsed ? 2 : 'auto',
                    }}
                  >
                    {item.icon}
                  </ListItemIcon>
                  {!isSidebarCollapsed && <ListItemText primary={item.text} />}
                </ListItem>
              ))}
            </React.Fragment>
          ))}
        </List>
      </Drawer>

      {/* Main content */}
      <Box component="main" sx={{ flexGrow: 1 }}>
        <AppBar
          position="fixed"
          sx={{
            backgroundColor: navyBlue,
            width: { sm: `calc(100% - ${isSidebarCollapsed ? 70 : drawerWidth}px)` },
            ml: { sm: `${isSidebarCollapsed ? 70 : drawerWidth}px` },
            transition: 'width 0.3s, margin-left 0.3s',
          }}
        >
          <Toolbar>
            <IconButton
              color="inherit"
              onClick={() => setSidebarCollapsed(!isSidebarCollapsed)}
              edge="start"
              sx={{ mr: 2 }}
            >
              <MenuIcon />
            </IconButton>
            <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
              SCAD Portal
            </Typography>

            <Box sx={{ 
              display: 'flex', 
              alignItems: 'center', 
              ml: 'auto',
              gap: 2
            }}>
              {/* Notifications */}
              <IconButton
                color="inherit"
                onClick={handleNotificationClick}
                sx={{ 
                  p: 1,
                  '&:hover': { backgroundColor: 'rgba(255, 255, 255, 0.1)' }
                }}
              >
                <Badge badgeContent={notifications.length} color="error">
                  <NotificationsIcon />
                </Badge>
              </IconButton>

              {/* Profile */}
              <IconButton
                color="inherit"
                onClick={() => setShowProfileMenu(!showProfileMenu)}
                sx={{ 
                  p: 1,
                  '&:hover': { backgroundColor: 'rgba(255, 255, 255, 0.1)' }
                }}
              >
                <Avatar sx={{ width: 32, height: 32 }} />
              </IconButton>
            </Box>

            {/* Profile Menu */}
            {showProfileMenu && (
              <Menu
                anchorEl={document.querySelector('.MuiAvatar-root')}
                open={showProfileMenu}
                onClose={() => setShowProfileMenu(false)}
                PaperProps={{
                  elevation: 0,
                  sx: {
                    overflow: 'visible',
                    filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
                    mt: 1.5,
                    bgcolor: 'background.paper',
                    color: 'text.primary',
                    borderRadius: 3,
                    minWidth: 340,
                    p: 0,
                  },
                }}
                transformOrigin={{ horizontal: 'right', vertical: 'top' }}
                anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
              >
                <Box sx={{ bgcolor: navyBlue, color: 'white', px: 3, py: 2, borderTopLeftRadius: 12, borderTopRightRadius: 12 }}>
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    Profile Options
                  </Typography>
                </Box>
                <Divider />
                <MenuItem sx={{ py: 2, px: 3, cursor: 'default', '&:hover': { background: 'none' } }}>
                  <ListItemIcon>
                    <EmailIcon fontSize="medium" sx={{ color: '#1976d2' }} />
                  </ListItemIcon>
                  <Typography sx={{ 
                    fontWeight: 500, 
                    fontSize: '0.95rem',
                    color: 'text.secondary',
                    wordBreak: 'break-all'
                  }}>
                    {SCAD_EMAIL}
                  </Typography>
                </MenuItem>
                <Divider />
                <MenuItem 
                  component={Link} 
                  to="/"
                  onClick={() => setShowProfileMenu(false)}
                  sx={{ py: 2, px: 3 }}
                >
                  <ListItemIcon>
                    <LogoutIcon fontSize="medium" sx={{ color: '#d32f2f' }} />
                  </ListItemIcon>
                  <Typography sx={{ fontWeight: 500, fontSize: '1.1rem', color: '#d32f2f' }}>Logout</Typography>
                </MenuItem>
              </Menu>
            )}

            {/* Notifications Menu */}
            <Menu
              anchorEl={notificationAnchorEl}
              open={showNotifications}
              onClose={handleNotificationClose}
              PaperProps={{
                sx: {
                  width: 320,
                  maxHeight: 440,
                  overflow: 'auto',
                  backgroundColor: 'white',
                  boxShadow: '0px 5px 15px rgba(0, 0, 0, 0.2)',
                  borderRadius: '8px',
                  mt: 1,
                  '& .MuiDivider-root': {
                    borderColor: 'rgba(0, 0, 0, 0.12)'
                  }
                }
              }}
              transformOrigin={{ horizontal: 'right', vertical: 'top' }}
              anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
            >
              <Box sx={{
                p: 2,
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                background: navyBlue,
                color: 'white',
                borderTopLeftRadius: '8px',
                borderTopRightRadius: '8px'
              }}>
                <Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: 'white' }}>
                  System Notifications
                </Typography>
                {notifications.length > 0 && (
                  <Typography
                    variant="button"
                    sx={{
                      cursor: 'pointer',
                      fontSize: '0.8rem',
                      opacity: 0.8,
                      '&:hover': { opacity: 1 }
                    }}
                    onClick={handleMarkAllAsRead}
                  >
                    Clear All
                  </Typography>
                )}
              </Box>
              <Divider />
              {notifications.length === 0 ? (
                <Box sx={{ p: 2, textAlign: 'center', color: 'text.secondary' }}>
                  <Typography variant="body2">No notifications</Typography>
                </Box>
              ) : (
                notifications.map((notification) => (
                  <MenuItem
                    key={notification.id}
                    onClick={() => handleMarkAsRead(notification.id)}
                    sx={{
                      py: 1.5,
                      px: 2,
                      borderBottom: '1px solid rgba(0, 0, 0, 0.08)',
                      backgroundColor: notification.isRead ? 'transparent' : 'rgba(25, 118, 210, 0.08)',
                      whiteSpace: 'normal',
                      minHeight: 'auto'
                    }}
                  >
                    <Box sx={{ 
                      display: 'flex', 
                      flexDirection: 'column',
                      width: '100%',
                      gap: 0.5
                    }}>
                      <Typography 
                        variant="body2" 
                        sx={{ 
                          flex: 1,
                          wordBreak: 'break-word'
                        }}
                      >
                        {notification.message}
                      </Typography>
                      <Typography 
                        variant="caption" 
                        color="text.secondary"
                        sx={{
                          display: 'block',
                          textAlign: 'right'
                        }}
                      >
                        {notification.time}
                      </Typography>
                    </Box>
                  </MenuItem>
                ))
              )}
            </Menu>
          </Toolbar>
        </AppBar>
        <Toolbar />
        
        {/* Page Content */}
        <Box sx={{ p: 3, backgroundColor: '#f5f5f5', minHeight: 'calc(100vh - 64px)', position: 'relative' }}>
          {/* Header Section for each page */}
          <Box sx={{ 
            mb: 4,
            p: 3,
            bgcolor: navyBlue,
            borderRadius: 2,
            color: 'white'
          }}>
            <Typography variant="h4" sx={{ fontWeight: 700, mb: 1 }}>
              {activeTab === 'companies' && 'Manage Companies'}
              {activeTab === 'cycle' && 'Internship Cycle'}
              {activeTab === 'students' && 'Student Management'}
              {activeTab === 'reports' && 'Internship Reports'}
              {activeTab === 'workshops' && 'Workshop Management'}
              {activeTab === 'statistics' && 'System Statistics'}
              {activeTab === 'internships' && 'Internship Management'}
              {activeTab === 'evaluations' && 'Evaluation Reports'}
              {activeTab === 'appointments' && 'Appointment Management'}
            </Typography>
            <Typography variant="subtitle1">
              {activeTab === 'companies' && 'View and manage registered companies in the system'}
              {activeTab === 'cycle' && 'Manage internship cycles and their configurations'}
              {activeTab === 'students' && 'View and manage student profiles and their progress'}
              {activeTab === 'reports' && 'Review and manage student internship reports'}
              {activeTab === 'workshops' && 'Organize and manage career development workshops'}
              {activeTab === 'statistics' && 'View system-wide statistics and analytics'}
              {activeTab === 'internships' && 'Monitor and manage ongoing internships'}
              {activeTab === 'evaluations' && 'Review company and student evaluations'}
              {activeTab === 'appointments' && 'Manage student career guidance appointments'}
            </Typography>
          </Box>

          {activeTab === 'companies' && <CompanyList />}
          {activeTab === 'cycle' && <InternshipCycle />}
          {activeTab === 'students' && <StudentList />}
          {activeTab === 'reports' && <ReportList />}
          {activeTab === 'workshops' && <WorkshopsPanel />}
          {activeTab === 'statistics' && <StatisticsPanel />}
          {activeTab === 'internships' && <InternshipList />}
          {activeTab === 'evaluations' && <EvaluationReportList />}
          {activeTab === 'appointments' && <AppointmentsPanel />}
        </Box>
      </Box>

      {/* Add CSS for animations */}
      <style>
        {`
          @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
          }
          
          .sidebar-tooltip {
            animation: fadeIn 0.2s ease;
          }
        `}
      </style>
    </Box>
  );
}
