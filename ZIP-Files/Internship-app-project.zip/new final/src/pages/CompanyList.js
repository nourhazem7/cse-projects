import React, { useState } from 'react';
import {
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  IconButton,
  Button,
  TextField,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Snackbar,
  Alert,
  InputAdornment,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import VisibilityIcon from '@mui/icons-material/Visibility';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import FilterListIcon from '@mui/icons-material/FilterList';
import MoreVertIcon from '@mui/icons-material/MoreVert';

const initialCompanies = [
  {
    id: 1,
    name: 'TechSpark',
    industry: 'Software',
    size: 'Medium',
    email: 'hr@techspark.com',
    location: 'Germany',
    status: 'Pending',
    description: 'TechSpark develops innovative cloud-based software solutions.'
  },
  {
    id: 2,
    name: 'GreenAgro',
    industry: 'Agriculture',
    size: 'Small',
    email: 'info@greenagro.org',
    location: 'Egypt',
    status: 'Approved',
    description: 'GreenAgro focuses on sustainable farming and agri-tech.'
  },
  {
    id: 3,
    name: 'Vodafone Egypt',
    industry: 'Telecommunications',
    size: 'Enterprise',
    email: 'jobs@vodafone.com.eg',
    location: 'Egypt',
    status: 'Pending',
    description: 'Vodafone provides mobile and data services in Egypt.'
  },
  {
    id: 4,
    name: 'Nestlé',
    industry: 'Food & Beverage',
    size: 'Enterprise',
    email: 'careers@nestle.com',
    location: 'Switzerland',
    status: 'Rejected',
    description: 'Nestlé is a global leader in food and nutrition.'
  }
];

const industries = ['All', 'Software', 'Agriculture', 'Telecommunications', 'Food & Beverage'];

export default function CompanyList() {
  const [companies, setCompanies] = useState(initialCompanies);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('All');
  const [selectedCompany, setSelectedCompany] = useState(null);
  const [showConfirmation, setShowConfirmation] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

  const handleStatusChange = (id, newStatus) => {
    setShowConfirmation(null);
    const updated = companies.map(company =>
      company.id === id ? { ...company, status: newStatus } : company
    );
    setCompanies(updated);
    setSelectedCompany(null);

    const changedCompany = companies.find(company => company.id === id);
    console.log(
      `📧 Email to ${changedCompany.email}: Your application has been ${newStatus.toLowerCase()} by the SCAD Office.`
    );

    setSnackbar({
      open: true,
      message: `${changedCompany.name} has been ${newStatus.toLowerCase()}. Email notification sent.`,
      severity: 'success'
    });
  };

  const getStatusChipProps = (status) => {
    switch (status) {
      case 'Approved':
        return { color: 'success', icon: <CheckCircleIcon /> };
      case 'Rejected':
        return { color: 'error', icon: <CancelIcon /> };
      case 'Pending':
        return { color: 'default', icon: null, sx: { bgcolor: '#e0e0e0', color: '#616161' } };
      default:
        return { color: 'default', icon: null };
    }
  };

  const filteredCompanies = companies.filter(company => {
    return (
      (filter === 'All' || company.industry === filter) &&
      company.name.toLowerCase().includes(search.toLowerCase())
    );
  });

  return (
    <Box sx={{ p: 3 }}>
      {/* Filters Section */}
      <Box sx={{ 
          display: 'flex',
        gap: 2, 
        mb: 3,
        flexWrap: 'wrap',
        alignItems: 'center' 
        }}>
        <TextField
          placeholder="Search companies..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          sx={{ minWidth: 300 }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
          }}
        />
        <FormControl sx={{ minWidth: 200 }}>
          <InputLabel id="industry-filter-label">
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <FilterListIcon fontSize="small" />
              Industry
            </Box>
          </InputLabel>
          <Select
            labelId="industry-filter-label"
            value={filter}
            label="Industry"
            onChange={(e) => setFilter(e.target.value)}
          >
            {industries.map((industry) => (
              <MenuItem key={industry} value={industry}>{industry}</MenuItem>
            ))}
          </Select>
        </FormControl>
      </Box>

      {/* Table Section */}
      <TableContainer component={Paper} sx={{ 
        boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
        borderRadius: 2,
        overflow: 'hidden'
      }}>
        <Table>
          <TableHead>
            <TableRow sx={{ backgroundColor: '#f8f9fa' }}>
              <TableCell sx={{ fontWeight: 600 }}>Company Name</TableCell>
              <TableCell sx={{ fontWeight: 600 }}>Industry</TableCell>
              <TableCell sx={{ fontWeight: 600 }}>Email</TableCell>
              <TableCell sx={{ fontWeight: 600 }}>Status</TableCell>
              <TableCell sx={{ fontWeight: 600 }}>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredCompanies.map((company) => (
              <TableRow 
                key={company.id}
                sx={{ '&:hover': { backgroundColor: '#f8f9fa' } }}
              >
                <TableCell>
                  <Typography variant="body1" sx={{ fontWeight: 500 }}>
                    {company.name}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    {company.location}
                  </Typography>
                </TableCell>
                <TableCell>{company.industry}</TableCell>
                <TableCell>{company.email}</TableCell>
                <TableCell>
                  <Chip
                    label={company.status}
                    size="small"
                    {...getStatusChipProps(company.status)}
                    sx={{ minWidth: 100 }}
                  />
                </TableCell>
                <TableCell>
                  <Box sx={{ display: 'flex', gap: 1 }}>
                    <IconButton
                      size="small"
                      onClick={() => setSelectedCompany(company)}
                      sx={{ color: '#0A1929' }}
                    >
                      <VisibilityIcon />
                    </IconButton>
                  </Box>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Company Details Dialog */}
      <Dialog 
        open={Boolean(selectedCompany)} 
        onClose={() => setSelectedCompany(null)}
        maxWidth="sm"
        fullWidth
      >
      {selectedCompany && (
          <>
            <DialogTitle>
              <Typography variant="h6" sx={{ fontWeight: 600 }}>
                Company Details
              </Typography>
            </DialogTitle>
            <DialogContent dividers>
              <Box sx={{ py: 1 }}>
                <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 0.5 }}>
                  {selectedCompany.name}
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                  {selectedCompany.description}
                </Typography>
                <Box sx={{ display: 'grid', gap: 2 }}>
                  <Box>
                    <Typography variant="caption" color="text.secondary">
                      Industry
                    </Typography>
                    <Typography variant="body2">
                      {selectedCompany.industry}
                    </Typography>
                  </Box>
                  <Box>
                    <Typography variant="caption" color="text.secondary">
                      Company Size
                    </Typography>
                    <Typography variant="body2">
                      {selectedCompany.size}
                    </Typography>
                  </Box>
                  <Box>
                    <Typography variant="caption" color="text.secondary">
                      Location
                    </Typography>
                    <Typography variant="body2">
                      {selectedCompany.location}
                    </Typography>
                  </Box>
                  <Box>
                    <Typography variant="caption" color="text.secondary">
                      Contact Email
                    </Typography>
                    <Typography variant="body2">
                      {selectedCompany.email}
                    </Typography>
                  </Box>
                  <Box>
                    <Typography variant="caption" color="text.secondary">
                      Status
                    </Typography>
                    <Box sx={{ mt: 0.5 }}>
                      <Chip
                        label={selectedCompany.status}
                        size="small"
                        {...getStatusChipProps(selectedCompany.status)}
                      />
                    </Box>
                  </Box>
                </Box>
              </Box>
            </DialogContent>
            <DialogActions sx={{ 
              p: 2, 
              gap: 1,
              borderTop: '1px solid rgba(0, 0, 0, 0.12)',
              justifyContent: selectedCompany.status === 'Pending' ? 'space-between' : 'flex-end'
            }}>
              {selectedCompany.status === 'Pending' && (
                <Box sx={{ display: 'flex', gap: 1 }}>
                  <Button
                    variant="contained"
                    color="success"
                    onClick={() => setShowConfirmation({ company: selectedCompany, action: 'Approved' })}
                    startIcon={<CheckCircleIcon />}
                  >
                    Approve
                  </Button>
                  <Button
                    variant="contained"
                    color="error"
                    onClick={() => setShowConfirmation({ company: selectedCompany, action: 'Rejected' })}
                    startIcon={<CancelIcon />}
                  >
                    Reject
                  </Button>
                </Box>
              )}
              <Button 
                onClick={() => setSelectedCompany(null)}
                color="inherit"
              >
                Close
              </Button>
            </DialogActions>
          </>
        )}
      </Dialog>

      {/* Confirmation Dialog */}
      <Dialog
        open={Boolean(showConfirmation)}
        onClose={() => setShowConfirmation(null)}
        maxWidth="xs"
        fullWidth
      >
        {showConfirmation && (
          <>
            <DialogTitle>
              Confirm Action
            </DialogTitle>
            <DialogContent>
              <Typography>
                Are you sure you want to {showConfirmation.action.toLowerCase()} {showConfirmation.company.name}?
              </Typography>
            </DialogContent>
            <DialogActions>
              <Button 
                onClick={() => setShowConfirmation(null)}
                color="inherit"
              >
                Cancel
              </Button>
              <Button
                onClick={() => handleStatusChange(showConfirmation.company.id, showConfirmation.action)}
                color={showConfirmation.action === 'Approved' ? 'success' : 'error'}
                variant="contained"
              >
                Confirm
              </Button>
            </DialogActions>
          </>
        )}
      </Dialog>

      {/* Snackbar Notifications */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert 
          onClose={() => setSnackbar({ ...snackbar, open: false })} 
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}

const thStyle = {
  padding: '12px 16px',
  borderBottom: '2px solid #e8eaed',
  textAlign: 'left',
  fontSize: '0.875rem',
  fontWeight: '500',
  color: '#5f6368'
};

const tdStyle = {
  padding: '12px 16px',
  fontSize: '0.875rem',
  color: '#202124'
};
