import React from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  Grid,
  Typography,
  Stack,
  IconButton,
  Tooltip,
  Snackbar,
  Alert,
  LinearProgress,
} from '@mui/material';
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip as RechartsTooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';
import DownloadIcon from '@mui/icons-material/Download';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import GroupIcon from '@mui/icons-material/Group';
import BusinessIcon from '@mui/icons-material/Business';
import SchoolIcon from '@mui/icons-material/School';
import jsPDF from 'jspdf';
import { format } from 'date-fns';

// Sample data - replace with real data from your backend
const reportStats = [
  { name: 'Approved', value: 120, color: '#2ecc71' },
  { name: 'Rejected', value: 40, color: '#e74c3c' },
  { name: 'Flagged', value: 30, color: '#f1c40f' },
  { name: 'Pending', value: 10, color: '#95a5a6' },
];

const departmentStats = [
  { label: 'CS', approved: 40, rejected: 10, flagged: 5 },
  { label: 'ENG', approved: 30, rejected: 5, flagged: 8 },
  { label: 'BA', approved: 25, rejected: 15, flagged: 4 },
];

const courseUsage = [
  { name: 'Data Structures', value: 45, color: '#3498db' },
  { name: 'Database Systems', value: 30, color: '#9b59b6' },
  { name: 'Software Engineering', value: 60, color: '#1abc9c' },
];

const companyEvaluations = [
  { name: 'Tech Corp', rating: 4.8, interns: 50 },
  { name: 'Global Solutions', rating: 4.2, interns: 30 },
  { name: 'Digital Dynamics', rating: 4.6, interns: 40 },
];

const monthlyStats = [
  { month: 'Jan', placements: 25 },
  { month: 'Feb', placements: 30 },
  { month: 'Mar', placements: 35 },
  { month: 'Apr', placements: 40 },
  { month: 'May', placements: 45 },
  { month: 'Jun', placements: 50 },
];

const StatCard = ({ title, value, icon, color, subtitle }) => (
  <Card sx={{ height: '100%' }}>
    <CardContent>
      <Stack spacing={2}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <Typography variant="h6" color="text.secondary">
            {title}
          </Typography>
          <Box sx={{ 
            backgroundColor: `${color}20`,
            p: 1,
            borderRadius: 1,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            {icon}
          </Box>
        </Box>
        <Typography variant="h4">
          {value}
        </Typography>
        {subtitle && (
          <Typography variant="body2" color="text.secondary">
            {subtitle}
          </Typography>
        )}
      </Stack>
    </CardContent>
  </Card>
);

export default function StatisticsPanel() {
  const [snackbar, setSnackbar] = React.useState({ open: false, message: '', severity: 'success' });

  const totalInterns = companyEvaluations.reduce((sum, company) => sum + company.interns, 0);
  const averageRating = (companyEvaluations.reduce((sum, company) => sum + company.rating, 0) / companyEvaluations.length).toFixed(1);
  const totalReports = reportStats.reduce((sum, stat) => sum + stat.value, 0);

  const generatePDF = () => {
    try {
      const doc = new jsPDF();
      doc.setFontSize(16);
      doc.text('Internship Statistics Report', 20, 20);
      doc.setFontSize(12);
      
      // Summary
      doc.text('Summary:', 20, 40);
      doc.text(`Total Interns: ${totalInterns}`, 30, 50);
      doc.text(`Average Company Rating: ${averageRating}`, 30, 60);
      doc.text(`Total Reports: ${totalReports}`, 30, 70);

      // Report Status
      doc.text('Report Status:', 20, 90);
      reportStats.forEach((item, i) => {
        doc.text(`${item.name}: ${item.value}`, 30, 100 + i * 10);
      });

      // Company Evaluations
      doc.text('Top Rated Companies:', 20, 140);
      companyEvaluations.forEach((c, i) => {
        doc.text(`${c.name} - Rating: ${c.rating}, Interns: ${c.interns}`, 30, 150 + i * 10);
      });

      doc.text(`Generated on: ${format(new Date(), 'PPpp')}`, 20, 280);
      
      doc.save('internship_statistics.pdf');
      
      setSnackbar({
        open: true,
        message: 'Report downloaded successfully',
        severity: 'success'
      });
    } catch (error) {
      setSnackbar({
        open: true,
        message: 'Failed to generate report',
        severity: 'error'
      });
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Stack spacing={3}>
        {/* Header */}
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center' }}>
          <Button
            variant="contained"
            startIcon={<DownloadIcon />}
            onClick={generatePDF}
          >
            Download Report
          </Button>
        </Box>

        {/* Summary Cards */}
        <Grid container spacing={2}>
          <Grid item xs={12} md={4}>
            <StatCard
              title="Total Interns"
              value={totalInterns}
              icon={<GroupIcon sx={{ color: '#3498db' }} />}
              color="#3498db"
              subtitle="Active internships this cycle"
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <StatCard
              title="Average Company Rating"
              value={averageRating}
              icon={<BusinessIcon sx={{ color: '#2ecc71' }} />}
              color="#2ecc71"
              subtitle="Based on intern feedback"
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <StatCard
              title="Total Reports"
              value={totalReports}
              icon={<SchoolIcon sx={{ color: '#9b59b6' }} />}
              color="#9b59b6"
              subtitle="Submitted this cycle"
            />
          </Grid>
        </Grid>

        {/* Charts */}
        <Grid container spacing={3}>
          {/* Report Status */}
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Report Status Distribution
                </Typography>
                <Box sx={{ height: 300 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={reportStats}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        outerRadius={100}
                        label
                      >
                        {reportStats.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <RechartsTooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </Box>
              </CardContent>
            </Card>
          </Grid>

          {/* Department Stats */}
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Reports by Department
                </Typography>
                <Box sx={{ height: 300 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={departmentStats}>
                      <XAxis dataKey="label" />
                      <YAxis />
                      <RechartsTooltip />
                      <Legend />
                      <Bar dataKey="approved" stackId="a" fill="#2ecc71" name="Approved" />
                      <Bar dataKey="rejected" stackId="a" fill="#e74c3c" name="Rejected" />
                      <Bar dataKey="flagged" stackId="a" fill="#f1c40f" name="Flagged" />
                    </BarChart>
                  </ResponsiveContainer>
                </Box>
              </CardContent>
            </Card>
          </Grid>

          {/* Monthly Trend */}
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Monthly Placement Trend
                </Typography>
                <Box sx={{ height: 300 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={monthlyStats}>
                      <XAxis dataKey="month" />
                      <YAxis />
                      <RechartsTooltip />
                      <Legend />
                      <Line type="monotone" dataKey="placements" stroke="#3498db" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </Box>
              </CardContent>
            </Card>
          </Grid>

          {/* Course Usage */}
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Popular Internship Courses
                </Typography>
                <Box sx={{ height: 300 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={courseUsage}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        outerRadius={100}
                        label
                      >
                        {courseUsage.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <RechartsTooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </Box>
              </CardContent>
            </Card>
          </Grid>

          {/* Company Ratings */}
          <Grid item xs={12}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Company Performance
                </Typography>
                <Box sx={{ height: 300 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={companyEvaluations}>
                      <XAxis dataKey="name" />
                      <YAxis yAxisId="left" orientation="left" stroke="#3498db" />
                      <YAxis yAxisId="right" orientation="right" stroke="#2ecc71" />
                      <RechartsTooltip />
                      <Legend />
                      <Bar yAxisId="left" dataKey="interns" fill="#3498db" name="Number of Interns" />
                      <Bar yAxisId="right" dataKey="rating" fill="#2ecc71" name="Rating" />
                    </BarChart>
                  </ResponsiveContainer>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Stack>

      {/* Snackbar for notifications */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          severity={snackbar.severity}
          variant="filled"
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}
