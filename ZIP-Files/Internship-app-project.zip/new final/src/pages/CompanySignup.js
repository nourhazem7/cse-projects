import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PhoneInput from 'react-phone-input-2';
import 'react-phone-input-2/lib/style.css';
import Select from 'react-select';
import { getData } from 'country-list';

export default function CompanySignup() {
  const [companyName, setCompanyName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [website, setWebsite] = useState('');
  const [industry, setIndustry] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const navigate = useNavigate();
  const [phone, setPhone] = useState('');
  const [location, setLocation] = useState(null);
  const [companyLogo, setCompanyLogo] = useState(null);
  const [companyDocs, setCompanyDocs] = useState(null);

  const countryOptions = getData().map((country) => ({
    value: country.code,
    label: country.name
  }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError('Please enter a valid email address');
      setIsLoading(false);
      return;
    }

    // Validate website format (optional field)
    if (website && !website.match(/^(https?:\/\/)?([\w-]+\.)+[\w-]+(\/[\w-./?%&=]*)?$/)) {
      setError('Please enter a valid website URL');
      setIsLoading(false);
      return;
    }

    // Validate file uploads
    if (!companyLogo) {
      setError('Please upload a company logo');
      setIsLoading(false);
      return;
    }

    if (!companyDocs) {
      setError('Please upload company registration documents');
      setIsLoading(false);
      return;
    }

    // Validate file types
    const allowedLogoTypes = ['image/jpeg', 'image/png', 'image/gif'];
    const allowedDocTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];

    if (!allowedLogoTypes.includes(companyLogo.type)) {
      setError('Company logo must be an image file (JPEG, PNG, or GIF)');
      setIsLoading(false);
      return;
    }

    if (!allowedDocTypes.includes(companyDocs.type)) {
      setError('Company documents must be in PDF or DOC format');
      setIsLoading(false);
      return;
    }

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 800));

    setShowSuccess(true);
    setTimeout(() => {
      navigate('/company-upload-docs');
    }, 2000);
  };

  return (
    <div style={{ 
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px',
      backgroundColor: '#f8f9fa'
    }}>
      <div style={{
        backgroundColor: 'white',
        borderRadius: '12px',
        boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
        padding: '40px',
        width: '100%',
        maxWidth: '400px',
        position: 'relative'
      }}>
        <div style={{
          textAlign: 'center',
          marginBottom: '32px'
        }}>
          <h1 style={{ 
            color: '#0A1929',
            fontSize: '32px',
            fontWeight: '700',
            marginBottom: '8px',
            letterSpacing: '-0.5px'
          }}>Company Sign Up</h1>
          <p style={{ 
            color: '#666',
            fontSize: '15px',
            margin: 0
          }}>Create your company account to post internship opportunities</p>
        </div>

        <form 
          onSubmit={handleSubmit}
          style={{ 
            display: "flex", 
            flexDirection: "column", 
            gap: "20px"
          }}
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <label 
              htmlFor="companyName" 
              style={{ 
                fontSize: '14px', 
                fontWeight: '500',
                color: '#444'
              }}
            >
              Company Name
            </label>
            <input 
              id="companyName"
              type="text" 
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              required
              placeholder="Enter your company name"
              style={{
                padding: '12px 16px',
                border: '1px solid #dfe1e5',
                borderRadius: '8px',
                fontSize: '15px',
                width: '100%',
                transition: 'border-color 0.2s',
                outline: 'none',
                boxSizing: 'border-box',
                WebkitAppearance: 'none',
                MozAppearance: 'none',
                appearance: 'none'
              }}
              onFocus={(e) => e.target.style.borderColor = '#0A1929'}
              onBlur={(e) => e.target.style.borderColor = '#dfe1e5'}
            />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <label 
              htmlFor="industry" 
              style={{ 
                fontSize: '14px', 
                fontWeight: '500',
                color: '#444'
              }}
            >
              Industry
            </label>
            <input 
              id="industry"
              type="text" 
              value={industry}
              onChange={(e) => setIndustry(e.target.value)}
              required
              placeholder="e.g. Technology, Healthcare, Finance"
              style={{
                padding: '12px 16px',
                border: '1px solid #dfe1e5',
                borderRadius: '8px',
                fontSize: '15px',
                width: '100%',
                transition: 'border-color 0.2s',
                outline: 'none',
                boxSizing: 'border-box',
                WebkitAppearance: 'none',
                MozAppearance: 'none',
                appearance: 'none'
              }}
              onFocus={(e) => e.target.style.borderColor = '#0A1929'}
              onBlur={(e) => e.target.style.borderColor = '#dfe1e5'}
            />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <label 
              htmlFor="email" 
              style={{ 
                fontSize: '14px', 
                fontWeight: '500',
                color: '#444'
              }}
            >
              Business Email
            </label>
            <input 
              id="email"
              type="email" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="Enter your business email"
              style={{
                padding: '12px 16px',
                border: '1px solid #dfe1e5',
                borderRadius: '8px',
                fontSize: '15px',
                width: '100%',
                transition: 'border-color 0.2s',
                outline: 'none',
                boxSizing: 'border-box',
                WebkitAppearance: 'none',
                MozAppearance: 'none',
                appearance: 'none'
              }}
              onFocus={(e) => e.target.style.borderColor = '#0A1929'}
              onBlur={(e) => e.target.style.borderColor = '#dfe1e5'}
            />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <label 
              htmlFor="website" 
              style={{ 
                fontSize: '14px', 
                fontWeight: '500',
                color: '#444'
              }}
            >
              Company Website
            </label>
            <input 
              id="website"
              type="url" 
              value={website}
              onChange={(e) => setWebsite(e.target.value)}
              placeholder="https://www.example.com"
              style={{
                padding: '12px 16px',
                border: '1px solid #dfe1e5',
                borderRadius: '8px',
                fontSize: '15px',
                width: '100%',
                transition: 'border-color 0.2s',
                outline: 'none',
                boxSizing: 'border-box',
                WebkitAppearance: 'none',
                MozAppearance: 'none',
                appearance: 'none'
              }}
              onFocus={(e) => e.target.style.borderColor = '#0A1929'}
              onBlur={(e) => e.target.style.borderColor = '#dfe1e5'}
            />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <label 
              htmlFor="password" 
              style={{ 
                fontSize: '14px', 
                fontWeight: '500',
                color: '#444'
              }}
            >
              Password
            </label>
            <input 
              id="password"
              type="password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="Choose a secure password"
              style={{
                padding: '12px 16px',
                border: '1px solid #dfe1e5',
                borderRadius: '8px',
                fontSize: '15px',
                width: '100%',
                transition: 'border-color 0.2s',
                outline: 'none',
                boxSizing: 'border-box',
                WebkitAppearance: 'none',
                MozAppearance: 'none',
                appearance: 'none'
              }}
              onFocus={(e) => e.target.style.borderColor = '#0A1929'}
              onBlur={(e) => e.target.style.borderColor = '#dfe1e5'}
            />
          </div>

          <PhoneInput
            country={'eg'}
            value={phone}
            onChange={(phone) => setPhone(phone)}
            inputStyle={{ width: '100%' }}
          />

          <label>
            Company Location:
            <Select
              options={countryOptions}
              value={location}
              onChange={(selectedOption) => setLocation(selectedOption)}
              placeholder="Select a country"
              required
            />
          </label>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <label 
              htmlFor="companyLogo" 
              style={{ 
                fontSize: '14px', 
                fontWeight: '500',
                color: '#444'
              }}
            >
              Company Logo
            </label>
            <input 
              id="companyLogo"
              type="file" 
              accept="image/*"
              onChange={(e) => setCompanyLogo(e.target.files[0])}
              required
              style={{
                padding: '12px 16px',
                border: '1px solid #dfe1e5',
                borderRadius: '8px',
                fontSize: '15px',
                width: '100%',
                transition: 'border-color 0.2s',
                outline: 'none',
                boxSizing: 'border-box'
              }}
              onFocus={(e) => e.target.style.borderColor = '#0A1929'}
              onBlur={(e) => e.target.style.borderColor = '#dfe1e5'}
            />
            <span style={{ 
              fontSize: '12px', 
              color: '#666',
              marginTop: '4px' 
            }}>
              Accepted formats: JPEG, PNG, GIF
            </span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <label 
              htmlFor="companyDocs" 
              style={{ 
                fontSize: '14px', 
                fontWeight: '500',
                color: '#444'
              }}
            >
              Company Registration Documents
            </label>
            <input 
              id="companyDocs"
              type="file" 
              accept=".pdf,.doc,.docx"
              onChange={(e) => setCompanyDocs(e.target.files[0])}
              required
              style={{
                padding: '12px 16px',
                border: '1px solid #dfe1e5',
                borderRadius: '8px',
                fontSize: '15px',
                width: '100%',
                transition: 'border-color 0.2s',
                outline: 'none',
                boxSizing: 'border-box'
              }}
              onFocus={(e) => e.target.style.borderColor = '#0A1929'}
              onBlur={(e) => e.target.style.borderColor = '#dfe1e5'}
            />
            <span style={{ 
              fontSize: '12px', 
              color: '#666',
              marginTop: '4px' 
            }}>
              Accepted formats: PDF, DOC, DOCX
            </span>
          </div>

          {error && (
            <div style={{
              color: '#dc3545',
              backgroundColor: '#f8d7da',
              padding: '12px 16px',
              borderRadius: '8px',
              fontSize: '14px',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm-1-7v2h2v-2h-2zm0-8v6h2V7h-2z" fill="currentColor"/>
              </svg>
              {error}
            </div>
          )}

          {showSuccess && (
            <div style={{
              color: '#0f5132',
              backgroundColor: '#d1e7dd',
              padding: '12px 16px',
              borderRadius: '8px',
              fontSize: '14px',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z" fill="currentColor"/>
              </svg>
              Registration successful! Redirecting to document verification...
            </div>
          )}

          <button 
            type="submit"
            disabled={isLoading}
            style={{
              padding: '14px 24px',
              backgroundColor: '#0A1929',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              cursor: isLoading ? 'default' : 'pointer',
              fontSize: '15px',
              fontWeight: '500',
              transition: 'all 0.2s',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px',
              opacity: isLoading ? 0.7 : 1,
              marginTop: '8px'
            }}
            onMouseEnter={(e) => !isLoading && (e.currentTarget.style.backgroundColor = '#1a2a3a')}
            onMouseLeave={(e) => !isLoading && (e.currentTarget.style.backgroundColor = '#0A1929')}
          >
            {isLoading ? (
              <>
                <svg 
                  width="20" 
                  height="20" 
                  viewBox="0 0 24 24"
                  style={{
                    animation: 'spin 1s linear infinite',
                    '@keyframes spin': {
                      '0%': { transform: 'rotate(0deg)' },
                      '100%': { transform: 'rotate(360deg)' }
                    }
                  }}
                >
                  <path d="M12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2ZM4 12C4 7.58172 7.58172 4 12 4V12H20C20 16.4183 16.4183 20 12 20C7.58172 20 4 16.4183 4 12Z" fill="currentColor"/>
                </svg>
                Creating Account...
              </>
            ) : (
              'Create Company Account'
            )}
          </button>
        </form>

        <div style={{ 
          marginTop: '32px',
          textAlign: 'center'
        }}>
          <p style={{ 
            color: '#666',
            fontSize: '14px',
            margin: 0
          }}>
            Already have an account?{' '}
            <a 
              href="/"
              style={{
                color: '#0A1929',
                textDecoration: 'none',
                fontWeight: '500'
              }}
              onMouseEnter={(e) => e.target.style.textDecoration = 'underline'}
              onMouseLeave={(e) => e.target.style.textDecoration = 'none'}
            >
              Sign in here
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
