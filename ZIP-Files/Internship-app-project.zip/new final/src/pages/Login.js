import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    
    // Hardcoded credentials
    const SCAD_EMAIL = 'scad@guc.edu.eg';
    const SCAD_PASSWORD = 'scad123';
    const COMPANY_EMAIL = 'company@example.com';
    const COMPANY_PASSWORD = 'company123';
    const STUDENT_EMAIL = 'student@guc.edu.eg';
    const STUDENT_PASSWORD = 'student123';
    const PRO_EMAIL = 'pro@guc.edu.eg';
    const PRO_PASSWORD = 'pro123';
    const FACULTY_EMAIL = 'faculty@guc.edu.eg';
    const FACULTY_PASSWORD = 'faculty123';

    // Trim the email to remove any accidental spaces
    const trimmedEmail = email.trim();
    
    console.log('Login attempt:', {
      enteredEmail: trimmedEmail,
      enteredPassword: password,
      matchesPro: trimmedEmail === PRO_EMAIL && password === PRO_PASSWORD,
      matchesStudent: trimmedEmail === STUDENT_EMAIL && password === STUDENT_PASSWORD,
      matchesScad: trimmedEmail === SCAD_EMAIL && password === SCAD_PASSWORD,
      matchesCompany: trimmedEmail === COMPANY_EMAIL && password === COMPANY_PASSWORD,
      matchesFaculty: trimmedEmail === FACULTY_EMAIL && password === FACULTY_PASSWORD
    });
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 800));

    if (trimmedEmail === PRO_EMAIL && password === PRO_PASSWORD) {
      console.log('Pro login successful');
      navigate('/pro/dashboard');
      return;
    }

    if (trimmedEmail === STUDENT_EMAIL && password === STUDENT_PASSWORD) {
      console.log('Student login successful');
      navigate('/student/dashboard');
      return;
    }
    
    if (trimmedEmail === SCAD_EMAIL && password === SCAD_PASSWORD) {
      console.log('SCAD login successful');
      navigate('/scad-dashboard');
      return;
    }
    
    if (trimmedEmail === COMPANY_EMAIL && password === COMPANY_PASSWORD) {
      console.log('Company login successful');
      navigate('/company-dashboard');
      return;
    }

    if (trimmedEmail === FACULTY_EMAIL && password === FACULTY_PASSWORD) {
      console.log('Faculty login successful');
      navigate('/faculty/dashboard');
      return;
    }

    console.log('Login failed - no matching credentials');
    setError('Invalid email or password. Please try again.');
    setIsLoading(false);
  };

  return (
    <div style={{ 
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px',
      backgroundColor: '#f8f9fa'
    }}>
      <div style={{
        backgroundColor: 'white',
        borderRadius: '12px',
        boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
        padding: '40px',
        width: '100%',
        maxWidth: '400px',
        position: 'relative'
      }}>
        <div style={{
          textAlign: 'center',
          marginBottom: '32px'
        }}>
          <h1 style={{ 
            color: '#0A1929',
            fontSize: '32px',
            fontWeight: '700',
            marginBottom: '8px',
            letterSpacing: '-0.5px'
          }}>Welcome Back!</h1>
          <p style={{ 
            color: '#666',
            fontSize: '15px',
            margin: 0
          }}>Sign in to continue to the GUC Internship Portal</p>
        </div>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <label 
              htmlFor="email"
              style={{ 
                fontSize: '14px',
                fontWeight: '500',
                color: '#444'
              }}
            >
              Email Address
            </label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="Enter your email"
              style={{
                padding: '12px 16px',
                border: '1px solid #dfe1e5',
                borderRadius: '8px',
                fontSize: '15px',
                width: '100%',
                transition: 'border-color 0.2s',
                outline: 'none',
                boxSizing: 'border-box',
                WebkitAppearance: 'none',
                MozAppearance: 'none',
                appearance: 'none'
              }}
              onFocus={(e) => e.target.style.borderColor = '#0A1929'}
              onBlur={(e) => e.target.style.borderColor = '#dfe1e5'}
            />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <label 
              htmlFor="password"
              style={{ 
                fontSize: '14px',
                fontWeight: '500',
                color: '#444'
              }}
            >
              Password
            </label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="Enter your password"
              style={{
                padding: '12px 16px',
                border: '1px solid #dfe1e5',
                borderRadius: '8px',
                fontSize: '15px',
                width: '100%',
                transition: 'border-color 0.2s',
                outline: 'none',
                boxSizing: 'border-box',
                WebkitAppearance: 'none',
                MozAppearance: 'none',
                appearance: 'none'
              }}
              onFocus={(e) => e.target.style.borderColor = '#0A1929'}
              onBlur={(e) => e.target.style.borderColor = '#dfe1e5'}
            />
          </div>

          {error && (
            <div style={{
              color: '#dc3545',
              backgroundColor: '#f8d7da',
              padding: '12px 16px',
              borderRadius: '8px',
              fontSize: '14px',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm-1-7v2h2v-2h-2zm0-8v6h2V7h-2z" fill="currentColor"/>
              </svg>
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            style={{
              padding: '14px 24px',
              backgroundColor: '#0A1929',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              cursor: isLoading ? 'default' : 'pointer',
              fontSize: '15px',
              fontWeight: '500',
              transition: 'all 0.2s',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px',
              opacity: isLoading ? 0.7 : 1
            }}
            onMouseEnter={(e) => !isLoading && (e.currentTarget.style.backgroundColor = '#1a2a3a')}
            onMouseLeave={(e) => !isLoading && (e.currentTarget.style.backgroundColor = '#0A1929')}
          >
            {isLoading ? (
              <>
                <svg 
                  width="20" 
                  height="20" 
                  viewBox="0 0 24 24"
                  style={{
                    animation: 'spin 1s linear infinite',
                    '@keyframes spin': {
                      '0%': { transform: 'rotate(0deg)' },
                      '100%': { transform: 'rotate(360deg)' }
                    }
                  }}
                >
                  <path d="M12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2ZM4 12C4 7.58172 7.58172 4 12 4V12H20C20 16.4183 16.4183 20 12 20C7.58172 20 4 16.4183 4 12Z" fill="currentColor"/>
                </svg>
                Signing in...
              </>
            ) : (
              'Sign In'
            )}
          </button>
        </form>

        <div style={{ 
          marginTop: '32px',
          textAlign: 'center'
        }}>
          <p style={{ 
            color: '#666',
            fontSize: '14px',
            marginBottom: '16px'
          }}>
            Want to post internship opportunities?
          </p>
          <div style={{
            display: 'flex',
            justifyContent: 'center'
          }}>
            <Link to="/signup-company" style={{ textDecoration: 'none' }}>
              <button style={{ 
                padding: '12px 24px',
                backgroundColor: 'white',
                color: '#0A1929',
                border: '1px solid #0A1929',
                borderRadius: '8px',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: '500',
                transition: 'all 0.2s',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                width: '100%'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#0A1929';
                e.currentTarget.style.color = 'white';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'white';
                e.currentTarget.style.color = '#0A1929';
              }}
            >
                🏢 Register Your Company
              </button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
