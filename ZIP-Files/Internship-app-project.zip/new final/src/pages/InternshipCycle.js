import React, { useState } from 'react';
import {
  Box,
  Paper,
  TextField,
  Button,
  Typography,
  Snackbar,
  Alert,
  Stack,
  Card,
  CardContent,
  Divider,
  LinearProgress,
  Chip,
  Grid,
  IconButton,
  Tooltip,
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import EventIcon from '@mui/icons-material/Event';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import GroupIcon from '@mui/icons-material/Group';
import BusinessIcon from '@mui/icons-material/Business';
import SchoolIcon from '@mui/icons-material/School';
import InfoIcon from '@mui/icons-material/Info';
import { format, differenceInDays, addDays } from 'date-fns';

export default function InternshipCycle() {
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!startDate || !endDate) {
      setSnackbar({
        open: true,
        message: 'Please select both start and end dates.',
        severity: 'error'
      });
      return;
    }

    if (startDate > endDate) {
      setSnackbar({
        open: true,
        message: 'End date must be after start date.',
        severity: 'error'
      });
      return;
    }

    setSnackbar({
      open: true,
      message: 'Internship cycle dates have been set successfully',
      severity: 'success'
    });
  };

  const currentCycle = {
    start: '2024-02-01',
    end: '2024-07-31',
    totalStudents: 245,
    activeCompanies: 32,
    placedStudents: 178,
    phases: [
      { name: 'Registration', start: '2024-02-01', end: '2024-02-15' },
      { name: 'Company Selection', start: '2024-02-16', end: '2024-03-01' },
      { name: 'Interviews', start: '2024-03-02', end: '2024-03-31' },
      { name: 'Internship Period', start: '2024-04-01', end: '2024-07-31' }
    ]
  };

  // Calculate progress percentage
  const totalDays = differenceInDays(new Date(currentCycle.end), new Date(currentCycle.start));
  const elapsedDays = differenceInDays(new Date(), new Date(currentCycle.start));
  const progress = Math.min(Math.max((elapsedDays / totalDays) * 100, 0), 100);

  // Find current phase
  const getCurrentPhase = () => {
    const now = new Date();
    return currentCycle.phases.find(phase => 
      now >= new Date(phase.start) && now <= new Date(phase.end)
    ) || currentCycle.phases[currentCycle.phases.length - 1];
  };

  const currentPhase = getCurrentPhase();

  return (
    <Box sx={{ p: 3 }}>
      <Stack spacing={3}>
        {/* Current Cycle Overview Card */}
        <Card sx={{ bgcolor: '#f8f9fa', position: 'relative', overflow: 'visible' }}>
          <CardContent>
            <Stack spacing={3}>
              {/* Header */}
              <Stack direction="row" alignItems="center" spacing={1}>
                <EventIcon color="primary" sx={{ fontSize: 28 }} />
                <Typography variant="h5" color="primary" sx={{ fontWeight: 600 }}>
                  Current Internship Cycle
                </Typography>
                <Chip 
                  label="Active"
                  size="small"
                  color="success"
                  sx={{ ml: 2 }}
                />
              </Stack>

              {/* Progress Section */}
              <Box sx={{ position: 'relative', mt: 1 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                  <Typography variant="body2" color="text.secondary">
                    Cycle Progress
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {Math.round(progress)}%
                  </Typography>
                </Box>
                <LinearProgress 
                  variant="determinate" 
                  value={progress} 
                  sx={{ 
                    height: 8, 
                    borderRadius: 4,
                    bgcolor: 'rgba(0,0,0,0.05)',
                    '& .MuiLinearProgress-bar': {
                      borderRadius: 4
                    }
                  }} 
                />
              </Box>

              {/* Dates and Stats Grid */}
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <Stack spacing={2}>
                    <Box>
                      <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                        Duration
                      </Typography>
                      <Stack direction="row" spacing={2} alignItems="center">
                        <AccessTimeIcon color="action" />
                        <Typography>
                          {format(new Date(currentCycle.start), 'MMM d, yyyy')} - {format(new Date(currentCycle.end), 'MMM d, yyyy')}
                        </Typography>
                      </Stack>
                    </Box>
                    <Box>
                      <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                        Current Phase
                      </Typography>
                      <Chip 
                        label={currentPhase.name}
                        color="primary"
                        variant="outlined"
                        icon={<CalendarMonthIcon />}
                />
                    </Box>
                  </Stack>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Stack spacing={2}>
                    <Box sx={{ display: 'flex', gap: 3 }}>
                      <Box>
                        <Typography variant="h6" sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <SchoolIcon color="primary" />
                          {currentCycle.totalStudents}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          Total Students
                        </Typography>
                      </Box>
                      <Box>
                        <Typography variant="h6" sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <BusinessIcon color="primary" />
                          {currentCycle.activeCompanies}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          Active Companies
                        </Typography>
                      </Box>
                      <Box>
                        <Typography variant="h6" sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <GroupIcon color="primary" />
                          {currentCycle.placedStudents}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          Placed Students
                        </Typography>
                      </Box>
                    </Box>
                  </Stack>
                </Grid>
              </Grid>

              {/* Timeline */}
              <Box>
                <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                  Cycle Timeline
                </Typography>
                <Stack spacing={2}>
                  {currentCycle.phases.map((phase, index) => (
                    <Box 
                      key={phase.name}
                      sx={{ 
              display: 'flex',
              alignItems: 'center',
                        gap: 2,
                        p: 1.5,
                        borderRadius: 1,
                        bgcolor: currentPhase.name === phase.name ? 'primary.lighter' : 'transparent',
                        border: '1px solid',
                        borderColor: currentPhase.name === phase.name ? 'primary.main' : 'divider'
                      }}
                    >
                      <Typography 
                        variant="body2" 
                        sx={{ 
                          minWidth: 150,
                          fontWeight: currentPhase.name === phase.name ? 600 : 400
                        }}
                      >
                        {phase.name}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {format(new Date(phase.start), 'MMM d')} - {format(new Date(phase.end), 'MMM d, yyyy')}
                      </Typography>
                      {currentPhase.name === phase.name && (
                        <Chip 
                          label="Current" 
                          size="small" 
                          color="primary"
                          sx={{ ml: 'auto' }}
                        />
                      )}
                    </Box>
                  ))}
                </Stack>
              </Box>
            </Stack>
          </CardContent>
        </Card>

        {/* Set New Cycle Card */}
        <Card>
          <CardContent>
            <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 3 }}>
              <Stack direction="row" alignItems="center" spacing={1}>
                <CalendarMonthIcon color="primary" />
                <Typography variant="h6" color="primary">
                  Set New Cycle
                </Typography>
              </Stack>
              <Tooltip title="Setting a new cycle will archive the current one">
                <IconButton size="small">
                  <InfoIcon />
                </IconButton>
              </Tooltip>
            </Stack>

            <form onSubmit={handleSubmit}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <Stack spacing={3}>
                  <Stack 
                    direction={{ xs: 'column', sm: 'row' }} 
                    spacing={2} 
                    divider={<Divider orientation="vertical" flexItem />}
                  >
                    <Box sx={{ flex: 1 }}>
                      <DatePicker
                        label="Start Date"
                        value={startDate}
                        onChange={(newValue) => setStartDate(newValue)}
                        renderInput={(params) => <TextField {...params} fullWidth />}
                        disablePast
                      />
                      <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
                        Select the start date for the new internship cycle
                      </Typography>
                    </Box>
                    <Box sx={{ flex: 1 }}>
                      <DatePicker
                        label="End Date"
                        value={endDate}
                        onChange={(newValue) => setEndDate(newValue)}
                        renderInput={(params) => <TextField {...params} fullWidth />}
                        disablePast
                        minDate={startDate}
                      />
                      <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
                        Cycle duration should be at least 3 months
                      </Typography>
                    </Box>
                  </Stack>

                  <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2 }}>
                    <Button
                      variant="outlined"
                      onClick={() => {
                        setStartDate(null);
                        setEndDate(null);
            }}
          >
                      Clear
                    </Button>
                    <Button
                      type="submit"
                      variant="contained"
                      size="large"
                      startIcon={<CalendarMonthIcon />}
                    >
                      Set Internship Cycle
                    </Button>
                  </Box>
                </Stack>
              </LocalizationProvider>
        </form>
          </CardContent>
        </Card>
      </Stack>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert 
          onClose={() => setSnackbar({ ...snackbar, open: false })} 
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}
