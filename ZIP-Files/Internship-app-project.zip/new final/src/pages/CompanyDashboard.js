import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import InternshipPosts from '../components/InternshipPosts';
import InternshipApplications from '../components/InternshipApplications';
import CompanyInterns from '../components/CompanyInterns';
import AvailableInternships from '../components/AvailableInternships';
import {
  AppBar,
  Box,
  Drawer,
  IconButton,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Typography,
  Menu,
  MenuItem,
  Avatar,
  Badge,
  Divider,
  ListSubheader,
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import NotificationsIcon from '@mui/icons-material/Notifications';
import PersonIcon from '@mui/icons-material/Person';
import LogoutIcon from '@mui/icons-material/Logout';
import WorkIcon from '@mui/icons-material/Work';
import PeopleIcon from '@mui/icons-material/People';
import DashboardIcon from '@mui/icons-material/Dashboard';
import BusinessIcon from '@mui/icons-material/Business';
import EmailIcon from '@mui/icons-material/Email';

const drawerWidth = 240;
const navyBlue = '#0A1929';
const lightNavyBlue = '#1A2B3C';

export default function CompanyDashboard() {
  const [activeView, setActiveView] = useState('posts');
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [isSidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [notificationAnchorEl, setNotificationAnchorEl] = useState(null);
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      type: 'registration_status',
      message: 'Your company registration has been approved! You can now post internship opportunities.',
      time: '5 minutes ago',
      isRead: false,
      icon: '🏢',
      variant: 'success'
    },
    {
      id: 2,
      type: 'registration_documents',
      message: 'Additional documents required for registration verification. Please check your email.',
      time: '1 hour ago',
      isRead: false,
      icon: '📄',
      variant: 'warning'
    },
    {
      id: 3,
      type: 'application_received',
      message: 'Sarah Johnson applied for Software Engineering Intern position',
      time: '2 hours ago',
      isRead: false,
      icon: '📥'
    },
    {
      id: 4,
      type: 'application_accepted',
      message: 'You accepted Ahmed Hassan\'s application for Data Science Intern',
      time: '3 hours ago',
      isRead: false,
      icon: '✅'
    },
    {
      id: 5,
      type: 'application_rejected',
      message: 'You rejected Michael Smith\'s application for UI/UX Design Intern',
      time: '5 hours ago',
      isRead: false,
      icon: '❌'
    },
    {
      id: 6,
      type: 'application_received',
      message: 'Omar Mohamed applied for Frontend Developer Intern position',
      time: '8 hours ago',
      isRead: true,
      icon: '📥'
    },
    {
      id: 7,
      type: 'evaluation_reminder',
      message: 'Reminder: Complete evaluation for John Doe\'s internship',
      time: '1 day ago',
      isRead: true,
      icon: '📋'
    },
    {
      id: 8,
      type: 'system',
      message: 'Your internship post for "Mobile Developer Intern" has been approved',
      time: '2 days ago',
      isRead: true,
      icon: '📱'
    }
  ]);

  // Handle marking all notifications as read
  const handleMarkAllAsRead = () => {
    setNotifications([]);
    setShowNotifications(false);
  };

  // Handle marking a single notification as read
  const handleMarkAsRead = (notificationId) => {
    setNotifications(prevNotifications => 
      prevNotifications.filter(notification => notification.id !== notificationId)
    );
  };

  // Handle notification button click
  const handleNotificationClick = (event) => {
    setNotificationAnchorEl(event.currentTarget);
    setShowNotifications(true);
    setShowProfileMenu(false);
  };

  // Handle notification menu close
  const handleNotificationClose = () => {
    setNotificationAnchorEl(null);
    setShowNotifications(false);
  };

  // Handle profile button click
  const handleProfileClick = () => {
    setShowProfileMenu(!showProfileMenu);
    setShowNotifications(false);
  };

  // Company email constant
  const COMPANY_EMAIL = 'company@example.com';

  const menuItems = [
    {
      type: 'section',
      title: 'Internships',
      items: [
        { text: 'Post Internships', icon: <WorkIcon />, onClick: () => setActiveView('posts') },
        { text: 'Applications', icon: <PeopleIcon />, onClick: () => setActiveView('applications') },
        { text: 'Current Interns', icon: <BusinessIcon />, onClick: () => setActiveView('interns') },
        { text: 'Available Positions', icon: <WorkIcon />, onClick: () => setActiveView('available') }
      ]
    }
  ];

  return (
    <Box sx={{ display: 'flex' }}>
      {/* Sidebar */}
      <Drawer
        variant="permanent"
        sx={{
          width: isSidebarCollapsed ? 70 : drawerWidth,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: isSidebarCollapsed ? 70 : drawerWidth,
            boxSizing: 'border-box',
            backgroundColor: navyBlue,
            color: 'white',
            transition: 'width 0.3s',
            overflowX: 'hidden',
          },
        }}
      >
        <Toolbar sx={{ 
          bgcolor: lightNavyBlue, 
          display: 'flex', 
          justifyContent: 'center',
          alignItems: 'center',
          minHeight: '64px !important',
          borderBottom: '1px solid rgba(255, 255, 255, 0.12)'
        }}>
          <Box sx={{ 
            display: 'flex', 
            flexDirection: 'column', 
            alignItems: 'center',
            opacity: !isSidebarCollapsed ? 1 : 0,
            transition: 'opacity 0.3s'
          }}>
            <Typography variant="h6" sx={{ 
              fontWeight: 'bold',
              letterSpacing: '0.5px',
              fontSize: '1.2rem',
              color: '#fff'
            }}>
              GUC SYSTEM
            </Typography>
            <Typography variant="subtitle2" sx={{ 
              color: 'rgba(255, 255, 255, 0.7)',
              fontSize: '0.75rem',
              marginTop: '4px'
            }}>
              Company Portal
            </Typography>
          </Box>
        </Toolbar>

        <List>
          {menuItems.map((section, sectionIndex) => (
            <React.Fragment key={section.title || sectionIndex}>
              {section.title && !isSidebarCollapsed && (
                <ListSubheader
                  sx={{
                    bgcolor: 'transparent',
                    color: 'rgba(255, 255, 255, 0.7)',
                    lineHeight: '30px',
                    mt: sectionIndex === 0 ? 0 : 2,
                  }}
                >
                  {section.title}
                </ListSubheader>
              )}
              {section.items.map((item) => (
                <ListItem
                  button
                  key={item.text}
                  onClick={item.onClick}
                  sx={{
                    '&:hover': {
                      bgcolor: lightNavyBlue,
                    },
                    px: !isSidebarCollapsed ? 2 : 1.5,
                    justifyContent: !isSidebarCollapsed ? 'initial' : 'center',
                    minHeight: 48,
                  }}
                >
                  <ListItemIcon 
                    sx={{ 
                      color: 'white', 
                      minWidth: !isSidebarCollapsed ? 40 : 'auto',
                      mr: !isSidebarCollapsed ? 2 : 'auto',
                    }}
                  >
                    {item.icon}
                  </ListItemIcon>
                  {!isSidebarCollapsed && <ListItemText primary={item.text} />}
                </ListItem>
              ))}
            </React.Fragment>
          ))}
        </List>
      </Drawer>

      {/* Main content */}
      <Box component="main" sx={{ flexGrow: 1 }}>
        <AppBar
          position="fixed"
          sx={{
            backgroundColor: navyBlue,
            width: { sm: `calc(100% - ${isSidebarCollapsed ? 70 : drawerWidth}px)` },
            ml: { sm: `${isSidebarCollapsed ? 70 : drawerWidth}px` },
            transition: 'width 0.3s, margin-left 0.3s',
          }}
        >
          <Toolbar>
            <IconButton
              color="inherit"
              onClick={() => setSidebarCollapsed(!isSidebarCollapsed)}
              edge="start"
              sx={{ mr: 2 }}
            >
              <MenuIcon />
            </IconButton>
            <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
              Company Portal
            </Typography>

            <Box sx={{ 
              display: 'flex', 
              alignItems: 'center', 
              ml: 'auto',
              gap: 2
            }}>
              {/* Notifications */}
              <IconButton
                color="inherit"
                onClick={handleNotificationClick}
                sx={{ 
                  p: 1,
                  '&:hover': { backgroundColor: 'rgba(255, 255, 255, 0.1)' }
                }}
              >
                <Badge badgeContent={notifications.length} color="error">
                  <NotificationsIcon />
                </Badge>
              </IconButton>

              {/* Profile */}
              <IconButton
                color="inherit"
                onClick={handleProfileClick}
                sx={{ 
                  p: 1,
                  '&:hover': { backgroundColor: 'rgba(255, 255, 255, 0.1)' }
                }}
              >
                <Avatar sx={{ width: 32, height: 32 }} />
              </IconButton>
            </Box>

            {/* Profile Menu */}
            {showProfileMenu && (
              <Menu
                anchorEl={document.querySelector('.MuiAvatar-root')}
                open={showProfileMenu}
                onClose={() => setShowProfileMenu(false)}
                PaperProps={{
                  elevation: 0,
                  sx: {
                    overflow: 'visible',
                    filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
                    mt: 1.5,
                    bgcolor: 'background.paper',
                    color: 'text.primary',
                    borderRadius: 3,
                    minWidth: 340,
                    p: 0,
                  },
                }}
                transformOrigin={{ horizontal: 'right', vertical: 'top' }}
                anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
              >
                <Box sx={{ bgcolor: navyBlue, color: 'white', px: 3, py: 2, borderTopLeftRadius: 12, borderTopRightRadius: 12 }}>
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    Profile Options
                  </Typography>
                </Box>
                <Divider />
                <MenuItem sx={{ py: 2, px: 3, cursor: 'default', '&:hover': { background: 'none' } }}>
                  <ListItemIcon>
                    <EmailIcon fontSize="medium" sx={{ color: '#1976d2' }} />
                  </ListItemIcon>
                  <Typography sx={{ 
                    fontWeight: 500, 
                    fontSize: '0.95rem',
                    color: 'text.secondary',
                    wordBreak: 'break-all'
                  }}>
                    {COMPANY_EMAIL}
                  </Typography>
                </MenuItem>
                <Divider />
                <MenuItem 
                  component={Link} 
                  to="/"
                  onClick={() => setShowProfileMenu(false)}
                  sx={{ py: 2, px: 3 }}
                >
                  <ListItemIcon>
                    <LogoutIcon fontSize="medium" sx={{ color: '#d32f2f' }} />
                  </ListItemIcon>
                  <Typography sx={{ fontWeight: 500, fontSize: '1.1rem', color: '#d32f2f' }}>Logout</Typography>
                </MenuItem>
              </Menu>
            )}

            {/* Notifications Menu */}
            <Menu
              anchorEl={notificationAnchorEl}
              open={showNotifications}
              onClose={handleNotificationClose}
              PaperProps={{
                sx: {
                  width: 320,
                  maxHeight: 440,
                  overflow: 'auto',
                  backgroundColor: 'white',
                  boxShadow: '0px 5px 15px rgba(0, 0, 0, 0.2)',
                  borderRadius: '8px',
                  mt: 1,
                  '& .MuiDivider-root': {
                    borderColor: 'rgba(0, 0, 0, 0.12)'
                  }
                }
              }}
              transformOrigin={{ horizontal: 'right', vertical: 'top' }}
              anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
            >
              <Box sx={{
                p: 2,
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                background: navyBlue,
                color: 'white',
                borderTopLeftRadius: '8px',
                borderTopRightRadius: '8px'
              }}>
                <Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: 'white' }}>
                  System Notifications
                </Typography>
                {notifications.length > 0 && (
                  <Typography
                    variant="button"
                    sx={{
                      cursor: 'pointer',
                      fontSize: '0.8rem',
                      opacity: 0.8,
                      '&:hover': { opacity: 1 }
                    }}
                    onClick={handleMarkAllAsRead}
                  >
                    Clear All
                  </Typography>
                )}
              </Box>
              <Divider />
              {notifications.length === 0 ? (
                <Box sx={{ p: 2, textAlign: 'center', color: 'text.secondary' }}>
                  <Typography variant="body2">No notifications</Typography>
                </Box>
              ) : (
                notifications.map((notification) => (
                  <MenuItem
                    key={notification.id}
                    onClick={() => handleMarkAsRead(notification.id)}
                    sx={{
                      py: 1.5,
                      px: 2,
                      borderBottom: '1px solid rgba(0, 0, 0, 0.08)',
                      backgroundColor: notification.isRead ? 'transparent' : 'rgba(25, 118, 210, 0.08)',
                      whiteSpace: 'normal',
                      minHeight: 'auto'
                    }}
                  >
                    <Box sx={{ 
                      display: 'flex', 
                      flexDirection: 'column',
                      width: '100%',
                      gap: 0.5
                    }}>
                      <Typography 
                        variant="body2" 
                        sx={{ 
                          flex: 1,
                          wordBreak: 'break-word'
                        }}
                      >
                        {notification.message}
                      </Typography>
                      <Typography 
                        variant="caption" 
                        color="text.secondary"
                        sx={{
                          display: 'block',
                          textAlign: 'right'
                        }}
                      >
                        {notification.time}
                      </Typography>
                    </Box>
                  </MenuItem>
                ))
              )}
            </Menu>
          </Toolbar>
        </AppBar>
        <Toolbar />
        
        {/* Page Content */}
        <Box sx={{ p: 3, backgroundColor: '#f5f5f5', minHeight: 'calc(100vh - 64px)' }}>
          {activeView === 'posts' && <InternshipPosts />}
          {activeView === 'applications' && <InternshipApplications />}
          {activeView === 'interns' && <CompanyInterns />}
          {activeView === 'available' && <AvailableInternships />}
        </Box>
      </Box>

      {/* Add CSS for animations */}
      <style>
        {`
          @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
          }
          
          .sidebar-tooltip {
            animation: fadeIn 0.2s ease;
          }
        `}
      </style>
    </Box>
  );
} 