import React, { useState } from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
  IconButton,
  Stack,
  TextField,
  Typography,
  Chip,
  MenuItem,
  Alert,
  Snackbar,
  Paper,
  Tooltip,
  Divider,
} from '@mui/material';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { TimePicker } from '@mui/x-date-pickers/TimePicker';
import PersonIcon from '@mui/icons-material/Person';
import EventIcon from '@mui/icons-material/Event';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import VideocamIcon from '@mui/icons-material/Videocam';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord';
import { format } from 'date-fns';
import VideoCallWindow from './VideoCallWindow';

const purposes = [
  'Career Guidance',
  'Report Clarification',
  'Internship Discussion',
  'General Inquiry'
];

export default function AppointmentsPanel({ triggerPopup }) {
   const [appointments, setAppointments] = useState([
    {
      id: 1,
      to: 'Student A',
      date: '2025-05-20',
      time: '14:00',
      purpose: 'Career Guidance',
      from: 'SCAD Officer',
      status: 'Accepted',
      online: true
    },
    {
      id: 2,
      to: 'Student B',
      date: '2025-05-21',
      time: '11:30',
      purpose: 'Report Clarification',
      from: 'SCAD Officer',
      status: 'Pending',
      online: false
    }
  ]);

  const [form, setForm] = useState({ 
    to: '', 
    date: null, 
    time: null, 
    purpose: '' 
  });
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const [incomingCall, setIncomingCall] = useState(null);
  const [inCallWith, setInCallWith] = useState(null);
  const [callControls, setCallControls] = useState({ video: true, mic: true, screenShared: false });
  const [otherLeft, setOtherLeft] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.to || !form.date || !form.time || !form.purpose) {
      setSnackbar({
        open: true,
        message: 'Please complete all fields',
        severity: 'error'
      });
      return;
    }

    const newAppointment = {
      id: Date.now(),
      ...form,
      date: format(form.date, 'yyyy-MM-dd'),
      time: format(form.time, 'HH:mm'),
      from: 'SCAD Officer',
      status: 'Pending',
      online: true
    };

    setAppointments([...appointments, newAppointment]);
    setForm({ to: '', date: null, time: null, purpose: '' });
    setSnackbar({
      open: true,
      message: 'Appointment request submitted successfully',
      severity: 'success'
    });
  };

  const updateStatus = (id, status) => {
    setAppointments(prev =>
      prev.map(appt => appt.id === id ? { ...appt, status } : appt)
    );
    setSnackbar({
      open: true,
      message: `Appointment ${status.toLowerCase()}`,
      severity: status === 'Accepted' ? 'success' : 'info'
    });
  };

  const startCall = (appt) => {
    if (typeof triggerPopup === 'function') {
      triggerPopup(`Calling ${appt.to}...`);
    }
    setInCallWith(appt);
    setOtherLeft(false);
  };

  const acceptCall = () => {
    setInCallWith(incomingCall);
    setIncomingCall(null);
    setOtherLeft(false);
  };

  const rejectCall = () => {
    setIncomingCall(null);
  };

  const endCall = () => {
    setOtherLeft(true);
    setInCallWith(null);
  };

  const toggleControl = (control) => {
    setCallControls(prev => ({ ...prev, [control]: !prev[control] }));
  };

  const getStatusChipProps = (status) => {
    switch (status) {
      case 'Accepted':
        return { 
          color: 'success',
          icon: <CheckCircleIcon />,
          variant: 'outlined'
        };
      case 'Rejected':
        return { 
          color: 'error',
          icon: <CancelIcon />,
          variant: 'outlined'
        };
      case 'Pending':
        return { 
          color: 'warning',
          variant: 'outlined'
        };
      default:
        return { 
          color: 'default',
          variant: 'outlined'
        };
    }
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Box sx={{ p: 3 }}>
        <Stack spacing={3}>
          {/* Request Form */}
          <Card>
            <CardContent>
              <Stack spacing={3}>
                <Typography variant="subtitle2" color="text.secondary">
                  New Appointment Request
                </Typography>
                <Grid container spacing={2}>
                  <Grid item xs={12} md={3}>
                    <TextField
                      fullWidth
                      label="Student Name"
                      value={form.to}
                      onChange={(e) => setForm({ ...form, to: e.target.value })}
                    />
                  </Grid>
                  <Grid item xs={12} md={3}>
                    <DatePicker
                      label="Date"
                      value={form.date}
                      onChange={(newValue) => setForm({ ...form, date: newValue })}
                      renderInput={(params) => <TextField {...params} fullWidth />}
                    />
                  </Grid>
                  <Grid item xs={12} md={2}>
                    <TimePicker
                      label="Time"
                      value={form.time}
                      onChange={(newValue) => setForm({ ...form, time: newValue })}
                      renderInput={(params) => <TextField {...params} fullWidth />}
                    />
                  </Grid>
                  <Grid item xs={12} md={3}>
                    <TextField
                      select
                      fullWidth
                      label="Purpose"
                      value={form.purpose}
                      onChange={(e) => setForm({ ...form, purpose: e.target.value })}
                    >
                      {purposes.map((purpose) => (
                        <MenuItem key={purpose} value={purpose}>
                          {purpose}
                        </MenuItem>
                      ))}
                    </TextField>
                  </Grid>
                  <Grid item xs={12} md={1}>
                    <Button
                      fullWidth
                      variant="contained"
                      onClick={handleSubmit}
                      sx={{ height: '100%' }}
                    >
                      Submit
                    </Button>
                  </Grid>
                </Grid>
              </Stack>
            </CardContent>
          </Card>

          {/* Appointments List */}
          <Stack spacing={2}>
            {appointments.map((appt) => (
              <Card key={appt.id} variant="outlined">
                <CardContent>
                  <Grid container spacing={2} alignItems="center">
                    <Grid item xs={12} md={3}>
                      <Stack direction="row" spacing={1} alignItems="center">
                        <PersonIcon color="action" fontSize="small" />
                        <Typography>{appt.to}</Typography>
                      </Stack>
                    </Grid>
                    <Grid item xs={12} md={2}>
                      <Stack direction="row" spacing={1} alignItems="center">
                        <EventIcon color="action" fontSize="small" />
                        <Typography>{appt.date}</Typography>
                      </Stack>
                    </Grid>
                    <Grid item xs={12} md={2}>
                      <Stack direction="row" spacing={1} alignItems="center">
                        <AccessTimeIcon color="action" fontSize="small" />
                        <Typography>{appt.time}</Typography>
                      </Stack>
                    </Grid>
                    <Grid item xs={12} md={2}>
                      <Typography variant="body2" color="text.secondary">
                        {appt.purpose}
                      </Typography>
                    </Grid>
                    <Grid item xs={12} md={1}>
                      <Stack direction="row" spacing={1} alignItems="center">
                        <FiberManualRecordIcon 
                          fontSize="small"
                          sx={{ 
                            color: appt.online ? 'success.main' : 'text.disabled',
                            width: 10,
                            height: 10
                          }} 
                        />
                        <Typography variant="body2" color="text.secondary">
                          {appt.online ? 'Online' : 'Offline'}
                        </Typography>
                      </Stack>
                    </Grid>
                    <Grid item xs={12} md={2}>
                      <Stack direction="row" spacing={1} alignItems="center" justifyContent="flex-end">
                        <Chip
                          label={appt.status}
                          size="small"
                          {...getStatusChipProps(appt.status)}
                        />
                        {appt.status === 'Pending' ? (
                          <Stack direction="row" spacing={1}>
                            <Tooltip title="Accept">
                              <IconButton
                                size="small"
                                onClick={() => updateStatus(appt.id, 'Accepted')}
                                sx={{ color: 'success.main' }}
                              >
                                <CheckCircleIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <Tooltip title="Reject">
                              <IconButton
                                size="small"
                                onClick={() => updateStatus(appt.id, 'Rejected')}
                                sx={{ color: 'error.main' }}
                              >
                                <CancelIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                          </Stack>
                        ) : appt.status === 'Accepted' && appt.online && (
                          <Tooltip title="Start Video Call">
                            <IconButton
                              size="small"
                              onClick={() => startCall(appt)}
                              sx={{ color: 'primary.main' }}
                            >
                              <VideocamIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        )}
                      </Stack>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            ))}
          </Stack>
        </Stack>

        {/* Incoming Call Dialog */}
        <Dialog
          open={Boolean(incomingCall)}
          maxWidth="xs"
          fullWidth
        >
          {incomingCall && (
            <>
              <DialogTitle sx={{ bgcolor: 'primary.main', color: 'white' }}>
                <Stack direction="row" alignItems="center" spacing={2}>
                  <VideocamIcon />
                  <Typography variant="h6">
                    Incoming Video Call
                  </Typography>
                </Stack>
              </DialogTitle>
              <DialogContent sx={{ p: 3 }}>
                <Typography>
                  {incomingCall.to} is calling...
                </Typography>
              </DialogContent>
              <DialogActions sx={{ p: 2, bgcolor: 'grey.50' }}>
                <Button onClick={rejectCall} color="error">
                  Reject
                </Button>
                <Button onClick={acceptCall} variant="contained" color="success">
                  Accept
                </Button>
              </DialogActions>
              </>
            )}
        </Dialog>

        {/* Video Call Window */}
      {inCallWith && (
        <VideoCallWindow
          user={inCallWith}
          onLeave={endCall}
          controls={callControls}
          toggleControl={toggleControl}
        />
      )}

        {/* Other Left Alert */}
      {otherLeft && (
          <Alert 
            severity="error"
            sx={{ 
              position: 'fixed',
              top: 20,
              left: '50%',
              transform: 'translateX(-50%)',
              zIndex: 2000
            }}
          >
            The other caller has left the call
          </Alert>
        )}

        {/* Snackbar for notifications */}
        <Snackbar
          open={snackbar.open}
          autoHideDuration={4000}
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        >
          <Alert
            onClose={() => setSnackbar({ ...snackbar, open: false })}
            severity={snackbar.severity}
            variant="filled"
            sx={{ width: '100%' }}
          >
            {snackbar.message}
          </Alert>
        </Snackbar>
      </Box>
    </LocalizationProvider>
  );
}
