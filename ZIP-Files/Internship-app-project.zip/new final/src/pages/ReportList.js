import React, { useState } from 'react';
import {
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  IconButton,
  Button,
  TextField,
  MenuItem,
  FormControl,
  InputLabel,
  Select,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Stack,
  Grid,
  Card,
  CardContent,
  Tooltip,
  InputAdornment,
  Snackbar,
  Alert,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import VisibilityIcon from '@mui/icons-material/Visibility';
import DownloadIcon from '@mui/icons-material/Download';
import CloseIcon from '@mui/icons-material/Close';
import PersonIcon from '@mui/icons-material/Person';
import SchoolIcon from '@mui/icons-material/School';
import DescriptionIcon from '@mui/icons-material/Description';
import jsPDF from 'jspdf';

const getStatusChipProps = (status) => {
  switch (status) {
    case 'Accepted':
      return { 
        color: 'success',
        variant: 'outlined'
      };
    case 'Pending':
      return { 
        color: 'warning',
        variant: 'outlined'
      };
    case 'Rejected':
      return { 
        color: 'error',
        variant: 'outlined'
      };
    case 'Flagged':
      return { 
        color: 'error',
        variant: 'outlined'
      };
    default:
      return { 
        color: 'default',
        variant: 'outlined'
      };
  }
};

const initialReports = [
  { id: 1, student: 'Laila Hassan', major: 'CS', title: 'AI Research', status: 'Pending', details: 'This report outlines the AI techniques implemented during the internship with a focus on NLP models.' },
  { id: 2, student: 'Omar Adel', major: 'ENG', title: 'Bridge Simulation', status: 'Accepted', details: 'The report includes CAD drawings and structural analysis performed using ANSYS.' },
  { id: 3, student: 'Mariam Said', major: 'ARCH', title: 'Urban Design', status: 'Flagged', details: 'A comprehensive urban planning study conducted in downtown Cairo with sustainability focus.' },
  { id: 4, student: 'Kareem Nabil', major: 'CS', title: 'Web App Report', status: 'Rejected', details: 'Details of full-stack development work completed during internship at a tech startup.' },
  { id: 5, student: 'Yasmine Tarek', major: 'ENG', title: 'Internship Summary', status: 'Pending', details: 'Summary of hands-on work done in mechanical prototyping and testing lab environment.' }
];

export default function ReportList() {
  const [majorFilter, setMajorFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [selectedReport, setSelectedReport] = useState(null);
  const [search, setSearch] = useState('');
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

  const filteredReports = initialReports.filter(report => {
    const matchesMajor = majorFilter === 'All' || report.major === majorFilter;
    const matchesStatus = statusFilter === 'All' || report.status === statusFilter;
    const matchesSearch = 
      report.student.toLowerCase().includes(search.toLowerCase()) ||
      report.title.toLowerCase().includes(search.toLowerCase()) ||
      report.major.toLowerCase().includes(search.toLowerCase());
    return matchesMajor && matchesStatus && matchesSearch;
  });

  const handleDownloadPDF = () => {
    if (!selectedReport) return;
    
    try {
      const doc = new jsPDF();
      doc.setFontSize(14);
      doc.text(`Internship Report`, 20, 20);
      doc.setFontSize(12);
      doc.text(`Student: ${selectedReport.student}`, 20, 35);
      doc.text(`Major: ${selectedReport.major}`, 20, 45);
      doc.text(`Title: ${selectedReport.title}`, 20, 55);
      doc.text(`Status: ${selectedReport.status}`, 20, 65);
      doc.text(`Details:`, 20, 80);
      doc.setFontSize(11);
      doc.text(doc.splitTextToSize(selectedReport.details, 170), 20, 90);
      doc.save(`${selectedReport.student.replace(/\s+/g, '_')}_Report.pdf`);
      
      setSnackbar({
        open: true,
        message: 'Report downloaded successfully',
        severity: 'success'
      });
    } catch (error) {
      setSnackbar({
        open: true,
        message: 'Failed to download report',
        severity: 'error'
      });
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Stack spacing={3}>
        {/* Filters Section */}
        <Card>
          <CardContent>
            <Stack spacing={2}>
              <Typography variant="subtitle2" color="text.secondary">
                Filters
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={4}>
                  <TextField
                    fullWidth
                    placeholder="Search reports..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <SearchIcon />
                        </InputAdornment>
                      ),
                    }}
                  />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <FormControl fullWidth>
                    <InputLabel>Major</InputLabel>
                    <Select
                      value={majorFilter}
                      label="Major"
                      onChange={(e) => setMajorFilter(e.target.value)}
                    >
                      <MenuItem value="All">All Majors</MenuItem>
                      <MenuItem value="CS">CS</MenuItem>
                      <MenuItem value="ENG">ENG</MenuItem>
                      <MenuItem value="ARCH">ARCH</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={4}>
                  <FormControl fullWidth>
                    <InputLabel>Status</InputLabel>
                    <Select
                      value={statusFilter}
                      label="Status"
                      onChange={(e) => setStatusFilter(e.target.value)}
                    >
                      <MenuItem value="All">All Status</MenuItem>
                      <MenuItem value="Pending">Pending</MenuItem>
                      <MenuItem value="Accepted">Accepted</MenuItem>
                      <MenuItem value="Flagged">Flagged</MenuItem>
                      <MenuItem value="Rejected">Rejected</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
              </Grid>
            </Stack>
          </CardContent>
        </Card>

        {/* Reports Table */}
        <TableContainer component={Paper} sx={{ 
          boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
          borderRadius: 2,
          overflow: 'hidden'
        }}>
          <Table>
            <TableHead>
              <TableRow sx={{ backgroundColor: '#f8f9fa' }}>
                <TableCell sx={{ fontWeight: 600 }}>Student</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Major</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Title</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Status</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredReports.map((report) => (
                <TableRow 
                  key={report.id}
                  sx={{ '&:hover': { backgroundColor: '#f8f9fa' } }}
                >
                  <TableCell>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <PersonIcon color="action" fontSize="small" />
                      <Typography>{report.student}</Typography>
                    </Stack>
                  </TableCell>
                  <TableCell>
                    <Chip 
                      label={report.major}
                      size="small"
                      color="primary"
                      variant="outlined"
                    />
                  </TableCell>
                  <TableCell>{report.title}</TableCell>
                  <TableCell>
                    <Chip
                      label={report.status}
                      size="small"
                      {...getStatusChipProps(report.status)}
                    />
                  </TableCell>
                  <TableCell>
                    <Stack direction="row" spacing={1}>
                      <Tooltip title="View Details">
                        <IconButton
                          size="small"
                          onClick={() => setSelectedReport(report)}
                          sx={{ color: 'primary.main' }}
                        >
                          <VisibilityIcon />
                        </IconButton>
                      </Tooltip>
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Stack>

      {/* Report Details Dialog */}
      <Dialog
        open={Boolean(selectedReport)}
        onClose={() => setSelectedReport(null)}
        maxWidth="md"
        fullWidth
      >
        {selectedReport && (
          <>
            <DialogTitle sx={{ px: 3, py: 2, bgcolor: 'primary.main', color: 'white' }}>
              <Stack direction="row" alignItems="center" spacing={2}>
                <DescriptionIcon />
                <Box>
                  <Typography variant="h6">
                    Report Details
                  </Typography>
                  <Typography variant="caption" sx={{ color: 'primary.lighter' }}>
                    {selectedReport.title}
                  </Typography>
                </Box>
              </Stack>
            </DialogTitle>
            <DialogContent sx={{ p: 3 }}>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <Stack spacing={3}>
                    <Box>
                      <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                        Student Information
                      </Typography>
                      <Stack spacing={2}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <PersonIcon color="action" fontSize="small" />
                          <Typography variant="body2">
                            {selectedReport.student}
                          </Typography>
                        </Box>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <SchoolIcon color="action" fontSize="small" />
                          <Typography variant="body2">
                            Major: {selectedReport.major}
                          </Typography>
                        </Box>
                      </Stack>
                    </Box>
                  </Stack>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Box>
                    <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                      Status
                    </Typography>
                    <Card variant="outlined">
                      <CardContent>
                        <Stack spacing={2}>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <Chip
                              label={selectedReport.status}
                              {...getStatusChipProps(selectedReport.status)}
                            />
                          </Box>
                        </Stack>
                      </CardContent>
                    </Card>
                  </Box>
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                    Report Details
                  </Typography>
                  <Card variant="outlined">
                    <CardContent>
                      <Typography variant="body2">
                        {selectedReport.details}
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>
              </Grid>
            </DialogContent>
            <DialogActions sx={{ p: 2, bgcolor: 'grey.50' }}>
              <Button
                startIcon={<CloseIcon />}
                onClick={() => setSelectedReport(null)}
              >
                Close
              </Button>
              <Button
                variant="contained"
                startIcon={<DownloadIcon />}
                onClick={handleDownloadPDF}
              >
                Download PDF
              </Button>
            </DialogActions>
          </>
        )}
      </Dialog>

      {/* Snackbar for notifications */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          severity={snackbar.severity}
          variant="filled"
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}
