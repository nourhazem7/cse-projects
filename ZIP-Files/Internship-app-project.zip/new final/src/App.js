import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './pages/Login';
import CompanySignup from './pages/CompanySignup';
import CompanyDocumentsUpload from './pages/CompanyDocumentsUpload';
import CompanyList from './pages/CompanyList';
import InternshipCycle from './pages/InternshipCycle';
import ScadDashboard from './pages/ScadDashboard';
import CompanyDashboard from './pages/CompanyDashboard';

// Faculty Pages
import FacultyDashboard from './faculty/pages/FacultyDashboard';
import StatisticsPanel from './faculty/pages/StatisticsPanel';
import ReportList from './faculty/pages/ReportList';
import EvaluationReportList from './faculty/pages/EvaluationReportList';

// Student Pages
import StudentLayout from './student/components/StudentLayout';
import Dashboard from './student/pages/Dashboard';
import Profile from './student/pages/Profile';
import Internships from './student/pages/Internships';
import SuggestedCompanies from './student/pages/SuggestedCompanies';
import InternshipManagement from './student/pages/InternshipManagement';
import InternshipRequirements from './student/pages/InternshipRequirements';
import ApplicationStatus from './student/pages/ApplicationStatus';
import PastApplications from './student/pages/PastApplications';
import ScadReport from './student/pages/ScadReport';
import Downloads from './student/pages/Downloads';
import InternshipDetails from './student/pages/InternshipDetails';
import ApplyInternship from './student/pages/ApplyInternship';
import InternshipReport from './student/pages/InternshipReport';
import InternshipEvaluation from './student/pages/InternshipEvaluation';

// Pro Pages
import ProLayout from './pro/components/p-StudentLayout';
import ProDashboard from './pro/pages/p-Dashboard';
import ProProfile from './pro/pages/p-Profile';
import ProInternships from './pro/pages/p-Internships';
import ProSuggestedCompanies from './pro/pages/p-SuggestedCompanies';
import ProInternshipManagement from './pro/pages/p-InternshipManagement';
import ProInternshipRequirements from './pro/pages/p-InternshipRequirements';
import ProApplicationStatus from './pro/pages/p-ApplicationStatus';
import ProPastApplications from './pro/pages/p-PastApplications';
import ProScadReport from './pro/pages/p-ScadReport';
import ProDownloads from './pro/pages/p-Downloads';
import ProInternshipDetails from './pro/pages/p-InternshipDetails';
import ProApplyInternship from './pro/pages/p-ApplyInternship';
import ProInternshipReport from './pro/pages/p-InternshipReport';
import ProInternshipEvaluation from './pro/pages/p-InternshipEvaluation';
import ProWorkshops from './pro/pages/p-Workshops';
import ProWorkshopCall from './pro/pages/p-WorkshopCall';
import ProCallPage from './pro/pages/p-CallPage';
import ProRequestAppointment from './pro/pages/p-RequestAppointment';
import ProfileViews from './pro/pages/p-ProfileViews';

export default function App() {
  return (
    <Router>
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<Login />} />
        
        {/* Company Routes */}
        <Route path="/signup-company" element={<CompanySignup />} />
        <Route path="/company-upload-docs" element={<CompanyDocumentsUpload />} />
        <Route path="/company-dashboard/*" element={<CompanyDashboard />} />
        
        {/* Faculty Routes */}
        <Route path="/faculty/dashboard" element={<FacultyDashboard />}>
          <Route path="statistics" element={<StatisticsPanel />} />
          <Route path="reports" element={<ReportList />} />
          <Route path="evaluations" element={<EvaluationReportList />} />
        </Route>
        
        {/* SCAD Admin Routes */}
        <Route path="/scad-dashboard/*" element={<ScadDashboard />} />
        <Route path="/scad-companies" element={<CompanyList />} />
        <Route path="/scad-cycle" element={<InternshipCycle />} />
        
        {/* Student Routes */}
        <Route path="/student" element={<StudentLayout />}>
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="profile" element={<Profile />} />
          <Route path="internships" element={<Internships />} />
          <Route path="suggested-companies" element={<SuggestedCompanies />} />
          <Route path="internship-management" element={<InternshipManagement />} />
          <Route path="internship-requirements" element={<InternshipRequirements />} />
          <Route path="application-status" element={<ApplicationStatus />} />
          <Route path="past-applications" element={<PastApplications />} />
          <Route path="scad-reports" element={<ScadReport />} />
          <Route path="downloads" element={<Downloads />} />
          <Route path="internship/:id" element={<InternshipDetails />} />
          <Route path="apply/:id" element={<ApplyInternship />} />
          <Route path="report/:id" element={<InternshipReport />} />
          <Route path="evaluation/:id" element={<InternshipEvaluation />} />
        </Route>

        {/* Pro Routes */}
        <Route path="/pro" element={<ProLayout />}>
          <Route path="dashboard" element={<ProDashboard />} />
          <Route path="profile" element={<ProProfile />} />
          <Route path="internships" element={<ProInternships />} />
          <Route path="suggested-companies" element={<ProSuggestedCompanies />} />
          <Route path="internship-management" element={<ProInternshipManagement />} />
          <Route path="internship-requirements" element={<ProInternshipRequirements />} />
          <Route path="application-status" element={<ProApplicationStatus />} />
          <Route path="past-applications" element={<ProPastApplications />} />
          <Route path="scad-reports" element={<ProScadReport />} />
          <Route path="downloads" element={<ProDownloads />} />
          <Route path="internship/:id" element={<ProInternshipDetails />} />
          <Route path="apply/:id" element={<ProApplyInternship />} />
          <Route path="report/:id" element={<ProInternshipReport />} />
          <Route path="evaluation/:id" element={<ProInternshipEvaluation />} />
          <Route path="workshops" element={<ProWorkshops />} />
          <Route path="workshop-call" element={<ProWorkshopCall />} />
          <Route path="call" element={<ProCallPage />} />
          <Route path="request-appointment" element={<ProRequestAppointment />} />
          <Route path="profile-views" element={<ProfileViews />} />
        </Route>
      </Routes>
    </Router>
  );
}
