import React, { useState } from 'react';

// Mock data for available internships
const initialInternships = [
  {
    id: 1,
    companyName: 'Tech Solutions Inc.',
    companyLogo: '💻',
    jobTitle: 'Software Engineering Intern',
    description: 'Join our development team to work on cutting-edge web applications.',
    duration: '3 months',
    location: 'Cairo, Egypt',
    department: 'Engineering',
    type: 'Full-time',
    status: 'Open',
    deadline: '2024-04-15',
    postedDate: '2024-03-01',
    isPaid: true,
    expectedSalary: '5000 EGP/month',
    requiredSkills: ['JavaScript', 'React', 'Node.js', 'Git']
  },
  {
    id: 2,
    companyName: 'Data Analytics Co.',
    companyLogo: '📊',
    jobTitle: 'Data Science Intern',
    description: 'Help us analyze big data and create meaningful insights.',
    duration: '6 months',
    location: 'Remote',
    department: 'Data Science',
    type: 'Part-time',
    status: 'Open',
    deadline: '2024-04-20',
    postedDate: '2024-03-05',
    isPaid: true,
    expectedSalary: '3000 EGP/month',
    requiredSkills: ['Python', 'SQL', 'Data Analysis', 'Machine Learning']
  },
  {
    id: 3,
    companyName: 'Creative Design Studio',
    companyLogo: '🎨',
    jobTitle: 'UI/UX Design Intern',
    description: 'Design beautiful and intuitive user interfaces for our clients.',
    duration: '4 months',
    location: 'Alexandria, Egypt',
    department: 'Design',
    type: 'Full-time',
    status: 'Open',
    deadline: '2024-04-10',
    postedDate: '2024-03-02',
    isPaid: false,
    expectedSalary: null,
    requiredSkills: ['Figma', 'Adobe XD', 'UI Design', 'Prototyping']
  },
  {
    id: 4,
    companyName: 'Marketing Masters',
    companyLogo: '📱',
    jobTitle: 'Digital Marketing Intern',
    description: 'Learn and apply digital marketing strategies.',
    duration: '3 months',
    location: 'Giza, Egypt',
    department: 'Marketing',
    type: 'Part-time',
    status: 'Open',
    deadline: '2024-04-25',
    postedDate: '2024-03-08',
    isPaid: false,
    expectedSalary: null,
    requiredSkills: ['Social Media', 'Content Creation', 'Analytics', 'SEO']
  }
];

export default function AvailableInternships() {
  const [internships, setInternships] = useState(initialInternships);
  const [search, setSearch] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('All');
  const [typeFilter, setTypeFilter] = useState('All');
  const [durationFilter, setDurationFilter] = useState('All');
  const [paidFilter, setPaidFilter] = useState('All');
  const [selectedInternship, setSelectedInternship] = useState(null);

  // Get unique departments and durations for filters
  const departments = ['All', ...new Set(internships.map(internship => internship.department))];
  const durations = ['All', ...new Set(internships.map(internship => internship.duration))];

  // Filter internships based on search and filters
  const filteredInternships = internships.filter(internship => {
    const matchesSearch = 
      internship.companyName.toLowerCase().includes(search.toLowerCase()) ||
      internship.jobTitle.toLowerCase().includes(search.toLowerCase()) ||
      internship.location.toLowerCase().includes(search.toLowerCase());
    const matchesDepartment = departmentFilter === 'All' || internship.department === departmentFilter;
    const matchesType = typeFilter === 'All' || internship.type === typeFilter;
    const matchesDuration = durationFilter === 'All' || internship.duration === durationFilter;
    const matchesPaid = paidFilter === 'All' || 
      (paidFilter === 'Paid' && internship.isPaid) || 
      (paidFilter === 'Unpaid' && !internship.isPaid);
    return matchesSearch && matchesDepartment && matchesType && matchesDuration && matchesPaid;
  });

  return (
    <div style={{ padding: '40px', position: 'relative' }}>
      {/* Header */}
      <div style={{
        backgroundColor: '#0A1929',
        margin: '-40px -40px 24px -40px',
        padding: '32px 40px',
        borderRadius: '16px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
        position: 'relative'
      }}>
        <h1 style={{ 
          fontSize: '42px',
          fontWeight: '400',
          color: 'white',
          margin: 0,
          marginBottom: '12px',
          letterSpacing: '-0.5px'
        }}>
          Available Internships
        </h1>
        <h2 style={{
          fontSize: '20px',
          fontWeight: '400',
          color: 'rgba(255, 255, 255, 0.8)',
          margin: 0,
          letterSpacing: '0.1px',
          lineHeight: 1.4,
          paddingRight: '140px'
        }}>
          Explore and apply for internship opportunities across various departments.
        </h2>
      </div>

      {/* Filters */}
      <div style={{ 
        backgroundColor: 'white',
        borderRadius: '8px',
        boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
        padding: '16px',
        marginBottom: '24px'
      }}>
        <div style={{ display: 'flex', gap: '16px', alignItems: 'center', flexWrap: 'wrap' }}>
          <input
            type="text"
            placeholder="Search by company, position, or location..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{
              padding: '8px 16px',
              border: '1px solid #dfe1e5',
              borderRadius: '4px',
              width: '100%',
              fontSize: '14px',
              marginBottom: '8px'
            }}
          />
          <div style={{ display: 'flex', gap: '16px', width: '100%', flexWrap: 'wrap' }}>
            <select
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
              style={{
                padding: '8px 16px',
                border: '1px solid #dfe1e5',
                borderRadius: '4px',
                backgroundColor: 'white',
                fontSize: '14px',
                flex: 1,
                minWidth: '150px'
              }}
            >
              {departments.map((dept, index) => (
                <option key={index} value={dept}>{dept}</option>
              ))}
            </select>

            <select
              value={durationFilter}
              onChange={(e) => setDurationFilter(e.target.value)}
              style={{
                padding: '8px 16px',
                border: '1px solid #dfe1e5',
                borderRadius: '4px',
                backgroundColor: 'white',
                fontSize: '14px',
                flex: 1,
                minWidth: '150px'
              }}
            >
              <option value="All">All Durations</option>
              {durations.map((duration, index) => (
                <option key={index} value={duration}>{duration}</option>
              ))}
            </select>

            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              style={{
                padding: '8px 16px',
                border: '1px solid #dfe1e5',
                borderRadius: '4px',
                backgroundColor: 'white',
                fontSize: '14px',
                flex: 1,
                minWidth: '150px'
              }}
            >
              <option value="All">All Types</option>
              <option value="Full-time">Full-time</option>
              <option value="Part-time">Part-time</option>
            </select>

            <select
              value={paidFilter}
              onChange={(e) => setPaidFilter(e.target.value)}
              style={{
                padding: '8px 16px',
                border: '1px solid #dfe1e5',
                borderRadius: '4px',
                backgroundColor: 'white',
                fontSize: '14px',
                flex: 1,
                minWidth: '150px'
              }}
            >
              <option value="All">All Compensation</option>
              <option value="Paid">Paid</option>
              <option value="Unpaid">Unpaid</option>
            </select>
          </div>
        </div>
      </div>

      {/* Internships List */}
      <div style={{ display: 'grid', gap: '16px' }}>
        {filteredInternships.map(internship => (
          <div
            key={internship.id}
            onClick={() => setSelectedInternship(internship)}
            style={{
              backgroundColor: 'white',
              borderRadius: '8px',
              boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
              padding: '20px',
              cursor: 'pointer',
              transition: 'transform 0.2s ease, box-shadow 0.2s ease'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'translateY(-2px)';
              e.currentTarget.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = '0 1px 3px rgba(0,0,0,0.1)';
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
              <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                <div style={{
                  width: '40px',
                  height: '40px',
                  backgroundColor: '#f8f9fa',
                  borderRadius: '8px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '24px'
                }}>
                  {internship.companyLogo}
                </div>
                <div>
                  <h3 style={{ margin: '0 0 4px 0', color: '#0A1929', fontSize: '18px' }}>{internship.jobTitle}</h3>
                  <p style={{ margin: '0', color: '#666', fontSize: '14px' }}>{internship.companyName}</p>
                </div>
              </div>
              <div style={{
                padding: '4px 12px',
                borderRadius: '12px',
                fontSize: '12px',
                fontWeight: '500',
                backgroundColor: '#e6f4ea',
                color: '#1e4620'
              }}>
                {internship.status}
              </div>
            </div>
            <div style={{ display: 'flex', gap: '16px', color: '#666', fontSize: '14px', flexWrap: 'wrap' }}>
              <span>📍 {internship.location}</span>
              <span>⏱️ {internship.duration}</span>
              <span>🎓 {internship.department}</span>
              <span>💼 {internship.type}</span>
              <span>💰 {internship.isPaid ? `Paid - ${internship.expectedSalary}` : 'Unpaid'}</span>
              <span>📅 Apply by: {internship.deadline}</span>
            </div>
            <p style={{ 
              margin: '12px 0 0 0', 
              color: '#666', 
              fontSize: '14px',
              display: '-webkit-box',
              WebkitLineClamp: '2',
              WebkitBoxOrient: 'vertical',
              overflow: 'hidden',
              textOverflow: 'ellipsis'
            }}>
              {internship.description}
            </p>
          </div>
        ))}
      </div>

      {/* Internship Details Modal */}
      {selectedInternship && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{
            backgroundColor: 'white',
            padding: '20px',
            borderRadius: '12px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
            width: '500px',
            maxHeight: '85vh',
            overflow: 'auto',
            position: 'relative'
          }}>
            <div style={{ 
              display: 'flex', 
              justifyContent: 'space-between', 
              alignItems: 'flex-start',
              marginBottom: '16px',
              position: 'sticky',
              top: 0,
              backgroundColor: 'white',
              zIndex: 1,
              paddingBottom: '12px',
              borderBottom: '1px solid #eee'
            }}>
              <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                <div style={{
                  width: '40px',
                  height: '40px',
                  backgroundColor: '#f8f9fa',
                  borderRadius: '8px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '24px'
                }}>
                  {selectedInternship.companyLogo}
                </div>
                <div>
                  <h3 style={{ margin: '0 0 4px 0', fontSize: '18px', color: '#0A1929' }}>
                    {selectedInternship.jobTitle}
                  </h3>
                  <p style={{ margin: '0', color: '#666', fontSize: '14px' }}>
                    {selectedInternship.companyName}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedInternship(null)}
                style={{
                  border: 'none',
                  background: 'none',
                  cursor: 'pointer',
                  padding: '4px',
                  fontSize: '20px',
                  color: '#666',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  width: '32px',
                  height: '32px',
                  borderRadius: '50%',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#f5f5f5'}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
              >
                ✕
              </button>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div>
                <label style={{ color: '#666', fontSize: '0.875rem', fontWeight: '500' }}>Description</label>
                <div style={{ fontSize: '0.9rem', marginTop: '4px', color: '#333' }}>{selectedInternship.description}</div>
              </div>

              <div>
                <label style={{ color: '#666', fontSize: '0.875rem', fontWeight: '500' }}>Required Skills</label>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginTop: '6px' }}>
                  {selectedInternship.requiredSkills.map((skill, index) => (
                    <span key={index} style={{
                      padding: '3px 10px',
                      backgroundColor: '#f0f2f5',
                      borderRadius: '12px',
                      fontSize: '12px',
                      color: '#0A1929'
                    }}>
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', fontSize: '0.9rem' }}>
                <div>
                  <label style={{ color: '#666', fontSize: '0.875rem', fontWeight: '500' }}>Location</label>
                  <div style={{ marginTop: '4px', color: '#333' }}>{selectedInternship.location}</div>
                </div>
                <div>
                  <label style={{ color: '#666', fontSize: '0.875rem', fontWeight: '500' }}>Duration</label>
                  <div style={{ marginTop: '4px', color: '#333' }}>{selectedInternship.duration}</div>
                </div>
                <div>
                  <label style={{ color: '#666', fontSize: '0.875rem', fontWeight: '500' }}>Department</label>
                  <div style={{ marginTop: '4px', color: '#333' }}>{selectedInternship.department}</div>
                </div>
                <div>
                  <label style={{ color: '#666', fontSize: '0.875rem', fontWeight: '500' }}>Type</label>
                  <div style={{ marginTop: '4px', color: '#333' }}>{selectedInternship.type}</div>
                </div>
                <div>
                  <label style={{ color: '#666', fontSize: '0.875rem', fontWeight: '500' }}>Compensation</label>
                  <div style={{ marginTop: '4px', color: '#333' }}>
                    {selectedInternship.isPaid ? `Paid - ${selectedInternship.expectedSalary}` : 'Unpaid'}
                  </div>
                </div>
                <div>
                  <label style={{ color: '#666', fontSize: '0.875rem', fontWeight: '500' }}>Apply by</label>
                  <div style={{ marginTop: '4px', color: '#333' }}>{selectedInternship.deadline}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
} 