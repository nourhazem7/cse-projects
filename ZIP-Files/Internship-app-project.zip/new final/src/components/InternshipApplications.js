import React, { useState } from 'react';

// Mock data for applications
const initialApplications = [
  {
    id: 1,
    postId: 1,
    postTitle: 'Software Engineering Intern',
    applicantName: 'Ahmed Mohamed',
    email: 'ahmed.mohamed@example.com',
    phone: '+20 123 456 7890',
    education: 'Computer Science, Cairo University',
    experience: '1 year of web development experience',
    skills: ['JavaScript', 'React', 'Node.js'],
    resumeUrl: '/resumes/ahmed_mohamed_resume.pdf',
    resumeName: 'Ahmed_Mohamed_Resume.pdf',
    coverLetter: 'I am excited to apply for this position...',
    status: 'Pending',
    appliedDate: '2024-03-20'
  },
  {
    id: 2,
    postId: 1,
    postTitle: 'Software Engineering Intern',
    applicantName: 'Sara Ahmed',
    email: 'sara.ahmed@example.com',
    phone: '+20 123 456 7891',
    education: 'Software Engineering, Ain Shams University',
    experience: '6 months internship at tech startup',
    skills: ['Python', 'Django', 'React'],
    resumeUrl: 'https://example.com/resume2.pdf',
    coverLetter: 'I believe my skills and enthusiasm make me...',
    status: 'Finalized',
    appliedDate: '2024-03-19'
  },
  {
    id: 3,
    postId: 2,
    postTitle: 'Data Science Intern',
    applicantName: 'Mohamed Ali',
    email: 'mohamed.ali@example.com',
    phone: '+20 123 456 7892',
    education: 'Data Science, Alexandria University',
    experience: 'Research assistant in ML lab',
    skills: ['Python', 'Machine Learning', 'SQL'],
    resumeUrl: 'https://example.com/resume3.pdf',
    coverLetter: 'With my background in data science...',
    status: 'Current Intern',
    appliedDate: '2024-03-18'
  }
];

export default function InternshipApplications() {
  const [applications, setApplications] = useState(initialApplications);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [postFilter, setPostFilter] = useState('All');
  const [selectedApplication, setSelectedApplication] = useState(null);
  const [showResumeModal, setShowResumeModal] = useState(false);
  const [selectedResume, setSelectedResume] = useState(null);
  const [downloadError, setDownloadError] = useState(null);
  const [confirmationModal, setConfirmationModal] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);

  // Get unique posts for filter dropdown
  const uniquePosts = [...new Set(applications.map(app => app.postTitle))];

  // Filter applications based on search, status, and post
  const filteredApplications = applications.filter(application => {
    const matchesSearch = 
      application.applicantName.toLowerCase().includes(search.toLowerCase()) ||
      application.postTitle.toLowerCase().includes(search.toLowerCase()) ||
      application.email.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'All' || application.status === statusFilter;
    const matchesPost = postFilter === 'All' || application.postTitle === postFilter;
    return matchesSearch && matchesStatus && matchesPost;
  });

  const updateApplicationStatus = (applicationId, newStatus) => {
    setConfirmationModal(null);
    setApplications(applications.map(app => 
      app.id === applicationId ? { ...app, status: newStatus } : app
    ));
    setSelectedApplication(null);
    
    // Show success message
    setSuccessMessage(`Application status successfully updated to ${newStatus}`);
    setTimeout(() => setSuccessMessage(null), 3000);
  };

  const handleStatusChange = (applicationId, newStatus) => {
    const messages = {
      'Finalized': 'Are you sure you want to finalize this application? This will allow you to accept or reject it.',
      'Accepted': 'Are you sure you want to accept this application? The applicant will be notified.',
      'Rejected': 'Are you sure you want to reject this application? The applicant will be notified.',
      'Current Intern': 'Are you sure you want to mark this applicant as a current intern?',
      'Internship Complete': 'Are you sure you want to mark this internship as complete?'
    };

    setConfirmationModal({
      applicationId,
      newStatus,
      message: messages[newStatus]
    });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Pending':
        return { bg: '#fff3e0', text: '#e65100' };
      case 'Accepted':
        return { bg: '#e6f4ea', text: '#1e4620' };
      case 'Rejected':
        return { bg: '#fce8e6', text: '#c5221f' };
      case 'Finalized':
        return { bg: '#e8f0fe', text: '#1a73e8' };
      case 'Current Intern':
        return { bg: '#e8eaf6', text: '#283593' };
      case 'Internship Complete':
        return { bg: '#f3e5f5', text: '#6a1b9a' };
      default:
        return { bg: '#f5f5f5', text: '#666666' };
    }
  };

  const handleViewResume = (resumeUrl) => {
    setSelectedResume(resumeUrl);
    setShowResumeModal(true);
  };

  const handleDownloadResume = async (application) => {
    try {
      setDownloadError(null);
      
      // For development/testing: Log the attempt
      console.log('Attempting to download resume:', application.resumeUrl);
      
      const response = await fetch(application.resumeUrl);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = application.resumeName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(downloadUrl);
    } catch (error) {
      console.error('Error downloading resume:', error);
      setDownloadError('Unable to download resume. Please try again later or contact support.');
      
      // For development/testing: Log detailed error
      console.log('Download error details:', {
        url: application.resumeUrl,
        error: error.message
      });
    }
  };

  return (
    <div style={{ padding: '40px', position: 'relative' }}>
      {/* Header */}
      <div style={{
        backgroundColor: '#0A1929',
        margin: '-40px -40px 24px -40px',
        padding: '32px 40px',
        borderRadius: '16px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
        position: 'relative'
      }}>
        <h1 style={{ 
          fontSize: '42px',
          fontWeight: '400',
          color: 'white',
          margin: 0,
          marginBottom: '12px',
          letterSpacing: '-0.5px'
        }}>
          Internship Applications
        </h1>
        <h2 style={{
          fontSize: '20px',
          fontWeight: '400',
          color: 'rgba(255, 255, 255, 0.8)',
          margin: 0,
          letterSpacing: '0.1px',
          lineHeight: 1.4,
          paddingRight: '140px'
        }}>
          Review and manage internship applications from potential candidates.
        </h2>
      </div>

      {/* Success Message Toast */}
      {successMessage && (
        <div style={{
          position: 'fixed',
          top: '24px',
          right: '24px',
          backgroundColor: '#e6f4ea',
          color: '#1e4620',
          padding: '12px 24px',
          borderRadius: '8px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
          zIndex: 2000,
          animation: 'slideIn 0.3s ease-out'
        }}>
          ✅ {successMessage}
        </div>
      )}

      {/* Confirmation Modal */}
      {confirmationModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 2000
        }}>
          <div style={{
            backgroundColor: 'white',
            padding: '24px',
            borderRadius: '8px',
            width: '400px',
            boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'
          }}>
            <h3 style={{ marginTop: 0, color: '#0A1929' }}>Confirm Status Change</h3>
            <p style={{ color: '#666', marginBottom: '24px' }}>{confirmationModal.message}</p>
            <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end' }}>
              <button
                onClick={() => setConfirmationModal(null)}
                style={{
                  padding: '8px 16px',
                  backgroundColor: '#f8f9fa',
                  color: '#666',
                  border: '1px solid #dfe1e5',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Cancel
              </button>
              <button
                onClick={() => updateApplicationStatus(confirmationModal.applicationId, confirmationModal.newStatus)}
                style={{
                  padding: '8px 16px',
                  backgroundColor: '#0A1929',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Updated Filters */}
      <div style={{ 
        backgroundColor: 'white',
        borderRadius: '8px',
        boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
        padding: '16px',
        marginBottom: '24px'
      }}>
        <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
          <input
            type="text"
            placeholder="Search applications..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{
              padding: '8px 16px',
              border: '1px solid #dfe1e5',
              borderRadius: '4px',
              width: '100%',
              fontSize: '14px'
            }}
          />

          <select 
            value={postFilter}
            onChange={(e) => setPostFilter(e.target.value)}
            style={{
              padding: '8px 16px',
              border: '1px solid #dfe1e5',
              borderRadius: '4px',
              backgroundColor: 'white',
              fontSize: '14px',
              minWidth: '150px'
            }}
          >
            <option value="All">All Posts</option>
            {uniquePosts.map((post, index) => (
              <option key={index} value={post}>{post}</option>
            ))}
          </select>

          <select 
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            style={{
              padding: '8px 16px',
              border: '1px solid #dfe1e5',
              borderRadius: '4px',
              backgroundColor: 'white',
              fontSize: '14px',
              minWidth: '150px'
            }}
          >
            <option value="All">All Status</option>
            <option value="Pending">Pending</option>
            <option value="Accepted">Accepted</option>
            <option value="Rejected">Rejected</option>
            <option value="Finalized">Finalized</option>
            <option value="Current Intern">Current Intern</option>
            <option value="Internship Complete">Internship Complete</option>
          </select>
        </div>
      </div>

      {/* Applications List */}
      <div style={{ display: 'grid', gap: '16px' }}>
        {filteredApplications.map(application => (
          <div
            key={application.id}
            style={{
              backgroundColor: 'white',
              borderRadius: '8px',
              boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
              padding: '20px',
              cursor: 'pointer',
              transition: 'transform 0.2s ease, box-shadow 0.2s ease'
            }}
            onClick={() => setSelectedApplication(application)}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'translateY(-2px)';
              e.currentTarget.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = '0 1px 3px rgba(0,0,0,0.1)';
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
              <div>
                <h3 style={{ margin: '0 0 8px 0', color: '#0A1929', fontSize: '18px' }}>{application.applicantName}</h3>
                <p style={{ margin: '0 0 8px 0', color: '#666', fontSize: '14px' }}>{application.postTitle}</p>
              </div>
              <div style={{
                padding: '4px 12px',
                borderRadius: '12px',
                fontSize: '12px',
                fontWeight: '500',
                backgroundColor: getStatusColor(application.status).bg,
                color: getStatusColor(application.status).text
              }}>
                {application.status}
              </div>
            </div>
            <div style={{ display: 'flex', gap: '12px', color: '#666', fontSize: '14px', flexWrap: 'wrap' }}>
              <span>📧 {application.email}</span>
              <span>📱 {application.phone}</span>
              <span>📅 Applied: {application.appliedDate}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Application Details Modal */}
      {selectedApplication && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{
            backgroundColor: 'white',
            padding: '20px',
            borderRadius: '12px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
            width: '450px',
            maxHeight: '70vh',
            overflow: 'auto',
            position: 'relative'
          }}>
            <div style={{ 
              display: 'flex', 
              justifyContent: 'space-between', 
              alignItems: 'flex-start',
              marginBottom: '12px',
              position: 'sticky',
              top: 0,
              backgroundColor: 'white',
              zIndex: 1,
              paddingBottom: '8px',
              borderBottom: '1px solid #eee'
            }}>
              <div>
                <h3 style={{ margin: '0 0 4px 0', fontSize: '16px', color: '#0A1929' }}>
                  {selectedApplication.applicantName}
                </h3>
                <p style={{ margin: '0', color: '#666', fontSize: '13px' }}>
                  {selectedApplication.postTitle}
                </p>
              </div>
              <button
                onClick={() => setSelectedApplication(null)}
                style={{
                  border: 'none',
                  background: 'none',
                  cursor: 'pointer',
                  padding: '4px',
                  fontSize: '18px',
                  color: '#666',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  width: '28px',
                  height: '28px',
                  borderRadius: '50%',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#f5f5f5'}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
              >
                ✕
              </button>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', fontSize: '0.875rem' }}>
                <div>
                  <label style={{ color: '#666', fontSize: '0.8125rem', fontWeight: '500' }}>Email</label>
                  <div style={{ marginTop: '2px', color: '#333' }}>{selectedApplication.email}</div>
                </div>
                <div>
                  <label style={{ color: '#666', fontSize: '0.8125rem', fontWeight: '500' }}>Phone</label>
                  <div style={{ marginTop: '2px', color: '#333' }}>{selectedApplication.phone}</div>
                </div>
                <div>
                  <label style={{ color: '#666', fontSize: '0.8125rem', fontWeight: '500' }}>Education</label>
                  <div style={{ marginTop: '2px', color: '#333' }}>{selectedApplication.education}</div>
                </div>
                <div>
                  <label style={{ color: '#666', fontSize: '0.8125rem', fontWeight: '500' }}>Applied Date</label>
                  <div style={{ marginTop: '2px', color: '#333' }}>{selectedApplication.appliedDate}</div>
                </div>
              </div>

              <div>
                <label style={{ color: '#666', fontSize: '0.8125rem', fontWeight: '500' }}>Experience</label>
                <div style={{ marginTop: '2px', color: '#333', fontSize: '0.875rem' }}>{selectedApplication.experience}</div>
              </div>

              <div>
                <label style={{ color: '#666', fontSize: '0.8125rem', fontWeight: '500' }}>Skills</label>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px', marginTop: '4px' }}>
                  {selectedApplication.skills.map((skill, index) => (
                    <span key={index} style={{
                      padding: '2px 8px',
                      backgroundColor: '#f0f2f5',
                      borderRadius: '12px',
                      fontSize: '11px',
                      color: '#0A1929'
                    }}>
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <label style={{ color: '#666', fontSize: '0.8125rem', fontWeight: '500' }}>Cover Letter</label>
                <div style={{ 
                  marginTop: '2px', 
                  color: '#333',
                  fontSize: '0.875rem',
                  backgroundColor: '#f8f9fa',
                  padding: '8px',
                  borderRadius: '6px',
                  maxHeight: '100px',
                  overflow: 'auto'
                }}>
                  {selectedApplication.coverLetter}
                </div>
              </div>

              {selectedApplication.resumeUrl && (
                <div>
                  <label style={{ color: '#666', fontSize: '0.8125rem', fontWeight: '500' }}>Resume</label>
                  <div style={{ marginTop: '4px' }}>
                    <button
                      onClick={() => handleDownloadResume(selectedApplication)}
                      style={{
                        padding: '6px 12px',
                        backgroundColor: '#f0f2f5',
                        border: 'none',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                        color: '#0A1929',
                        fontSize: '13px'
                      }}
                      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#e4e6e9'}
                      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#f0f2f5'}
                    >
                      📎 Download Resume
                    </button>
                  </div>
                </div>
              )}

              {/* Status Change Buttons */}
              {selectedApplication.status !== 'Internship Complete' && (
                <div style={{ 
                  marginTop: '4px',
                  paddingTop: '12px',
                  borderTop: '1px solid #eee',
                  display: 'flex',
                  gap: '8px',
                  justifyContent: 'flex-end'
                }}>
                  {selectedApplication.status === 'Pending' && (
                    <button
                      onClick={() => handleStatusChange(selectedApplication.id, 'Finalized')}
                      style={{
                        padding: '6px 12px',
                        backgroundColor: '#0A1929',
                        color: 'white',
                        border: 'none',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        fontSize: '13px'
                      }}
                      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#1a2a3a'}
                      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#0A1929'}
                    >
                      Finalize Application
                    </button>
                  )}
                  {selectedApplication.status === 'Finalized' && (
                    <>
                      <button
                        onClick={() => handleStatusChange(selectedApplication.id, 'Rejected')}
                        style={{
                          padding: '6px 12px',
                          backgroundColor: '#fce8e6',
                          color: '#c5221f',
                          border: 'none',
                          borderRadius: '6px',
                          cursor: 'pointer',
                          fontSize: '13px'
                        }}
                        onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#fad1ce'}
                        onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#fce8e6'}
                      >
                        Reject
                      </button>
                      <button
                        onClick={() => handleStatusChange(selectedApplication.id, 'Accepted')}
                        style={{
                          padding: '6px 12px',
                          backgroundColor: '#e6f4ea',
                          color: '#1e4620',
                          border: 'none',
                          borderRadius: '6px',
                          cursor: 'pointer',
                          fontSize: '13px'
                        }}
                        onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#ceead6'}
                        onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#e6f4ea'}
                      >
                        Accept
                      </button>
                    </>
                  )}
                  {selectedApplication.status === 'Accepted' && (
                    <button
                      onClick={() => handleStatusChange(selectedApplication.id, 'Current Intern')}
                      style={{
                        padding: '6px 12px',
                        backgroundColor: '#e8f0fe',
                        color: '#1a73e8',
                        border: 'none',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        fontSize: '13px'
                      }}
                      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#d4e4fd'}
                      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#e8f0fe'}
                    >
                      Start Internship
                    </button>
                  )}
                  {selectedApplication.status === 'Current Intern' && (
                    <button
                      onClick={() => handleStatusChange(selectedApplication.id, 'Internship Complete')}
                      style={{
                        padding: '6px 12px',
                        backgroundColor: '#f3e5f5',
                        color: '#6a1b9a',
                        border: 'none',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        fontSize: '13px'
                      }}
                      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#e8d5ea'}
                      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#f3e5f5'}
                    >
                      Complete Internship
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Resume PDF Modal */}
      {showResumeModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.75)',
          zIndex: 1100,
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center'
        }}>
          <div style={{
            backgroundColor: 'white',
            padding: '24px',
            borderRadius: '8px',
            width: '90%',
            height: '90%',
            position: 'relative',
            display: 'flex',
            flexDirection: 'column'
          }}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '16px'
            }}>
              <h3 style={{ margin: 0 }}>Resume</h3>
              <button
                onClick={() => {
                  setShowResumeModal(false);
                  setSelectedResume(null);
                }}
                style={{
                  border: 'none',
                  background: 'none',
                  cursor: 'pointer',
                  fontSize: '24px',
                  padding: '4px',
                  color: '#666'
                }}
              >
                ✕
              </button>
            </div>
            <div style={{
              flex: 1,
              border: '1px solid #eee',
              borderRadius: '4px',
              overflow: 'hidden'
            }}>
              <iframe
                src={selectedResume}
                style={{
                  width: '100%',
                  height: '100%',
                  border: 'none'
                }}
                title="Resume PDF Viewer"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
} 