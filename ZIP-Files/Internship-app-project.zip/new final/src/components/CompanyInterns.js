import React, { useState } from 'react';

// Mock data for current interns
const initialInterns = [
  {
    id: 1,
    name: 'Ahmed Mohamed',
    email: 'ahmed.mohamed@example.com',
    phone: '+20 123 456 7890',
    major: 'Computer Science',
    university: 'Cairo University',
    position: 'Software Engineering Intern',
    startDate: '2024-01-15',
    expectedEndDate: '2024-07-15',
    supervisor: 'Sarah Wilson',
    progress: 'On Track',
    department: 'Engineering',
    projects: ['Frontend Development', 'API Integration'],
    status: 'Current Intern',
    evaluation: null
  },
  {
    id: 2,
    name: 'Sara Ahmed',
    email: 'sara.ahmed@example.com',
    phone: '+20 123 456 7891',
    major: 'Data Science',
    university: 'Ain Shams University',
    position: 'Data Science Intern',
    startDate: '2024-02-01',
    expectedEndDate: '2024-08-01',
    supervisor: 'John Smith',
    progress: 'Excellent',
    department: 'Analytics',
    projects: ['Data Analysis', 'Machine Learning Model'],
    status: 'Internship Complete',
    evaluation: {
      overallPerformance: 'Excellent',
      technicalSkills: 5,
      communicationSkills: 4,
      initiative: 5,
      teamwork: 4,
      comments: 'Sara demonstrated exceptional analytical skills and contributed significantly to our ML projects.'
    }
  },
  {
    id: 3,
    name: 'Mohamed Ali',
    email: 'mohamed.ali@example.com',
    phone: '+20 123 456 7892',
    major: 'Software Engineering',
    university: 'Alexandria University',
    position: 'Backend Developer Intern',
    startDate: '2024-03-01',
    expectedEndDate: '2024-09-01',
    supervisor: 'Emily Brown',
    progress: 'Good',
    department: 'Engineering',
    projects: ['Database Optimization', 'Server Architecture'],
    status: 'Internship Complete',
    evaluation: null
  }
];

export default function CompanyInterns() {
  const defaultEvaluation = {
    overallPerformance: 'Good',
    technicalSkills: 3,
    communicationSkills: 3,
    initiative: 3,
    teamwork: 3,
    comments: ''
  };

  const [interns, setInterns] = useState(initialInterns);
  const [search, setSearch] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [selectedIntern, setSelectedIntern] = useState(null);
  const [showEvaluationModal, setShowEvaluationModal] = useState(false);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
  const [showUpdateSuccess, setShowUpdateSuccess] = useState(false);
  const [showDeleteSuccess, setShowDeleteSuccess] = useState(false);
  const [evaluation, setEvaluation] = useState(defaultEvaluation);
  const [evaluatingInternId, setEvaluatingInternId] = useState(null);

  // Get unique departments for filter
  const departments = ['All', ...new Set(interns.map(intern => intern.department))];

  // Filter interns based on search, department, and status
  const filteredInterns = interns.filter(intern => {
    const matchesSearch = 
      intern.name.toLowerCase().includes(search.toLowerCase()) ||
      intern.position.toLowerCase().includes(search.toLowerCase()) ||
      intern.department.toLowerCase().includes(search.toLowerCase());
    const matchesDepartment = departmentFilter === 'All' || intern.department === departmentFilter;
    const matchesStatus = statusFilter === 'All' || intern.status === statusFilter;
    return matchesSearch && matchesDepartment && matchesStatus;
  });

  const getStatusStyle = (status, hasEvaluation) => {
    const baseStyle = {
      padding: '4px 12px',
      borderRadius: '12px',
      fontSize: '12px',
      fontWeight: '500'
    };

    if (status === 'Current Intern') {
      return { ...baseStyle, backgroundColor: '#e8f0fe', color: '#1a73e8' };
    } else if (status === 'Internship Complete') {
      return hasEvaluation 
        ? { ...baseStyle, backgroundColor: '#e6f4ea', color: '#1e4620' }  // Green for completed with evaluation
        : { ...baseStyle, backgroundColor: '#fff3e0', color: '#e65100' }; // Orange for completed without evaluation
    }
    return { ...baseStyle, backgroundColor: '#f8f9fa', color: '#666' };
  };

  const getStatusLabel = (status, hasEvaluation) => {
    if (status === 'Internship Complete') {
      return hasEvaluation ? 'Evaluated' : 'Not Evaluated';
    }
    return status;
  };

  const handleEvaluationSubmit = () => {
    if (!selectedIntern) return;
    
    setInterns(interns.map(intern => 
      intern.id === selectedIntern.id 
        ? { 
            ...intern, 
            evaluation
          } 
        : intern
    ));
    setShowEvaluationModal(false);
    setSelectedIntern(null);
    setShowSuccessMessage(true);
    setTimeout(() => setShowSuccessMessage(false), 3000); // Hide after 3 seconds
  };

  const handleUpdateEvaluation = () => {
    if (!selectedIntern || !selectedIntern.evaluation) return;
    
    setEvaluation(selectedIntern.evaluation);
    setEvaluatingInternId(selectedIntern.id);
    setShowEvaluationModal(true);
    setSelectedIntern(null);
  };

  const handleDeleteEvaluation = () => {
    setShowDeleteConfirmation(true);
  };

  const confirmDeleteEvaluation = () => {
    setInterns(interns.map(intern => 
      intern.id === selectedIntern.id 
        ? { 
            ...intern, 
            evaluation: null
          } 
        : intern
    ));
    setShowDeleteConfirmation(false);
    setSelectedIntern(null);
    setShowDeleteSuccess(true);
    setTimeout(() => setShowDeleteSuccess(false), 3000);
  };

  return (
    <div style={{ padding: '40px', position: 'relative' }}>
      {/* Success Messages */}
      {showSuccessMessage && (
        <div style={{
          position: 'fixed',
          top: '20px',
          right: '20px',
          backgroundColor: '#e6f4ea',
          color: '#1e4620',
          padding: '16px 24px',
          borderRadius: '8px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
          zIndex: 2000,
          animation: 'slideIn 0.3s ease'
        }}>
          ✅ Evaluation submitted successfully!
        </div>
      )}

      {showUpdateSuccess && (
        <div style={{
          position: 'fixed',
          top: '20px',
          right: '20px',
          backgroundColor: '#e3f2fd',
          color: '#1565c0',
          padding: '16px 24px',
          borderRadius: '8px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
          zIndex: 2000,
          animation: 'slideIn 0.3s ease'
        }}>
          ✅ Evaluation updated successfully!
        </div>
      )}

      {showDeleteSuccess && (
        <div style={{
          position: 'fixed',
          top: '20px',
          right: '20px',
          backgroundColor: '#fce4ec',
          color: '#c2185b',
          padding: '16px 24px',
          borderRadius: '8px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
          zIndex: 2000,
          animation: 'slideIn 0.3s ease'
        }}>
          ✅ Evaluation deleted successfully!
        </div>
      )}

      {/* Add this style for the animation */}
      <style>
        {`
          @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
          }
          @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
          }
          
          .sidebar-tooltip {
            animation: fadeIn 0.2s ease;
          }
        `}
      </style>

      {/* Header */}
      <div style={{
        backgroundColor: '#0A1929',
        margin: '-40px -40px 24px -40px',
        padding: '32px 40px',
        borderRadius: '16px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
        position: 'relative'
      }}>
        <h1 style={{ 
          fontSize: '42px',
          fontWeight: '400',
          color: 'white',
          margin: 0,
          marginBottom: '12px',
          letterSpacing: '-0.5px'
        }}>
          Company Interns
        </h1>
        <h2 style={{
          fontSize: '20px',
          fontWeight: '400',
          color: 'rgba(255, 255, 255, 0.8)',
          margin: 0,
          letterSpacing: '0.1px',
          lineHeight: 1.4,
          paddingRight: '140px'
        }}>
          Monitor and evaluate interns' progress throughout their internship period.
        </h2>
      </div>

      {/* Filters */}
      <div style={{ 
        backgroundColor: 'white',
        borderRadius: '8px',
        boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
        padding: '16px',
        marginBottom: '24px'
      }}>
        <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
          <input
            type="text"
            placeholder="Search by name or position..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{
              padding: '8px 16px',
              border: '1px solid #dfe1e5',
              borderRadius: '4px',
              width: '100%',
              fontSize: '14px'
            }}
          />

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            style={{
              padding: '8px 16px',
              border: '1px solid #dfe1e5',
              borderRadius: '4px',
              backgroundColor: 'white',
              fontSize: '14px',
              minWidth: '150px'
            }}
          >
            <option value="All">All Status</option>
            <option value="Current Intern">Current Intern</option>
            <option value="Internship Complete">Internship Complete</option>
          </select>

          <select
            value={departmentFilter}
            onChange={(e) => setDepartmentFilter(e.target.value)}
            style={{
              padding: '8px 16px',
              border: '1px solid #dfe1e5',
              borderRadius: '4px',
              backgroundColor: 'white',
              fontSize: '14px',
              minWidth: '150px'
            }}
          >
            {departments.map((dept, index) => (
              <option key={index} value={dept}>{dept}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Interns List */}
      <div style={{ display: 'grid', gap: '16px' }}>
        {filteredInterns.map(intern => (
          <div
            key={intern.id}
            style={{
              backgroundColor: 'white',
              borderRadius: '8px',
              boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
              padding: '20px',
              cursor: 'pointer',
              transition: 'transform 0.2s ease, box-shadow 0.2s ease'
            }}
            onClick={() => setSelectedIntern(intern)}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'translateY(-2px)';
              e.currentTarget.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = '0 1px 3px rgba(0,0,0,0.1)';
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
              <div>
                <h3 style={{ margin: '0 0 8px 0', color: '#0A1929', fontSize: '18px' }}>{intern.name}</h3>
                <p style={{ margin: '0 0 8px 0', color: '#666', fontSize: '14px' }}>{intern.position}</p>
              </div>
              <div style={getStatusStyle(intern.status, !!intern.evaluation)}>
                {getStatusLabel(intern.status, !!intern.evaluation)}
              </div>
            </div>
            <div style={{ display: 'flex', gap: '24px', color: '#666', fontSize: '14px', flexWrap: 'wrap' }}>
              <span>📍 {intern.department}</span>
              <span>📅 Started: {intern.startDate}</span>
              <span>🎓 {intern.university}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Intern Details Modal */}
      {selectedIntern && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{
            backgroundColor: 'white',
            padding: '16px',
            borderRadius: '12px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
            width: '500px',
            maxHeight: '65vh',
            overflow: 'auto',
            position: 'relative'
          }}>
            <div style={{ 
              display: 'flex', 
              justifyContent: 'space-between', 
              alignItems: 'flex-start',
              marginBottom: '12px',
              position: 'sticky',
              top: 0,
              backgroundColor: 'white',
              zIndex: 1,
              paddingBottom: '8px',
              borderBottom: '1px solid #eee'
            }}>
              <div>
                <h3 style={{ margin: '0 0 4px 0', fontSize: '16px', color: '#0A1929' }}>
                  {selectedIntern.name}
                </h3>
                <p style={{ margin: '0', color: '#666', fontSize: '14px' }}>
                  {selectedIntern.position}
                </p>
              </div>
              <button
                onClick={() => setSelectedIntern(null)}
                style={{
                  border: 'none',
                  background: 'none',
                  cursor: 'pointer',
                  padding: '4px',
                  fontSize: '20px',
                  color: '#666',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  width: '32px',
                  height: '32px',
                  borderRadius: '50%',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#f5f5f5'}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
              >
                ✕
              </button>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', fontSize: '0.9rem' }}>
                <div>
                  <label style={{ color: '#666', fontSize: '0.875rem', fontWeight: '500' }}>Email</label>
                  <div style={{ marginTop: '4px', color: '#333' }}>{selectedIntern.email}</div>
                </div>
                <div>
                  <label style={{ color: '#666', fontSize: '0.875rem', fontWeight: '500' }}>Phone</label>
                  <div style={{ marginTop: '4px', color: '#333' }}>{selectedIntern.phone}</div>
                </div>
                <div>
                  <label style={{ color: '#666', fontSize: '0.875rem', fontWeight: '500' }}>Major</label>
                  <div style={{ marginTop: '4px', color: '#333' }}>{selectedIntern.major}</div>
                </div>
                <div>
                  <label style={{ color: '#666', fontSize: '0.875rem', fontWeight: '500' }}>University</label>
                  <div style={{ marginTop: '4px', color: '#333' }}>{selectedIntern.university}</div>
                </div>
                <div>
                  <label style={{ color: '#666', fontSize: '0.875rem', fontWeight: '500' }}>Department</label>
                  <div style={{ marginTop: '4px', color: '#333' }}>{selectedIntern.department}</div>
                </div>
                <div>
                  <label style={{ color: '#666', fontSize: '0.875rem', fontWeight: '500' }}>Supervisor</label>
                  <div style={{ marginTop: '4px', color: '#333' }}>{selectedIntern.supervisor}</div>
                </div>
                <div>
                  <label style={{ color: '#666', fontSize: '0.875rem', fontWeight: '500' }}>Start Date</label>
                  <div style={{ marginTop: '4px', color: '#333' }}>{selectedIntern.startDate}</div>
                </div>
                <div>
                  <label style={{ color: '#666', fontSize: '0.875rem', fontWeight: '500' }}>Expected End Date</label>
                  <div style={{ marginTop: '4px', color: '#333' }}>{selectedIntern.expectedEndDate}</div>
                </div>
              </div>

              <div>
                <label style={{ color: '#666', fontSize: '0.875rem', fontWeight: '500' }}>Projects</label>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginTop: '6px' }}>
                  {selectedIntern.projects.map((project, index) => (
                    <span key={index} style={{
                      padding: '3px 10px',
                      backgroundColor: '#f0f2f5',
                      borderRadius: '12px',
                      fontSize: '12px',
                      color: '#0A1929'
                    }}>
                      {project}
                    </span>
                  ))}
                </div>
              </div>

              {selectedIntern.evaluation ? (
                <div>
                  <label style={{ color: '#666', fontSize: '0.875rem', fontWeight: '500' }}>Evaluation</label>
                  <div style={{ marginTop: '8px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                      <div>
                        <label style={{ color: '#666', fontSize: '0.75rem' }}>Technical Skills</label>
                        <div style={{ color: '#333', fontSize: '0.875rem' }}>{selectedIntern.evaluation.technicalSkills}/5</div>
                      </div>
                      <div>
                        <label style={{ color: '#666', fontSize: '0.75rem' }}>Communication</label>
                        <div style={{ color: '#333', fontSize: '0.875rem' }}>{selectedIntern.evaluation.communicationSkills}/5</div>
                      </div>
                      <div>
                        <label style={{ color: '#666', fontSize: '0.75rem' }}>Initiative</label>
                        <div style={{ color: '#333', fontSize: '0.875rem' }}>{selectedIntern.evaluation.initiative}/5</div>
                      </div>
                      <div>
                        <label style={{ color: '#666', fontSize: '0.75rem' }}>Teamwork</label>
                        <div style={{ color: '#333', fontSize: '0.875rem' }}>{selectedIntern.evaluation.teamwork}/5</div>
                      </div>
                    </div>
                    <div>
                      <label style={{ color: '#666', fontSize: '0.75rem' }}>Comments</label>
                      <div style={{ color: '#333', fontSize: '0.875rem' }}>{selectedIntern.evaluation.comments}</div>
                    </div>
                    <div style={{ display: 'flex', gap: '12px', marginTop: '16px' }}>
                      <button
                        onClick={handleUpdateEvaluation}
                        style={{
                          padding: '8px 16px',
                          backgroundColor: '#0A1929',
                          color: 'white',
                          border: 'none',
                          borderRadius: '6px',
                          cursor: 'pointer',
                          fontSize: '14px',
                          fontWeight: '500',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px'
                        }}
                      >
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z" fill="currentColor"/>
                        </svg>
                        Update Evaluation
                      </button>
                      <button
                        onClick={handleDeleteEvaluation}
                        style={{
                          padding: '8px 16px',
                          backgroundColor: '#fce4ec',
                          color: '#c2185b',
                          border: 'none',
                          borderRadius: '6px',
                          cursor: 'pointer',
                          fontSize: '14px',
                          fontWeight: '500',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px'
                        }}
                      >
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z" fill="currentColor"/>
                        </svg>
                        Delete Evaluation
                      </button>
                    </div>
                  </div>
                </div>
              ) : selectedIntern.status === 'Internship Complete' && (
                <div style={{ 
                  display: 'flex', 
                  flexDirection: 'column', 
                  alignItems: 'center',
                  gap: '12px',
                  padding: '16px',
                  backgroundColor: '#fff3e0',
                  borderRadius: '8px',
                  marginTop: '8px'
                }}>
                  <p style={{ 
                    margin: 0,
                    color: '#e65100',
                    fontSize: '14px',
                    textAlign: 'center'
                  }}>
                    This intern has completed their internship but hasn't been evaluated yet.
                  </p>
                  <button
                    onClick={() => {
                      setEvaluatingInternId(selectedIntern.id);
                      setShowEvaluationModal(true);
                      setSelectedIntern(null);
                    }}
                    style={{
                      padding: '8px 16px',
                      backgroundColor: '#0A1929',
                      color: 'white',
                      border: 'none',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      fontSize: '14px',
                      fontWeight: '500',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '6px'
                    }}
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M11 7h2v2h-2V7zm0 4h2v6h-2v-6zm1-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" fill="currentColor"/>
                    </svg>
                    Evaluate Intern
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Evaluation Modal */}
      {showEvaluationModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{
            backgroundColor: 'white',
            padding: '16px',
            borderRadius: '8px',
            width: '450px',
            maxHeight: '65vh',
            overflow: 'auto'
          }} onClick={e => e.stopPropagation()}>
            <div style={{ 
              display: 'flex', 
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '12px',
              borderBottom: '1px solid #eee',
              paddingBottom: '8px'
            }}>
              <h3 style={{ margin: 0, fontSize: '16px' }}>Final Evaluation</h3>
              <button
                onClick={() => {
                  setShowEvaluationModal(false);
                  setEvaluation(defaultEvaluation);
                  setEvaluatingInternId(null);
                }}
                style={{
                  border: 'none',
                  background: 'none',
                  cursor: 'pointer',
                  fontSize: '20px'
                }}
              >
                ✕
              </button>
            </div>

            <div style={{ display: 'grid', gap: '16px' }}>
              <div>
                <label style={{ color: '#666', fontSize: '0.875rem' }}>Overall Performance</label>
                <select
                  value={evaluation.overallPerformance}
                  onChange={(e) => setEvaluation({ ...evaluation, overallPerformance: e.target.value })}
                  style={{
                    width: '100%',
                    padding: '8px',
                    marginTop: '4px',
                    border: '1px solid #dfe1e5',
                    borderRadius: '4px'
                  }}
                >
                  <option value="Excellent">Excellent</option>
                  <option value="Good">Good</option>
                  <option value="Satisfactory">Satisfactory</option>
                  <option value="Needs Improvement">Needs Improvement</option>
                </select>
              </div>

              {['Technical Skills', 'Communication Skills', 'Initiative', 'Teamwork'].map((skill) => (
                <div key={skill}>
                  <label style={{ color: '#666', fontSize: '0.875rem' }}>{skill}</label>
                  <div style={{ display: 'flex', gap: '8px', marginTop: '4px' }}>
                    {[1, 2, 3, 4, 5].map((rating) => (
                      <button
                        key={rating}
                        onClick={() => setEvaluation({ 
                          ...evaluation, 
                          [skill.toLowerCase().replace(' ', '')]: rating 
                        })}
                        style={{
                          padding: '8px',
                          border: 'none',
                          background: 'none',
                          cursor: 'pointer',
                          opacity: rating <= evaluation[skill.toLowerCase().replace(' ', '')] ? 1 : 0.3
                        }}
                      >
                        ⭐
                      </button>
                    ))}
                  </div>
                </div>
              ))}

              <div>
                <label style={{ color: '#666', fontSize: '0.875rem' }}>Comments</label>
                <textarea
                  value={evaluation.comments}
                  onChange={(e) => setEvaluation({ ...evaluation, comments: e.target.value })}
                  style={{
                    width: '100%',
                    padding: '8px',
                    marginTop: '4px',
                    border: '1px solid #dfe1e5',
                    borderRadius: '4px',
                    minHeight: '80px',
                    resize: 'vertical'
                  }}
                  placeholder="Add your comments about the intern's performance..."
                />
              </div>
            </div>

            <div style={{ display: 'flex', gap: '12px', marginTop: '24px' }}>
              <button
                onClick={() => {
                  setShowEvaluationModal(false);
                  setEvaluation(defaultEvaluation);
                  setEvaluatingInternId(null);
                }}
                style={{
                  padding: '8px 16px',
                  backgroundColor: '#f8f9fa',
                  color: '#666',
                  border: '1px solid #dfe1e5',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  const updatedInterns = interns.map(intern => 
                    intern.id === evaluatingInternId 
                      ? { 
                          ...intern, 
                          evaluation: { ...evaluation }
                        } 
                      : intern
                  );
                  setInterns(updatedInterns);
                  setShowEvaluationModal(false);
                  setShowSuccessMessage(true);
                  setTimeout(() => setShowSuccessMessage(false), 3000);
                  setEvaluation(defaultEvaluation);
                  setEvaluatingInternId(null);
                }}
                style={{
                  padding: '8px 16px',
                  backgroundColor: '#0A1929',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Submit Evaluation
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirmation && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{
            backgroundColor: 'white',
            padding: '24px',
            borderRadius: '8px',
            width: '400px',
            textAlign: 'center'
          }}>
            <h3 style={{ margin: '0 0 16px 0', color: '#c2185b' }}>Delete Evaluation?</h3>
            <p style={{ margin: '0 0 24px 0', color: '#666' }}>
              Are you sure you want to delete this evaluation? This action cannot be undone.
            </p>
            <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
              <button
                onClick={() => setShowDeleteConfirmation(false)}
                style={{
                  padding: '8px 16px',
                  backgroundColor: '#f8f9fa',
                  color: '#666',
                  border: '1px solid #dfe1e5',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Cancel
              </button>
              <button
                onClick={confirmDeleteEvaluation}
                style={{
                  padding: '8px 16px',
                  backgroundColor: '#c2185b',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
} 