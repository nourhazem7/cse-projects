import React, { useState } from 'react';

// Mock data for internship posts
const initialPosts = [
  {
    id: 1,
    title: 'Software Engineering Intern',
    description: 'Looking for a passionate software engineering intern to join our development team.',
    requirements: 'Strong knowledge of JavaScript, React, and Node.js',
    skills: ['JavaScript', 'React', 'Node.js', 'Git'],
    duration: '3 months',
    location: 'Cairo, Egypt',
    type: 'Full-time',
    isPaid: true,
    expectedSalary: '5000 EGP/month',
    status: 'Open',
    applicationsCount: 12,
    postedDate: '2024-03-15'
  },
  {
    id: 2,
    title: 'Data Science Intern',
    description: 'Join our data science team to work on exciting ML projects.',
    requirements: 'Python, pandas, scikit-learn experience required',
    skills: ['Python', 'Pandas', 'Scikit-learn', 'SQL'],
    duration: '6 months',
    location: 'Remote',
    type: 'Part-time',
    isPaid: true,
    expectedSalary: '3000 EGP/month',
    status: 'Open',
    applicationsCount: 8,
    postedDate: '2024-03-10'
  },
  {
    id: 3,
    title: 'UI/UX Design Intern',
    description: 'Help us create beautiful and intuitive user interfaces.',
    requirements: 'Figma, Adobe XD, and basic prototyping skills',
    skills: ['Figma', 'Adobe XD', 'Prototyping', 'UI Design'],
    duration: '4 months',
    location: 'Alexandria, Egypt',
    type: 'Full-time',
    isPaid: false,
    expectedSalary: null,
    status: 'Closed',
    applicationsCount: 15,
    postedDate: '2024-02-28'
  }
];

export default function InternshipPosts() {
  const [posts, setPosts] = useState(initialPosts);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [selectedPost, setSelectedPost] = useState(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [editingPost, setEditingPost] = useState(null);
  const [deletingPost, setDeletingPost] = useState(null);
  const [newPost, setNewPost] = useState({
    title: '',
    description: '',
    requirements: '',
    skills: [],
    duration: '',
    location: '',
    type: 'Full-time',
    isPaid: false,
    expectedSalary: ''
  });

  // Filter posts based on search and filters
  const filteredPosts = posts.filter(post => {
    const matchesSearch = 
      post.title.toLowerCase().includes(search.toLowerCase()) ||
      post.description.toLowerCase().includes(search.toLowerCase()) ||
      post.location.toLowerCase().includes(search.toLowerCase());
    const matchesType = typeFilter === 'All' || post.type === typeFilter;
    const matchesStatus = statusFilter === 'All' || post.status === statusFilter;
    return matchesSearch && matchesType && matchesStatus;
  });

  const handleAddPost = (e) => {
    e.preventDefault();
    const currentDate = new Date().toISOString().split('T')[0];
    const newPostWithDetails = {
      ...newPost,
      id: posts.length + 1,
      status: 'Open',
      applicationsCount: 0,
      postedDate: currentDate
    };
    setPosts([...posts, newPostWithDetails]);
    setShowAddModal(false);
    setNewPost({
      title: '',
      description: '',
      requirements: '',
      skills: [],
      duration: '',
      location: '',
      type: 'Full-time',
      isPaid: false,
      expectedSalary: ''
    });
  };

  const handleEditPost = (e) => {
    e.preventDefault();
    setPosts(posts.map(post => 
      post.id === editingPost.id ? editingPost : post
    ));
    setShowEditModal(false);
    setEditingPost(null);
  };

  const handleDeletePost = () => {
    setPosts(posts.filter(post => post.id !== deletingPost.id));
    setShowDeleteConfirm(false);
    setDeletingPost(null);
  };

  const startEdit = (post) => {
    setEditingPost({ ...post });
    setShowEditModal(true);
    setSelectedPost(null);
  };

  const startDelete = (post) => {
    setDeletingPost(post);
    setShowDeleteConfirm(true);
    setSelectedPost(null);
  };

  return (
    <div style={{ padding: '40px', position: 'relative' }}>
      {/* Header */}
      <div style={{
        backgroundColor: '#0A1929',
        margin: '-40px -40px 24px -40px',
        padding: '32px 40px',
        borderRadius: '16px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
        position: 'relative'
      }}>
        <h1 style={{ 
          fontSize: '42px',
          fontWeight: '400',
          color: 'white',
          margin: 0,
          marginBottom: '12px',
          letterSpacing: '-0.5px'
        }}>
          Internship Posts
        </h1>
        <h2 style={{
          fontSize: '20px',
          fontWeight: '400',
          color: 'rgba(255, 255, 255, 0.8)',
          margin: 0,
          letterSpacing: '0.1px',
          lineHeight: 1.4,
          paddingRight: '140px'
        }}>
          Create and manage internship opportunities for potential candidates.
        </h2>
        <button
          onClick={() => setShowAddModal(true)}
          style={{
            position: 'absolute',
            right: '40px',
            bottom: '32px',
            padding: '10px 20px',
            backgroundColor: 'rgba(255, 255, 255, 0.1)',
            color: 'white',
            border: '1px solid rgba(255, 255, 255, 0.2)',
            borderRadius: '8px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            fontSize: '14px',
            fontWeight: '500',
            transition: 'all 0.2s ease'
          }}
          onMouseEnter={(e) => e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.2)'}
          onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.1)'}
        >
          ➕ New Post
        </button>
      </div>

      {/* Filters */}
      <div style={{ 
        backgroundColor: 'white',
        borderRadius: '8px',
        boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
        padding: '16px',
        marginBottom: '24px'
      }}>
        <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
          <input
            type="text"
            placeholder="Search internship posts..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{
              padding: '8px 16px',
              border: '1px solid #dfe1e5',
              borderRadius: '4px',
              width: '100%',
              fontSize: '14px'
            }}
          />

          <select 
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            style={{
              padding: '8px 16px',
              border: '1px solid #dfe1e5',
              borderRadius: '4px',
              backgroundColor: 'white',
              fontSize: '14px',
              minWidth: '150px'
            }}
          >
            <option value="All">All Types</option>
            <option value="Full-time">Full-time</option>
            <option value="Part-time">Part-time</option>
          </select>

          <select 
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            style={{
              padding: '8px 16px',
              border: '1px solid #dfe1e5',
              borderRadius: '4px',
              backgroundColor: 'white',
              fontSize: '14px',
              minWidth: '150px'
            }}
          >
            <option value="All">All Status</option>
            <option value="Open">Open</option>
            <option value="Closed">Closed</option>
          </select>
        </div>
      </div>

      {/* Posts List */}
      <div style={{ display: 'grid', gap: '16px' }}>
        {filteredPosts.map(post => (
          <div
            key={post.id}
            style={{
              backgroundColor: 'white',
              borderRadius: '8px',
              boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
              padding: '20px',
              cursor: 'pointer',
              transition: 'transform 0.2s ease, box-shadow 0.2s ease'
            }}
            onClick={() => setSelectedPost(post)}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'translateY(-2px)';
              e.currentTarget.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = '0 1px 3px rgba(0,0,0,0.1)';
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
              <div>
                <h3 style={{ margin: '0 0 8px 0', color: '#0A1929', fontSize: '18px' }}>{post.title}</h3>
                <p style={{ margin: '0 0 8px 0', color: '#666', fontSize: '14px' }}>{post.description}</p>
              </div>
              <div style={{
                padding: '4px 12px',
                borderRadius: '12px',
                fontSize: '12px',
                fontWeight: '500',
                backgroundColor: post.status === 'Open' ? '#e6f4ea' : '#fce8e6',
                color: post.status === 'Open' ? '#1e4620' : '#c5221f'
              }}>
                {post.status}
              </div>
            </div>
            <div style={{ display: 'flex', gap: '12px', color: '#666', fontSize: '14px', flexWrap: 'wrap' }}>
              <span>📍 {post.location}</span>
              <span>⏱️ {post.duration}</span>
              <span>💰 {post.isPaid ? `Paid - ${post.expectedSalary}` : 'Unpaid'}</span>
              <span>👥 {post.applicationsCount} applications</span>
              <span>📅 Posted: {post.postedDate}</span>
            </div>
            <div style={{ marginTop: '12px' }}>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                {post.skills.map((skill, index) => (
                  <span key={index} style={{
                    padding: '4px 12px',
                    backgroundColor: '#f0f2f5',
                    borderRadius: '16px',
                    fontSize: '12px',
                    color: '#0A1929'
                  }}>
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Post Details Modal */}
      {selectedPost && (
        <div style={{
          position: 'fixed',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          backgroundColor: 'white',
          padding: '16px',
          borderRadius: '8px',
          boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
          zIndex: 1000,
          width: '500px',
          maxHeight: '60vh',
          overflow: 'auto'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
            <h3 style={{ margin: 0, fontSize: '16px' }}>{selectedPost.title}</h3>
            <div style={{ display: 'flex', gap: '12px' }}>
              <button
                onClick={() => startEdit(selectedPost)}
                style={{
                  border: 'none',
                  background: '#f0f2f5',
                  cursor: 'pointer',
                  padding: '8px 12px',
                  fontSize: '14px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  borderRadius: '6px',
                  color: '#0A1929',
                  fontWeight: '500',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = '#e4e6e9';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = '#f0f2f5';
                }}
                title="Edit Post"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z" fill="currentColor"/>
                </svg>
                Edit
              </button>
              <button
                onClick={() => startDelete(selectedPost)}
                style={{
                  border: 'none',
                  background: 'none',
                  cursor: 'pointer',
                  padding: '4px',
                  fontSize: '16px'
                }}
                title="Delete"
              >
                🗑️
              </button>
              <button
                onClick={() => setSelectedPost(null)}
                style={{
                  border: 'none',
                  background: 'none',
                  cursor: 'pointer',
                  padding: '4px',
                  fontSize: '20px'
                }}
              >
                ✕
              </button>
            </div>
          </div>
          
          <div style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
            <div>
              <label style={{ color: '#666', fontSize: '0.875rem' }}>Description</label>
              <div style={{ fontSize: '1rem', marginTop: '4px' }}>{selectedPost.description}</div>
            </div>
            <div>
              <label style={{ color: '#666', fontSize: '0.875rem' }}>Requirements</label>
              <div style={{ fontSize: '1rem', marginTop: '4px' }}>{selectedPost.requirements}</div>
            </div>
            <div>
              <label style={{ color: '#666', fontSize: '0.875rem' }}>Required Skills</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginTop: '4px' }}>
                {selectedPost.skills.map((skill, index) => (
                  <span key={index} style={{
                    padding: '4px 12px',
                    backgroundColor: '#f0f2f5',
                    borderRadius: '16px',
                    fontSize: '12px',
                    color: '#0A1929'
                  }}>
                    {skill}
                  </span>
                ))}
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              <div>
                <label style={{ color: '#666', fontSize: '0.875rem' }}>Location</label>
                <div style={{ fontSize: '1rem', marginTop: '4px' }}>{selectedPost.location}</div>
              </div>
              <div>
                <label style={{ color: '#666', fontSize: '0.875rem' }}>Duration</label>
                <div style={{ fontSize: '1rem', marginTop: '4px' }}>{selectedPost.duration}</div>
              </div>
              <div>
                <label style={{ color: '#666', fontSize: '0.875rem' }}>Type</label>
                <div style={{ fontSize: '1rem', marginTop: '4px' }}>{selectedPost.type}</div>
              </div>
              <div>
                <label style={{ color: '#666', fontSize: '0.875rem' }}>Compensation</label>
                <div style={{ fontSize: '1rem', marginTop: '4px' }}>
                  {selectedPost.isPaid ? `Paid - ${selectedPost.expectedSalary}` : 'Unpaid'}
                </div>
              </div>
              <div>
                <label style={{ color: '#666', fontSize: '0.875rem' }}>Status</label>
                <div style={{ fontSize: '1rem', marginTop: '4px' }}>
                  <span style={{
                    padding: '4px 12px',
                    borderRadius: '12px',
                    fontSize: '12px',
                    fontWeight: '500',
                    backgroundColor: selectedPost.status === 'Open' ? '#e6f4ea' : '#fce8e6',
                    color: selectedPost.status === 'Open' ? '#1e4620' : '#c5221f'
                  }}>
                    {selectedPost.status}
                  </span>
                </div>
              </div>
            </div>
            <div>
              <label style={{ color: '#666', fontSize: '0.875rem' }}>Applications</label>
              <div style={{ fontSize: '1rem', marginTop: '4px' }}>
                {selectedPost.applicationsCount} applications received
              </div>
            </div>
            <div>
              <label style={{ color: '#666', fontSize: '0.875rem' }}>Posted Date</label>
              <div style={{ fontSize: '1rem', marginTop: '4px' }}>{selectedPost.postedDate}</div>
            </div>
          </div>

          <div style={{ 
            display: 'flex', 
            gap: '12px', 
            marginTop: '24px',
            borderTop: '1px solid #eee',
            paddingTop: '20px'
          }}>
            <button
              onClick={() => {
                setPosts(posts.map(p => 
                  p.id === selectedPost.id 
                    ? { ...p, status: p.status === 'Open' ? 'Closed' : 'Open' }
                    : p
                ));
                setSelectedPost(null);
              }}
              style={{
                flex: 1,
                padding: '8px 16px',
                backgroundColor: selectedPost.status === 'Open' ? '#fce8e6' : '#e6f4ea',
                color: selectedPost.status === 'Open' ? '#c5221f' : '#1e4620',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '14px'
              }}
            >
              {selectedPost.status === 'Open' ? '🚫 Close Position' : '✅ Reopen Position'}
            </button>
          </div>
        </div>
      )}

      {/* Edit Post Modal */}
      {showEditModal && (
        <div style={{
          position: 'fixed',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          backgroundColor: 'white',
          padding: '12px',
          borderRadius: '12px',
          boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
          zIndex: 1000,
          width: '450px',
          maxHeight: '60vh',
          overflow: 'auto'
        }}>
          <div style={{ 
            display: 'flex', 
            justifyContent: 'space-between', 
            alignItems: 'center', 
            marginBottom: '8px',
            borderBottom: '1px solid #eee',
            paddingBottom: '8px'
          }}>
            <h3 style={{ margin: 0, fontSize: '16px', color: '#0A1929' }}>Edit Internship Post</h3>
            <button
              onClick={() => {
                setShowEditModal(false);
                setEditingPost(null);
              }}
              style={{
                border: 'none',
                background: 'none',
                cursor: 'pointer',
                padding: '4px',
                fontSize: '18px',
                color: '#666'
              }}
            >
              ✕
            </button>
          </div>

          <form onSubmit={handleEditPost}>
            <div style={{ display: 'grid', gap: '12px' }}>
              <div>
                <label style={{ display: 'block', marginBottom: '2px', color: '#666', fontSize: '0.75rem' }}>
                  Title
                </label>
                <input
                  type="text"
                  value={editingPost.title}
                  onChange={(e) => setEditingPost({ ...editingPost, title: e.target.value })}
                  required
                  style={{
                    width: '100%',
                    padding: '6px 10px',
                    border: '1px solid #dfe1e5',
                    borderRadius: '6px',
                    fontSize: '13px'
                  }}
                />
              </div>

              <div>
                <label style={{ display: 'block', marginBottom: '2px', color: '#666', fontSize: '0.75rem' }}>
                  Description
                </label>
                <textarea
                  value={editingPost.description}
                  onChange={(e) => setEditingPost({ ...editingPost, description: e.target.value })}
                  required
                  style={{
                    width: '100%',
                    padding: '6px 10px',
                    border: '1px solid #dfe1e5',
                    borderRadius: '6px',
                    fontSize: '13px',
                    height: '40px',
                    resize: 'none'
                  }}
                />
              </div>

              <div>
                <label style={{ display: 'block', marginBottom: '2px', color: '#666', fontSize: '0.75rem' }}>
                  Requirements
                </label>
                <textarea
                  value={editingPost.requirements}
                  onChange={(e) => setEditingPost({ ...editingPost, requirements: e.target.value })}
                  required
                  style={{
                    width: '100%',
                    padding: '6px 10px',
                    border: '1px solid #dfe1e5',
                    borderRadius: '6px',
                    fontSize: '13px',
                    height: '40px',
                    resize: 'none'
                  }}
                />
              </div>

              <div>
                <label style={{ display: 'block', marginBottom: '2px', color: '#666', fontSize: '0.75rem' }}>
                  Skills (comma-separated)
                </label>
                <input
                  type="text"
                  value={editingPost.skills.join(', ')}
                  onChange={(e) => setEditingPost({ 
                    ...editingPost, 
                    skills: e.target.value.split(',').map(skill => skill.trim()).filter(Boolean)
                  })}
                  placeholder="e.g. JavaScript, React, Node.js"
                  style={{
                    width: '100%',
                    padding: '6px 10px',
                    border: '1px solid #dfe1e5',
                    borderRadius: '6px',
                    fontSize: '13px'
                  }}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                <div>
                  <label style={{ display: 'block', marginBottom: '2px', color: '#666', fontSize: '0.75rem' }}>
                    Duration
                  </label>
                  <input
                    type="text"
                    value={editingPost.duration}
                    onChange={(e) => setEditingPost({ ...editingPost, duration: e.target.value })}
                    required
                    style={{
                      width: '100%',
                      padding: '6px 10px',
                      border: '1px solid #dfe1e5',
                      borderRadius: '6px',
                      fontSize: '13px'
                    }}
                  />
                </div>

                <div>
                  <label style={{ display: 'block', marginBottom: '2px', color: '#666', fontSize: '0.75rem' }}>
                    Location
                  </label>
                  <input
                    type="text"
                    value={editingPost.location}
                    onChange={(e) => setEditingPost({ ...editingPost, location: e.target.value })}
                    required
                    style={{
                      width: '100%',
                      padding: '6px 10px',
                      border: '1px solid #dfe1e5',
                      borderRadius: '6px',
                      fontSize: '13px'
                    }}
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                <div>
                  <label style={{ display: 'block', marginBottom: '2px', color: '#666', fontSize: '0.75rem' }}>
                    Type
                  </label>
                  <select
                    value={editingPost.type}
                    onChange={(e) => setEditingPost({ ...editingPost, type: e.target.value })}
                    required
                    style={{
                      width: '100%',
                      padding: '6px 10px',
                      border: '1px solid #dfe1e5',
                      borderRadius: '6px',
                      fontSize: '13px',
                      backgroundColor: 'white',
                      appearance: 'none',
                      backgroundImage: `url("data:image/svg+xml,%3Csvg width='10' height='6' viewBox='0 0 10 6' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1 1L5 5L9 1' stroke='%23666666' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")`,
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 8px center'
                    }}
                  >
                    <option value="Full-time">Full-time</option>
                    <option value="Part-time">Part-time</option>
                  </select>
                </div>

                <div>
                  <label style={{ display: 'block', marginBottom: '2px', color: '#666', fontSize: '0.75rem' }}>
                    Compensation
                  </label>
                  <select
                    value={editingPost.isPaid ? 'paid' : 'unpaid'}
                    onChange={(e) => {
                      const isPaid = e.target.value === 'paid';
                      setEditingPost({ 
                        ...editingPost, 
                        isPaid,
                        expectedSalary: isPaid ? editingPost.expectedSalary || '' : null
                      });
                    }}
                    style={{
                      width: '100%',
                      padding: '6px 10px',
                      border: '1px solid #dfe1e5',
                      borderRadius: '6px',
                      fontSize: '13px',
                      backgroundColor: 'white',
                      appearance: 'none',
                      backgroundImage: `url("data:image/svg+xml,%3Csvg width='10' height='6' viewBox='0 0 10 6' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1 1L5 5L9 1' stroke='%23666666' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")`,
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 8px center'
                    }}
                  >
                    <option value="paid">Paid</option>
                    <option value="unpaid">Unpaid</option>
                  </select>
                </div>
              </div>

              {editingPost.isPaid && (
                <div>
                  <label style={{ display: 'block', marginBottom: '2px', color: '#666', fontSize: '0.75rem' }}>
                    Expected Salary
                  </label>
                  <input
                    type="text"
                    value={editingPost.expectedSalary || ''}
                    onChange={(e) => setEditingPost({ ...editingPost, expectedSalary: e.target.value })}
                    placeholder="e.g. 5000 EGP/month"
                    style={{
                      width: '100%',
                      padding: '6px 10px',
                      border: '1px solid #dfe1e5',
                      borderRadius: '6px',
                      fontSize: '13px'
                    }}
                  />
                </div>
              )}
            </div>

            <div style={{ 
              display: 'flex', 
              gap: '8px', 
              marginTop: '12px',
              borderTop: '1px solid #eee',
              paddingTop: '12px'
            }}>
              <button
                type="submit"
                style={{
                  flex: 1,
                  padding: '8px 16px',
                  backgroundColor: '#0A1929',
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontSize: '13px',
                  fontWeight: '500'
                }}
              >
                Save Changes
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowEditModal(false);
                  setEditingPost(null);
                }}
                style={{
                  flex: 1,
                  padding: '8px 16px',
                  backgroundColor: 'white',
                  color: '#0A1929',
                  border: '1px solid #0A1929',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontSize: '13px',
                  fontWeight: '500'
                }}
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div style={{
          position: 'fixed',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          backgroundColor: 'white',
          padding: '16px',
          borderRadius: '8px',
          boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
          zIndex: 1000,
          width: '400px',
          textAlign: 'center'
        }}>
          <h3 style={{ margin: '0 0 12px 0', fontSize: '16px' }}>Delete Internship Post</h3>
          <p style={{ margin: '0 0 16px 0', color: '#666', fontSize: '14px' }}>
            Are you sure you want to delete "{deletingPost.title}"? This action cannot be undone.
          </p>
          <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
            <button
              onClick={handleDeletePost}
              style={{
                padding: '10px 20px',
                backgroundColor: '#dc3545',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '14px'
              }}
            >
              Delete
            </button>
            <button
              onClick={() => {
                setShowDeleteConfirm(false);
                setDeletingPost(null);
              }}
              style={{
                padding: '10px 20px',
                backgroundColor: 'white',
                color: '#0A1929',
                border: '1px solid #0A1929',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '14px'
              }}
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Add New Post Modal */}
      {showAddModal && (
        <div style={{
          position: 'fixed',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          backgroundColor: 'white',
          padding: '12px',
          borderRadius: '12px',
          boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
          zIndex: 1000,
          width: '450px',
          maxHeight: '55vh',
          overflow: 'auto'
        }}>
          <div style={{ 
            display: 'flex', 
            justifyContent: 'space-between', 
            alignItems: 'center', 
            marginBottom: '8px',
            borderBottom: '1px solid #eee',
            paddingBottom: '8px'
          }}>
            <h3 style={{ 
              margin: 0,
              fontSize: '16px',
              color: '#0A1929',
              fontWeight: '500'
            }}>Create New Internship Post</h3>
            <button
              onClick={() => setShowAddModal(false)}
              style={{
                border: 'none',
                background: 'none',
                cursor: 'pointer',
                padding: '4px',
                fontSize: '20px',
                color: '#666',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                borderRadius: '50%',
                transition: 'all 0.2s ease'
              }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#f5f5f5'}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
            >
              ✕
            </button>
          </div>

          <form onSubmit={handleAddPost} style={{ display: 'grid', gap: '6px', maxWidth: '420px', margin: '0 auto' }}>
            <div style={{ display: 'grid', gap: '6px' }}>
              <div>
                <label style={{ 
                  display: 'block', 
                  marginBottom: '2px', 
                  color: '#0A1929', 
                  fontSize: '0.875rem',
                  fontWeight: '500'
                }}>
                  Title
                </label>
                <input
                  type="text"
                  value={newPost.title}
                  onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
                  required
                  style={{
                    width: '100%',
                    padding: '6px 12px',
                    border: '1px solid #dfe1e5',
                    borderRadius: '8px',
                    fontSize: '14px',
                    transition: 'border-color 0.2s ease',
                    outline: 'none'
                  }}
                  onFocus={(e) => e.target.style.borderColor = '#0A1929'}
                  onBlur={(e) => e.target.style.borderColor = '#dfe1e5'}
                />
              </div>

              <div>
                <label style={{ 
                  display: 'block', 
                  marginBottom: '2px', 
                  color: '#0A1929', 
                  fontSize: '0.875rem',
                  fontWeight: '500'
                }}>
                  Description
                </label>
                <textarea
                  value={newPost.description}
                  onChange={(e) => setNewPost({ ...newPost, description: e.target.value })}
                  required
                  style={{
                    width: '100%',
                    padding: '6px 12px',
                    border: '1px solid #dfe1e5',
                    borderRadius: '8px',
                    fontSize: '14px',
                    height: '35px',
                    resize: 'none',
                    transition: 'border-color 0.2s ease',
                    outline: 'none'
                  }}
                />
              </div>

              <div>
                <label style={{ 
                  display: 'block', 
                  marginBottom: '2px', 
                  color: '#0A1929', 
                  fontSize: '0.875rem',
                  fontWeight: '500'
                }}>
                  Requirements
                </label>
                <textarea
                  value={newPost.requirements}
                  onChange={(e) => setNewPost({ ...newPost, requirements: e.target.value })}
                  required
                  style={{
                    width: '100%',
                    padding: '6px 12px',
                    border: '1px solid #dfe1e5',
                    borderRadius: '8px',
                    fontSize: '14px',
                    height: '30px',
                    resize: 'none',
                    transition: 'border-color 0.2s ease',
                    outline: 'none'
                  }}
                />
              </div>

              <div>
                <label style={{ 
                  display: 'block', 
                  marginBottom: '2px', 
                  color: '#0A1929', 
                  fontSize: '0.875rem',
                  fontWeight: '500'
                }}>
                  Skills Required (comma-separated)
                </label>
                <input
                  type="text"
                  value={newPost.skills.join(', ')}
                  onChange={(e) => setNewPost({ 
                    ...newPost, 
                    skills: e.target.value.split(',').map(skill => skill.trim()).filter(Boolean)
                  })}
                  placeholder="e.g. JavaScript, React, Node.js"
                  style={{
                    width: '100%',
                    padding: '6px 12px',
                    border: '1px solid #dfe1e5',
                    borderRadius: '8px',
                    fontSize: '14px',
                    transition: 'border-color 0.2s ease',
                    outline: 'none'
                  }}
                  onFocus={(e) => e.target.style.borderColor = '#0A1929'}
                  onBlur={(e) => e.target.style.borderColor = '#dfe1e5'}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                <div>
                  <label style={{ 
                    display: 'block', 
                    marginBottom: '2px', 
                    color: '#0A1929', 
                    fontSize: '0.875rem',
                    fontWeight: '500'
                  }}>
                    Duration
                  </label>
                  <input
                    type="text"
                    value={newPost.duration}
                    onChange={(e) => setNewPost({ ...newPost, duration: e.target.value })}
                    required
                    placeholder="e.g. 3 months"
                    style={{
                      width: '100%',
                      padding: '6px 10px',
                      border: '1px solid #dfe1e5',
                      borderRadius: '6px',
                      fontSize: '13px',
                      transition: 'border-color 0.2s ease',
                      outline: 'none'
                    }}
                    onFocus={(e) => e.target.style.borderColor = '#0A1929'}
                    onBlur={(e) => e.target.style.borderColor = '#dfe1e5'}
                  />
                </div>

                <div>
                  <label style={{ 
                    display: 'block', 
                    marginBottom: '2px', 
                    color: '#0A1929', 
                    fontSize: '0.875rem',
                    fontWeight: '500'
                  }}>
                    Type
                  </label>
                  <select
                    value={newPost.type}
                    onChange={(e) => setNewPost({ ...newPost, type: e.target.value })}
                    required
                    style={{
                      width: '100%',
                      padding: '6px 10px',
                      border: '1px solid #dfe1e5',
                      borderRadius: '6px',
                      fontSize: '13px',
                      backgroundColor: 'white',
                      transition: 'border-color 0.2s ease',
                      outline: 'none',
                      cursor: 'pointer',
                      appearance: 'none',
                      backgroundImage: `url("data:image/svg+xml,%3Csvg width='10' height='6' viewBox='0 0 10 6' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1 1L5 5L9 1' stroke='%23666666' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")`,
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 10px center'
                    }}
                    onFocus={(e) => e.target.style.borderColor = '#0A1929'}
                    onBlur={(e) => e.target.style.borderColor = '#dfe1e5'}
                  >
                    <option value="Full-time">Full-time</option>
                    <option value="Part-time">Part-time</option>
                  </select>
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                <div>
                  <label style={{ 
                    display: 'block', 
                    marginBottom: '2px', 
                    color: '#0A1929', 
                    fontSize: '0.875rem',
                    fontWeight: '500'
                  }}>
                    Location
                  </label>
                  <input
                    type="text"
                    value={newPost.location}
                    onChange={(e) => setNewPost({ ...newPost, location: e.target.value })}
                    required
                    placeholder="e.g. Cairo, Egypt"
                    style={{
                      width: '100%',
                      padding: '6px 10px',
                      border: '1px solid #dfe1e5',
                      borderRadius: '6px',
                      fontSize: '13px',
                      transition: 'border-color 0.2s ease',
                      outline: 'none'
                    }}
                    onFocus={(e) => e.target.style.borderColor = '#0A1929'}
                    onBlur={(e) => e.target.style.borderColor = '#dfe1e5'}
                  />
                </div>

                <div>
                  <label style={{ 
                    display: 'block', 
                    marginBottom: '2px', 
                    color: '#0A1929', 
                    fontSize: '0.875rem',
                    fontWeight: '500'
                  }}>
                    Compensation
                  </label>
                  <select
                    value={newPost.isPaid ? 'paid' : 'unpaid'}
                    onChange={(e) => {
                      const isPaid = e.target.value === 'paid';
                      setNewPost({ 
                        ...newPost, 
                        isPaid,
                        expectedSalary: isPaid ? newPost.expectedSalary : null
                      });
                    }}
                    style={{
                      width: '100%',
                      padding: '6px 10px',
                      border: '1px solid #dfe1e5',
                      borderRadius: '6px',
                      fontSize: '13px',
                      backgroundColor: 'white',
                      transition: 'border-color 0.2s ease',
                      outline: 'none',
                      cursor: 'pointer',
                      appearance: 'none',
                      backgroundImage: `url("data:image/svg+xml,%3Csvg width='10' height='6' viewBox='0 0 10 6' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1 1L5 5L9 1' stroke='%23666666' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")`,
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'right 10px center'
                    }}
                    onFocus={(e) => e.target.style.borderColor = '#0A1929'}
                    onBlur={(e) => e.target.style.borderColor = '#dfe1e5'}
                  >
                    <option value="paid">Paid</option>
                    <option value="unpaid">Unpaid</option>
                  </select>
                </div>
              </div>

              {newPost.isPaid && (
                <div>
                  <label style={{ 
                    display: 'block', 
                    marginBottom: '2px', 
                    color: '#0A1929', 
                    fontSize: '0.875rem',
                    fontWeight: '500'
                  }}>
                    Expected Salary
                  </label>
                  <input
                    type="text"
                    value={newPost.expectedSalary || ''}
                    onChange={(e) => setNewPost({ ...newPost, expectedSalary: e.target.value })}
                    placeholder="e.g. 5000 EGP/month"
                    style={{
                      width: '100%',
                      padding: '6px 12px',
                      border: '1px solid #dfe1e5',
                      borderRadius: '8px',
                      fontSize: '14px',
                      transition: 'border-color 0.2s ease',
                      outline: 'none'
                    }}
                    onFocus={(e) => e.target.style.borderColor = '#0A1929'}
                    onBlur={(e) => e.target.style.borderColor = '#dfe1e5'}
                  />
                </div>
              )}
            </div>

            <div style={{ 
              display: 'flex', 
              gap: '8px', 
              marginTop: '4px',
              borderTop: '1px solid #eee',
              paddingTop: '8px'
            }}>
              <button
                type="submit"
                style={{
                  flex: 1,
                  padding: '8px 16px',
                  backgroundColor: '#0A1929',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: '500',
                  transition: 'background-color 0.2s ease'
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#1a2a3a'}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#0A1929'}
              >
                Create Post
              </button>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                style={{
                  flex: 1,
                  padding: '8px 16px',
                  backgroundColor: 'white',
                  color: '#0A1929',
                  border: '1px solid #0A1929',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: '500',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#f5f5f5';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'white';
                }}
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
} 