import React, { useState } from 'react';
import FacultyHeader from '../components/FacultyHeader';
import VisibilityIcon from '@mui/icons-material/Visibility';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import IconButton from '@mui/material/IconButton';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import FlagIcon from '@mui/icons-material/Flag';
import FilterListIcon from '@mui/icons-material/FilterList';
import Select from '@mui/material/Select';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';

export default function ReportList({ canEditStatus, canCommentOnRejection }) {
  const [reports, setReports] = useState([
    {
      id: 1,
      studentName: 'John Doe',
      studentId: '43-0123',
      companyName: 'Tech Corp',
      submissionDate: '2024-03-15',
      status: 'pending',
      content: 'Completed the first week of internship. Worked on frontend development using React.',
      department: 'Software Engineering',
      weekNumber: 1
    },
    {
      id: 2,
      studentName: 'Sarah Ahmed',
      studentId: '43-0456',
      companyName: 'Global Solutions',
      submissionDate: '2024-03-14',
      status: 'approved',
      content: 'Participated in system architecture design and database optimization tasks.',
      department: 'Computer Science',
      weekNumber: 2
    },
    {
      id: 3,
      studentName: 'Mohamed Hassan',
      studentId: '43-0789',
      companyName: 'Innovation Labs',
      submissionDate: '2024-03-13',
      status: 'rejected',
      content: 'Worked on mobile app development and API integration.',
      department: 'Software Engineering',
      weekNumber: 1,
      rejectionReason: 'Report needs more technical details'
    },
    {
      id: 4,
      studentName: 'Nour Ibrahim',
      studentId: '43-1011',
      companyName: 'Digital Dynamics',
      submissionDate: '2024-03-15',
      status: 'pending',
      content: 'Assisted in QA testing and documentation of new features.',
      department: 'Computer Science',
      weekNumber: 3
    },
    {
      id: 5,
      studentName: 'Yara Mahmoud',
      studentId: '43-1213',
      companyName: 'Tech Corp',
      submissionDate: '2024-03-12',
      status: 'approved',
      content: 'Implemented new security features and conducted code reviews.',
      department: 'Software Engineering',
      weekNumber: 2
    },
    {
      id: 6,
      studentName: 'Ahmed Kamal',
      studentId: '43-1415',
      companyName: 'Innovation Labs',
      submissionDate: '2024-03-11',
      status: 'pending',
      content: 'Developed microservices and worked on cloud deployment.',
      department: 'Computer Science',
      weekNumber: 1
    }
  ]);

  const [showCommentModal, setShowCommentModal] = useState(false);
  const [selectedReport, setSelectedReport] = useState(null);
  const [comment, setComment] = useState('');
  const [showNotification, setShowNotification] = useState(false);
  const [statusMenuAnchorEl, setStatusMenuAnchorEl] = useState(null);
  const [activeReportId, setActiveReportId] = useState(null);
  const [pendingStatus, setPendingStatus] = useState(null);

  // Add filter states
  const [majorFilter, setMajorFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  // Get unique majors from reports
  const majors = [...new Set(reports.map(report => report.department))];
  
  // Get unique statuses from reports
  const statuses = [...new Set(reports.map(report => report.status))];

  // Filter reports based on selected filters
  const filteredReports = reports.filter(report => {
    const matchesMajor = majorFilter === 'all' || report.department === majorFilter;
    const matchesStatus = statusFilter === 'all' || report.status === statusFilter;
    return matchesMajor && matchesStatus;
  });

  const handleStatusMenuOpen = (event, reportId) => {
    event.stopPropagation();
    setStatusMenuAnchorEl(event.currentTarget);
    setActiveReportId(reportId);
  };

  const handleStatusMenuClose = () => {
    setStatusMenuAnchorEl(null);
    setActiveReportId(null);
  };

  const handleStatusChange = (reportId, newStatus) => {
    if ((newStatus === 'rejected' || newStatus === 'flagged') && canCommentOnRejection) {
      const report = reports.find(r => r.id === reportId);
      setPendingStatus(newStatus);
      handleCommentClick(report);
      handleStatusMenuClose();
      return;
    }

    setReports(reports.map(report => 
      report.id === reportId ? { ...report, status: newStatus } : report
    ));
    
    // Show notification
    setShowNotification(true);
    setTimeout(() => {
      setShowNotification(false);
    }, 3000);

    handleStatusMenuClose();
  };

  const handleDownloadReport = (report) => {
    const link = document.createElement('a');
    link.href = report.reportUrl;
    link.target = '_blank';
    link.download = `Report_${report.studentName}_Week${report.weekNumber}.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCommentClick = (report) => {
    setSelectedReport(report);
    setComment(report.rejectionReason || report.flagReason || '');
    setShowCommentModal(true);
  };

  const handleCommentSubmit = () => {
    if (selectedReport) {
      setReports(reports.map(report =>
        report.id === selectedReport.id
          ? { 
              ...report, 
              status: pendingStatus || 'rejected',
              ...(pendingStatus === 'flagged' 
                ? { flagReason: comment }
                : { rejectionReason: comment })
            }
          : report
      ));
      setShowCommentModal(false);
      setSelectedReport(null);
      setComment('');
      setPendingStatus(null);
      
      // Show notification
      setShowNotification(true);
      setTimeout(() => {
        setShowNotification(false);
      }, 3000);
    }
  };

  const getStatusStyle = (status) => {
    const baseStyle = {
      padding: '4px 8px',
      borderRadius: '12px',
      fontSize: '0.875rem',
      fontWeight: '500',
      textAlign: 'center',
      width: 'fit-content',
      display: 'flex',
      alignItems: 'center',
      gap: '4px'
    };

    switch (status) {
      case 'approved':
        return { ...baseStyle, backgroundColor: '#e6f4ea', color: '#1e4620' };
      case 'rejected':
        return { ...baseStyle, backgroundColor: '#fce8e6', color: '#c5221f' };
      case 'pending':
        return { ...baseStyle, backgroundColor: '#fff3e0', color: '#e65100' };
      case 'flagged':
        return { ...baseStyle, backgroundColor: '#fff8e6', color: '#997404' };
      default:
        return baseStyle;
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'approved':
        return <CheckCircleIcon sx={{ fontSize: 16 }} />;
      case 'rejected':
        return <CancelIcon sx={{ fontSize: 16 }} />;
      case 'flagged':
        return <FlagIcon sx={{ fontSize: 16 }} />;
      default:
        return null;
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <FacultyHeader 
        title="Internship Reports"
        subtitle="Review and manage student internship reports and their status."
      />

      {/* Filters Section */}
      <div style={{ 
        backgroundColor: 'white',
        padding: '16px',
        borderRadius: '8px',
        marginBottom: '16px',
        boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
        display: 'flex',
        gap: '16px',
        alignItems: 'center'
      }}>
        <div style={{ 
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          color: '#666'
        }}>
          <FilterListIcon sx={{ fontSize: 20 }} />
          <span style={{ fontSize: '14px', fontWeight: 500 }}>Filters:</span>
        </div>

        <FormControl size="small" sx={{ minWidth: 200 }}>
          <InputLabel>Department</InputLabel>
          <Select
            value={majorFilter}
            onChange={(e) => setMajorFilter(e.target.value)}
            label="Department"
          >
            <MenuItem value="all">All Departments</MenuItem>
            {majors.map(major => (
              <MenuItem key={major} value={major}>{major}</MenuItem>
            ))}
          </Select>
        </FormControl>

        <FormControl size="small" sx={{ minWidth: 200 }}>
          <InputLabel>Status</InputLabel>
          <Select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            label="Status"
          >
            <MenuItem value="all">All Statuses</MenuItem>
            {statuses.map(status => (
              <MenuItem key={status} value={status} sx={{
                color: status === 'approved' ? '#1e4620' :
                       status === 'rejected' ? '#c5221f' :
                       status === 'flagged' ? '#997404' :
                       status === 'pending' ? '#e65100' : 'inherit',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}>
                {getStatusIcon(status)}
                {status.charAt(0).toUpperCase() + status.slice(1)}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        {(majorFilter !== 'all' || statusFilter !== 'all') && (
          <button
            onClick={() => {
              setMajorFilter('all');
              setStatusFilter('all');
            }}
            style={{
              padding: '6px 12px',
              backgroundColor: '#f8f9fa',
              border: '1px solid #dfe1e5',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '13px',
              color: '#666',
              display: 'flex',
              alignItems: 'center',
              gap: '4px'
            }}
          >
            Clear Filters
          </button>
        )}
      </div>

      <div style={{ 
        backgroundColor: 'white',
        borderRadius: '8px',
        boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
        overflow: 'hidden'
      }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '14px' }}>
          <thead>
            <tr style={{ backgroundColor: '#f8f9fa' }}>
              <th style={thStyle}>Student</th>
              <th style={thStyle}>ID</th>
              <th style={thStyle}>Department</th>
              <th style={thStyle}>Company</th>
              <th style={thStyle}>Week</th>
              <th style={thStyle}>Date</th>
              <th style={thStyle}>Status</th>
              <th style={thStyle}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredReports.map(report => (
              <tr key={report.id} 
                style={{ 
                  borderBottom: '1px solid #dee2e6',
                  backgroundColor: 'white',
                  transition: 'background-color 0.2s'
                }}
              >
                <td style={tdStyle}>{report.studentName}</td>
                <td style={tdStyle}>{report.studentId}</td>
                <td style={tdStyle}>{report.department}</td>
                <td style={tdStyle}>{report.companyName}</td>
                <td style={tdStyle}>Week {report.weekNumber}</td>
                <td style={tdStyle}>{report.submissionDate}</td>
                <td style={tdStyle}>
                  <div style={getStatusStyle(report.status)}>
                    {getStatusIcon(report.status)}
                    {report.status.charAt(0).toUpperCase() + report.status.slice(1)}
                  </div>
                </td>
                <td style={{...tdStyle, width: '120px'}}>
                  <div style={{ 
                    display: 'flex', 
                    gap: '8px', 
                    position: 'relative',
                    justifyContent: 'flex-start'
                  }}>
                    <button
                      onClick={() => setSelectedReport(report)}
                      style={{
                        padding: '6px 12px',
                        border: 'none',
                        borderRadius: '4px',
                        backgroundColor: '#0A1929',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px',
                        color: 'white',
                        fontSize: '13px',
                        minWidth: '80px',
                        justifyContent: 'center',
                        transition: 'background-color 0.2s'
                      }}
                      title="View Details"
                      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#1a2a3a'}
                      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#0A1929'}
                    >
                      <VisibilityIcon sx={{ fontSize: 16 }} /> View
                    </button>
                    {canEditStatus && report.status === 'pending' && (
                      <IconButton
                        size="small"
                        onClick={(e) => handleStatusMenuOpen(e, report.id)}
                        sx={{ 
                          padding: '4px',
                          backgroundColor: '#f8f9fa',
                          '&:hover': { backgroundColor: '#e9ecef' }
                        }}
                      >
                        <MoreVertIcon fontSize="small" />
                      </IconButton>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Status Change Menu */}
      <Menu
        anchorEl={statusMenuAnchorEl}
        open={Boolean(statusMenuAnchorEl)}
        onClose={handleStatusMenuClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
      >
        <MenuItem 
          onClick={() => handleStatusChange(activeReportId, 'approved')}
          sx={{ 
            color: '#1e4620',
            gap: 1,
            '&:hover': { backgroundColor: '#e6f4ea' }
          }}
        >
          <CheckCircleIcon fontSize="small" />
          Approve
        </MenuItem>
        <MenuItem 
          onClick={() => handleStatusChange(activeReportId, 'rejected')}
          sx={{ 
            color: '#c5221f',
            gap: 1,
            '&:hover': { backgroundColor: '#fce8e6' }
          }}
        >
          <CancelIcon fontSize="small" />
          Reject
        </MenuItem>
        <MenuItem 
          onClick={() => handleStatusChange(activeReportId, 'flagged')}
          sx={{ 
            color: '#997404',
            gap: 1,
            '&:hover': { backgroundColor: '#fff8e6' }
          }}
        >
          <FlagIcon fontSize="small" />
          Flag
        </MenuItem>
      </Menu>

      {/* Success Notification */}
      {showNotification && (
        <div style={{
          position: 'fixed',
          bottom: '24px',
          left: '50%',
          transform: 'translateX(-50%)',
          backgroundColor: '#d1ecf1',
          color: '#0c5460',
          padding: '12px 24px',
          borderRadius: '8px',
          fontSize: '14px',
          boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
          zIndex: 1000,
          animation: 'slideUp 0.3s ease'
        }}>
          Status updated successfully
        </div>
      )}

      {/* View Report Modal */}
      {selectedReport && (
        <div style={{
          position: 'fixed',
          top: '64px',
          left: '240px',
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{
            backgroundColor: 'white',
            padding: '24px',
            borderRadius: '8px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
            width: '450px',
            maxHeight: '50%',
            overflow: 'auto',
            transform: 'translateY(-32px)'
          }} onClick={e => e.stopPropagation()}>
            <div style={{ marginBottom: '24px' }}>
              <h3 style={{ margin: '0 0 4px 0', color: '#0A1929' }}>Report Details</h3>
              <div style={{ height: '2px', width: '40px', backgroundColor: '#0A1929' }} />
            </div>

            <div style={{ display: 'grid', gap: '16px' }}>
              <div>
                <label style={{ color: '#666', fontSize: '0.875rem' }}>Student</label>
                <div style={{ fontSize: '1rem', marginTop: '4px' }}>{selectedReport.studentName}</div>
              </div>
              <div>
                <label style={{ color: '#666', fontSize: '0.875rem' }}>Student ID</label>
                <div style={{ fontSize: '1rem', marginTop: '4px' }}>{selectedReport.studentId}</div>
              </div>
              <div>
                <label style={{ color: '#666', fontSize: '0.875rem' }}>Department</label>
                <div style={{ fontSize: '1rem', marginTop: '4px' }}>{selectedReport.department}</div>
              </div>
              <div>
                <label style={{ color: '#666', fontSize: '0.875rem' }}>Company</label>
                <div style={{ fontSize: '1rem', marginTop: '4px' }}>{selectedReport.companyName}</div>
              </div>
              <div>
                <label style={{ color: '#666', fontSize: '0.875rem' }}>Week Number</label>
                <div style={{ fontSize: '1rem', marginTop: '4px' }}>Week {selectedReport.weekNumber}</div>
              </div>
              <div>
                <label style={{ color: '#666', fontSize: '0.875rem' }}>Submission Date</label>
                <div style={{ fontSize: '1rem', marginTop: '4px' }}>{selectedReport.submissionDate}</div>
              </div>
              <div>
                <label style={{ color: '#666', fontSize: '0.875rem' }}>Status</label>
                <div style={{ fontSize: '1rem', marginTop: '4px' }}>
                  <div style={getStatusStyle(selectedReport.status)}>{selectedReport.status.charAt(0).toUpperCase() + selectedReport.status.slice(1)}</div>
                </div>
              </div>
              <div>
                <label style={{ color: '#666', fontSize: '0.875rem' }}>Content</label>
                <div style={{ fontSize: '1rem', marginTop: '4px', lineHeight: '1.5' }}>{selectedReport.content}</div>
              </div>
              {selectedReport.rejectionReason && (
                <div>
                  <label style={{ color: '#666', fontSize: '0.875rem' }}>Rejection Reason</label>
                  <div style={{ fontSize: '1rem', marginTop: '4px', color: '#c5221f' }}>{selectedReport.rejectionReason}</div>
                </div>
              )}
              {selectedReport.flagReason && (
                <div>
                  <label style={{ color: '#666', fontSize: '0.875rem' }}>Flag Reason</label>
                  <div style={{ fontSize: '1rem', marginTop: '4px', color: '#997404' }}>{selectedReport.flagReason}</div>
                </div>
              )}
            </div>

            <div style={{ 
              display: 'flex', 
              justifyContent: 'flex-end',
              gap: '12px',
              marginTop: '24px',
              paddingTop: '16px',
              borderTop: '1px solid #eee'
            }}>
              <button
                onClick={() => handleDownloadReport(selectedReport)}
                style={{
                  padding: '8px 16px',
                  backgroundColor: '#0A1929',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '14px',
                  transition: 'background-color 0.2s'
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#1a2a3a'}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#0A1929'}
              >
                Download PDF
              </button>
              <button
                onClick={() => setSelectedReport(null)}
                style={{
                  padding: '8px 16px',
                  backgroundColor: '#f8f9fa',
                  color: '#666',
                  border: '1px solid #dfe1e5',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '14px',
                  transition: 'all 0.2s'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#eee';
                  e.currentTarget.style.borderColor = '#ccc';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = '#f8f9fa';
                  e.currentTarget.style.borderColor = '#dfe1e5';
                }}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Comment Modal */}
      {showCommentModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{
            backgroundColor: 'white',
            padding: '24px',
            borderRadius: '8px',
            width: '400px',
            maxWidth: '90%',
            transform: 'translateY(-32px)'
          }}>
            <div style={{ marginBottom: '24px' }}>
              <h3 style={{ margin: '0 0 4px 0', color: '#0A1929' }}>
                {pendingStatus === 'flagged' ? 'Add Flag Comment' : 'Add Rejection Comment'}
              </h3>
              <div style={{ height: '2px', width: '40px', backgroundColor: '#0A1929' }} />
            </div>
            
            <div style={{ marginBottom: '16px' }}>
              <div style={{ fontSize: '14px', color: '#666' }}>
                Student: {selectedReport?.studentName}<br />
                Report Week: {selectedReport?.weekNumber}
              </div>
            </div>

            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              style={{
                width: '100%',
                minHeight: '100px',
                padding: '12px',
                marginBottom: '20px',
                borderRadius: '4px',
                border: '1px solid #ddd',
                resize: 'vertical',
                fontSize: '14px',
                lineHeight: '1.5'
              }}
              placeholder="Enter your comment here..."
            />

            <div style={{ 
              display: 'flex', 
              justifyContent: 'flex-end',
              gap: '12px',
              borderTop: '1px solid #eee',
              paddingTop: '16px'
            }}>
              <button
                onClick={() => setShowCommentModal(false)}
                style={{
                  padding: '8px 16px',
                  backgroundColor: '#f8f9fa',
                  color: '#666',
                  border: '1px solid #dfe1e5',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '14px'
                }}
              >
                Cancel
              </button>
              <button
                onClick={handleCommentSubmit}
                style={{
                  padding: '8px 16px',
                  backgroundColor: '#0A1929',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '14px'
                }}
              >
                Save Comment
              </button>
            </div>
          </div>
        </div>
      )}

      <style>
        {`
          @keyframes slideUp {
            from { transform: translate(-50%, 100%); opacity: 0; }
            to { transform: translate(-50%, 0); opacity: 1; }
          }
        `}
      </style>
    </div>
  );
}

const thStyle = {
  padding: '12px 16px',
  textAlign: 'left',
  borderBottom: '1px solid #eee',
  color: '#666',
  fontWeight: '600'
};

const tdStyle = {
  padding: '12px 16px',
  fontSize: '14px',
  color: '#202124'
};