import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import ReportList from './ReportList';
import EvaluationReportList from './EvaluationReportList';
import StatisticsPanel from './StatisticsPanel';
import {
  AppBar,
  Box,
  Drawer,
  IconButton,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Typography,
  Menu,
  MenuItem,
  Avatar,
  Badge,
  Divider,
  ListSubheader,
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import NotificationsIcon from '@mui/icons-material/Notifications';
import PersonIcon from '@mui/icons-material/Person';
import LogoutIcon from '@mui/icons-material/Logout';
import EmailIcon from '@mui/icons-material/Email';
import AssessmentIcon from '@mui/icons-material/Assessment';
import DescriptionIcon from '@mui/icons-material/Description';
import BarChartIcon from '@mui/icons-material/BarChart';

const drawerWidth = 240;
const navyBlue = '#0A1929';
const lightNavyBlue = '#1A2B3C';

export default function FacultyDashboard() {
  const [activeView, setActiveView] = useState('internship');
  const [isDrawerOpen, setIsDrawerOpen] = useState(true);
  const [profileAnchorEl, setProfileAnchorEl] = useState(null);
  const [notificationAnchorEl, setNotificationAnchorEl] = useState(null);
  const navigate = useNavigate();

  const [notifications, setNotifications] = useState([
    {
      id: 1,
      title: 'New Report Submission',
      message: 'A new internship report has been submitted for review.',
      type: 'report',
      icon: <DescriptionIcon sx={{ color: '#4caf50' }} />,
      timestamp: 'Just now',
      read: false
    },
    {
      id: 2,
      title: 'Evaluation Required',
      message: 'Pending evaluation for student internship reports.',
      type: 'evaluation',
      icon: <AssessmentIcon sx={{ color: '#ff9800' }} />,
      timestamp: '30 minutes ago',
      read: false
    }
  ]);

  useEffect(() => {
    const savedDrawerState = localStorage.getItem('facultyDrawerOpen');
    if (savedDrawerState !== null) {
      setIsDrawerOpen(savedDrawerState === 'true');
    }
  }, []);

  const menuItems = [
    {
      type: 'section',
      title: 'Reports Management',
      items: [
        { 
          text: 'Internship Reports', 
          icon: <DescriptionIcon />, 
          onClick: () => setActiveView('internship')
        },
        { 
          text: 'Evaluation Reports', 
          icon: <AssessmentIcon />, 
          onClick: () => setActiveView('evaluation')
        },
        { 
          text: 'Statistics', 
          icon: <BarChartIcon />, 
          onClick: () => setActiveView('statistics')
        }
      ]
    }
  ];

  const handleDrawerToggle = () => {
    const newState = !isDrawerOpen;
    setIsDrawerOpen(newState);
    localStorage.setItem('facultyDrawerOpen', newState.toString());
  };

  const handleProfileMenuOpen = (event) => {
    setProfileAnchorEl(event.currentTarget);
  };

  const handleProfileMenuClose = () => {
    setProfileAnchorEl(null);
  };

  const handleNotificationMenuOpen = (event) => {
    setNotificationAnchorEl(event.currentTarget);
  };

  const handleNotificationMenuClose = () => {
    setNotificationAnchorEl(null);
  };

  const handleLogout = () => {
    handleProfileMenuClose();
    navigate('/');
  };

  const unreadNotificationCount = notifications.filter(n => !n.read).length;

  return (
    <Box sx={{ display: 'flex' }}>
      {/* Sidebar */}
      <Drawer
        variant="permanent"
        sx={{
          width: isDrawerOpen ? drawerWidth : 70,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: isDrawerOpen ? drawerWidth : 70,
            boxSizing: 'border-box',
            backgroundColor: navyBlue,
            color: 'white',
            transition: 'width 0.3s',
            overflowX: 'hidden',
          },
        }}
      >
        <Toolbar sx={{ 
          bgcolor: lightNavyBlue, 
          display: 'flex', 
          justifyContent: 'center',
          alignItems: 'center',
          minHeight: '64px !important',
          borderBottom: '1px solid rgba(255, 255, 255, 0.12)'
        }}>
          <Box sx={{ 
            display: 'flex', 
            flexDirection: 'column', 
            alignItems: 'center',
            opacity: isDrawerOpen ? 1 : 0,
            transition: 'opacity 0.3s'
          }}>
            <Typography variant="h6" sx={{ 
              fontWeight: 'bold',
              letterSpacing: '0.5px',
              fontSize: '1.2rem',
              color: '#fff'
            }}>
              GUC SYSTEM
            </Typography>
            <Typography variant="subtitle2" sx={{ 
              color: 'rgba(255, 255, 255, 0.7)',
              fontSize: '0.75rem',
              marginTop: '4px'
            }}>
              Faculty Portal
            </Typography>
          </Box>
        </Toolbar>

        <List>
          {menuItems.map((section, sectionIndex) => (
            <React.Fragment key={section.title || sectionIndex}>
              {section.title && isDrawerOpen && (
                <ListSubheader
                  sx={{
                    bgcolor: 'transparent',
                    color: 'rgba(255, 255, 255, 0.7)',
                    lineHeight: '30px',
                    mt: sectionIndex === 0 ? 0 : 2,
                  }}
                >
                  {section.title}
                </ListSubheader>
              )}
              {section.items.map((item) => (
                <ListItem
                  button
                  key={item.text}
                  onClick={item.onClick}
                  sx={{
                    '&:hover': {
                      bgcolor: lightNavyBlue,
                    },
                    px: isDrawerOpen ? 2 : 1.5,
                    justifyContent: isDrawerOpen ? 'initial' : 'center',
                    minHeight: 48,
                  }}
                >
                  <ListItemIcon 
                    sx={{ 
          color: 'white',
                      minWidth: isDrawerOpen ? 40 : 'auto',
                      mr: isDrawerOpen ? 2 : 'auto',
                    }}
                  >
                    {item.icon}
                  </ListItemIcon>
                  {isDrawerOpen && <ListItemText primary={item.text} />}
                </ListItem>
              ))}
            </React.Fragment>
          ))}
        </List>
      </Drawer>

      {/* Main content */}
      <Box component="main" sx={{ flexGrow: 1 }}>
        <AppBar
          position="fixed"
          sx={{
            backgroundColor: navyBlue,
            width: { sm: `calc(100% - ${isDrawerOpen ? drawerWidth : 70}px)` },
            ml: { sm: `${isDrawerOpen ? drawerWidth : 70}px` },
            transition: 'width 0.3s, margin-left 0.3s',
          }}
        >
          <Toolbar>
            <IconButton
              color="inherit"
              onClick={handleDrawerToggle}
              edge="start"
              sx={{ mr: 2 }}
            >
              <MenuIcon />
            </IconButton>
            <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
              Faculty Portal
            </Typography>

            <Box sx={{ 
          display: 'flex',
              alignItems: 'center', 
              ml: 'auto',
              gap: 2
            }}>
              {/* Notifications */}
              <IconButton
                color="inherit"
                onClick={handleNotificationMenuOpen}
                sx={{ 
                  p: 1,
                  '&:hover': { backgroundColor: 'rgba(255, 255, 255, 0.1)' }
                }}
              >
                <Badge badgeContent={unreadNotificationCount} color="error">
                  <NotificationsIcon />
                </Badge>
              </IconButton>

              {/* Profile */}
              <IconButton
                color="inherit"
                onClick={handleProfileMenuOpen}
                sx={{ 
                  p: 1,
                  '&:hover': { backgroundColor: 'rgba(255, 255, 255, 0.1)' }
                }}
              >
                <Avatar sx={{ width: 32, height: 32 }} />
              </IconButton>
            </Box>

            {/* Profile Menu */}
            <Menu
              anchorEl={profileAnchorEl}
              open={Boolean(profileAnchorEl)}
              onClose={handleProfileMenuClose}
              PaperProps={{
                elevation: 0,
                sx: {
                  overflow: 'visible',
                  filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
                  mt: 1.5,
                  bgcolor: 'background.paper',
                  color: 'text.primary',
                  borderRadius: 3,
                  minWidth: 340,
                  p: 0,
                },
              }}
              transformOrigin={{ horizontal: 'right', vertical: 'top' }}
              anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
            >
              <Box sx={{ bgcolor: navyBlue, color: 'white', px: 3, py: 2, borderTopLeftRadius: 12, borderTopRightRadius: 12 }}>
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  Profile Options
                </Typography>
              </Box>
              <Divider />
              <MenuItem sx={{ py: 2, px: 3, cursor: 'default', '&:hover': { background: 'none' } }}>
                <ListItemIcon>
                  <EmailIcon fontSize="medium" sx={{ color: '#1976d2' }} />
                </ListItemIcon>
                <Typography sx={{ 
                  fontWeight: 500, 
                  fontSize: '0.95rem',
                  color: 'text.secondary',
                  wordBreak: 'break-all'
                }}>
                  faculty@guc.edu.eg
                </Typography>
              </MenuItem>
              <Divider />
              <MenuItem 
                onClick={handleLogout}
                sx={{ py: 2, px: 3 }}
              >
                <ListItemIcon>
                  <LogoutIcon fontSize="medium" sx={{ color: '#d32f2f' }} />
                </ListItemIcon>
                <Typography sx={{ fontWeight: 500, fontSize: '1.1rem', color: '#d32f2f' }}>Logout</Typography>
              </MenuItem>
            </Menu>

            {/* Notifications Menu */}
            <Menu
              anchorEl={notificationAnchorEl}
              open={Boolean(notificationAnchorEl)}
              onClose={handleNotificationMenuClose}
              PaperProps={{
                sx: {
                  width: 320,
                  maxHeight: 440,
                  overflow: 'auto',
                  backgroundColor: 'white',
                  boxShadow: '0px 5px 15px rgba(0, 0, 0, 0.2)',
                  borderRadius: '8px',
                  mt: 1,
                  '& .MuiDivider-root': {
                    borderColor: 'rgba(0, 0, 0, 0.12)'
                  }
                }
              }}
              transformOrigin={{ horizontal: 'right', vertical: 'top' }}
              anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
            >
              <Box sx={{
                p: 2,
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                background: navyBlue,
                color: 'white',
                borderTopLeftRadius: '8px',
                borderTopRightRadius: '8px'
              }}>
                <Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: 'white' }}>
                  Notifications
                </Typography>
              </Box>
              <Divider />
              {notifications.length === 0 ? (
                <Box sx={{ p: 2, textAlign: 'center', color: 'text.secondary' }}>
                  <Typography variant="body2">No notifications</Typography>
                </Box>
              ) : (
                notifications.map((notification) => (
                  <MenuItem
                    key={notification.id}
                    sx={{
                      py: 1.5,
                      px: 2,
                      borderBottom: '1px solid rgba(0, 0, 0, 0.08)',
                      backgroundColor: notification.read ? 'transparent' : 'rgba(25, 118, 210, 0.08)',
                      whiteSpace: 'normal',
                      minHeight: 'auto'
                    }}
                  >
                    <Box sx={{ 
                      display: 'flex', 
                      flexDirection: 'column',
                width: '100%',
                      gap: 0.5
                    }}>
                      <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                        {notification.title}
                      </Typography>
                      <Typography 
                        variant="body2" 
                        sx={{ 
                          flex: 1,
                          wordBreak: 'break-word'
                        }}
                      >
                        {notification.message}
                      </Typography>
                      <Typography 
                        variant="caption" 
                        color="text.secondary"
                        sx={{
                          display: 'block',
                          textAlign: 'right'
                        }}
                      >
                        {notification.timestamp}
                      </Typography>
                    </Box>
                  </MenuItem>
                ))
              )}
            </Menu>
          </Toolbar>
        </AppBar>
        <Toolbar />
        
        {/* Page Content */}
        <Box sx={{ p: 3, backgroundColor: '#f5f5f5', minHeight: 'calc(100vh - 64px)' }}>
          {activeView === 'internship' && <ReportList canEditStatus={true} canCommentOnRejection={true} />}
          {activeView === 'evaluation' && <EvaluationReportList />}
          {activeView === 'statistics' && <StatisticsPanel />}
        </Box>
      </Box>
    </Box>
  );
}
