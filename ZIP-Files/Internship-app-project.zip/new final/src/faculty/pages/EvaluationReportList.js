import React, { useState } from 'react';
import jsPDF from 'jspdf';
import FacultyHeader from '../components/FacultyHeader';

const mockEvaluations = [
  {
    id: 1,
    student: 'Ali Ahmed',
    studentId: '58-4367',
    company: 'AgroTech Ltd.',
    supervisor: 'Eng. Amr Khaled',
    startDate: '2025-06-01',
    endDate: '2025-08-30'
  },
  {
    id: 2,
    student: 'Sara Hassan',
    studentId: '59-4412',
    company: 'GreenFuture Inc.',
    supervisor: 'Dr. Laila Mansour',
    startDate: '2025-07-01',
    endDate: '2025-09-15'
  },
];

export default function EvaluationReportList() {
  const [selectedEvaluation, setSelectedEvaluation] = useState(null);

  const downloadPdf = (evaluation) => {
    const doc = new jsPDF();
    doc.text('Internship Evaluation Report', 10, 10);
    doc.text(`Student: ${evaluation.student}`, 10, 20);
    doc.text(`Student ID: ${evaluation.studentId}`, 10, 30);
    doc.text(`Company: ${evaluation.company}`, 10, 40);
    doc.text(`Supervisor: ${evaluation.supervisor}`, 10, 50);
    doc.text(`Internship Dates: ${evaluation.startDate} - ${evaluation.endDate}`, 10, 60);
    doc.save(`${evaluation.student}-EvaluationReport.pdf`);
  };

  const Modal = ({ evaluation, onClose }) => {
    if (!evaluation) return null;

    return (
      <div style={{
        position: 'fixed',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        backgroundColor: 'white',
        borderRadius: '8px',
        boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
        width: '90%',
        maxWidth: '500px',
        zIndex: 1000
      }}>
        {/* Header */}
        <div style={{
          backgroundColor: '#0A1929',
          padding: '8px 12px',
          borderTopLeftRadius: '8px',
          borderTopRightRadius: '8px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <h3 style={{
            color: 'white',
            margin: 0,
            fontSize: '15px',
            fontWeight: '500'
          }}>
            Evaluation Report Details
          </h3>
          <button
            onClick={onClose}
            style={{
              background: 'none',
              border: 'none',
              color: 'white',
              fontSize: '18px',
              cursor: 'pointer',
              padding: '0',
              opacity: '0.8',
              transition: 'opacity 0.2s'
            }}
          >
            ×
          </button>
        </div>

        {/* Content */}
        <div style={{
          padding: '12px',
          maxHeight: '300px',
          overflowY: 'auto'
        }}>
          {/* Basic Info */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: '8px',
            marginBottom: '12px',
            fontSize: '12px'
          }}>
            <InfoItem label="Student" value={evaluation.student} />
            <InfoItem label="ID" value={evaluation.studentId} />
            <InfoItem label="Company" value={evaluation.company} />
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: '8px',
            marginBottom: '12px',
            fontSize: '12px'
          }}>
            <InfoItem label="Supervisor" value={evaluation.supervisor} />
            <InfoItem label="Start" value={evaluation.startDate} />
            <InfoItem label="End" value={evaluation.endDate} />
          </div>

          {/* Performance Metrics */}
          <div style={{
            backgroundColor: '#f8f9fa',
            borderRadius: '6px',
            padding: '8px 10px',
            marginBottom: '12px'
          }}>
            <h4 style={{ 
              color: '#0A1929', 
              margin: '0 0 6px 0',
              fontSize: '13px',
              fontWeight: '500'
            }}>
              Performance Metrics
            </h4>
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(2, 1fr)',
              gap: '6px'
            }}>
              <MetricItem label="Technical Skills" value="4.5/5" />
              <MetricItem label="Communication" value="4.2/5" />
              <MetricItem label="Problem Solving" value="4.8/5" />
              <MetricItem label="Team Work" value="4.6/5" />
              <MetricItem label="Initiative" value="4.3/5" />
            </div>
          </div>

          {/* Supervisor Comments */}
          <div style={{
            backgroundColor: '#f8f9fa',
            borderRadius: '6px',
            padding: '8px 10px'
          }}>
            <h4 style={{ 
              color: '#0A1929', 
              margin: '0 0 6px 0',
              fontSize: '13px',
              fontWeight: '500'
            }}>
              Supervisor Comments
            </h4>
            <p style={{
              margin: 0,
              fontSize: '12px',
              lineHeight: '1.3',
              color: '#495057'
            }}>
              The student has shown exceptional progress throughout the internship period. 
              Their ability to learn and adapt to new technologies was particularly noteworthy.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div style={{
          padding: '8px 12px',
          borderTop: '1px solid #e9ecef',
          display: 'flex',
          justifyContent: 'flex-end',
          gap: '8px'
        }}>
          <button
            onClick={onClose}
            style={{
              padding: '4px 10px',
              backgroundColor: '#6c757d',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '12px'
            }}
          >
            Close
          </button>
          <button
            onClick={() => downloadPdf(evaluation)}
            style={{
              padding: '4px 10px',
              backgroundColor: '#0A1929',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '12px'
            }}
          >
            Download PDF
          </button>
        </div>
      </div>
    );
  };

  const InfoItem = ({ label, value }) => (
    <div>
      <div style={{ 
        color: '#6c757d',
        fontSize: '11px',
        marginBottom: '1px'
      }}>
        {label}
      </div>
      <div style={{
        fontSize: '12px',
        color: '#212529',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis'
      }}>
        {value}
      </div>
    </div>
  );

  const MetricItem = ({ label, value }) => (
    <div style={{
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      fontSize: '12px'
    }}>
      <span style={{ color: '#495057' }}>{label}</span>
      <span style={{ 
        color: '#0A1929',
        fontWeight: '500'
      }}>
        {value}
      </span>
    </div>
  );

  return (
    <div style={{ padding: '20px' }}>
      <FacultyHeader 
        title="Evaluation Reports"
        subtitle="Review and manage student evaluation reports submitted by company supervisors."
      />

      <div style={{
        backgroundColor: 'white',
        borderRadius: '8px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
        overflow: 'hidden'
      }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '14px' }}>
          <thead>
            <tr>
              <th style={thStyle}>Student</th>
              <th style={thStyle}>Student ID</th>
              <th style={thStyle}>Company</th>
              <th style={thStyle}>Supervisor</th>
              <th style={thStyle}>Period</th>
              <th style={thStyle}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {mockEvaluations.map((evaluation) => (
              <tr key={evaluation.id} style={{ borderBottom: '1px solid #dee2e6' }}>
                <td style={tdStyle}>{evaluation.student}</td>
                <td style={tdStyle}>{evaluation.studentId}</td>
                <td style={tdStyle}>{evaluation.company}</td>
                <td style={tdStyle}>{evaluation.supervisor}</td>
                <td style={tdStyle}>
                  {evaluation.startDate} - {evaluation.endDate}
                </td>
                <td style={tdStyle}>
                  <button
                    onClick={() => setSelectedEvaluation(evaluation)}
                    style={{
                      padding: '6px 12px',
                      backgroundColor: '#0A1929',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontSize: '13px'
                    }}
                  >
                    View
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedEvaluation && (
        <>
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            zIndex: 999
          }} onClick={() => setSelectedEvaluation(null)} />
          <Modal 
            evaluation={selectedEvaluation} 
            onClose={() => setSelectedEvaluation(null)} 
          />
        </>
      )}
    </div>
  );
}

const thStyle = {
  backgroundColor: '#f8f9fa',
  color: '#495057',
  padding: '12px 16px',
  textAlign: 'left',
  borderBottom: '2px solid #dee2e6',
  whiteSpace: 'nowrap'
};

const tdStyle = {
  padding: '12px 16px',
  color: '#212529'
};
