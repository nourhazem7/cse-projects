import React from 'react';
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import jsPDF from 'jspdf';
import FacultyHeader from '../components/FacultyHeader';

const reportStats = [
  { name: 'Approved', value: 120 },
  { name: 'Rejected', value: 40 },
  { name: 'Flagged', value: 30 },
  { name: 'Pending', value: 10 },
];

const barData = [
  { label: 'CS', approved: 40, rejected: 10, flagged: 5 },
  { label: 'ENG', approved: 30, rejected: 5, flagged: 8 },
  { label: 'BA', approved: 25, rejected: 15, flagged: 4 },
];

const courseUsage = [
  { name: 'Data Structures', value: 45 },
  { name: 'Database Systems', value: 30 },
  { name: 'Software Engineering', value: 60 },
];

const companyEvaluations = [
  { name: 'Tech Corp', rating: 4.8, interns: 50 },
  { name: 'Global Solutions', rating: 4.2, interns: 30 },
  { name: 'Digital Dynamics', rating: 4.6, interns: 40 },
];

const COLORS = ['#2ecc71', '#e74c3c', '#f1c40f', '#95a5a6'];

export default function StatisticsPanel() {
  const generatePDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text('Internship Report Statistics Summary', 20, 20);

    doc.setFontSize(12);
    doc.text('Overall Status:', 20, 40);
    reportStats.forEach((item, i) => {
      doc.text(`${item.name}: ${item.value}`, 30, 50 + i * 10);
    });

    doc.text('Top Rated Companies:', 20, 100);
    companyEvaluations.forEach((c, i) => {
      doc.text(`${c.name} - Rating: ${c.rating}, Interns: ${c.interns}`, 30, 110 + i * 10);
    });

    doc.save('internship_statistics.pdf');
  };

  return (
    <div style={{ padding: '20px' }}>
      <FacultyHeader 
        title="Statistics Dashboard"
        subtitle="View and analyze internship program statistics and performance metrics."
      />
      
      <div style={{ textAlign: 'center', marginBottom: '30px' }}>
        <button onClick={generatePDF} style={{ padding: '10px 20px', backgroundColor: '#0a3d62', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer' }}>
          📥 Generate Report (PDF)
        </button>
      </div>

      <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-around', gap: '40px' }}>
        <div style={{ width: '400px', height: '300px' }}>
          <h4 style={{ textAlign: 'center' }}>Overall Report Status</h4>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={reportStats} dataKey="value" nameKey="name" outerRadius={100} label>
                {reportStats.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div style={{ width: '500px', height: '300px' }}>
          <h4 style={{ textAlign: 'center' }}>Report Status by Department</h4>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={barData} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
              <XAxis dataKey="label" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="approved" stackId="a" fill="#2ecc71" name="Approved" />
              <Bar dataKey="rejected" stackId="a" fill="#e74c3c" name="Rejected" />
              <Bar dataKey="flagged" stackId="a" fill="#f1c40f" name="Flagged" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div style={{ width: '400px', height: '300px' }}>
          <h4 style={{ textAlign: 'center' }}>Most Used Internship Courses</h4>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={courseUsage} dataKey="value" nameKey="name" outerRadius={100} label>
                {courseUsage.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div style={{ width: '600px', height: '300px' }}>
          <h4 style={{ textAlign: 'center' }}>Top Rated Companies</h4>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={companyEvaluations} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="rating" fill="#3498db" name="Rating" />
              <Bar dataKey="interns" fill="#8e44ad" name="Internship Count" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
