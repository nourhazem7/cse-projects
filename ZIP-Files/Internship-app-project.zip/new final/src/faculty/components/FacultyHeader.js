import React from 'react';

const FacultyHeader = ({ title, subtitle }) => {
  return (
    <div style={{
      backgroundColor: '#0A1929',
      margin: '-20px -20px 24px -20px',
      padding: '32px 40px',
      borderRadius: '16px',
      boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
      position: 'relative'
    }}>
      <h1 style={{ 
        fontSize: '42px',
        fontWeight: '400',
        color: 'white',
        margin: 0,
        marginBottom: '12px',
        letterSpacing: '-0.5px'
      }}>
        {title}
      </h1>
      <h2 style={{
        fontSize: '20px',
        fontWeight: '400',
        color: 'rgba(255, 255, 255, 0.8)',
        margin: 0,
        letterSpacing: '0.1px',
        lineHeight: 1.4,
        paddingRight: '140px'
      }}>
        {subtitle}
      </h2>
    </div>
  );
};

export default FacultyHeader; 