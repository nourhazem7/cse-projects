import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextField,
  Tooltip,
  InputAdornment,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  IconButton,
  OutlinedInput,
  Snackbar,
  Alert,
} from '@mui/material';
import {
  Search as SearchIcon,
  CheckCircle as CheckCircleIcon,
  Schedule as ScheduleIcon,
  RateReview as RateReviewIcon,
  Edit as EditIcon,
  Block as BlockIcon,
  RestartAlt as RestartAltIcon,
  Visibility as VisibilityIcon,
  VisibilityOff as VisibilityOffIcon,
  Description as DescriptionIcon,
  Business as BusinessIcon,
  CalendarToday as CalendarTodayIcon,
  Lock as LockIcon,
  Download as DownloadIcon,
  Star as StarIcon,
} from '@mui/icons-material';

// Theme colors
const navyBlue = '#0A1929';
const navyHover = '#16243a';

// Helper function to determine internship status based on dates
const getInternshipStatus = (startDate, endDate) => {
  const today = new Date();
  const end = new Date(endDate);

  if (today > end) {
    return 'completed';
  } else {
    return 'current';
  }
};

// Initial data - will be saved to localStorage if not already present
const initialInternships = [
  {
    id: 1,
    companyName: 'Tech Solutions Inc.',
    jobTitle: 'Software Engineering Intern',
    startDate: '2024-06-01',
    endDate: '2024-08-31',
    hasEvaluation: false,
    get status() {
      return getInternshipStatus(this.startDate, this.endDate);
    }
  },
  {
    id: 2,
    companyName: 'Digital Marketing Pro',
    jobTitle: 'Marketing Intern',
    startDate: '2025-06-01',
    endDate: '2025-12-31',
    hasEvaluation: false,
    get status() {
      return getInternshipStatus(this.startDate, this.endDate);
    }
  },
  {
    id: 3,
    companyName: 'Data Analytics Co',
    jobTitle: 'Data Science Intern',
    startDate: '2025-01-01',
    endDate: '2025-05-31',
    hasEvaluation: false,
    get status() {
      return getInternshipStatus(this.startDate, this.endDate);
    }
  },
  {
    id: 4,
    companyName: 'Innovation Labs',
    jobTitle: 'Full Stack Developer Intern',
    startDate: new Date().toISOString().split('T')[0], // Today
    endDate: '2024-08-31',
    hasEvaluation: false,
    get status() {
      return getInternshipStatus(this.startDate, this.endDate);
    }
  },
  {
    id: 5,
    companyName: 'Global Tech Solutions',
    jobTitle: 'Mobile App Developer Intern',
    startDate: '2025-09-01',
    endDate: '2025-12-31',
    hasEvaluation: false,
    get status() {
      return getInternshipStatus(this.startDate, this.endDate);
    }
  },
  // --- More current internships ---
  {
    id: 6,
    companyName: 'NextGen AI',
    jobTitle: 'AI Research Intern',
    startDate: '2024-05-15',
    endDate: '2024-09-15',
    hasEvaluation: false,
    get status() {
      return getInternshipStatus(this.startDate, this.endDate);
    }
  },
  {
    id: 7,
    companyName: 'Green Energy Corp',
    jobTitle: 'Sustainability Intern',
    startDate: '2024-04-01',
    endDate: '2024-10-01',
    hasEvaluation: false,
    get status() {
      return getInternshipStatus(this.startDate, this.endDate);
    }
  },
  {
    id: 8,
    companyName: 'FinTech StartUp',
    jobTitle: 'FinTech Analyst Intern',
    startDate: '2024-07-01',
    endDate: '2024-12-01',
    hasEvaluation: false,
    get status() {
      return getInternshipStatus(this.startDate, this.endDate);
    }
  },
  {
    id: 9,
    companyName: 'EduTech Solutions',
    jobTitle: 'E-Learning Developer Intern',
    startDate: '2024-06-15',
    endDate: '2024-09-30',
    hasEvaluation: false,
    get status() {
      return getInternshipStatus(this.startDate, this.endDate);
    }
  },
  {
    id: 10,
    companyName: 'HealthTech Innovations',
    jobTitle: 'Healthcare Data Intern',
    startDate: '2024-05-01',
    endDate: '2024-08-15',
    hasEvaluation: false,
    get status() {
      return getInternshipStatus(this.startDate, this.endDate);
    }
  }
];

function InternshipManagement() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [internshipsList, setInternshipsList] = useState([]);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const [evaluationDialog, setEvaluationDialog] = useState({
    open: false,
    internship: null,
    data: {
      rating: 0,
      review: '',
      recommendToOthers: true,
      courses: []
    }
  });

  useEffect(() => {
    // Always reset internships data in localStorage to ensure latest dummy data is used
    localStorage.setItem('internships', JSON.stringify(initialInternships));

    // Load internships from localStorage
    const loadedInternships = JSON.parse(localStorage.getItem('internships') || '[]');
    
    // Load evaluation statuses
    const savedEvaluations = JSON.parse(localStorage.getItem('internshipEvaluations') || '{}');
    const deletedEvaluations = JSON.parse(localStorage.getItem('deletedEvaluations') || '[]');
    
    // Map the loaded internships with their current status
    const updatedInternships = loadedInternships.map(internship => ({
      ...internship,
      hasEvaluation: !!savedEvaluations[internship.id],
      isDeleted: deletedEvaluations.includes(internship.id),
      // Recreate the status getter
      get status() {
        return getInternshipStatus(this.startDate, this.endDate);
      }
    }));

    setInternshipsList(updatedInternships);
  }, []);

  const handleCreateEvaluation = (internship) => {
    const savedEvaluations = JSON.parse(localStorage.getItem('internshipEvaluations') || '{}');
    const existingEvaluation = savedEvaluations[internship.id] || {
      rating: 0,
      review: '',
      recommendToOthers: true,
      courses: [],
      createdAt: new Date().toISOString()
    };

    setEvaluationDialog({
      open: true,
      internship: internship,
      data: existingEvaluation
    });
  };

  const handleCloseEvaluation = () => {
    setEvaluationDialog({
      open: false,
      internship: null,
      data: {
        rating: 0,
        review: '',
        recommendToOthers: true,
        courses: []
      }
    });
  };

  const handleSaveEvaluation = () => {
    const savedEvaluations = JSON.parse(localStorage.getItem('internshipEvaluations') || '{}');
    
    savedEvaluations[evaluationDialog.internship.id] = {
      ...evaluationDialog.data,
      updatedAt: new Date().toISOString()
    };

    localStorage.setItem('internshipEvaluations', JSON.stringify(savedEvaluations));

    // Update the internships list to reflect the new evaluation
    const updatedInternships = internshipsList.map(internship => {
      if (internship.id === evaluationDialog.internship.id) {
        return {
          ...internship,
          hasEvaluation: true
        };
      }
      return internship;
    });

    setInternshipsList(updatedInternships);
    handleCloseEvaluation();

    setSnackbar({
      open: true,
      message: 'Evaluation saved successfully!',
      severity: 'success'
    });
  };

  const handleDownloadReport = (internship) => {
    // Create the report content
    const reportContent = {
      title: `Internship Report - ${internship.companyName}`,
      jobTitle: internship.jobTitle,
      company: internship.companyName,
      duration: `${new Date(internship.startDate).toLocaleDateString()} - ${new Date(internship.endDate).toLocaleDateString()}`,
      status: internship.status,
    };

    // Convert the content to a string
    const reportString = JSON.stringify(reportContent, null, 2);

    // Create a blob and download link
    const blob = new Blob([reportString], { type: 'application/pdf' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `internship-report-${internship.id}.pdf`;
    
    // Trigger download
    document.body.appendChild(link);
    link.click();
    
    // Cleanup
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);

    // Show success message
    setSnackbar({
      open: true,
      message: 'Report downloaded successfully!',
      severity: 'success'
    });
  };

  // Filter internships based on search term and status
  const filteredInternships = internshipsList.filter((internship) => {
    const matchesSearch = 
      internship.jobTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
      internship.companyName.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = 
      filterStatus === 'all' || 
      internship.status === filterStatus;

    return matchesSearch && matchesStatus;
  });

  return (
    <Box sx={{ flexGrow: 1 }}>
      {/* Header Section */}
      <Box sx={{ 
        mb: 4,
        p: 3,
        bgcolor: navyBlue,
        borderRadius: 2,
        color: 'white',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <Box>
          <Typography variant="h4" gutterBottom>
            Internship Management
          </Typography>
          <Typography variant="subtitle1">
            View and manage your internships
          </Typography>
        </Box>
      </Box>

      {/* Search and Filter Section */}
      <Grid container spacing={2} sx={{ mb: 4 }}>
        <Grid item xs={12} md={6}>
          <TextField
            fullWidth
            variant="outlined"
            placeholder="Search by job title or company name"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon />
                </InputAdornment>
              ),
            }}
          />
        </Grid>
        <Grid item xs={12} md={6}>
          <FormControl fullWidth variant="outlined">
            <InputLabel>Filter by Status</InputLabel>
            <Select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              label="Filter by Status"
            >
              <MenuItem value="all">All Internships</MenuItem>
              <MenuItem value="current">Current</MenuItem>
              <MenuItem value="completed">Completed</MenuItem>
            </Select>
          </FormControl>
        </Grid>
      </Grid>

      {/* Internships Grid */}
      <Grid container spacing={3}>
        {filteredInternships.map((internship) => (
          <Grid item xs={12} md={6} lg={4} key={internship.id}>
            <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
              <CardContent sx={{ flexGrow: 1 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                  <Typography variant="h6">
                    {internship.jobTitle}
                  </Typography>
                  <Chip
                    icon={internship.status === 'current' ? <ScheduleIcon /> : <CheckCircleIcon />}
                    label={internship.status.charAt(0).toUpperCase() + internship.status.slice(1)}
                    color={internship.status === 'current' ? 'primary' : 'success'}
                  />
                </Box>
                
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <BusinessIcon sx={{ mr: 1, color: 'text.secondary' }} />
                  <Typography color="text.secondary">
                    {internship.companyName}
                  </Typography>
                </Box>

                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <CalendarTodayIcon sx={{ mr: 1, color: 'text.secondary', fontSize: '1rem' }} />
                  <Typography variant="body2" color="text.secondary">
                    {new Date(internship.startDate).toLocaleDateString()} - {new Date(internship.endDate).toLocaleDateString()}
                  </Typography>
                </Box>
              </CardContent>
              <CardActions sx={{ p: 2, gap: 1 }}>
                <Button
                  variant={internship.hasEvaluation ? "contained" : "outlined"}
                  startIcon={
                    internship.status === 'current' ? <LockIcon /> :
                    internship.hasEvaluation ? <EditIcon /> : <RateReviewIcon />
                  }
                  onClick={() => handleCreateEvaluation(internship)}
                  disabled={internship.status === 'current'}
                  fullWidth
                  sx={{
                    opacity: internship.status === 'current' ? 1 : 1,
                    bgcolor: internship.status === 'current' ? '#e3e6f0' : '#0A1929',
                    color: internship.status === 'current' ? '#0A1929' : 'white',
                    borderColor: '#0A1929',
                    borderWidth: internship.status === 'current' ? 2 : 1,
                    borderStyle: 'solid',
                    '&:hover': {
                      bgcolor: internship.status === 'current' ? '#e3e6f0' : '#16243a',
                      borderColor: '#16243a',
                    },
                  }}
                >
                  {internship.status === 'current' ? (
                    <Tooltip title="Evaluation is available after internship completion">
                      <span>Evaluate</span>
                    </Tooltip>
                  ) : (
                    internship.hasEvaluation ? 'View/Edit' : 'Evaluate'
                  )}
                </Button>
                <Button
                  variant="outlined"
                  startIcon={
                    internship.status === 'current' ? <LockIcon /> : <DownloadIcon />
                  }
                  onClick={() => handleDownloadReport(internship)}
                  disabled={internship.status === 'current'}
                  fullWidth
                  sx={{
                    opacity: internship.status === 'current' ? 1 : 1,
                    bgcolor: internship.status === 'current' ? '#e3e6f0' : '#0A1929',
                    color: internship.status === 'current' ? '#0A1929' : 'white',
                    borderColor: '#0A1929',
                    borderWidth: internship.status === 'current' ? 2 : 1,
                    borderStyle: 'solid',
                    '&:hover': {
                      bgcolor: internship.status === 'current' ? '#e3e6f0' : '#16243a',
                      borderColor: '#16243a',
                    },
                  }}
                >
                  {internship.status === 'current' ? (
                    <Tooltip title="Reports are available after internship completion">
                      <span>Download</span>
                    </Tooltip>
                  ) : (
                    'DOWNLOAD'
                  )}
                </Button>
              </CardActions>
            </Card>
          </Grid>
        ))}
        {filteredInternships.length === 0 && (
          <Grid item xs={12}>
            <Card sx={{ p: 2, textAlign: 'center' }}>
              <Typography color="text.secondary">
                No internships found matching your criteria
              </Typography>
            </Card>
          </Grid>
        )}
      </Grid>

      {/* Evaluation Dialog */}
      <Dialog 
        open={evaluationDialog.open} 
        onClose={handleCloseEvaluation}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle sx={{ bgcolor: navyBlue, color: 'white' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <RateReviewIcon />
            <Typography variant="h6">
              {evaluationDialog.internship?.hasEvaluation ? 'Edit Evaluation' : 'Create Evaluation'}
            </Typography>
          </Box>
        </DialogTitle>
        <DialogContent sx={{ mt: 2 }}>
          {evaluationDialog.internship && (
            <Box>
              <Typography variant="h6" gutterBottom>
                {evaluationDialog.internship.jobTitle} at {evaluationDialog.internship.companyName}
              </Typography>
              
              <Box sx={{ my: 3 }}>
                <Typography component="legend" gutterBottom>Rating</Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  {[1, 2, 3, 4, 5].map((value) => (
                    <IconButton
                      key={value}
                      onClick={() => setEvaluationDialog(prev => ({
                        ...prev,
                        data: { ...prev.data, rating: value }
                      }))}
                      sx={{
                        color: value <= evaluationDialog.data.rating ? 'primary.main' : 'grey.300'
                      }}
                    >
                      <StarIcon />
                    </IconButton>
                  ))}
                </Box>
              </Box>

              <TextField
                fullWidth
                multiline
                rows={4}
                label="Review"
                value={evaluationDialog.data.review}
                onChange={(e) => setEvaluationDialog(prev => ({
                  ...prev,
                  data: { ...prev.data, review: e.target.value }
                }))}
                sx={{ mb: 3 }}
              />

              <FormControl fullWidth sx={{ mb: 3 }}>
                <InputLabel>Would you recommend this internship?</InputLabel>
                <Select
                  value={evaluationDialog.data.recommendToOthers}
                  onChange={(e) => setEvaluationDialog(prev => ({
                    ...prev,
                    data: { ...prev.data, recommendToOthers: e.target.value }
                  }))}
                  label="Would you recommend this internship?"
                >
                  <MenuItem value={true}>Yes, I would recommend</MenuItem>
                  <MenuItem value={false}>No, I would not recommend</MenuItem>
                </Select>
              </FormControl>

              <FormControl fullWidth>
                <InputLabel>Relevant Courses</InputLabel>
                <Select
                  multiple
                  value={evaluationDialog.data.courses}
                  onChange={(e) => setEvaluationDialog(prev => ({
                    ...prev,
                    data: { ...prev.data, courses: e.target.value }
                  }))}
                  input={<OutlinedInput label="Relevant Courses" />}
                  renderValue={(selected) => (
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                      {selected.map((value) => (
                        <Chip key={value} label={value} />
                      ))}
                    </Box>
                  )}
                >
                  {['CS101', 'CS202', 'CS303', 'CS404', 'CS505'].map((course) => (
                    <MenuItem key={course} value={course}>
                      {course}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ p: 2, gap: 1 }}>
          <Button
            onClick={handleCloseEvaluation}
            variant="outlined"
            sx={{
              borderColor: navyBlue,
              color: navyBlue,
              '&:hover': {
                borderColor: navyHover,
                bgcolor: 'rgba(10, 25, 41, 0.04)'
              }
            }}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSaveEvaluation}
            variant="contained"
            sx={{
              bgcolor: navyBlue,
              color: 'white',
              '&:hover': {
                bgcolor: navyHover
              }
            }}
          >
            Save Evaluation
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar for notifications */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert 
          onClose={() => setSnackbar({ ...snackbar, open: false })} 
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}

export default InternshipManagement; 