import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Paper,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  IconButton,
  Divider,
  Tooltip,
  Grid,
} from '@mui/material';
import {
  Description as DescriptionIcon,
  Download as DownloadIcon,
  Assignment as AssignmentIcon,
  InsertDriveFile as FileIcon,
  WorkOutline as WorkIcon,
} from '@mui/icons-material';

// Theme colors
const navyBlue = '#0A1929';

function Downloads() {
  const [downloadableFiles, setDownloadableFiles] = useState([]);

  useEffect(() => {
    // Load downloadable files from localStorage
    const internships = JSON.parse(localStorage.getItem('internships') || '[]');
    const allReports = [];
    
    // Gather all reports from internships
    internships.forEach(internship => {
      const reports = JSON.parse(localStorage.getItem(`reports_${internship.id}`) || '[]');
      reports.forEach(report => {
        allReports.push({
          ...report,
          type: 'report',
          internshipName: `${internship.companyName} - ${internship.jobTitle}`,
          internshipId: internship.id,
          fileType: 'pdf'
        });
      });
    });

    // Add standard documents and CV
    const files = [
      ...allReports,
      {
        id: 'internship-guide',
        title: 'Internship Guidelines',
        type: 'document',
        description: 'Official guidelines for internship procedures and requirements',
        fileType: 'pdf'
      },
      {
        id: 'evaluation-form',
        title: 'Evaluation Form Template',
        type: 'document',
        description: 'Template for internship evaluation',
        fileType: 'docx'
      },
      {
        id: 'cv',
        title: 'My CV',
        type: 'document',
        description: 'Current version of your curriculum vitae',
        fileType: 'pdf',
        lastUpdated: new Date().toISOString()
      }
    ];

    setDownloadableFiles(files);
  }, []);

  const handleDownload = (file) => {
    // Create the file content based on the file type
    let content = '';
    let filename = '';
    let mimeType = '';

    switch (file.type) {
      case 'report':
        content = generateReportPDF(file);
        filename = `${file.title.toLowerCase().replace(/\s+/g, '-')}-report.pdf`;
        mimeType = 'application/pdf';
        break;
      case 'document':
        if (file.id === 'cv') {
          content = generateCV();
          filename = 'my-cv.pdf';
          mimeType = 'application/pdf';
        } else if (file.id === 'internship-guide') {
          content = generateInternshipGuide();
          filename = 'internship-guidelines.pdf';
          mimeType = 'application/pdf';
        } else if (file.id === 'evaluation-form') {
          content = generateEvaluationForm();
          filename = 'evaluation-form.docx';
          mimeType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
        }
        break;
      default:
        console.error('Unknown file type');
        return;
    }

    // Create a Blob and download the file
    const blob = new Blob([content], { type: mimeType });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
  };

  // Helper functions to generate file content
  const generateReportPDF = (report) => {
    // In a real application, you would use a PDF generation library
    // For now, we'll return a simple string representation
    return `
      Report: ${report.title}
      Internship: ${report.internshipName}
      
      Introduction:
      ${report.introduction}
      
      Content:
      ${report.body}
      
      Helpful Courses:
      ${report.helpfulCourses.join(', ')}
    `;
  };

  const generateCV = () => {
    // In a real application, you would generate a proper CV
    return 'My CV Content';
  };

  const generateInternshipGuide = () => {
    // In a real application, you would have actual guide content
    return 'Internship Guidelines Content';
  };

  const generateEvaluationForm = () => {
    // In a real application, you would generate a proper form template
    return 'Evaluation Form Template Content';
  };

  const getFileIcon = (type, fileType) => {
    switch (type) {
      case 'report':
        return <AssignmentIcon />;
      case 'document':
        if (fileType === 'pdf') {
          return <DescriptionIcon />;
        } else {
          return <FileIcon />;
        }
      default:
        return <DescriptionIcon />;
    }
  };

  return (
    <Box sx={{ flexGrow: 1 }}>
      {/* Header Section */}
      <Box sx={{ 
        mb: 4,
        p: 3,
        bgcolor: navyBlue,
        borderRadius: 2,
        color: 'white'
      }}>
        <Typography variant="h4" gutterBottom>
          Downloads
        </Typography>
        <Typography variant="subtitle1">
          Access and download your reports and important documents
        </Typography>
      </Box>

      <Grid container spacing={3}>
        {/* Reports Section */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <AssignmentIcon sx={{ mr: 1 }} />
              <Typography variant="h6">
                Internship Reports
              </Typography>
            </Box>
            <List>
              {downloadableFiles
                .filter(file => file.type === 'report')
                .map((file) => (
                  <React.Fragment key={file.id}>
                    <ListItem
                      secondaryAction={
                        <Tooltip title="Download">
                          <IconButton
                            edge="end"
                            onClick={() => handleDownload(file)}
                            sx={{ 
                              color: navyBlue,
                              '&:hover': { bgcolor: 'rgba(10, 25, 41, 0.04)' }
                            }}
                          >
                            <DownloadIcon />
                          </IconButton>
                        </Tooltip>
                      }
                    >
                      <ListItemIcon>
                        {getFileIcon(file.type, file.fileType)}
                      </ListItemIcon>
                      <ListItemText
                        primary={file.title}
                        secondary={file.internshipName}
                      />
                    </ListItem>
                    <Divider />
                  </React.Fragment>
                ))}
              {downloadableFiles.filter(file => file.type === 'report').length === 0 && (
                <Typography color="text.secondary" sx={{ py: 2, textAlign: 'center' }}>
                  No reports available for download
                </Typography>
              )}
            </List>
          </Paper>
        </Grid>

        {/* Documents Section */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <DescriptionIcon sx={{ mr: 1 }} />
              <Typography variant="h6">
                Important Documents
              </Typography>
            </Box>
            <List>
              {downloadableFiles
                .filter(file => file.type === 'document')
                .map((file) => (
                  <React.Fragment key={file.id}>
                    <ListItem
                      secondaryAction={
                        <Tooltip title="Download">
                          <IconButton
                            edge="end"
                            onClick={() => handleDownload(file)}
                            sx={{ 
                              color: navyBlue,
                              '&:hover': { bgcolor: 'rgba(10, 25, 41, 0.04)' }
                            }}
                          >
                            <DownloadIcon />
                          </IconButton>
                        </Tooltip>
                      }
                    >
                      <ListItemIcon>
                        {getFileIcon(file.type, file.fileType)}
                      </ListItemIcon>
                      <ListItemText
                        primary={file.title}
                        secondary={
                          <>
                            {file.description}
                            {file.lastUpdated && (
                              <Typography variant="caption" display="block" color="text.secondary">
                                Last updated: {new Date(file.lastUpdated).toLocaleDateString()}
                              </Typography>
                            )}
                          </>
                        }
                      />
                    </ListItem>
                    <Divider />
                  </React.Fragment>
                ))}
            </List>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
}

export default Downloads; 