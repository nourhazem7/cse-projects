import React from 'react';
import {
  Box,
  Typography,
  Grid,
  Paper,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Button,
  LinearProgress,
  Avatar,
} from '@mui/material';
import {
  WorkOutline as WorkIcon,
  Person as PersonIcon,
  Assignment as AssignmentIcon,
  CalendarToday as CalendarIcon,
  CheckCircle as CheckCircleIcon,
  Schedule as ScheduleIcon,
  PendingActions as PendingActionsIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

// Theme colors
const navyBlue = '#0A1929';
const lightNavyBlue = '#1A2B3C';

// Dummy data for dashboard
const upcomingDeadlines = [
  {
    id: 1,
    company: 'Tech Solutions Inc.',
    position: 'Software Engineering Intern',
    deadline: '2024-04-15',
  },
  {
    id: 2,
    company: 'Digital Marketing Pro',
    position: 'Marketing Intern',
    deadline: '2024-04-20',
  },
];

const recentActivities = [
  {
    id: 1,
    type: 'application',
    description: 'Applied to Software Engineering Internship at Tech Corp',
    date: '2024-03-20',
  },
  {
    id: 2,
    type: 'interview',
    description: 'Upcoming interview with Innovation Labs',
    date: '2024-03-25',
  },
];

function Dashboard() {
  const navigate = useNavigate();

  const handleViewAllDeadlines = () => {
    navigate('/student/internships');
  };

  const handleCompleteProfile = () => {
    navigate('/student/profile');
  };

  const handleBrowseInternships = () => {
    navigate('/student/internships');
  };

  const handleUpdateProfile = () => {
    navigate('/student/profile');
  };

  const handleApplicationStatus = () => {
    navigate('/student/application-status');
  };

  return (
    <Box sx={{ flexGrow: 1 }}>
      {/* Header Section */}
      <Box sx={{ 
        mb: 4,
        p: 3,
        bgcolor: navyBlue,
        borderRadius: 2,
        color: 'white'
      }}>
        <Typography variant="h4" gutterBottom>
          Welcome Back, Student!
        </Typography>
        <Typography variant="subtitle1">
          Track your internship applications and stay updated with the latest opportunities.
        </Typography>
      </Box>

      <Grid container spacing={3}>
        {/* Quick Stats */}
        <Grid item xs={12} md={8}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <Paper sx={{ p: 2, bgcolor: lightNavyBlue, color: 'white' }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                  <Avatar sx={{ bgcolor: 'primary.main' }}>
                    <AssignmentIcon />
                  </Avatar>
                  <Box>
                    <Typography variant="h6">5</Typography>
                    <Typography variant="body2">Active Applications</Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Paper sx={{ p: 2, bgcolor: lightNavyBlue, color: 'white' }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                  <Avatar sx={{ bgcolor: 'success.main' }}>
                    <CheckCircleIcon />
                  </Avatar>
                  <Box>
                    <Typography variant="h6">2</Typography>
                    <Typography variant="body2">Interviews Scheduled</Typography>
                  </Box>
                </Box>
              </Paper>
            </Grid>
          </Grid>

          {/* Application Progress */}
          <Paper sx={{ mt: 3, p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Application Progress
            </Typography>
            <Box sx={{ mb: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="body2">Profile Completion</Typography>
                <Typography variant="body2">80%</Typography>
              </Box>
              <LinearProgress variant="determinate" value={80} sx={{ height: 8, borderRadius: 4 }} />
            </Box>
            <Button variant="contained" onClick={handleCompleteProfile}>
              Complete Your Profile
            </Button>
          </Paper>

          {/* Recent Activity */}
          <Paper sx={{ mt: 3, p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Recent Activity
            </Typography>
            <List>
              {recentActivities.map((activity) => (
                <ListItem key={activity.id}>
                  <ListItemIcon>
                    {activity.type === 'application' ? <AssignmentIcon /> : <ScheduleIcon />}
                  </ListItemIcon>
                  <ListItemText
                    primary={activity.description}
                    secondary={activity.date}
                  />
                </ListItem>
              ))}
            </List>
          </Paper>
        </Grid>

        {/* Right Sidebar */}
        <Grid item xs={12} md={4}>
          {/* Upcoming Deadlines */}
          <Paper sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <CalendarIcon color="primary" />
              Upcoming Deadlines
            </Typography>
            <List>
              {upcomingDeadlines.map((deadline) => (
                <ListItem key={deadline.id}>
                  <ListItemText
                    primary={deadline.position}
                    secondary={
                      <>
                        <Typography component="span" variant="body2" color="text.primary">
                          {deadline.company}
                        </Typography>
                        {' — Deadline: ' + deadline.deadline}
                      </>
                    }
                  />
                </ListItem>
              ))}
            </List>
            <Button variant="outlined" fullWidth sx={{ mt: 2 }} onClick={handleViewAllDeadlines}>
              View All Deadlines
            </Button>
          </Paper>

          {/* Quick Links */}
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Quick Links
            </Typography>
            <List>
              <ListItem button onClick={handleBrowseInternships}>
                <ListItemIcon>
                  <WorkIcon />
                </ListItemIcon>
                <ListItemText primary="Browse Internships" />
              </ListItem>
              <ListItem button onClick={handleUpdateProfile}>
                <ListItemIcon>
                  <PersonIcon />
                </ListItemIcon>
                <ListItemText primary="Update Profile" />
              </ListItem>
              <ListItem button onClick={handleApplicationStatus}>
                <ListItemIcon>
                  <PendingActionsIcon />
                </ListItemIcon>
                <ListItemText primary="Application Status" />
              </ListItem>
            </List>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
}

export default Dashboard; 