import React, { useState } from 'react';
import {
  Box,
  Typography,
  Paper,
  Grid,
  Chip,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Divider,
} from '@mui/material';
import {
  Business as BusinessIcon,
  AttachMoney as AttachMoneyIcon,
  AccessTime as AccessTimeIcon,
  LocationOn as LocationOnIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

// eslint-disable-next-line no-unused-vars
const navyBlue = '#0A1929';

function InternshipDetails({ internship, onClose }) {
  const navigate = useNavigate();
  const [showApplyDialog, setShowApplyDialog] = useState(false);
  const [coverLetter, setCoverLetter] = useState('');

  const handleApply = () => {
    // Here you would typically submit the application to your backend
    console.log('Applying with cover letter:', coverLetter);
    setShowApplyDialog(false);
    navigate('/student/application-status');
  };

  return (
    <Box sx={{ p: 3 }}>
      <Paper sx={{ p: 3 }}>
        {/* Header Section */}
        <Box sx={{ mb: 4 }}>
          <Typography variant="h4" gutterBottom>
            {internship.title}
          </Typography>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
            <BusinessIcon color="action" />
            <Typography variant="h6" color="text.secondary">
              {internship.company}
            </Typography>
          </Box>
          <Box sx={{ display: 'flex', gap: 2 }}>
            <Chip
              label={internship.isPaid ? 'Paid' : 'Unpaid'}
              color={internship.isPaid ? 'success' : 'default'}
              icon={internship.isPaid ? <AttachMoneyIcon /> : undefined}
            />
            <Chip label={internship.industry} color="primary" variant="outlined" />
          </Box>
        </Box>

        <Divider sx={{ my: 3 }} />

        {/* Details Section */}
        <Grid container spacing={3}>
          <Grid item xs={12} md={8}>
            <Typography variant="h6" gutterBottom>
              Description
            </Typography>
            <Typography paragraph>
              {internship.description}
            </Typography>

            {/* Requirements Section */}
            <Typography variant="h6" gutterBottom sx={{ mt: 3 }}>
              Requirements
            </Typography>
            <ul>
              <li>Currently enrolled in a relevant degree program</li>
              <li>Strong academic performance</li>
              <li>Excellent communication skills</li>
              <li>Ability to work in a team environment</li>
            </ul>

            {/* Responsibilities Section */}
            <Typography variant="h6" gutterBottom sx={{ mt: 3 }}>
              Responsibilities
            </Typography>
            <ul>
              <li>Assist in project development and implementation</li>
              <li>Collaborate with team members on various tasks</li>
              <li>Participate in team meetings and discussions</li>
              <li>Document work and maintain project records</li>
            </ul>
          </Grid>

          <Grid item xs={12} md={4}>
            <Paper elevation={0} sx={{ p: 2, bgcolor: 'grey.50' }}>
              <Typography variant="h6" gutterBottom>
                Internship Details
              </Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <AccessTimeIcon color="action" />
                  <Typography>Duration: {internship.duration}</Typography>
                </Box>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <LocationOnIcon color="action" />
                  <Typography>Location: {internship.location}</Typography>
                </Box>
                {internship.isPaid && (
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <AttachMoneyIcon color="action" />
                    <Typography>Salary: {internship.salary}</Typography>
                  </Box>
                )}
              </Box>

              <Button
                variant="contained"
                fullWidth
                sx={{ mt: 3 }}
                onClick={() => setShowApplyDialog(true)}
              >
                Apply Now
              </Button>
            </Paper>
          </Grid>
        </Grid>
      </Paper>

      {/* Apply Dialog */}
      <Dialog 
        open={showApplyDialog} 
        onClose={() => setShowApplyDialog(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>Apply for {internship.title}</DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 2 }}>
            <Typography variant="subtitle1" gutterBottom>
              Please provide a cover letter explaining why you're interested in this position
            </Typography>
            <TextField
              multiline
              rows={6}
              fullWidth
              placeholder="Write your cover letter here..."
              value={coverLetter}
              onChange={(e) => setCoverLetter(e.target.value)}
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowApplyDialog(false)}>Cancel</Button>
          <Button 
            variant="contained"
            onClick={handleApply}
            disabled={!coverLetter.trim()}
          >
            Submit Application
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}

export default InternshipDetails; 