import React, { useState } from 'react';
import {
    Box,
    Typography,
    Grid,
    Paper,
    TextField,
    Button,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    IconButton,
} from '@mui/material';
import {
    PlayArrow as PlayArrowIcon,
    School as SchoolIcon,
    ArrowBack as ArrowBackIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

// Theme colors
const navyBlue = '#0A1929';

const InternshipRequirements = () => {
    const navigate = useNavigate();
    const [selectedVideo, setSelectedVideo] = useState(null);

    // Real videos data with actual YouTube content
    const majorVideos = [
        {
            id: 1,
            major: "Computer Science & Engineering",
            thumbnail: "https://img.youtube.com/vi/yUQbl9J3kJU/maxresdefault.jpg",
            title: "How to Get a Software Engineering Internship",
            description: "Comprehensive guide on landing your first software engineering internship, including resume tips, interview preparation, and application strategies.",
            duration: "14:53",
            videoUrl: "https://www.youtube.com/embed/yUQbl9J3kJU",
            videoId: "yUQbl9J3kJU"
        },
        {
            id: 2,
            major: "Business Informatics",
            thumbnail: "https://img.youtube.com/vi/YWeWSzjQheg/maxresdefault.jpg",
            title: "How to Get an Internship With No Experience",
            description: "Learn how to secure an internship even without prior experience, with practical tips and strategies for standing out.",
            duration: "10:03",
            videoUrl: "https://www.youtube.com/embed/YWeWSzjQheg",
            videoId: "YWeWSzjQheg"
        },
        {
            id: 3,
            major: "Media Engineering",
            thumbnail: "https://img.youtube.com/vi/q20N8Drax80/maxresdefault.jpg",
            title: "How to Get an Internship in 2024",
            description: "Updated guide for securing internships in 2024, covering modern application processes and what companies are looking for.",
            duration: "13:46",
            videoUrl: "https://www.youtube.com/embed/q20N8Drax80",
            videoId: "q20N8Drax80"
        },
        {
            id: 4,
            major: "General Engineering",
            thumbnail: "https://img.youtube.com/vi/z5LuiOiq9G4/maxresdefault.jpg",
            title: "How to Get an Engineering Internship",
            description: "Essential tips and strategies for engineering students looking to secure valuable internship positions.",
            duration: "8:31",
            videoUrl: "https://www.youtube.com/embed/z5LuiOiq9G4",
            videoId: "z5LuiOiq9G4"
        }
    ];

    const handleOpenVideo = (video) => {
        setSelectedVideo(video);
    };

    const handleCloseVideo = () => {
        setSelectedVideo(null);
    };

    return (
        <Box sx={{ flexGrow: 1 }}>
            {/* Header Section */}
            <Box sx={{ 
                mb: 4,
                p: 3,
                bgcolor: navyBlue,
                borderRadius: 2,
                color: 'white',
                display: 'flex',
                alignItems: 'center',
                gap: 2
            }}>
                <IconButton color="inherit" onClick={() => navigate('/student/internship-management')}>
                    <ArrowBackIcon />
                </IconButton>
                <Box>
                    <Typography variant="h4" gutterBottom>
                        Internship Requirements
                    </Typography>
                    <Typography variant="subtitle1">
                        View requirement videos for internships based on your major
                    </Typography>
                </Box>
            </Box>

            {/* Videos Grid */}
            <Grid container spacing={3}>
                {majorVideos.map((video) => (
                    <Grid item xs={12} md={6} lg={4} key={video.id}>
                        <Paper sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
                            <Box
                                component="img"
                                height="200"
                                src={video.thumbnail}
                                alt={video.title}
                                sx={{
                                    cursor: 'pointer',
                                    '&:hover': {
                                        opacity: 0.9,
                                    }
                                }}
                                onClick={() => handleOpenVideo(video)}
                            />
                            <Box sx={{ p: 3, flexGrow: 1 }}>
                                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                                    <Typography variant="h6" gutterBottom>
                                        {video.title}
                                    </Typography>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                                    <SchoolIcon sx={{ mr: 1, color: 'text.secondary' }} />
                                    <Typography color="text.secondary">
                                        {video.major}
                                    </Typography>
                                </Box>
                                <Typography variant="body2" color="text.secondary" paragraph>
                                    {video.description}
                                </Typography>
                                <Typography variant="caption" color="text.secondary">
                                    Duration: {video.duration}
                                </Typography>
                            </Box>
                            <Box sx={{ p: 2, display: 'flex', justifyContent: 'flex-end' }}>
                                <Button
                                    size="small"
                                    startIcon={<PlayArrowIcon />}
                                    onClick={() => handleOpenVideo(video)}
                                    variant="contained"
                                    sx={{
                                        bgcolor: navyBlue,
                                        color: 'white',
                                        '&:hover': {
                                            bgcolor: '#16243a',
                                        },
                                    }}
                                >
                                    Watch Video
                                </Button>
                            </Box>
                        </Paper>
                    </Grid>
                ))}
            </Grid>

            {/* Video Dialog */}
            <Dialog
                open={Boolean(selectedVideo)}
                onClose={handleCloseVideo}
                maxWidth="md"
                fullWidth
            >
                <DialogTitle>
                    {selectedVideo?.title}
                </DialogTitle>
                <DialogContent>
                    <Box sx={{ position: 'relative', width: '100%', paddingTop: '56.25%' }}>
                        {selectedVideo && (
                            <iframe
                                style={{
                                    position: 'absolute',
                                    top: 0,
                                    left: 0,
                                    width: '100%',
                                    height: '100%',
                                    border: 'none'
                                }}
                                src={`${selectedVideo.videoUrl}?autoplay=1`}
                                title={selectedVideo.title}
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowFullScreen
                            />
                        )}
                    </Box>
                    <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
                        {selectedVideo?.description}
                    </Typography>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseVideo}>
                        Close
                    </Button>
                </DialogActions>
            </Dialog>
        </Box>
    );
};

export default InternshipRequirements; 