import React, { useState } from 'react';
import {
  Box,
  Typography,
  Paper,
  Grid,
  TextField,
  Button,
  Avatar,
  IconButton,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Autocomplete,
  MenuItem,
} from '@mui/material';
import {
  Edit as EditIcon,
  Description as DescriptionIcon,
  CloudUpload as CloudUploadIcon,
  Delete as DeleteIcon,
  LinkedIn as LinkedInIcon,
  GitHub as GitHubIcon,
  Language as LanguageIcon,
} from '@mui/icons-material';

// Theme colors
const navyBlue = '#0A1929';
const lightNavyBlue = '#1A2B3C';

// Dummy data for skills
const skillCategories = {
  technical: ['JavaScript', 'React', 'Node.js', 'Python', 'Java', 'SQL', 'HTML', 'CSS', 'TypeScript', 'MongoDB', 'Git'],
  soft: ['Communication', 'Leadership', 'Problem Solving', 'Teamwork', 'Time Management', 'Adaptability', 'Critical Thinking'],
  languages: ['English', 'Arabic', 'French', 'German', 'Spanish', 'Chinese', 'Japanese'],
};

const majorOptions = [
  'Computer Science and Engineering',
  'Business Informatics',
  'Media Engineering',
  'General Engineering',
  'Mechatronics',
  'Civil Engineering',
  'Architecture',
  'Pharmacy',
  'Biotechnology',
  'Management',
  'Other'
];
const semesterOptions = Array.from({ length: 10 }, (_, i) => (i + 1).toString());

function Profile() {
  const [editMode, setEditMode] = useState(false);
  const [tempProfileData, setTempProfileData] = useState({});
  const [profileData, setProfileData] = useState({
    firstName: 'John',
    lastName: 'Doe',
    studentId: '43-0123',
    email: 'john.doe@student.guc.edu.eg',
    phone: '+20 123 456 7890',
    major: 'Computer Science and Engineering',
    gpa: '3.75',
    semester: '7',
    skills: {
      technical: ['JavaScript', 'React', 'Python'],
      soft: ['Communication', 'Teamwork'],
      languages: ['English', 'Arabic'],
    },
    socialLinks: {
      linkedin: 'https://linkedin.com/in/johndoe',
      github: 'https://github.com/johndoe',
      portfolio: 'https://johndoe.dev',
    },
  });

  const [documents, setDocuments] = useState([
    {
      id: 1,
      name: 'Resume.pdf',
      type: 'resume',
      uploadDate: '2024-03-15',
      status: 'verified',
    },
    {
      id: 2,
      name: 'Transcript.pdf',
      type: 'transcript',
      uploadDate: '2024-03-10',
      status: 'pending',
    },
  ]);

  const [skillsDialog, setSkillsDialog] = useState({
    open: false,
    category: '',
    availableSkills: [],
  });

  const handleEditProfile = () => {
    setTempProfileData(profileData);
    setEditMode(true);
  };

  const handleSaveProfile = () => {
    setProfileData(tempProfileData);
    setEditMode(false);
  };

  const handleCancelEdit = () => {
    setEditMode(false);
  };

  const handleProfileInputChange = (field) => (event) => {
    const value = event.target.value;
    if (field.includes('.')) {
      const [section, key] = field.split('.');
      setTempProfileData({
        ...tempProfileData,
        [section]: {
          ...tempProfileData[section],
          [key]: value,
        },
      });
    } else {
      setTempProfileData({
        ...tempProfileData,
        [field]: value,
      });
    }
  };

  const handleDocumentDelete = (documentId) => {
    setDocuments(documents.filter((doc) => doc.id !== documentId));
  };

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const newDocument = {
        id: Date.now(),
        name: file.name,
        type: 'document',
        uploadDate: new Date().toISOString().split('T')[0],
        status: 'pending',
      };
      setDocuments([...documents, newDocument]);
    }
  };

  const handleSkillsDialogOpen = (category) => {
    setSkillsDialog({
      open: true,
      category,
      availableSkills: skillCategories[category] || [],
    });
  };

  const handleSkillsDialogClose = () => {
    setSkillsDialog({
      open: false,
      category: '',
      availableSkills: [],
    });
  };

  const handleAddSkill = (newSkills) => {
    setProfileData({
      ...profileData,
      skills: {
        ...profileData.skills,
        [skillsDialog.category]: newSkills,
      },
    });
  };

  const handleRemoveSkill = (category, skillToRemove) => {
    setProfileData({
      ...profileData,
      skills: {
        ...profileData.skills,
        [category]: profileData.skills[category].filter(skill => skill !== skillToRemove),
      },
    });
  };

  return (
    <Box sx={{ flexGrow: 1 }}>
      {/* Header Section */}
      <Box sx={{ mb: 4, p: 3, bgcolor: navyBlue, borderRadius: 2, color: 'white', position: 'relative' }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 3 }}>
          <Typography variant="h4">
            My Profile
          </Typography>
          {!editMode && (
            <IconButton onClick={handleEditProfile} sx={{ color: 'white' }}>
              <EditIcon />
            </IconButton>
          )}
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 3 }}>
          <Box sx={{ position: 'relative' }}>
            <Avatar
              sx={{ width: 100, height: 100, bgcolor: lightNavyBlue }}
              src="/path-to-profile-image.jpg"
            >
              {profileData.firstName[0] + profileData.lastName[0]}
            </Avatar>
          </Box>
          <Box>
            <Typography variant="h4">
              {profileData.firstName} {profileData.lastName}
            </Typography>
            <Typography variant="subtitle1" sx={{ opacity: 0.8 }}>
              Student ID: {profileData.studentId}
            </Typography>
          </Box>
        </Box>
      </Box>

      <Grid container spacing={3}>
        {/* Personal Information */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, mb: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">
                Personal Information
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <Box>
                <Typography variant="subtitle2">First Name</Typography>
                {editMode ? (
                  <TextField fullWidth value={tempProfileData.firstName} onChange={handleProfileInputChange('firstName')} />
                ) : (
                  <Typography>{profileData.firstName}</Typography>
                )}
              </Box>
              <Box>
                <Typography variant="subtitle2">Last Name</Typography>
                {editMode ? (
                  <TextField fullWidth value={tempProfileData.lastName} onChange={handleProfileInputChange('lastName')} />
                ) : (
                  <Typography>{profileData.lastName}</Typography>
                )}
              </Box>
              <Box>
                <Typography variant="subtitle2">Email</Typography>
                <Typography>{profileData.email}</Typography>
              </Box>
              <Box>
                <Typography variant="subtitle2">Phone</Typography>
                {editMode ? (
                  <TextField fullWidth value={tempProfileData.phone} onChange={handleProfileInputChange('phone')} />
                ) : (
                  <Typography>{profileData.phone}</Typography>
                )}
              </Box>
            </Box>
          </Paper>

          {/* Academic Information */}
          <Paper sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">
                Academic Information
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <Box>
                <Typography variant="subtitle2">Major</Typography>
                {editMode ? (
                  <TextField
                    select
                    fullWidth
                    value={tempProfileData.major}
                    onChange={handleProfileInputChange('major')}
                  >
                    {majorOptions.map((option) => (
                      <MenuItem key={option} value={option}>{option}</MenuItem>
                    ))}
                  </TextField>
                ) : (
                  <Typography>{profileData.major}</Typography>
                )}
              </Box>
              <Box>
                <Typography variant="subtitle2">GPA</Typography>
                {editMode ? (
                  <TextField fullWidth value={tempProfileData.gpa} onChange={handleProfileInputChange('gpa')} />
                ) : (
                  <Typography>{profileData.gpa}</Typography>
                )}
              </Box>
              <Box>
                <Typography variant="subtitle2">Semester</Typography>
                {editMode ? (
                  <TextField
                    select
                    fullWidth
                    value={tempProfileData.semester}
                    onChange={handleProfileInputChange('semester')}
                  >
                    {semesterOptions.map((option) => (
                      <MenuItem key={option} value={option}>{option}</MenuItem>
                    ))}
                  </TextField>
                ) : (
                  <Typography>{profileData.semester}</Typography>
                )}
              </Box>
            </Box>
          </Paper>
        </Grid>

        {/* Right Side */}
        <Grid item xs={12} md={6}>
          {/* Skills Section */}
          <Paper sx={{ p: 3, mb: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">
                Skills
              </Typography>
            </Box>
            
            {/* Technical Skills */}
            <Box sx={{ mb: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                <Typography variant="subtitle1" color="textSecondary">
                  Technical Skills
                </Typography>
                {editMode && (
                  <Button
                    size="small"
                    onClick={() => handleSkillsDialogOpen('technical')}
                  >
                    Edit Skills
                  </Button>
                )}
              </Box>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                {profileData.skills.technical.map((skill) => (
                  <Chip
                    key={skill}
                    label={skill}
                    onDelete={editMode ? () => handleRemoveSkill('technical', skill) : undefined}
                  />
                ))}
              </Box>
            </Box>

            {/* Soft Skills */}
            <Box sx={{ mb: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                <Typography variant="subtitle1" color="textSecondary">
                  Soft Skills
                </Typography>
                {editMode && (
                  <Button
                    size="small"
                    onClick={() => handleSkillsDialogOpen('soft')}
                  >
                    Edit Skills
                  </Button>
                )}
              </Box>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                {profileData.skills.soft.map((skill) => (
                  <Chip
                    key={skill}
                    label={skill}
                    onDelete={editMode ? () => handleRemoveSkill('soft', skill) : undefined}
                  />
                ))}
              </Box>
            </Box>

            {/* Languages */}
            <Box>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                <Typography variant="subtitle1" color="textSecondary">
                  Languages
                </Typography>
                {editMode && (
                  <Button
                    size="small"
                    onClick={() => handleSkillsDialogOpen('languages')}
                  >
                    Edit Languages
                  </Button>
                )}
              </Box>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                {profileData.skills.languages.map((language) => (
                  <Chip
                    key={language}
                    label={language}
                    onDelete={editMode ? () => handleRemoveSkill('languages', language) : undefined}
                  />
                ))}
              </Box>
            </Box>
          </Paper>

          {/* Skills Dialog */}
          <Dialog
            open={skillsDialog.open}
            onClose={handleSkillsDialogClose}
            maxWidth="sm"
            fullWidth
          >
            <DialogTitle>
              Edit {skillsDialog.category ? skillsDialog.category.charAt(0).toUpperCase() + skillsDialog.category.slice(1) : ''} Skills
            </DialogTitle>
            <DialogContent>
              <Autocomplete
                multiple
                options={skillsDialog.availableSkills}
                value={profileData.skills[skillsDialog.category] || []}
                onChange={(event, newValue) => handleAddSkill(newValue)}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    variant="outlined"
                    label="Select Skills"
                    placeholder="Type or select skills"
                    fullWidth
                    sx={{ mt: 2 }}
                  />
                )}
                freeSolo
              />
            </DialogContent>
            <DialogActions>
              <Button onClick={handleSkillsDialogClose} color="inherit">
                Cancel
              </Button>
              <Button onClick={handleSkillsDialogClose} color="primary">
                Done
              </Button>
            </DialogActions>
          </Dialog>

          {/* Social Links */}
          <Paper sx={{ p: 3, mb: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">
                Social Links
              </Typography>
            </Box>
            <List>
              <ListItem>
                <ListItemIcon>
                  <LinkedInIcon color={editMode ? "primary" : "inherit"} />
                </ListItemIcon>
                {editMode ? (
                  <TextField
                    fullWidth
                    label="LinkedIn URL"
                    value={tempProfileData.socialLinks.linkedin}
                    onChange={handleProfileInputChange('socialLinks.linkedin')}
                    placeholder="https://linkedin.com/in/username"
                    sx={{ ml: 2 }}
                  />
                ) : (
                  <ListItemText
                    primary="LinkedIn"
                    secondary={profileData.socialLinks.linkedin}
                    sx={{
                      '& .MuiListItemText-secondary': {
                        color: 'primary.main',
                        textDecoration: 'underline',
                        cursor: 'pointer',
                      },
                    }}
                    onClick={() => window.open(profileData.socialLinks.linkedin, '_blank')}
                  />
                )}
              </ListItem>
              <ListItem>
                <ListItemIcon>
                  <GitHubIcon color={editMode ? "primary" : "inherit"} />
                </ListItemIcon>
                {editMode ? (
                  <TextField
                    fullWidth
                    label="GitHub URL"
                    value={tempProfileData.socialLinks.github}
                    onChange={handleProfileInputChange('socialLinks.github')}
                    placeholder="https://github.com/username"
                    sx={{ ml: 2 }}
                  />
                ) : (
                  <ListItemText
                    primary="GitHub"
                    secondary={profileData.socialLinks.github}
                    sx={{
                      '& .MuiListItemText-secondary': {
                        color: 'primary.main',
                        textDecoration: 'underline',
                        cursor: 'pointer',
                      },
                    }}
                    onClick={() => window.open(profileData.socialLinks.github, '_blank')}
                  />
                )}
              </ListItem>
              <ListItem>
                <ListItemIcon>
                  <LanguageIcon color={editMode ? "primary" : "inherit"} />
                </ListItemIcon>
                {editMode ? (
                  <TextField
                    fullWidth
                    label="Portfolio URL"
                    value={tempProfileData.socialLinks.portfolio}
                    onChange={handleProfileInputChange('socialLinks.portfolio')}
                    placeholder="https://yourportfolio.com"
                    sx={{ ml: 2 }}
                  />
                ) : (
                  <ListItemText
                    primary="Portfolio"
                    secondary={profileData.socialLinks.portfolio}
                    sx={{
                      '& .MuiListItemText-secondary': {
                        color: 'primary.main',
                        textDecoration: 'underline',
                        cursor: 'pointer',
                      },
                    }}
                    onClick={() => window.open(profileData.socialLinks.portfolio, '_blank')}
                  />
                )}
              </ListItem>
            </List>
          </Paper>

          {/* Documents */}
          <Paper sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">
                Documents
              </Typography>
              <Button
                variant="contained"
                component="label"
                startIcon={<CloudUploadIcon />}
              >
                Upload File
                <input
                  type="file"
                  hidden
                  accept=".pdf,.doc,.docx"
                  onChange={handleFileUpload}
                />
              </Button>
            </Box>
            <List>
              {documents.map((document) => (
                <ListItem
                  key={document.id}
                  secondaryAction={
                    <IconButton
                      edge="end"
                      aria-label="delete"
                      onClick={() => handleDocumentDelete(document.id)}
                    >
                      <DeleteIcon />
                    </IconButton>
                  }
                >
                  <ListItemIcon>
                    <DescriptionIcon />
                  </ListItemIcon>
                  <ListItemText
                    primary={document.name}
                    secondary={
                      <>
                        <Typography component="span" variant="body2">
                          Uploaded: {document.uploadDate}
                        </Typography>
                        <br />
                        <Chip
                          size="small"
                          label={document.status}
                          color={document.status === 'verified' ? 'success' : 'warning'}
                          sx={{ mt: 1 }}
                        />
                      </>
                    }
                  />
                </ListItem>
              ))}
            </List>
          </Paper>
        </Grid>
      </Grid>
      {editMode && (
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2, mt: 2 }}>
          <Button variant="contained" color="primary" onClick={handleSaveProfile}>Save</Button>
          <Button variant="outlined" color="error" onClick={handleCancelEdit}>Cancel</Button>
        </Box>
      )}
    </Box>
  );
}

export default Profile; 