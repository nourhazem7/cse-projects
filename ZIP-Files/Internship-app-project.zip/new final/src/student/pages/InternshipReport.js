import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  Typography,
  Paper,
  TextField,
  Grid,
  Button,
  IconButton,
  List,
  ListItem,
  ListItemText,
  Divider,
  Tooltip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  OutlinedInput,
} from '@mui/material';
import {
  ArrowBack as ArrowBackIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Add as AddIcon,
  Save as SaveIcon,
  Visibility as VisibilityIcon,
} from '@mui/icons-material';

// Theme colors
const navyBlue = '#0A1929';

// Available courses mock data
const availableCourses = [
  { code: 'CS101', name: 'Introduction to Programming' },
  { code: 'CS202', name: 'Data Structures' },
  { code: 'CS303', name: 'Software Engineering' },
  { code: 'CS404', name: 'Database Systems' },
  { code: 'CS505', name: 'Web Development' },
  { code: 'CS606', name: 'Mobile Development' },
  { code: 'CS707', name: 'Cloud Computing' },
  { code: 'CS808', name: 'Artificial Intelligence' },
];

function InternshipReport() {
  const { internshipId } = useParams();
  const navigate = useNavigate();
  const [internship, setInternship] = useState(null);
  const [reports, setReports] = useState([]);
  const [currentReport, setCurrentReport] = useState({
    title: '',
    introduction: '',
    body: '',
    lastModified: null,
    status: 'draft', // draft or submitted
    helpfulCourses: [] // Add helpfulCourses to the report state
  });
  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [viewMode, setViewMode] = useState(false);

  useEffect(() => {
    // Load internship data
    const internships = JSON.parse(localStorage.getItem('internships') || '[]');
    const foundInternship = internships.find(i => i.id === parseInt(internshipId));
    setInternship(foundInternship);

    // Load reports for this internship
    const savedReports = JSON.parse(localStorage.getItem(`reports_${internshipId}`) || '[]');
    setReports(savedReports);
  }, [internshipId]);

  const handleSave = (isDraft = true) => {
    if (!validateReport()) {
      return;
    }

    const newReport = {
      ...currentReport,
      lastModified: new Date().toISOString(),
      status: isDraft ? 'draft' : 'submitted'
    };

    let updatedReports;
    if (editingId !== null) {
      updatedReports = reports.map(report => 
        report.id === editingId ? { ...newReport, id: editingId } : report
      );
    } else {
      updatedReports = [...reports, { ...newReport, id: Date.now() }];
    }

    localStorage.setItem(`reports_${internshipId}`, JSON.stringify(updatedReports));
    setReports(updatedReports);
    resetForm();
  };

  const handleEdit = (report) => {
    setCurrentReport({
      ...report,
      lastModified: new Date().toISOString()
    });
    setEditingId(report.id);
    setIsEditing(true);
    setViewMode(false);
  };

  const handleView = (report) => {
    setCurrentReport(report);
    setEditingId(report.id);
    setViewMode(true);
    setIsEditing(false);
  };

  const handleDelete = (reportId) => {
    if (window.confirm('Are you sure you want to delete this report? This action cannot be undone.')) {
      const updatedReports = reports.filter(report => report.id !== reportId);
      localStorage.setItem(`reports_${internshipId}`, JSON.stringify(updatedReports));
      setReports(updatedReports);
      
      // If we're currently editing/viewing this report, reset the form
      if (editingId === reportId) {
        resetForm();
    }
    }
  };

  const handleCancel = () => {
    if (isEditing && editingId !== null) {
      // If we're editing an existing report, confirm before canceling
      if (window.confirm('Are you sure you want to cancel? Any unsaved changes will be lost.')) {
        resetForm();
      }
    } else {
      resetForm();
    }
  };

  const validateReport = () => {
    if (!currentReport.title.trim()) {
      alert('Please provide a title');
      return false;
    }
    if (!currentReport.introduction.trim()) {
      alert('Please provide an introduction');
      return false;
    }
    if (!currentReport.body.trim()) {
      alert('Please provide report content');
      return false;
    }
    if (currentReport.helpfulCourses.length === 0) {
      alert('Please select at least one helpful course');
      return false;
    }
    return true;
  };

  const resetForm = () => {
    setCurrentReport({
      title: '',
      introduction: '',
      body: '',
      lastModified: null,
      status: 'draft',
      helpfulCourses: []
    });
    setIsEditing(false);
    setEditingId(null);
    setViewMode(false);
  };

  if (!internship) {
    return <Typography>Loading...</Typography>;
  }

  return (
    <Box sx={{ flexGrow: 1 }}>
      {/* Header Section */}
      <Box sx={{ 
        mb: 4,
        p: 3,
        bgcolor: navyBlue,
        borderRadius: 2,
        color: 'white',
        display: 'flex',
        alignItems: 'center',
        gap: 2
      }}>
        <IconButton color="inherit" onClick={() => navigate('/student/internship-management')}>
          <ArrowBackIcon />
        </IconButton>
          <Box>
          <Typography variant="h4" gutterBottom>
            Internship Reports
          </Typography>
          <Typography variant="subtitle1">
            {internship.companyName} - {internship.jobTitle}
                    </Typography>
        </Box>
                </Box>

      <Grid container spacing={3}>
        {/* Reports List */}
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 2, height: '100%' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">My Reports</Typography>
                  <Button
                variant="contained"
                startIcon={<AddIcon />}
                onClick={() => {
                  setIsEditing(true);
                  setViewMode(false);
                  setEditingId(null);
                  setCurrentReport({
                    title: '',
                    introduction: '',
                    body: '',
                    lastModified: null,
                    status: 'draft',
                    helpfulCourses: []
                  });
                }}
                disabled={isEditing || viewMode}
              >
                New Report
                  </Button>
            </Box>
            <List>
              {reports.map((report) => (
                <React.Fragment key={report.id}>
                  <ListItem
                    sx={{
                      bgcolor: editingId === report.id ? 'action.selected' : 'transparent',
                      borderRadius: 1,
                      '&:hover': {
                        bgcolor: 'action.hover',
                      },
                    }}
                  >
                    <ListItemText
                      primary={
                        <Typography variant="subtitle1" sx={{ fontWeight: 500 }}>
                          {report.title}
                        </Typography>
                      }
                      secondary={
                        <Box>
                          <Typography variant="caption" display="block" sx={{ color: report.status === 'submitted' ? 'success.main' : 'info.main' }}>
                            Status: {report.status.charAt(0).toUpperCase() + report.status.slice(1)}
                          </Typography>
                          <Typography variant="caption">
                            Last modified: {new Date(report.lastModified).toLocaleString()}
                          </Typography>
                        </Box>
                      }
                    />
                    <Box sx={{ display: 'flex', gap: 1 }}>
                      <Tooltip title="View">
                        <IconButton
                          size="small"
                          onClick={() => handleView(report)}
                          sx={{
                            '&:hover': { color: 'primary.main' }
                          }}
                        >
                          <VisibilityIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Edit Report">
                        <IconButton
                          size="small"
                          onClick={() => handleEdit(report)}
                          sx={{
                            '&:hover': { color: 'primary.main' }
                          }}
                        >
                          <EditIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Delete Report">
                        <IconButton
                          size="small"
                          onClick={() => handleDelete(report.id)}
                          sx={{
                            '&:hover': { color: 'error.main' }
                          }}
                        >
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                </Box>
                  </ListItem>
                  <Divider sx={{ my: 1 }} />
                </React.Fragment>
              ))}
              {reports.length === 0 && (
                <Typography color="text.secondary" align="center">
                  No reports yet. Create your first report!
                </Typography>
              )}
            </List>
          </Paper>
              </Grid>

        {/* Report Form */}
        <Grid item xs={12} md={8}>
          {(isEditing || viewMode) && (
            <Paper sx={{ p: 3 }}>
              <Typography variant="h6" gutterBottom>
                {viewMode ? 'View Report' : (editingId ? 'Edit Report' : 'New Report')}
              </Typography>
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Report Title"
                    value={currentReport.title}
                    onChange={(e) => setCurrentReport({ ...currentReport, title: e.target.value })}
                  required
                    disabled={viewMode}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  multiline
                  rows={4}
                  label="Introduction"
                    value={currentReport.introduction}
                    onChange={(e) => setCurrentReport({ ...currentReport, introduction: e.target.value })}
                  required
                    disabled={viewMode}
                    helperText="Provide an overview of your report"
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  multiline
                  rows={8}
                  label="Report Body"
                    value={currentReport.body}
                    onChange={(e) => setCurrentReport({ ...currentReport, body: e.target.value })}
                  required
                    disabled={viewMode}
                    helperText="Detailed content of your report"
                />
              </Grid>
              <Grid item xs={12}>
                  <FormControl fullWidth disabled={viewMode}>
                    <InputLabel id="courses-label">Helpful Courses</InputLabel>
                    <Select
                      labelId="courses-label"
                      multiple
                      value={currentReport.helpfulCourses}
                      onChange={(e) => setCurrentReport({ ...currentReport, helpfulCourses: e.target.value })}
                      input={<OutlinedInput label="Helpful Courses" />}
                      renderValue={(selected) => (
                        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                          {selected.map((courseCode) => {
                            const course = availableCourses.find(c => c.code === courseCode);
                            return (
                              <Chip 
                                key={courseCode} 
                                label={`${courseCode} - ${course?.name}`} 
                                size="small"
                              />
                            );
                          })}
                        </Box>
                      )}
                    >
                      {availableCourses.map((course) => (
                        <MenuItem key={course.code} value={course.code}>
                          {course.code} - {course.name}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12}>
                  <Box sx={{ display: 'flex', gap: 2, justifyContent: 'flex-end' }}>
                    <Button variant="outlined" onClick={handleCancel}>
                      {viewMode ? 'Close' : 'Cancel'}
                    </Button>
                    {!viewMode && (
                      <>
                  <Button
                    variant="outlined"
                    startIcon={<SaveIcon />}
                          onClick={() => handleSave(true)}
                          color="primary"
                  >
                          Save as Draft
                  </Button>
                  <Button
                    variant="contained"
                          onClick={() => handleSave(false)}
                    color="primary"
                  >
                          Submit Report
                  </Button>
                      </>
                    )}
                </Box>
              </Grid>
            </Grid>
            </Paper>
          )}
        </Grid>
      </Grid>
    </Box>
  );
}

export default InternshipReport; 