import React from 'react';
import {
  Box,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Drawer,
  IconButton,
  Typography,
} from '@mui/material';
import {
  Dashboard as DashboardIcon,
  Work as WorkIcon,
  Business as BusinessIcon,
  Assignment as AssignmentIcon,
  CheckCircle as CheckCircleIcon,
  Menu as MenuIcon,
  ManageAccounts as ManageAccountsIcon,
  Download as DownloadIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

const StudentSidebar = ({ open, onToggle }) => {
  const navigate = useNavigate();

  const sections = [
    {
      items: [
        { text: 'Dashboard', icon: <DashboardIcon />, path: '/student/dashboard' }
      ]
    },
    {
      title: 'Find Internships',
      items: [
        { text: 'Browse All Internships', icon: <WorkIcon />, path: '/student/internships' },
        { text: 'Suggested Companies', icon: <BusinessIcon />, path: '/student/suggested-companies' },
        { text: 'Internship Management', icon: <ManageAccountsIcon />, path: '/student/internship-management' }
      ]
    },
    {
      title: 'My Applications',
      items: [
        { text: 'Application Status', icon: <AssignmentIcon />, path: '/student/application-status' },
        { text: 'Past Applications', icon: <CheckCircleIcon />, path: '/student/past-applications' }
      ]
    },
    {
      title: 'Documents',
      items: [
        { text: 'Download Files', icon: <DownloadIcon />, path: '/student/downloads' }
      ]
    }
  ];

  return (
    <Drawer
      variant="permanent"
      sx={{
        width: open ? 240 : 70,
        transition: 'width 0.3s',
        '& .MuiDrawer-paper': {
          width: open ? 240 : 70,
          transition: 'width 0.3s',
          backgroundColor: '#0A1929',
          color: 'white',
          overflowX: 'hidden',
        },
      }}
    >
      <Box sx={{ p: 2, display: 'flex', alignItems: 'center', justifyContent: open ? 'space-between' : 'center' }}>
        {open && (
          <Typography variant="h6" component="div">
            Student Portal
          </Typography>
        )}
        <IconButton onClick={onToggle} sx={{ color: 'white' }}>
          <MenuIcon />
        </IconButton>
      </Box>

      {sections.map((section, index) => (
        <Box key={index}>
          {section.title && open && (
            <Typography
              variant="subtitle2"
              sx={{
                px: 3,
                py: 2,
                color: 'rgba(255, 255, 255, 0.7)',
                fontSize: '0.875rem',
              }}
            >
              {section.title}
            </Typography>
          )}
          <List>
            {section.items.map((item) => (
              <ListItem
                button
                key={item.text}
                onClick={() => navigate(item.path)}
                sx={{
                  minHeight: 48,
                  justifyContent: open ? 'initial' : 'center',
                  px: 2.5,
                  '&:hover': {
                    backgroundColor: '#1A2B3C',
                  },
                }}
              >
                <ListItemIcon
                  sx={{
                    minWidth: 0,
                    mr: open ? 3 : 'auto',
                    justifyContent: 'center',
                    color: 'white',
                  }}
                >
                  {item.icon}
                </ListItemIcon>
                <ListItemText
                  primary={item.text}
                  sx={{
                    opacity: open ? 1 : 0,
                    color: 'white',
                  }}
                />
              </ListItem>
            ))}
          </List>
        </Box>
      ))}
    </Drawer>
  );
};

export default StudentSidebar; 