import React, { useState, useEffect } from 'react';
import {
  AppBar,
  Box,
  Drawer,
  IconButton,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Typography,
  Menu,
  MenuItem,
  Avatar,
  Badge,
  Divider,
  ListSubheader,
  Chip,
} from '@mui/material';
import DashboardIcon from '@mui/icons-material/Dashboard';
import WorkIcon from '@mui/icons-material/Work';
import PersonIcon from '@mui/icons-material/Person';
import LogoutIcon from '@mui/icons-material/Logout';
import EmailIcon from '@mui/icons-material/Email';
import MenuIcon from '@mui/icons-material/Menu';
import BusinessIcon from '@mui/icons-material/Business';
import NewReleasesIcon from '@mui/icons-material/NewReleases';
import DescriptionIcon from '@mui/icons-material/Description';
import WorkHistoryIcon from '@mui/icons-material/WorkHistory';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import PendingIcon from '@mui/icons-material/Pending';
import DownloadIcon from '@mui/icons-material/Download';
import AssessmentIcon from '@mui/icons-material/Assessment';
import PlayCircleOutlineIcon from '@mui/icons-material/PlayCircleOutline';
import NotificationsActiveIcon from '@mui/icons-material/NotificationsActive';
import NotificationsIcon from '@mui/icons-material/Notifications';
import { useNavigate, Outlet } from 'react-router-dom';

const drawerWidth = 240;
const navyBlue = '#0A1929';
const lightNavyBlue = '#1A2B3C';

// Updated dummy email notifications with types
const initialEmails = [
  {
    id: 1,
    title: 'Interview Invitation',
    message: 'You have been invited for an interview at Tech Corp.',
    read: false,
    time: '1 hour ago',
    type: 'interview'
  },
  {
    id: 2,
    title: 'Application Received',
    message: 'Your internship application has been received by Innovation Labs.',
    read: false,
    time: '3 hours ago',
    type: 'application'
  },
  {
    id: 3,
    title: 'Document Request',
    message: 'Please submit your updated resume for the Data Science position.',
    read: false,
    time: '1 day ago',
    type: 'document'
  }
];

function StudentLayout() {
  const [isDrawerOpen, setIsDrawerOpen] = useState(true);
  const [profileAnchorEl, setProfileAnchorEl] = useState(null);
  const [emailAnchorEl, setEmailAnchorEl] = useState(null);
  const [emails, setEmails] = useState(initialEmails);
  const [notificationAnchorEl, setNotificationAnchorEl] = useState(null);
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      title: 'SCAD Report Status Update',
      message: 'Your SCAD report for Tech Corp has been approved. Click to view details.',
      type: 'report',
      icon: <DescriptionIcon sx={{ color: '#4caf50' }} />,
      timestamp: 'Just now',
      read: false
    },
    {
      id: 2,
      title: 'Internship Cycle Update',
      message: 'The next internship cycle will begin in 2 weeks',
      type: 'warning',
      icon: <NotificationsActiveIcon sx={{ color: '#ff9800' }} />,
      timestamp: '30 minutes ago',
      read: false
    },
    {
      id: 3,
      title: 'New Internship Opportunity',
      message: 'A new internship position has been posted in your field.',
      type: 'opportunity',
      icon: <WorkIcon sx={{ color: '#4caf50' }} />,
      timestamp: '2 hours ago',
      read: false
    },
    {
      id: 4,
      title: 'Application Status Update',
      message: 'Your application for Company XYZ has been reviewed.',
      type: 'status',
      icon: <DescriptionIcon sx={{ color: '#2196f3' }} />,
      timestamp: '1 day ago',
      read: false
    }
  ]);
  const navigate = useNavigate();

  const unreadEmailCount = emails.filter(email => !email.read).length;
  const unreadNotificationCount = notifications.filter(n => !n.read).length;

  // Add localStorage persistence for drawer state
  useEffect(() => {
    const savedDrawerState = localStorage.getItem('drawerOpen');
    if (savedDrawerState !== null) {
      setIsDrawerOpen(savedDrawerState === 'true');
    }
  }, []);

  // Define menu items with sections
  const menuItems = [
    {
      type: 'section',
      items: [
        { text: 'Dashboard', icon: <DashboardIcon />, path: '/student/dashboard' },
      ]
    },
    {
      type: 'section',
      title: 'Find Internships',
      items: [
        { text: 'Browse All Internships', icon: <WorkIcon />, path: '/student/internships' },
        { text: 'Suggested Companies', icon: <BusinessIcon />, path: '/student/suggested-companies' },
        { text: 'Internship Management', icon: <WorkHistoryIcon />, path: '/student/internship-management' },
        { text: 'Requirements Videos', icon: <PlayCircleOutlineIcon />, path: '/student/internship-requirements' },
      ]
    },
    {
      type: 'section',
      title: 'My Applications',
      items: [
        { text: 'Application Status', icon: <PendingIcon />, path: '/student/application-status' },
        { text: 'Past Applications', icon: <CheckCircleIcon />, path: '/student/past-applications' },
      ]
    },
    {
      type: 'section',
      title: 'Reports',
      items: [
        { text: 'SCAD Reports', icon: <AssessmentIcon />, path: '/student/scad-reports' },
        { text: 'Download Files', icon: <DownloadIcon />, path: '/student/downloads' },
      ]
    }
  ];

  const handleDrawerToggle = () => {
    const newState = !isDrawerOpen;
    setIsDrawerOpen(newState);
    localStorage.setItem('drawerOpen', newState.toString());
  };

  const handleProfileMenuOpen = (event) => {
    setProfileAnchorEl(event.currentTarget);
  };

  const handleProfileMenuClose = () => {
    setProfileAnchorEl(null);
  };

  const handleEmailMenuOpen = (event) => {
    setEmailAnchorEl(event.currentTarget);
  };

  const handleEmailMenuClose = () => {
    setEmailAnchorEl(null);
  };

  const handleLogout = () => {
    handleProfileMenuClose();
    // Add logout logic here
    navigate('/');
  };

  const handleProfile = () => {
    handleProfileMenuClose();
    navigate('/student/profile');
  };

  const handleEmailClick = (emailId) => {
    setEmails(emails.map(email =>
      email.id === emailId ? { ...email, read: true } : email
    ));
  };

  const handleMarkAllEmailsRead = () => {
    setEmails(emails.map(email => ({ ...email, read: true })));
    handleEmailMenuClose();
  };

  // Function to get email icon based on type
  const getEmailIcon = (type) => {
    switch (type) {
      case 'interview':
        return <BusinessIcon sx={{ color: '#4CAF50' }} />;
      case 'application':
        return <DescriptionIcon sx={{ color: '#2196F3' }} />;
      case 'document':
        return <NewReleasesIcon sx={{ color: '#f44336' }} />;
      default:
        return <EmailIcon sx={{ color: '#757575' }} />;
    }
  };

  const handleNotificationMenuOpen = (event) => setNotificationAnchorEl(event.currentTarget);
  const handleNotificationMenuClose = () => setNotificationAnchorEl(null);
  const handleNotificationClick = (id) => {
    setNotifications(notifications.map(n => n.id === id ? { ...n, read: true } : n));
  };
  const handleMarkAllNotificationsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })));
    handleNotificationMenuClose();
  };

  // Notification menu PaperProps and header style
  const notificationPaperProps = {
    sx: {
      width: 320,
      maxHeight: 440,
      overflow: 'auto',
      backgroundColor: 'white',
      boxShadow: '0px 5px 15px rgba(0, 0, 0, 0.2)',
      borderRadius: '8px',
      '& .MuiDivider-root': {
        borderColor: 'rgba(0, 0, 0, 0.12)'
      }
    }
  };
  const navyHeaderStyle = {
    p: 2,
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    background: navyBlue,
    color: 'white',
    borderTopLeftRadius: '8px',
    borderTopRightRadius: '8px'
  };

  return (
    <Box sx={{ display: 'flex' }}>
      <AppBar
        position="fixed"
        sx={{
          backgroundColor: navyBlue,
          width: { sm: `calc(100% - ${isDrawerOpen ? drawerWidth : 64}px)` },
          ml: { sm: `${isDrawerOpen ? drawerWidth : 64}px` },
          transition: 'width 0.3s, margin-left 0.3s',
        }}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            onClick={handleDrawerToggle}
            edge="start"
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" component="div">
            Student Portal
          </Typography>
          <Box sx={{ 
            display: 'flex', 
            alignItems: 'center', 
            ml: 'auto',
            gap: 2 // Add consistent gap between icons
          }}>
            <IconButton
              size="large"
              color="inherit"
              onClick={handleNotificationMenuOpen}
              sx={{ 
                p: 1,
                '&:hover': { backgroundColor: 'rgba(255, 255, 255, 0.1)' }
              }}
            >
              <Badge badgeContent={unreadNotificationCount} color="error">
                <NotificationsIcon />
              </Badge>
            </IconButton>
            <IconButton
              size="large"
              color="inherit"
              onClick={handleEmailMenuOpen}
              sx={{ 
                p: 1,
                '&:hover': { backgroundColor: 'rgba(255, 255, 255, 0.1)' }
              }}
            >
              <Badge badgeContent={unreadEmailCount} color="error">
                <EmailIcon />
              </Badge>
            </IconButton>
            <IconButton
              size="large"
              color="inherit"
              onClick={handleProfileMenuOpen}
              sx={{ 
                p: 1,
                '&:hover': { backgroundColor: 'rgba(255, 255, 255, 0.1)' }
              }}
            >
              <Avatar sx={{ width: 32, height: 32 }} />
            </IconButton>
          </Box>

          {/* Email Menu */}
          <Menu
            anchorReference="anchorPosition"
            anchorPosition={emailAnchorEl ? { top: 64, left: window.innerWidth - 24 } : undefined}
            open={Boolean(emailAnchorEl)}
            onClose={handleEmailMenuClose}
            PaperProps={notificationPaperProps}
            transformOrigin={{ horizontal: 'right', vertical: 'top' }}
          >
            {/* Header */}
            <Box sx={navyHeaderStyle}>
              <Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: 'white' }}>
                Email Notifications
              </Typography>
              <Chip
                label={`${unreadEmailCount} new`}
                size="small"
                color="error"
                sx={{ display: unreadEmailCount ? 'flex' : 'none' }}
              />
            </Box>
            <Divider />
            <List dense sx={{ p: 0, bgcolor: 'white' }}>
              {emails.length === 0 ? (
                <ListItem>
                  <ListItemText
                    primary={<Typography sx={{ color: 'rgba(0,0,0,0.5)' }}>No emails</Typography>}
                  />
                </ListItem>
              ) : (
                emails.map((email) => (
                  <ListItem
                    key={email.id}
                    button
                    onClick={() => handleEmailClick(email.id)}
                    sx={{
                      py: 1.5,
                      px: 2,
                      borderBottom: '1px solid rgba(0, 0, 0, 0.08)',
                      backgroundColor: email.read ? 'white' : 'rgba(25, 118, 210, 0.05)',
                      '&:hover': {
                        backgroundColor: email.read ? 'rgba(0, 0, 0, 0.04)' : 'rgba(25, 118, 210, 0.1)',
                      }
                    }}
                  >
                    <ListItemIcon sx={{ minWidth: '40px' }}>
                      {getEmailIcon(email.type)}
                    </ListItemIcon>
                    <ListItemText
                      primary={email.title}
                      secondary={email.message}
                      primaryTypographyProps={{
                        color: navyBlue,
                        fontWeight: email.read ? 'normal' : 'bold',
                        fontSize: '0.95rem'
                      }}
                      secondaryTypographyProps={{
                        color: 'text.secondary',
                        fontSize: '0.85rem'
                      }}
                      sx={{ mr: 1 }}
                    />
                    <Typography
                      variant="caption"
                      sx={{
                        color: 'text.secondary',
                        alignSelf: 'flex-start',
                        whiteSpace: 'nowrap'
                      }}
                    >
                      {email.time}
                    </Typography>
                  </ListItem>
                ))
              )}
            </List>
            <Box
              sx={{
                display: 'flex',
                justifyContent: 'center',
                p: 1.5,
                borderTop: '1px solid rgba(0, 0, 0, 0.08)',
                backgroundColor: 'white'
              }}
            >
              <Typography
                variant="body2"
                sx={{
                  cursor: 'pointer',
                  color: navyBlue,
                  fontWeight: 500,
                  display: unreadEmailCount ? 'block' : 'none',
                  '&:hover': {
                    textDecoration: 'underline'
                  }
                }}
                onClick={unreadEmailCount ? handleMarkAllEmailsRead : undefined}
              >
                Mark all as read
              </Typography>
            </Box>
          </Menu>

          {/* Notification Menu */}
          <Menu
            anchorReference="anchorPosition"
            anchorPosition={notificationAnchorEl ? { top: 64, left: window.innerWidth - 24 } : undefined}
            open={Boolean(notificationAnchorEl)}
            onClose={handleNotificationMenuClose}
            PaperProps={notificationPaperProps}
            transformOrigin={{ horizontal: 'right', vertical: 'top' }}
          >
            {/* Header */}
            <Box sx={navyHeaderStyle}>
              <Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: 'white' }}>
                System Notifications
              </Typography>
              <Chip
                label={`${unreadNotificationCount} new`}
                size="small"
                color="error"
                sx={{ display: unreadNotificationCount ? 'flex' : 'none' }}
              />
            </Box>
            <Divider />
            <List dense sx={{ p: 0, bgcolor: 'white' }}>
              {notifications.length === 0 ? (
                <ListItem>
                  <ListItemText
                    primary={<Typography sx={{ color: 'rgba(0,0,0,0.5)' }}>No notifications</Typography>}
                  />
                </ListItem>
              ) : (
                notifications.map((notification) => (
                  <ListItem
                    key={notification.id}
                    button
                    onClick={() => handleNotificationClick(notification.id)}
                    sx={{
                      py: 1.5,
                      px: 2,
                      borderBottom: '1px solid rgba(0, 0, 0, 0.08)',
                      backgroundColor: notification.read ? 'white' : 'rgba(25, 118, 210, 0.05)',
                      '&:hover': {
                        backgroundColor: notification.read ? 'rgba(0, 0, 0, 0.04)' : 'rgba(25, 118, 210, 0.1)',
                      }
                    }}
                  >
                    <ListItemIcon sx={{ minWidth: '40px' }}>
                      {notification.icon}
                    </ListItemIcon>
                    <ListItemText
                      primary={notification.title}
                      secondary={notification.message}
                      primaryTypographyProps={{
                        color: navyBlue,
                        fontWeight: notification.read ? 'normal' : 'bold',
                        fontSize: '0.95rem'
                      }}
                      secondaryTypographyProps={{
                        color: 'text.secondary',
                        fontSize: '0.85rem'
                      }}
                      sx={{ mr: 1 }}
                    />
                    <Typography
                      variant="caption"
                      sx={{
                        color: 'text.secondary',
                        alignSelf: 'flex-start',
                        whiteSpace: 'nowrap'
                      }}
                    >
                      {notification.timestamp}
                    </Typography>
                  </ListItem>
                ))
              )}
            </List>
            <Box
              sx={{
                display: 'flex',
                justifyContent: 'center',
                p: 1.5,
                borderTop: '1px solid rgba(0, 0, 0, 0.08)',
                backgroundColor: 'white'
              }}
            >
              <Typography
                variant="body2"
                sx={{
                  cursor: 'pointer',
                  color: navyBlue,
                  fontWeight: 500,
                  display: unreadNotificationCount ? 'block' : 'none',
                  '&:hover': {
                    textDecoration: 'underline'
                  }
                }}
                onClick={unreadNotificationCount ? handleMarkAllNotificationsRead : undefined}
              >
                Mark all as read
              </Typography>
            </Box>
          </Menu>

          {/* Profile Menu */}
          <Menu
            anchorEl={profileAnchorEl}
            open={Boolean(profileAnchorEl)}
            onClose={handleProfileMenuClose}
            PaperProps={{
              elevation: 0,
              sx: {
                overflow: 'visible',
                filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
                mt: 1.5,
                bgcolor: 'background.paper',
                color: 'text.primary',
                borderRadius: 3,
                minWidth: 340,
                p: 0,
              },
            }}
            transformOrigin={{ horizontal: 'right', vertical: 'top' }}
            anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
          >
            {/* Header */}
            <Box sx={{ bgcolor: navyBlue, color: 'white', px: 3, py: 2, borderTopLeftRadius: 12, borderTopRightRadius: 12 }}>
              <Typography variant="h6" sx={{ fontWeight: 600 }}>
                Profile Options
              </Typography>
            </Box>
            <Divider />
            <MenuItem onClick={handleProfile} sx={{ py: 2, px: 3 }}>
              <ListItemIcon>
                <PersonIcon fontSize="medium" sx={{ color: '#1976d2' }} />
              </ListItemIcon>
              <Typography sx={{ fontWeight: 500, fontSize: '1.1rem' }}>Profile</Typography>
            </MenuItem>
            <Divider />
            <MenuItem onClick={handleLogout} sx={{ py: 2, px: 3 }}>
              <ListItemIcon>
                <LogoutIcon fontSize="medium" sx={{ color: '#d32f2f' }} />
              </ListItemIcon>
              <Typography sx={{ fontWeight: 500, fontSize: '1.1rem', color: '#d32f2f' }}>Logout</Typography>
            </MenuItem>
          </Menu>
        </Toolbar>
      </AppBar>

      <Box
        component="nav"
        sx={{ 
          width: { sm: isDrawerOpen ? drawerWidth : 64 }, 
          flexShrink: { sm: 0 },
          transition: 'width 0.3s'
        }}
      >
        <Drawer
          variant="permanent"
          sx={{
            display: 'block',
            '& .MuiDrawer-paper': {
              boxSizing: 'border-box',
              width: isDrawerOpen ? drawerWidth : 64,
              bgcolor: navyBlue,
              borderRight: '1px solid rgba(255, 255, 255, 0.12)',
              transition: 'width 0.3s',
              overflowX: 'hidden',
            },
          }}
          open={isDrawerOpen}
        >
          <Box sx={{ bgcolor: navyBlue, color: 'white', height: '100%' }}>
            <Toolbar sx={{ 
              bgcolor: lightNavyBlue, 
              display: 'flex', 
              justifyContent: 'center',
              alignItems: 'center',
              minHeight: '80px !important',
              borderBottom: '1px solid rgba(255, 255, 255, 0.12)'
            }}>
              <Box sx={{ 
                display: 'flex', 
                flexDirection: 'column', 
                alignItems: 'center',
                opacity: isDrawerOpen ? 1 : 0,
                transition: 'opacity 0.3s'
              }}>
                <Typography variant="h6" sx={{ 
                  fontWeight: 'bold',
                  letterSpacing: '0.5px',
                  fontSize: '1.2rem',
                  color: '#fff'
                }}>
                  GUC SYSTEM
                </Typography>
                <Typography variant="subtitle2" sx={{ 
                  color: 'rgba(255, 255, 255, 0.7)',
                  fontSize: '0.75rem',
                  marginTop: '4px'
                }}>
                  Student Portal
                </Typography>
              </Box>
            </Toolbar>
            <List>
              {menuItems.map((section, sectionIndex) => (
                <React.Fragment key={section.title || sectionIndex}>
                  {section.title && isDrawerOpen && (
                    <ListSubheader
                      sx={{
                        bgcolor: 'transparent',
                        color: 'rgba(255, 255, 255, 0.7)',
                        lineHeight: '30px',
                        mt: sectionIndex === 0 ? 0 : 2,
                      }}
                    >
                      {section.title}
                    </ListSubheader>
                  )}
                  {section.items.map((item) => (
                    <ListItem
                      button
                      key={item.text}
                      onClick={() => navigate(item.path)}
                      sx={{
                        '&:hover': {
                          bgcolor: lightNavyBlue,
                        },
                        px: isDrawerOpen ? 2 : 1.5,
                        justifyContent: isDrawerOpen ? 'initial' : 'center',
                        minHeight: 48,
                      }}
                    >
                      <ListItemIcon 
                        sx={{ 
                          color: 'white', 
                          minWidth: isDrawerOpen ? 40 : 'auto',
                          mr: isDrawerOpen ? 2 : 'auto',
                        }}
                      >
                        {item.icon}
                      </ListItemIcon>
                      {isDrawerOpen && <ListItemText primary={item.text} />}
                    </ListItem>
                  ))}
                </React.Fragment>
              ))}
            </List>
          </Box>
        </Drawer>
      </Box>
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: 3,
          width: { sm: `calc(100% - ${isDrawerOpen ? drawerWidth : 64}px)` },
          transition: 'width 0.3s, margin-left 0.3s',
        }}
      >
        <Toolbar />
        <Outlet />
      </Box>
    </Box>
  );
}

export default StudentLayout; 