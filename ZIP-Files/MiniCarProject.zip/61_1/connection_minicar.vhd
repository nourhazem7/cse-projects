library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Mini_Car_Top is
    Port (
        btn_forward   : in  STD_LOGIC;
        btn_backward  : in  STD_LOGIC;
        btn_right     : in  STD_LOGIC;
        btn_left      : in  STD_LOGIC;
        lane_sensor   : in  STD_LOGIC;
        motor_signals : out STD_LOGIC_VECTOR(3 downto 0);
        seven_seg     : out STD_LOGIC_VECTOR(6 downto 0)
    );
end Mini_Car_Top;

architecture Combined of Mini_Car_Top is
   
    constant CHAR_A : STD_LOGIC_VECTOR(6 downto 0) := "0001000";
    constant CHAR_L : STD_LOGIC_VECTOR(6 downto 0) := "1000111";
    constant CHAR_E : STD_LOGIC_VECTOR(6 downto 0) := "0000110";
    constant CHAR_R : STD_LOGIC_VECTOR(6 downto 0) := "0101111";
    constant CHAR_T : STD_LOGIC_VECTOR(6 downto 0) := "0000111";
    constant BLANK  : STD_LOGIC_VECTOR(6 downto 0) := "1111111";


    signal char_index   : INTEGER := 0;
    signal current_char : STD_LOGIC_VECTOR(6 downto 0) := BLANK;

   
    signal alert_signal : STD_LOGIC;

begin
   
    process(btn_forward, btn_backward, btn_right, btn_left)
    begin
        motor_signals <= (3 downto 0 => '0');
        motor_signals(0) <= btn_forward;
        motor_signals(1) <= btn_backward;
        motor_signals(2) <= btn_right;
        motor_signals(3) <= btn_left;
    end process;

 
    alert_signal <= lane_sensor;

   
    process(alert_signal)
    begin
        if alert_signal = '1' then
            case char_index is
                when 0 => current_char <= CHAR_A;
                when 1 => current_char <= CHAR_L;
                when 2 => current_char <= CHAR_E;
                when 3 => current_char <= CHAR_R;
                when 4 => current_char <= CHAR_T;
                when others => current_char <= BLANK;
            end case;
            char_index <= (char_index + 1) mod 5;
        else
            current_char <= BLANK;
            char_index <= 0;
        end if;
    end process;

    seven_seg <= current_char;
end Combined;