library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Mini_Car_Top is
    Port (
switch_1      :in  STD_LOGIC;
switch_2      :in  STD_LOGIC;
switch_3      :in  STD_LOGIC;
switch_4      :in  STD_LOGIC;
sensor_in     :in STD_LOGIC_VECTOR(1 DOWNTO 0);
A      :out STD_LOGIC_VECTOR(6 DOWNTO 0 );
L      :out STD_LOGIC_VECTOR(6 DOWNTO 0 );
E      :out STD_LOGIC_VECTOR(6 DOWNTO 0 );
R      :out STD_LOGIC_VECTOR(6 DOWNTO 0 );
T      :out STD_LOGIC_VECTOR(6 DOWNTO 0 );
right_motor_1 :out STD_LOGIC;
right_motor_2 :out STD_LOGIC;
left_motor_1  :out STD_LOGIC;
left_motor_2 :out STD_LOGIC;
LED      :out STD_LOGIC
    );
end Mini_Car_Top;

architecture Combined of Mini_Car_Top is
begin

process (sensor_in)  
begin

left_motor_1<='0';
left_motor_2<='0';
right_motor_1<='0';
right_motor_2<='0';


if sensor_in="00" then
LED<='1';
A(6 DOWNTO 0)<="0001000";
L(6 DOWNTO 0)<="1110001";
E(6 DOWNTO 0)<="0110000";
R(6 DOWNTO 0)<="0111001";
T(6 DOWNTO 0)<="1110000";

right_motor_1<='0';
right_motor_2<='0';
left_motor_1<='0';
left_motor_2<='0';

else
LED<='0';
A(6 DOWNTO 0)<="1111111";
L(6 DOWNTO 0)<="1111111";
E(6 DOWNTO 0)<="1111111";
R(6 DOWNTO 0)<="1111111";
T(6 DOWNTO 0)<="1111111";

if switch_1 = '1' and switch_2='0'  then     
right_motor_1<='1';
right_motor_2<='0';
elsif   switch_1 = '1' and switch_2 = '1' then  
right_motor_1<='0';
right_motor_2<='1';
else
right_motor_1<='0';
right_motor_2<='0';
end if;

if switch_3 = '1' and switch_4 = '0' then    --
left_motor_1<='0';
left_motor_2<='1';
elsif  switch_3 = '1' and switch_4 = '1'  then       --
left_motor_1<='1';
left_motor_2<='0';
else
left_motor_1<='0';
left_motor_2<='0';
end if;


end if ;

end process;
end Combined ;
