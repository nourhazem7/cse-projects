LIBRARY ieee;
USE ieee.std_logic_1164.ALL;

ENTITY DigitalClock_tb IS
END DigitalClock_tb;

ARCHITECTURE Behavioral OF DigitalClock_tb IS
    SIGNAL clk : STD_LOGIC := '0';
    SIGNAL reset_n : STD_LOGIC := '1'; 
    SIGNAL sec : INTEGER RANGE 0 TO 59;
    SIGNAL min : INTEGER RANGE 0 TO 59;
    SIGNAL hr : INTEGER RANGE 0 TO 23;

    CONSTANT clk_period : TIME := 20 NS; 
    COMPONENT DigitalClock
        PORT (
            clk : IN STD_LOGIC;
            reset_n : IN STD_LOGIC;
            seconds : OUT INTEGER RANGE 0 TO 59;
            minutes :OUT INTEGER RANGE 0 TO 59;
            hours : OUT INTEGER RANGE 0 TO 23
        );
    END COMPONENT;
BEGIN

    UUT: DigitalClock
        PORT MAP (
            clk => clk,
            reset_n => reset_n,
            seconds => sec,
            minutes => min,
            hours => hr
        );

   
    clk_process : PROCESS
    BEGIN
        clk <= '0';
        WAIT FOR 10 ps;
        clk <= '1';
        WAIT FOR 10 ps;
    END PROCESS clk_process;


    reset_process : PROCESS
    BEGIN
        reset_n <= '1'; 
        WAIT FOR 40 ps;
        reset_n <= '0'; 
        WAIT FOR 20 ps; 
	reset_n <= '1';
        WAIT; 
    END PROCESS reset_process;

END Behavioral;

