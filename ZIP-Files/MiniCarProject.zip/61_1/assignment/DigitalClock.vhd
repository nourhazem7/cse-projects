library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity DigitalClock is
    Port (
        clk : in STD_LOGIC;
        reset_n : in STD_LOGIC; 
        seconds : out INTEGER RANGE 0 TO 59;
        minutes : out INTEGER RANGE 0 TO 59;
        hours :out INTEGER RANGE 0 TO 23
    );
end DigitalClock;

architecture Behavioral of DigitalClock is
    signal sec : Integer Range 0 TO 59;
    signal min :INTEGER RANGE 0 TO 59;
    signal hr : INTEGER RANGE 0 TO 23;
    
begin

    process(clk)
    begin
        if rising_edge(clk) then
            if reset_n = '0' then 
                sec <=0;
                min <= 0;
                hr <= 0;
            else
                    if sec = 59 then
                        sec <= 0;
                        if min = 59 then
                            min <= 0;
                            if hr = 23 then
                                hr <= 0;
                            else
                                hr <= hr + 1;
                            end if;
                        else
                            min <= min + 1;
                        end if;
                    else
                        sec <= sec + 1;
                    end if;
               
            end if;
        end if;
    end process;

    
    seconds <= sec;
    minutes <= min;
    hours <= hr;

end Behavioral;

