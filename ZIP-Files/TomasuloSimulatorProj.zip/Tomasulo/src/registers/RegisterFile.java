package registers;

import java.util.HashMap;
import java.util.Map;

/**
 * Integer register file.
 * Registers are named like R0, R1, ... or simply numbers (we normalize to uppercase).
 */
public class RegisterFile {

    private final Map<String, Integer> regs = new HashMap<>();

    public RegisterFile() {
        // optionally pre-fill registers with zero
    }

    public int getInt(String reg) {
        if (reg == null) return 0;
        String key = reg.toUpperCase();
        Integer v = regs.get(key);
        return v == null ? 0 : v;
    }

    public void setInt(String reg, int value) {
        if (reg == null) return;
        regs.put(reg.toUpperCase(), value);
    }

    // convenience for loading multiple registers
    public void preload(String reg, int value) {
        setInt(reg, value);
    }
    
    public void debugPrint() {
        System.out.println("Integer Register File (Register : Value):");
        for (int i = 0; i <= 31; i++) {
            String regName = "R" + i;
            int value = regs.getOrDefault(regName, 0);
            System.out.println(regName + " : " + value);
        }
    }

}
