package registers;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * RegisterStatus tracks which reservation station will produce the value for a register (Qi).
 * If a register has no pending producer, the tag is null or empty.
 */
public class RegisterStatus {

    private final Map<String, String> tagMap = new HashMap<>();

    public RegisterStatus() {}

    /**
     * Get the producer tag for a register (Qi). Returns null or empty if value ready.
     */
    public String getTag(String reg) {
        if (reg == null) return null;
        String t = tagMap.get(reg.toUpperCase());
        return t == null ? "" : t;
    }

    /**
     * Set the producer tag for a destination register.
     */
    public void setTag(String reg, String tag) {
        if (reg == null) return;
        tagMap.put(reg.toUpperCase(), tag);
    }

    /**
     * Clear the producer tag for a register (value now available).
     */
    public void clearTag(String reg) {
        if (reg == null) return;
        tagMap.remove(reg.toUpperCase());
    }
    
    
    public Set<String> getAllRegisters() {
        return tagMap.keySet();
    }

    public void debugPrint() {
        System.out.println("Register Status (Register : Qi):");
        if (tagMap.isEmpty()) {
            System.out.println("  <all registers ready>");
            return;
        }
        for (Map.Entry<String, String> entry : tagMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }
    }

}
