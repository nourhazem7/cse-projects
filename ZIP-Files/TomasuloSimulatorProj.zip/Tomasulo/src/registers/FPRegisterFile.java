package registers;

import java.util.HashMap;
import java.util.Map;

/**
 * Floating-point register file.
 * Registers named F0, F1, F2, etc.
 */
public class FPRegisterFile {

    private final Map<String, Double> regs = new HashMap<>();

    public FPRegisterFile() {}

    public double getFP(String reg) {
        if (reg == null) return 0.0;
        String key = reg.toUpperCase();
        Double v = regs.get(key);
        return v == null ? 0.0 : v;
    }

    public void setFP(String reg, double value) {
        if (reg == null) return;
        regs.put(reg.toUpperCase(), value);
    }

    public void preload(String reg, double value) {
        setFP(reg, value);
    }
    
    public void debugPrint() {
        System.out.println("Floating-Point Register File (Register : Value):");
        for (int i = 0; i <= 31; i++) {
            String regName = "F" + i;
            double value = regs.getOrDefault(regName, 0.0);
            System.out.println(regName + " : " + value);
        }
    }
}
