package memory;

/**
 * Byte-addressable main memory abstraction.
 * Simple read/write methods; bounds checked.
 */
public class Memory {
    public final byte[] mem;

    public Memory(int sizeBytes) {
        if (sizeBytes <= 0) throw new IllegalArgumentException("Memory size must be positive");
        this.mem = new byte[sizeBytes];
    }

    public int size() {
        return mem.length;
    }

    /**
     * Read `len` bytes starting at `address`.
     * Throws IndexOutOfBoundsException if out of range.
     */
    public byte[] readBytes(int address, int len) {
        if (len < 0) throw new IllegalArgumentException("len must be >= 0");
        if (address < 0 || address + len > mem.length) {
            throw new IndexOutOfBoundsException("Memory read out of bounds: " + address + " len " + len);
        }
        byte[] out = new byte[len];
        System.arraycopy(mem, address, out, 0, len);
        return out;
    }

    /**
     * Write `data` bytes starting at `address`.
     */
    public void writeBytes(int address, byte[] data) {
        if (address < 0 || address + data.length > mem.length) {
            throw new IndexOutOfBoundsException("Memory write out of bounds: " + address + " len " + data.length);
        }
        System.arraycopy(data, 0, mem, address, data.length);
    }

    /**
     * Convenience: write a 4-byte word (little-endian).
     */
    public void writeWordLE(int address, int value) {
        byte[] b = new byte[4];
        b[0] = (byte) (value & 0xFF);
        b[1] = (byte) ((value >> 8) & 0xFF);
        b[2] = (byte) ((value >> 16) & 0xFF);
        b[3] = (byte) ((value >> 24) & 0xFF);
        writeBytes(address, b);
    }

    /**
     * Convenience: read a 4-byte word (little-endian).
     */
    public int readWordLE(int address) {
        byte[] b = readBytes(address, 4);
        return ((b[3] & 0xFF) << 24) | ((b[2] & 0xFF) << 16) | ((b[1] & 0xFF) << 8) | (b[0] & 0xFF);
    }
    
    
    public void debugPrint() {
        System.out.println("Memory dump:");
        for (int addr = 0; addr < mem.length; addr++) {
            int val = mem[addr] & 0xFF;
            System.out.println("[" + addr + "] : " + val);
        }
    }

}
