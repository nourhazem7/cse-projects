package memory;

import java.util.Arrays;

import utils.Config;

/**
 * Simple direct-mapped data cache.
 *
 * Mapping strategy:
 * - Block size = B bytes
 * - Number of lines = cacheSize / B = N
 * - For memory address A:
 *    blockNumber = A / B
 *    index = blockNumber % N
 *    tag = blockNumber / N (or simply blockNumber)
 *
 * On access:
 *  - compute index and tag
 *  - if block at index.valid && block.tag == blockNumber -> HIT
 *  - else -> MISS: fetch block from memory at starting address blockStart = blockNumber * B
 *
 * This class returns a CacheResult with the requested bytes and cycles consumed.
 */
public class Cache {
    private final CacheBlock[] lines;
    private final int blockSize;
    private final int numLines;
    private final Memory memory;
    private final int hitLatency;
    private final int missPenalty;

    public static class CacheResult {
        public final byte[] data;
        public final boolean isHit;
        public final int cyclesTaken;

        public CacheResult(byte[] data, boolean isHit, int cyclesTaken) {
            this.data = data;
            this.isHit = isHit;
            this.cyclesTaken = cyclesTaken;
        }
    }

    public Cache(Config cfg, Memory memory) {
        this.blockSize = cfg.cacheBlockSize;
        if (cfg.cacheSize % blockSize != 0) {
            throw new IllegalArgumentException("cacheSize must be multiple of blockSize");
        }
        this.numLines = cfg.cacheSize / blockSize;
        if (numLines <= 0) throw new IllegalArgumentException("cache must have at least 1 line");
        this.lines = new CacheBlock[numLines];
        for (int i = 0; i < numLines; ++i) lines[i] = new CacheBlock(blockSize);
        this.memory = memory;
        this.hitLatency = cfg.cacheHitLatency;
        this.missPenalty = cfg.cacheMissPenalty;
    }

    /**
     * Read `len` bytes from address. Returns bytes, hit-flag, and cycles used.
     * This method handles block loads into the cache on misses.
     */
    public CacheResult readBytesAccurate(int address, int len) {
        if (len < 0) throw new IllegalArgumentException("len must be >= 0");

        byte[] out = new byte[len];
        int blockNumber = address / blockSize;
        int blockStart = blockNumber * blockSize;
        int index = blockNumber % numLines;
        CacheBlock line = lines[index];

        boolean hit = (line.valid && line.tag == blockNumber && line.blockStartAddress == address);
        int cycles = 0;
 
        if (!hit) {
            // MISS: fetch full block from memory
            byte[] blockData = memory.readBytes(blockStart, blockSize);
            line.loadFromMemory(blockData, blockSize);
            line.tag = blockNumber;
            line.blockStartAddress = address;     //  store the starting address
            cycles += missPenalty;   // count MISS once
        }
        else
        {
        	cycles += hitLatency;
        }
        
     
        // on miss, read from MEMORY (cache already updated for next time)
        byte[] memoryData = memory.readBytes(address, len);
        System.arraycopy(memoryData, 0, out, 0, len);
        

        line.lastUsed = System.nanoTime();
        return new CacheResult(out, hit, cycles);
    }

    
    /**
     * PROBE write: Only compute cycles. DO NOT modify memory or cache.
     * Used for store RS to determine execution latency.
     */
    public CacheResult probeWriteBytes(int address, byte[] data) {
        int blockNumber = address / blockSize;
        int index = blockNumber % numLines;
        CacheBlock line = lines[index];

        boolean hit = (line.valid && line.tag == blockNumber && line.blockStartAddress == address);

        int cycles = hit ? hitLatency : missPenalty;
        
        if (!hit) {
            line.blockStartAddress = address;     //  store the starting address
        }

        return new CacheResult(null, hit, cycles);
    }

    
    /**
     * Write bytes to address. For simplicity, use write-back with write-allocate:
     * - If the block is present in cache, update it (and memory write happens on block eviction or explicit write-back).
     * - If not present, fetch the block into cache (write-allocate), then update it.
     *
     * Note: For Tomasulo and correctness, you may choose write-through semantics instead;
     * adjust this method to your preferred policy. The PDF doesn't mandate a policy;
     * document whichever you choose. Here we implement write-allocate & update cache block immediately.
     *
     * Returns cycles consumed and hit-flag.
     */
    public CacheResult writeBytes(int address, byte[] data) {

        int blockNumber = address / blockSize;
        int blockStart = blockNumber * blockSize;
        int index = blockNumber % numLines;
        CacheBlock line = lines[index];

        boolean hit = (line.valid && line.tag == blockNumber && line.blockStartAddress == address);
        int cycles = hit ? hitLatency : missPenalty;

        // write-allocate
        if (!hit) {
            byte[] blockData = memory.readBytes(blockStart, blockSize);
            line.loadFromMemory(blockData, blockSize);
            line.tag = blockNumber;
            line.blockStartAddress = address;     //  store the starting address
        }

        // Write the actual bytes
        memory.writeBytes(address, data);
        
        // 2) Write to CACHE LINE as well (write-through)
        int offset = address - line.blockStartAddress;
        for (int i = 0; i < data.length; i++) {
            int pos = offset + i;
            if (pos >= 0 && pos < blockSize) {
                line.data[pos] = data[i];
            }
        }

        line.lastUsed = System.nanoTime();

        return new CacheResult(data, hit, cycles);
    }

    
    // Optional helper: expose blockSize for GUI
    public int getBlockSize() {
        return blockSize;
    }

    public int getNumLines() {
        return numLines;
    }
    
    public void debugPrint() {
        System.out.println("\n===== CACHE CONTENT =====");
        for (int i = 0; i < lines.length; i++) {
            CacheBlock line = lines[i];
            System.out.print("Line " + i + ": ");
            System.out.print("valid=" + line.valid + ", tag=" + line.tag + ", data=[");
            for (byte b : line.data) {
                System.out.print((b & 0xFF) + " ");
            }
            System.out.println("]");
        }
    }

    
//===================================================================================================================//
 
    /**
     * Helper for GUI: produce a snapshot list where each element is a String[]
     * representing: { lineIndex, valid, tag, dataString }.
     */
    public java.util.List<String[]> getLinesAsStrings() {
        java.util.List<String[]> rows = new java.util.ArrayList<>();
        for (int i = 0; i < lines.length; i++) {
            CacheBlock line = lines[i];
            StringBuilder sb = new StringBuilder();
            sb.append("[");
            for (int j = 0; j < line.data.length; j++) {
                if (j > 0) sb.append(" ");
                sb.append((line.data[j] & 0xFF));
            }
            sb.append("]");
            rows.add(new String[] { Integer.toString(i), Boolean.toString(line.valid), Long.toString(line.tag), sb.toString() });
        }
        return rows;
    }    

//===================================================================================================================//

}
