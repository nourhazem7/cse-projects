package memory;

public class MemoryInit {

    /**
     * Writes an 8-byte FP value to memory (little-endian, integer-style handling)
     */
    public static void writeFP(Memory memory, int address, long value) {
        byte[] bytes = new byte[8];
        for (int i = 0; i < 8; i++) {
            bytes[i] = (byte) ((value >> (8 * i)) & 0xFF); // 8 bits per byte
        }
        memory.writeBytes(address, bytes);
    }

    /**
     * Writes a 4-byte integer to memory (little-endian)
     */
    public static void writeINT(Memory memory, int address, int value) {
        byte[] bytes = new byte[4];
        for (int i = 0; i < 4; i++) {
            bytes[i] = (byte) ((value >> (8 * i)) & 0xFF); // 8 bits per byte
        }
        memory.writeBytes(address, bytes);
    }
    
    /**
     * Writes a 1-byte value to memory.
     */
    public static void writeByte(Memory memory, int address, int value) {
        byte[] bytes = new byte[1];
        bytes[0] = (byte)(value & 0xFF);   // lowest 8 bits only
        memory.writeBytes(address, bytes);
    }


    /**
     * Initialize Memory for Test Cases
     */
    public static void initTestCase1(Memory memory) {
        // Each FP value occupies 8 bytes, addresses must not overlap

    	writeFP(memory, 0, 4);
       // writeINT(memory, 4, 15); 
       // writeINT(memory, 8, 2);
       // writeINT(memory, 16, 7);
        writeFP(memory, 20, 44);
      //  writeINT(memory, 24, 9); 
        //writeINT(memory, 32, 5); 
    }
}
