package memory;

/**
 * Represents a single cache block (line) in the direct-mapped cache.
 * Holds the block's data and tag/valid metadata.
 */
public class CacheBlock {
    public boolean valid;
    public int tag;         // blockTag (block number)
    public byte[] data;     // length = blockSize
    public int blockStartAddress;
    public long lastUsed;   // optional LRU timestamp if we later move to associativity

    public CacheBlock(int blockSize) {
        this.valid = false;
        this.tag = -1;
        this.data = new byte[blockSize];
        this.blockStartAddress = -1;
        this.lastUsed = 0;
    }

    public void loadFromMemory(byte[] blockData, int blockSize) {
        System.arraycopy(blockData, 0, this.data, 0, blockSize);
        this.valid = true;
    }
}
