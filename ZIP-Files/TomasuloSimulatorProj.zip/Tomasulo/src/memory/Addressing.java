package memory;

/**
 * Addressing helpers. For this project we implement a single effective address formula:
 * EA = baseRegisterValue + offset.
 *
 * This class centralizes addressing semantics so we can document them clearly (PDF requirement).
 */
public class Addressing {

    /**
     * Compute effective address given base register value and offset.
     * (We assume signed offset; integer arithmetic.)
     *
     * @param baseValue value of base register (in bytes)
     * @param offset    immediate offset (in bytes)
     * @return effective address (non-negative int)
     */
    public static int computeEffectiveAddress(int baseValue, int offset) {
        // In java, overflow wraps; we assume addresses fit in int and check bounds at memory access time.
        return baseValue + offset;
    }

    /**
     * For aligned accesses (e.g., word read), compute block start address.
     *
     * @param address incoming byte-address
     * @param blockSize block size in bytes
     * @return start (base) address of the block containing this address
     */
    public static int blockStartAddress(int address, int blockSize) {
        return (address / blockSize) * blockSize;
    }
}
