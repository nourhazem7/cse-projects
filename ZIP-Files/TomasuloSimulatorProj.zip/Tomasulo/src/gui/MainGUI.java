package gui;

import core.*;
import memory.Cache;
import memory.Memory;
import memory.MemoryInit;
import registers.FPRegisterFile;
import registers.RegisterFile;
import registers.RegisterStatus;
import stations.*;
import utils.Config;

import javafx.application.Application;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.List;
import java.util.Map;

/**
 * Simple JavaFX GUI for the Tomasulo simulator.
 *
 * Requirements:
 * - TomasuloEngine must expose getters (see instructions in assistant response).
 * - Cache must expose getLinesAsStrings method (see instructions above).
 */
public class MainGUI extends Application {

    private TomasuloEngine engine;

    // UI controls
    private Label cycleLabel = new Label("Cycle: 0");
    private Label cdbLabel = new Label("No broadcast yet");
    private Button nextCycleBtn = new Button("Next Cycle");
    private Button startBtn = new Button("Start Simulation");

    // Tables for stations
    private TableView<stations.StationEntry> fpAddTable = new TableView<>();
    private TableView<stations.StationEntry> fpMultTable = new TableView<>();
    private TableView<stations.StationEntry> intTable = new TableView<>();
    private TableView<stations.StationEntry> fpLoadTable = new TableView<>();
    private TableView<stations.StationEntry> fpStoreTable = new TableView<>();
    private TableView<stations.StationEntry> intLoadTable = new TableView<>();
    private TableView<stations.StationEntry> intStoreTable = new TableView<>();

    // Register tables
    private TableView<RegRow> intRegTable = new TableView<>();
    private TableView<RegRow> fpRegTable = new TableView<>();
    private TableView<RegStatusRow> regStatusTable = new TableView<>();

    // cache and memory change views
    private TableView<String[]> cacheTable = new TableView<>();
    private TextArea memChangesArea = new TextArea();

    // config inputs
    private TextField cacheBlockSizeField = new TextField("8");
    private TextField cacheSizeField = new TextField("32");
    private TextField cacheHitLatencyField = new TextField("1");
    private TextField cacheMissPenaltyField = new TextField("4");
    private TextField fpAddLatencyField = new TextField("3");
    private TextField fpSubLatencyField = new TextField("3");
    private TextField fpMulLatencyField = new TextField("3");
    private TextField fpDivLatencyField = new TextField("3");
    private TextField intAddLatencyField = new TextField("3");
    private TextField intSubLatencyField = new TextField("3");
    private TextField fpAddSizeField = new TextField("3");
    private TextField fpMultSizeField = new TextField("2");
    private TextField intStationSizeField = new TextField("3");
    private TextField fpLoadSizeField = new TextField("3");
    private TextField fpStoreSizeField = new TextField("3");
    private TextField intLoadSizeField = new TextField("3");
    private TextField intStoreSizeField = new TextField("3");
    private TextField programPathField = new TextField("program1");

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Tomasulo Simulator (GUI)");

        BorderPane root = new BorderPane();
        root.setPadding(new Insets(8));

        // top: config pane
        VBox topBox = new VBox(6);
        topBox.setPadding(new Insets(6));
        topBox.getChildren().add(createConfigPane());
        root.setTop(topBox);

        // center: split pane with stations + registers
        SplitPane centerSplit = new SplitPane();
        centerSplit.setOrientation(javafx.geometry.Orientation.HORIZONTAL);

        // Left: stations
        VBox stationsBox = new VBox(8);
        stationsBox.setPadding(new Insets(6));
        stationsBox.getChildren().addAll(new Label("Reservation Stations (click Start)"),
                new Label("FP ADD"), fpAddTable,
                new Label("FP MULT"), fpMultTable,
                new Label("INT ALU"), intTable,
                new Label("FP LOAD"), fpLoadTable,
                new Label("FP STORE"), fpStoreTable,
                new Label("INT LOAD"), intLoadTable,
                new Label("INT STORE"), intStoreTable
        );
        stationsBox.setPrefWidth(1200);  

        // Right: registers + cache + mem changes
        VBox rightBox = new VBox(8);
        rightBox.setPadding(new Insets(6));

        rightBox.getChildren().addAll(
        		new Label("CDB Broadcast:"), cdbLabel, 
                new Label("Integer Registers"), intRegTable,
                new Label("FP Registers"), fpRegTable,
                new Label("Register Status (Qi)"), regStatusTable,
                new Label("Cache"), cacheTable,
                new Label("Memory changes (this cycle)"), memChangesArea
        );
        
        regStatusTable.setPrefHeight(260);  
        cacheTable.setPrefHeight(260);

        ScrollPane leftScroll = new ScrollPane(stationsBox);
        leftScroll.setFitToWidth(true);     // table fits horizontally
        leftScroll.setFitToHeight(false);   // important: allow vertical scrolling
        leftScroll.setPannable(true);
        leftScroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        leftScroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);

        ScrollPane rightScroll = new ScrollPane(rightBox);
        rightScroll.setFitToWidth(true);
        rightScroll.setFitToHeight(false);   // allow vertical scrolling
        rightScroll.setPannable(true);
        rightScroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        rightScroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);

        centerSplit.getItems().addAll(leftScroll, rightScroll);


        root.setCenter(centerSplit);

        // bottom: control bar
        HBox bottom = new HBox(8);
        bottom.setPadding(new Insets(6));
        cycleLabel.setMinWidth(120);
        nextCycleBtn.setDisable(true);
        bottom.getChildren().addAll(startBtn, nextCycleBtn, cycleLabel);
        root.setBottom(bottom);

        // prepare tables (columns)
        prepareStationTable(fpAddTable);
        prepareStationTable(fpMultTable);
        prepareStationTable(intTable);
        prepareStationTable(fpLoadTable);
        prepareStationTable(fpStoreTable);
        prepareStationTable(intLoadTable);
        prepareStationTable(intStoreTable);

        prepareRegTable(intRegTable);
        prepareRegTable(fpRegTable);

        prepareRegStatusTable();

        prepareCacheTable();

        memChangesArea.setEditable(false);
        memChangesArea.setPrefRowCount(6);

        // button actions
        startBtn.setOnAction(e -> onStartSimulation());
        nextCycleBtn.setOnAction(e -> onNextCycle());

        Scene scene = new Scene(root, 1200, 820);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // ----------------- UI helpers -----------------

    private TitledPane createConfigPane() {
        GridPane g = new GridPane();
        g.setVgap(4);
        g.setHgap(6);

        int r = 0;
        g.add(new Label("cacheBlockSize"), 0, r); g.add(cacheBlockSizeField, 1, r++);
        g.add(new Label("cacheSize"), 0, r); g.add(cacheSizeField, 1, r++);
        g.add(new Label("cacheHitLatency"), 0, r); g.add(cacheHitLatencyField, 1, r++);
        g.add(new Label("cacheMissPenalty"), 0, r); g.add(cacheMissPenaltyField, 1, r++);
        g.add(new Label("FP ADD latency"), 2, 0); g.add(fpAddLatencyField, 3, 0);
        g.add(new Label("FP SUB latency"), 2, 1); g.add(fpSubLatencyField, 3, 1);
        g.add(new Label("FP MUL latency"), 2, 2); g.add(fpMulLatencyField, 3, 2);
        g.add(new Label("FP DIV latency"), 2, 3); g.add(fpDivLatencyField, 3, 3);
        g.add(new Label("INT ADD latency"), 2, 4); g.add(intAddLatencyField, 3, 4);
        g.add(new Label("INT SUB latency"), 2, 5); g.add(intSubLatencyField, 3, 5);

        int rr = 0;
        g.add(new Label("FP Add station size"), 4, rr); g.add(fpAddSizeField, 5, rr++);
        g.add(new Label("FP Mult station size"), 4, rr); g.add(fpMultSizeField, 5, rr++);
        g.add(new Label("Integer ALU station size"), 4, rr); g.add(intStationSizeField, 5, rr++);
        g.add(new Label("FP Load buffer size"), 4, rr); g.add(fpLoadSizeField, 5, rr++);
        g.add(new Label("FP Store buffer size"), 4, rr); g.add(fpStoreSizeField, 5, rr++);
        g.add(new Label("Int Load buffer size"), 4, rr); g.add(intLoadSizeField, 5, rr++);
        g.add(new Label("Int Store buffer size"), 4, rr); g.add(intStoreSizeField, 5, rr++);

        g.add(new Label("Program file path"), 0, r); g.add(programPathField, 1, r, 3, 1);

        TitledPane tp = new TitledPane("Configuration (set then click Start Simulation)", g);
        tp.setCollapsible(false);
        return tp;
    }

    private void onStartSimulation() {
        try {
            Config cfg = new Config();

            cfg.cacheBlockSize = Integer.parseInt(cacheBlockSizeField.getText().trim());
            cfg.cacheSize = Integer.parseInt(cacheSizeField.getText().trim());
            cfg.cacheHitLatency = Integer.parseInt(cacheHitLatencyField.getText().trim());
            cfg.cacheMissPenalty = Integer.parseInt(cacheMissPenaltyField.getText().trim());

            cfg.fpAddLatency = Integer.parseInt(fpAddLatencyField.getText().trim());
            cfg.fpSubLatency = Integer.parseInt(fpSubLatencyField.getText().trim());
            cfg.fpMulLatency = Integer.parseInt(fpMulLatencyField.getText().trim());
            cfg.fpDivLatency = Integer.parseInt(fpDivLatencyField.getText().trim());
            cfg.intAddLatency = Integer.parseInt(intAddLatencyField.getText().trim());
            cfg.intSubLatency = Integer.parseInt(intSubLatencyField.getText().trim());

            int fpAddSize = Integer.parseInt(fpAddSizeField.getText().trim());
            int fpMultSize = Integer.parseInt(fpMultSizeField.getText().trim());
            int intStSize = Integer.parseInt(intStationSizeField.getText().trim());
            int fpLoadSize = Integer.parseInt(fpLoadSizeField.getText().trim());
            int fpStoreSize = Integer.parseInt(fpStoreSizeField.getText().trim());
            int intLoadSize = Integer.parseInt(intLoadSizeField.getText().trim());
            int intStoreSize = Integer.parseInt(intStoreSizeField.getText().trim());

            String programPath = programPathField.getText().trim();

            // Build engine (same as your main)
            InstructionQueue queue = new InstructionQueue();
            queue.loadFromFile(programPath);

            Memory memory = new Memory(60);
            MemoryInit.initTestCase1(memory);

            Cache cache = new Cache(cfg, memory);

            RegisterFile intRF = new RegisterFile();
            FPRegisterFile fpRF = new FPRegisterFile();
            RegisterStatus regStatus = new RegisterStatus();
            
            intRF.preload("R1", 0); 
            intRF.preload("R2", 0);
            //intRF.preload("R3", -5);

            fpRF.preload("F1", 5.00);
            fpRF.preload("F3", 10.0);
            fpRF.preload("F4", 2.0); 
            //fpRF.preload("F10", 35.0);
 
            FPAddStation fpAdd = new FPAddStation(fpAddSize);
            FPMultStation fpMult = new FPMultStation(fpMultSize);
            IntStation intSt = new IntStation(intStSize);

            FPLoadBuffer fpLoad = new FPLoadBuffer(fpLoadSize);
            FPStoreBuffer fpStoreBuf = new FPStoreBuffer(fpStoreSize);
            IntLoadBuffer intLoad = new IntLoadBuffer(intLoadSize);
            IntStoreBuffer intStoreBuf = new IntStoreBuffer(intStoreSize);

            IssueUnit issue = new IssueUnit(queue, intRF, fpRF, regStatus,
                    fpAdd, fpMult, intSt, fpLoad, fpStoreBuf, intLoad, intStoreBuf, cfg); 

            ExecuteUnit exec = new ExecuteUnit(fpAdd, fpMult, intSt,
                    fpLoad, fpStoreBuf, intLoad, intStoreBuf,
                    intRF, fpRF, cache, cfg);

            engine = new TomasuloEngine(
                    queue, issue, exec, intRF, fpRF, regStatus,
                    fpAdd, fpMult, intSt, fpLoad, fpStoreBuf,
                    intLoad, intStoreBuf, cache, memory, cfg
            );

            engine.initializeMemorySnapshot();

            // start button usage
            nextCycleBtn.setDisable(false);
            startBtn.setDisable(true);

            // initialize UI with cycle 0 snapshot
            updateAllViews();

        } catch (Exception ex) {
            ex.printStackTrace();
            Alert a = new Alert(Alert.AlertType.ERROR, "Failed to start simulation: " + ex.getMessage());
            a.showAndWait();
        }
    }

    private void onNextCycle() {
        if (engine == null) return;
        engine.stepCycle();
        
        String msg = engine.getLastCdbMessage();
        if (msg == null || msg.isEmpty()) {
            cdbLabel.setText("(No broadcast this cycle)");
        } else {
            cdbLabel.setText(msg);
        }
        
        updateAllViews();

        if (engine.isFinished()) {
            nextCycleBtn.setDisable(true);
            Alert a = new Alert(Alert.AlertType.INFORMATION, "Simulation completed.");
            a.showAndWait();
        }
    }

    private void updateAllViews() {
        cycleLabel.setText("Cycle: " + engine.getCycle());

        // Stations
        updateStationTable(fpAddTable, engine.getFpAddEntries());
        updateStationTable(fpMultTable, engine.getFpMultEntries());
        updateStationTable(intTable, engine.getIntStationEntries());
        updateStationTable(fpLoadTable, engine.getFpLoadEntries());
        updateStationTable(fpStoreTable, engine.getFpStoreEntries());
        updateStationTable(intLoadTable, engine.getIntLoadEntries());
        updateStationTable(intStoreTable, engine.getIntStoreEntries());

        // Registers
        updateRegTable(intRegTable, engine.getIntRegisterFile(), false);
        updateRegTable(fpRegTable, engine.getFpRegisterFile(), true);
        updateRegStatusTable(engine.getRegisterStatus());


        // Cache snapshot
        updateCacheTable(engine.getCacheObject());

        List<Map.Entry<Integer,Integer>> changes = engine.getMemoryChangesAndAdvanceSnapshot();
        if (changes.isEmpty()) {
            memChangesArea.setText("(no changes this cycle)");
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append("=== Memory Changes in Cycle ").append(engine.getCycle()).append(" ===\n");
            for (Map.Entry<Integer,Integer> e : changes) {
                sb.append("mem[").append(e.getKey()).append("] = ").append(e.getValue()).append("\n");
            }
            memChangesArea.setText(sb.toString());
            memChangesArea.positionCaret(0);  // ← forces refresh
        }

    }

    // --------------- table preparation ---------------

    private void prepareStationTable(TableView<stations.StationEntry> table) {
        table.setPrefHeight(160);

        TableColumn<stations.StationEntry, String> idxCol = new TableColumn<>("idx");
        idxCol.setCellValueFactory(c -> {
            stations.StationEntry e = c.getValue();
            // find index by searching parent station entries (slow but fine for a small GUI)
            return new ReadOnlyStringWrapper(Integer.toString(getIndexInParent(e)));
        });
        idxCol.setPrefWidth(40);

        TableColumn<stations.StationEntry, String> busyCol = new TableColumn<>("busy");
        busyCol.setCellValueFactory(c -> new ReadOnlyStringWrapper(Boolean.toString(c.getValue().busy)));
        busyCol.setPrefWidth(60);

        TableColumn<stations.StationEntry, String> tagCol = new TableColumn<>("tag");
        tagCol.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().tag));
        tagCol.setPrefWidth(110);

        TableColumn<stations.StationEntry, String> opCol = new TableColumn<>("op");
        opCol.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().op));
        opCol.setPrefWidth(80);

        TableColumn<stations.StationEntry, String> VjCol = new TableColumn<>("Vj");
        VjCol.setCellValueFactory(c -> {
            stations.StationEntry e = c.getValue();
            // display empty if Qj is non-empty (unknown)
            if (e.Qj != null && !e.Qj.isEmpty()) return new ReadOnlyStringWrapper("");
            return new ReadOnlyStringWrapper(Double.toString(e.Vj));
        });
        VjCol.setPrefWidth(80);

        TableColumn<stations.StationEntry, String> VkCol = new TableColumn<>("Vk");
        VkCol.setCellValueFactory(c -> {
            stations.StationEntry e = c.getValue();
            if (e.Qk != null && !e.Qk.isEmpty()) return new ReadOnlyStringWrapper("");
            return new ReadOnlyStringWrapper(Double.toString(e.Vk));
        });
        VkCol.setPrefWidth(80);

        TableColumn<stations.StationEntry, String> QjCol = new TableColumn<>("Qj");
        QjCol.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().Qj));
        QjCol.setPrefWidth(110);

        TableColumn<stations.StationEntry, String> QkCol = new TableColumn<>("Qk");
        QkCol.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().Qk));
        QkCol.setPrefWidth(110);

        TableColumn<stations.StationEntry, String> ACol = new TableColumn<>("A");
        ACol.setCellValueFactory(c -> new ReadOnlyStringWrapper(Integer.toString(c.getValue().A)));
        ACol.setPrefWidth(60);

        TableColumn<stations.StationEntry, String> destCol = new TableColumn<>("dest");
        destCol.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().dest));
        destCol.setPrefWidth(70);

        TableColumn<stations.StationEntry, String> remCol = new TableColumn<>("remCycles");
        remCol.setCellValueFactory(c -> new ReadOnlyStringWrapper(Integer.toString(c.getValue().remainingCycles)));
        remCol.setPrefWidth(80);

        TableColumn<stations.StationEntry, String> resReadyCol = new TableColumn<>("resultReady");
        resReadyCol.setCellValueFactory(c -> new ReadOnlyStringWrapper(Boolean.toString(c.getValue().resultReady)));
        resReadyCol.setPrefWidth(100);

        table.getColumns().clear();
        table.getColumns().addAll(idxCol, busyCol, tagCol, opCol, VjCol, VkCol, QjCol, QkCol, ACol, destCol, remCol, resReadyCol);
    }

    private int getIndexInParent(stations.StationEntry e) {
        // Try all station arrays to find the index. This is O(N) but N is small.
        stations.StationEntry[] arrs[] = new stations.StationEntry[][] {
                engine.getFpAddEntries(),
                engine.getFpMultEntries(),
                engine.getIntStationEntries(),
                engine.getFpLoadEntries(),
                engine.getFpStoreEntries(),
                engine.getIntLoadEntries(),
                engine.getIntStoreEntries()
        };

        for (stations.StationEntry[] arr : arrs) {
            if (arr == null) continue;
            for (int i = 0; i < arr.length; i++) {
                if (arr[i] == e) return i;
            }
        }
        return -1;
    }

    private void updateStationTable(TableView<stations.StationEntry> table, stations.StationEntry[] entries) {
        ObservableList<stations.StationEntry> items = FXCollections.observableArrayList();
        if (entries != null) {
            for (stations.StationEntry e : entries) items.add(e);
        }
        table.setItems(items);
        table.refresh();   // ← REQUIRED
    }


    // register table (two columns)
    private void prepareRegTable(TableView<RegRow> table) {
        TableColumn<RegRow, String> name = new TableColumn<>("Reg");
        name.setCellValueFactory(new PropertyValueFactory<>("name"));
        name.setPrefWidth(80);
        TableColumn<RegRow, String> val = new TableColumn<>("Value");
        val.setCellValueFactory(new PropertyValueFactory<>("value"));
        val.setPrefWidth(120);
        table.getColumns().clear();
        table.getColumns().addAll(name, val);
        table.setPrefHeight(260);
    }
    
    private void prepareRegStatusTable() {
        TableColumn<RegStatusRow, String> regCol = new TableColumn<>("Register");
        regCol.setCellValueFactory(new PropertyValueFactory<>("reg"));
        regCol.setPrefWidth(80);

        TableColumn<RegStatusRow, String> qiCol = new TableColumn<>("Qi");
        qiCol.setCellValueFactory(new PropertyValueFactory<>("qi"));
        qiCol.setPrefWidth(120);

        regStatusTable.getColumns().clear();
        regStatusTable.getColumns().addAll(regCol, qiCol);
        regStatusTable.setPrefHeight(200);
    }


    private void updateRegTable(TableView<RegRow> table, Object regFileObj, boolean isFp) {
        ObservableList<RegRow> rows = FXCollections.observableArrayList();
        if (isFp) {
            registers.FPRegisterFile rf = (registers.FPRegisterFile) regFileObj;
            for (int i=0;i<32;i++) {
                String n = "F" + i;
                double v = rf.getFP(n);
                rows.add(new RegRow(n, Double.toString(v)));
            }
        } else {
            registers.RegisterFile rf = (registers.RegisterFile) regFileObj;
            for (int i=0;i<32;i++) {
                String n = "R" + i;
                int v = rf.getInt(n);
                rows.add(new RegRow(n, Integer.toString(v)));
            }
        }
        table.setItems(rows);
    }
    
    private void updateRegStatusTable(RegisterStatus rs) {
        ObservableList<RegStatusRow> rows = FXCollections.observableArrayList();

        for (int i = 0; i < 32; i++) {
            String r = "R" + i;
            String tag = rs.getTag(r);
            if (tag != null && !tag.isEmpty()) {
                rows.add(new RegStatusRow(r, tag));
            }
        }
        for (int i = 0; i < 32; i++) {
            String f = "F" + i;
            String tag = rs.getTag(f);
            if (tag != null && !tag.isEmpty()) {
                rows.add(new RegStatusRow(f, tag));
            }
        }

        regStatusTable.setItems(rows);
    }


    // cache table
    private void prepareCacheTable() {
        cacheTable.setPrefHeight(180);
        TableColumn<String[], String> lineCol = new TableColumn<>("Line");
        lineCol.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue()[0]));
        lineCol.setPrefWidth(50);
        TableColumn<String[], String> validCol = new TableColumn<>("valid");
        validCol.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue()[1]));
        validCol.setPrefWidth(60);
        TableColumn<String[], String> tagCol = new TableColumn<>("tag");
        tagCol.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue()[2]));
        tagCol.setPrefWidth(80);
        TableColumn<String[], String> dataCol = new TableColumn<>("data");
        dataCol.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue()[3]));
        dataCol.setPrefWidth(300);

        cacheTable.getColumns().clear();
        cacheTable.getColumns().addAll(lineCol, validCol, tagCol, dataCol);
    }

    private void updateCacheTable(Cache cache) {
        List<String[]> snap = cache.getLinesAsStrings();
        ObservableList<String[]> obs = FXCollections.observableArrayList(snap);
        cacheTable.setItems(obs);
    }

    // ----------------- small models -----------------
    public static class RegRow {
        private final String name;
        private final String value;
        public RegRow(String name, String value) { this.name = name; this.value = value; }
        public String getName() { return name; }
        public String getValue() { return value; }
    }
    
    public static class RegStatusRow {
        private final String reg;
        private final String qi;
        public RegStatusRow(String reg, String qi) {
            this.reg = reg;
            this.qi = qi;
        }
        public String getReg() { return reg; }
        public String getQi() { return qi; }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
