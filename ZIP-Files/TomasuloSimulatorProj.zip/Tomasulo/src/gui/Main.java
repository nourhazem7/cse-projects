package gui;

import core.*;
import memory.Cache;
import memory.Memory;
import memory.MemoryInit;
import registers.*;
import stations.*;
import utils.Config;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws Exception {

        Scanner sc = new Scanner(System.in);

        System.out.println("==== Tomasulo Simulator (Console Mode) ====");

        // ===============================
        // 1. READ CONFIG FROM USER
        // ===============================
        Config cfg = new Config();

        System.out.print("Enter cache block size (bytes): ");
        cfg.cacheBlockSize = sc.nextInt();

        System.out.print("Enter total cache size (bytes): ");
        cfg.cacheSize = sc.nextInt();

        System.out.print("Enter cache hit latency (cycles): ");
        cfg.cacheHitLatency = sc.nextInt();

        System.out.print("Enter cache miss penalty (cycles): ");
        cfg.cacheMissPenalty = sc.nextInt();

        // Instruction latencies
        System.out.print("FP ADD latency: ");
        cfg.fpAddLatency = sc.nextInt();

        System.out.print("FP SUB latency: ");
        cfg.fpSubLatency = sc.nextInt();

        System.out.print("FP MUL latency: ");
        cfg.fpMulLatency = sc.nextInt();

        System.out.print("FP DIV latency: ");
        cfg.fpDivLatency = sc.nextInt();

        System.out.print("Integer ADD latency: ");
        cfg.intAddLatency = sc.nextInt();

        System.out.print("Integer SUB latency: ");
        cfg.intSubLatency = sc.nextInt();

        // Reservation Station Sizes
        System.out.print("FP Add station size: ");
        int fpAddSize = sc.nextInt();

        System.out.print("FP Mult station size: ");
        int fpMultSize = sc.nextInt();

        System.out.print("Integer ALU station size: ");
        int intStSize = sc.nextInt();

        System.out.print("FP Load buffer size: ");
        int fpLoadSize = sc.nextInt();

        System.out.print("FP Store buffer size: ");
        int fpStoreSize = sc.nextInt();

        System.out.print("Int Load buffer size: ");
        int intLoadSize = sc.nextInt();

        System.out.print("Int Store buffer size: ");
        int intStoreSize = sc.nextInt();

        // Program file path
        System.out.print("Enter program file path (e.g., program.txt): ");
        String programPath = sc.next();

        // ===============================
        // 2. CREATE COMPONENTS
        // ===============================
        InstructionQueue queue = new InstructionQueue();
        queue.loadFromFile(programPath);

        Memory memory = new Memory(60);
        // Preload memory for Test Case
        MemoryInit.initTestCase1(memory);
        
        Cache cache = new Cache(cfg, memory); 

        RegisterFile intRF = new RegisterFile();
        FPRegisterFile fpRF = new FPRegisterFile();
        RegisterStatus regStatus = new RegisterStatus();
        
        //intRF.preload("R1", 24);
        //intRF.preload("R2", 3);
        //intRF.preload("R3", -5);

        //fpRF.preload("F2", 4.0);
        //fpRF.preload("F4", 2.0);
        //fpRF.preload("F14", 90.00); 


        // Reservation stations
        FPAddStation fpAdd = new FPAddStation(fpAddSize);
        FPMultStation fpMult = new FPMultStation(fpMultSize);
        IntStation intSt = new IntStation(intStSize);

        FPLoadBuffer fpLoad = new FPLoadBuffer(fpLoadSize);
        FPStoreBuffer fpStoreBuf = new FPStoreBuffer(fpStoreSize);
        IntLoadBuffer intLoad = new IntLoadBuffer(intLoadSize);
        IntStoreBuffer intStoreBuf = new IntStoreBuffer(intStoreSize);

        // Issue + Execute units
        IssueUnit issue = new IssueUnit(queue, intRF, fpRF, regStatus,
                fpAdd, fpMult, intSt, fpLoad, fpStoreBuf, intLoad, intStoreBuf, cfg);

        ExecuteUnit exec = new ExecuteUnit(fpAdd, fpMult, intSt,
                fpLoad, fpStoreBuf, intLoad, intStoreBuf,
                intRF, fpRF, cache, cfg);

        TomasuloEngine engine = new TomasuloEngine(
                queue, issue, exec, intRF, fpRF, regStatus,
                fpAdd, fpMult, intSt, fpLoad, fpStoreBuf,
                intLoad, intStoreBuf, cache, memory, cfg
        );

        // ===============================
        // 3. RUN UNTIL DONE
        // ===============================
        while (!engine.isFinished()) {
            engine.stepCycle();
        }

        System.out.println("Simulation completed.");
    }
}

