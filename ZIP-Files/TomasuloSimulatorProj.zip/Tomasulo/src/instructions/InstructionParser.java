package instructions;

public class InstructionParser {

    public static Instruction parseLine(String line) {
        if (line == null) return null;

        // remove comments
        int c = line.indexOf('#');
        if (c != -1) line = line.substring(0, c);

        line = line.trim();
        if (line.isEmpty()) return null;

        // Remove extra spaces
        line = line.replaceAll("\\s+", " ");
        Instruction instr = new Instruction();
        instr.original = line;

        // Split at first space: opcode + rest
        String[] first = line.split(" ", 2);
        instr.opcode = first[0].toUpperCase();

        if (first.length < 2) {
            System.err.println("Invalid instruction: " + line);
            return null;
        }

        String args = first[1].trim();

        // ====================================================================
        // LOAD / STORE (L.S, L.D, S.S, S.D, LW, SW)
        // ====================================================================
        if (args.contains("(")) {
            return parseLoadStore(instr, args);
        }

        // ====================================================================
        // ALU immediate: ADDI / SUBI / DADDI / DSUBI
        // MUST BE CHECKED BEFORE 3-REG LOGIC
        // ====================================================================
        if (isImmediateOpcode(instr.opcode) &&
            args.split(",").length == 3 &&
            isInteger(args.split(",")[2].trim())) {

            return parseAluImmediate(instr, args);
        }
        
        // ====================================================================
        // BRANCH
        // ====================================================================
        if (instr.opcode.equals("BEQ") || instr.opcode.equals("BNE")) {
            return parseBranch(instr, args);
        }

        // ====================================================================
        // 3-register ALU including FP (ADD.S, ADD.D ... ADD R1, R2, R3)
        // ====================================================================
        if (args.split(",").length == 3) {
            return parseAluThreeReg(instr, args);
        }
        

        System.err.println("Unrecognized instruction format: " + line);
        return null;
    }

    // ---------------------------------------------------------
    // Detect ADDI / SUBI / DADDI / DSUBI
    // ---------------------------------------------------------
    private static boolean isImmediateOpcode(String op) {
        op = op.toUpperCase();
        return op.equals("ADDI") ||
               op.equals("SUBI") ||
               op.equals("DADDI") ||
               op.equals("DSUBI");
    }

    // ---------------------------------------------------------
    // LOAD / STORE including FP .S and .D (LW / LD / SW / SD / L.S / L.D / S.S / S.D)
    // ---------------------------------------------------------
    private static Instruction parseLoadStore(Instruction instr, String args) {
        String[] parts = args.split(",");
        instr.rd = parts[0].trim().toUpperCase(); 

        String right = parts[1].trim();   // "8(R2)"
        String immPart = right.substring(0, right.indexOf("(")).trim();
        String baseReg = right.substring(right.indexOf("(") + 1, right.indexOf(")")).trim();

        instr.rs = baseReg.toUpperCase();
        instr.imm = Integer.parseInt(immPart);

        switch (instr.opcode) {
            case "L.D":
            case "S.D":
                instr.isFloat = true;
                instr.byteSize = 8;
                break;

            case "L.S":
            case "S.S":
                instr.isFloat = true;
                instr.byteSize = 4;
                break;

            case "LW":
            case "SW":
                instr.isFloat = false;
                instr.byteSize = 4;
                break;

            case "LD":   
            case "SD":   
                instr.isFloat = false;
                instr.byteSize = 8;
                break;
                
            default:
                instr.byteSize = 4;
        }
        return instr;
    }

    // ---------------------------------------------------------
    // ALU Immediate (ADDI / SUBI / DADDI / DSUBI)
    // ---------------------------------------------------------
    private static Instruction parseAluImmediate(Instruction instr, String args) {
        String[] parts = args.split(",");
        instr.rd = parts[0].trim().toUpperCase();
        instr.rs = parts[1].trim().toUpperCase();
        instr.imm = Integer.parseInt(parts[2].trim());

        instr.isFloat = false;
        
        // DADDI / DSUBI still produce integer values but may accept 64-bit in a real ISA
        instr.byteSize = 4;

        return instr;
    }

    // ---------------------------------------------------------
    // ALU Three-Reg: FP or Int (ADD.D / ADD.S / SUB.D / SUB.S / MUL.D / MUL.S / DIV.D / DIV.S)
    // (ADD.S F1, F2, F3) OR (ADD R1, R2, R3) 
    // ---------------------------------------------------------
    private static Instruction parseAluThreeReg(Instruction instr, String args) {
        String[] parts = args.split(",");
        instr.rd = parts[0].trim().toUpperCase();
        instr.rs = parts[1].trim().toUpperCase();
        instr.rt = parts[2].trim().toUpperCase();

        // FP detection
        if (instr.opcode.endsWith(".S")) {
            instr.isFloat = true;
            instr.byteSize = 4;
        } else if (instr.opcode.endsWith(".D")) {
            instr.isFloat = true;
            instr.byteSize = 8;
        } else {
            instr.isFloat = false;
            instr.byteSize = 4;
        }

        return instr;
    }

    // ---------------------------------------------------------
    // BRANCH (BEQ / BNE) 
    // ---------------------------------------------------------
    private static Instruction parseBranch(Instruction instr, String args) {
        String[] parts = args.split(",");
        instr.rs = parts[0].trim().toUpperCase();
        instr.rt = parts[1].trim().toUpperCase();

        String last = parts[2].trim();
        instr.imm = isInteger(last) ? Integer.parseInt(last) : 0;

        instr.isFloat = false;
        return instr;
    }

    private static boolean isInteger(String s) {
        try { Integer.parseInt(s); return true; }
        catch (Exception e) { return false; }
    }
}
