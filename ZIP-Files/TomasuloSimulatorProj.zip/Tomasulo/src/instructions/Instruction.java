package instructions;

/**
 * Minimal Instruction model used by parser / queue / Tomasulo units.
 * Fields kept generic and public for simplicity in the simulator.
 */
public class Instruction {
    public String original;   // original assembly line (for debugging)
    public String opcode;     // e.g., "L.D", "ADD.D", "LW", "ADDI", "S.D", "BEQ"
    public String rd;         // destination register (for loads/ALU)
    public String rs;         // source/base register
    public String rt;         // second source (or value register for store)
    public int imm;           // immediate (offset) or branch target placeholder
    public boolean isFloat;   // true for FP instructions (F registers)
    public int byteSize;      // how many bytes this instruction will read/write (4 or 8 for loads/stores)
    public int issueOrder = 0; // global issue order assigned on issue
    public int lineNumber = -1; // optional line number

    public Instruction() {}

    @Override
    public String toString() {
        return "[" + opcode + " " + original + " | issueOrder=" + issueOrder + "]";
    }
}
