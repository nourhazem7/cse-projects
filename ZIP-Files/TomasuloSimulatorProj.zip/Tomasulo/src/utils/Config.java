package utils;

/**
 * Runtime configuration holder. GUI will create and update an instance before simulation starts.
 */
public class Config {
    // Cache settings (in bytes)
    public int cacheBlockSize = 16;   // default block size
    public int cacheSize = 1024;      // default total cache size

    // Cache timing (in cycles)
    public int cacheHitLatency = 1;
    public int cacheMissPenalty = 50; // cycles to fetch a block from main memory

    // Memory size (bytes)
    public int memorySize = 1 << 20; // default 1 MiB

    // Instruction latencies (in cycles) — user-configurable
    public int fpAddLatency = 2;
    public int fpSubLatency = 2;
    public int fpMulLatency = 10;
    public int fpDivLatency = 40;

    public int intAddLatency = 1;
    public int intSubLatency = 1;

    // Loads / Stores use cache latencies (from cacheHitLatency & cacheMissPenalty).
    // Optionally add base overhead cycles for load/store EA calc:
    public int loadAddressCalcLatency = 1; // optional EA compute overhead
    public int storeAddressCalcLatency = 1;

    // Station sizes (user-selectable)
    public int fpAddStationSize = 3;
    public int fpMultStationSize = 2;
    public int intStationSize = 3;
    public int fpLoadBufferSize = 3;
    public int fpStoreBufferSize = 3;
    public int intLoadBufferSize = 3;
    public int intStoreBufferSize = 3;

    public Config() {}

    public Config(int cacheBlockSize, int cacheSize, int cacheHitLatency, int cacheMissPenalty, int memorySize) {
        this.cacheBlockSize = cacheBlockSize;
        this.cacheSize = cacheSize;
        this.cacheHitLatency = cacheHitLatency;
        this.cacheMissPenalty = cacheMissPenalty;
        this.memorySize = memorySize;
    }
}
