package stations;

import instructions.Instruction;

/**
 * Integer store buffer (similar to FPStoreBuffer).
 */
public class IntStoreBuffer extends ReservationStation {

    public IntStoreBuffer(int size) {
        super("IntStore", size);
    }

    public int issueStore(Instruction instr, int effectiveAddress, int issueOrder) {
        int idx = super.issue(instr, issueOrder);
        if (idx == -1) return -1;
        StationEntry e = entries[idx];
        e.A = effectiveAddress;
        return idx;
    }

    public int findReadyStoreEntry() {
        for (int i = 0; i < entries.length; i++) {
            StationEntry e = entries[i];
            if (e.busy && (e.Qj == null || e.Qj.isEmpty()) && e.remainingCycles == 0) return i;
        }
        return -1;
    }

    public boolean hasActiveStoreWithAddress(int addr) {
        for (StationEntry e : getEntries()) {
            if (e.busy && e.A == addr) return true;
        }
        return false;
    }
}
