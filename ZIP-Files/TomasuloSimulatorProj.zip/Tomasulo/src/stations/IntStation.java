package stations;

public class IntStation extends ReservationStation {

    public IntStation(int size) {
        super("IntStation", size);
    }
    
    
    /**
     * Issue into INT ADD station. Returns index or -1 if full.
     */
    public int issue(instructions.Instruction instr, int issueOrder) {
        return super.issue(instr, issueOrder);
    }

    public int findReadyEntry() {
        for (int i = 0; i < entries.length; i++) {
            StationEntry e = entries[i];
            if (e.busy && e.Qj.isEmpty() && e.Qk.isEmpty() && e.remainingCycles == 0)
                return i;
        }
        return -1;
    }

    public StationEntry[] findAllCompletedEntries() {
        return java.util.Arrays.stream(entries)
                .filter(e -> e.busy && e.remainingCycles == 0 && e.instruction != null)
                .toArray(StationEntry[]::new);
    }
}
