package stations;

import instructions.Instruction;

/**
 * Integer load buffer (similar to FPLoadBuffer, but kept separate per our design).
 */
public class IntLoadBuffer extends ReservationStation {

    public IntLoadBuffer(int size) {
        super("IntLoad", size);
    }

    public int issueLoad(Instruction instr, int effectiveAddress, int issueOrder) {
        int idx = super.issue(instr, issueOrder);
        if (idx == -1) return -1;
        StationEntry e = entries[idx];
        e.A = effectiveAddress;
        return idx;
    }

    public int findReadyLoadEntry() {
        for (int i = 0; i < entries.length; i++) {
            StationEntry e = entries[i];
            if (e.busy && (e.Qj == null || e.Qj.isEmpty()) && e.remainingCycles == 0) return i;
        }
        return -1;
    }

    public boolean hasActiveLoadWithAddress(int addr) {
        for (StationEntry e : getEntries()) {
            if (e.busy && e.A == addr) return true;
        }
        return false;
    }
}
