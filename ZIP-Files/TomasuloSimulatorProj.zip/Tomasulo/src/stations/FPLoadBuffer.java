package stations;

import instructions.Instruction;
import registers.RegisterStatus;

/**
 * FP Load Buffer
 *
 * Behavior notes:
 * - Issue: the IssueUnit should compute effective address (EA) using Addressing.computeEffectiveAddress(...)
 *   before calling issueLoad. That allows the load to be checked against store buffer addresses prior to being issued.
 * - issueLoad returns index of entry or -1 if buffer is full.
 * - hasActiveEntryWithAddress/hasActiveStoreWithAddress helpers allow the IssueUnit to check address clashes.
 */
public class FPLoadBuffer extends ReservationStation {

    public FPLoadBuffer(int size) {
        super("FPLoad", size);
    }

    
    /**
     * Issue a load into the buffer. Caller must have computed EA before calling.
     * Returns index or -1 if full.
     */
    public int issueLoad(Instruction instr, int effectiveAddress, int issueOrder) {
        int idx = super.issue(instr, issueOrder);
        if (idx == -1) return -1;
        StationEntry e = entries[idx];
        e.A = effectiveAddress;
        // e.dest should be set by IssueUnit after this call (or we can set here)
        return idx;
    }
    
    /**
     * Find a load entry that is ready to access memory:
     * - busy
     * - EA known (we use A != 0 as proxy, but callers should ensure A set)
     * - value dependencies (none typically)
     */
    public int findReadyLoadEntry() {
        for (int i = 0; i < entries.length; i++) {
            StationEntry e = entries[i];
            if (e.busy && e.remainingCycles == 0 /* not executing */ && (e.Qj == null || e.Qj.isEmpty())) {
                // EA assumed computed; IssueUnit ensures address clash checks before issue
                return i;
            }
        }
        return -1;
    }
    
    /**
     * Check if any active load in this buffer has the same address.
     */
    public boolean hasActiveLoadWithAddress(int address) {
        for (StationEntry e : getEntries()) {
            if (e.busy && e.A == address) return true;
        }
        return false;
    }
}
