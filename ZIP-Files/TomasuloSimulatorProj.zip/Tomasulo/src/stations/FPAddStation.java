package stations;

public class FPAddStation extends ReservationStation {

    public FPAddStation(int size) {
        super("FPAdd", size);
    }
    
    /**
     * Issue into FP Add station. Returns index or -1 if full.
     */
    public int issue( instructions.Instruction instr, int issueOrder) {
        return super.issue(instr, issueOrder);
    }

    /**
     * Find an entry index that is ready to start executing (operands ready and not already executing).
     * Returns index or -1 if none.
     * Note: "ready" here means Qj=="" and Qk=="" and remainingCycles==0 and busy==true.
     */
    public int findReadyEntry() {
        for (int i = 0; i < entries.length; i++) {
            StationEntry e = entries[i];
            if (e.busy && e.Qj.isEmpty() && e.Qk.isEmpty() && e.remainingCycles == 0)
            	// not executing yet, operands ready
                return i;
        }
        return -1;
    }

    /**
     * Return any entries currently completed (remainingCycles == 0 and busy == true).
     * The engine may call this and then decide which entry to broadcast.
     */
    public StationEntry[] findAllCompletedEntries() {
        return java.util.Arrays.stream(entries)
                .filter(e -> e.busy && e.remainingCycles == 0 && e.instruction != null)
                .toArray(StationEntry[]::new);
    }
}
