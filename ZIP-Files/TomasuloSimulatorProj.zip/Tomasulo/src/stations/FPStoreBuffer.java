package stations;

import instructions.Instruction;

/**
 * FP Store Buffer
 *
 * Behavior notes:
 * - Issue: the IssueUnit should compute EA before calling issueStore.
 * - Before permitting a STORE to be issued, the IssueUnit must call:
 *     storeBuffer.hasActiveEntryWithAddress(EA) and loadBuffer.hasActiveLoadWithAddress(EA)
 *   per your special rules.
 */
public class FPStoreBuffer extends ReservationStation {

    public FPStoreBuffer(int size) {
        super("FPStore", size);
    }

    /**
     * Issue a store into the store buffer. Caller should fill value or Qj/Qk as needed.
     * We set A here (the effective address).
     *
     * @return index of issued entry or -1 if full
     */
    public int issueStore(Instruction instr, int effectiveAddress, int issueOrder) {
        int idx = super.issue(instr, issueOrder);
        if (idx == -1) return -1;
        StationEntry e = entries[idx];
        e.A = effectiveAddress;
        return idx;
    }
    
    public int findReadyStoreEntry() {
        for (int i = 0; i < entries.length; i++) {
            StationEntry e = entries[i];
            // ready when value (Vj) is available (Qj empty) and A is set
            if (e.busy && (e.Qj == null || e.Qj.isEmpty()) && e.remainingCycles == 0) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Check if any active store in this buffer has the same address.
     */
    public boolean hasActiveStoreWithAddress(int address) {
        for (StationEntry e : getEntries()) {
            if (e.busy && e.A == address) return true;
        }
        return false;
    }

}
