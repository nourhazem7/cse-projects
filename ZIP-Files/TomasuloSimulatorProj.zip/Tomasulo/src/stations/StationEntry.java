package stations;

import instructions.Instruction;

/**
 * Represents ONE row/entry inside ANY reservation station or buffer.
 *
 * This object stores:
 * - operand values (Vj, Vk)
 * - tags (Qj, Qk)
 * - busy flag
 * - operation code
 * - destination register tag
 * - effective address field (for loads/stores)
 * - execution countdown
 * - issue order (for CDB arbitration)
 * - unique tag identifying this entry
 */
public class StationEntry {

    // Basic reservation station fields
    public boolean busy = false;
    public String op = "";  // Operation type: ADD.D, MUL.D, LD, SD, ADDI, etc.

    // Operand values (double used to hold both int and FP values)
    public double Vj = 0;
    public double Vk = 0;

    // Tags (Qi) for operands if they're not ready
    public String Qj = "";
    public String Qk = "";

    // Effective address for loads/stores
    public int A = 0;

    // Destination register tag (Qi)
    public String dest = ""; 

    // Execution countdown
    public int remainingCycles = -1; 

    // Global issue order provided by InstructionQueue (Needed for deciding when publishing on CDB (tie-break)) 
    public int issueOrder = -1;
    
    // Tracks the issuing cycle of an instruction
    public int issueCycle;

    
    // Unique tag for this entry (set by ReservationStation.issue)
    public String tag = "";

    // The original instruction object
    public Instruction instruction; // full instruction object
    
    // Computed result and flag (used for ALU results)
    public double result;       // numeric result (int or FP encoded as double)
    public boolean resultReady; // true if `result` holds the ALU/load result ready to broadcast
    public byte[] loadedBytes = null;
    
    // Cycle in which this entry reached remainingCycles == 0.
    // -1 means "not finished yet / not recorded".
    public int finishedCycle = -1;


    
    //==============================================================================================//
    // CONSTRUCTOR
    public StationEntry()
    {
    	clear();
    }
    //==============================================================================================//
    
    
    /**
     * Reset the entry to a free/unused state.
     * Note: we keep the object; callers reuse it.
     */
    public void clear() {
    	// Debug trace: show WHEN an entry is being cleared (and from which call site)
       // System.out.println("DEBUG: StationEntry.clear() called on tag='" + tag + "' op='" + op +
                      //     "' remCycles=" + remainingCycles + " -- stacktrace follows:");
       // Thread.dumpStack();
        
        
        busy = false;
        tag = "";
        op = "";
        instruction = null;

        Vj = -0.0;
        Vk = -0.0;
        Qj = "";
        Qk = "";

        dest = "";
        A = -1;

        remainingCycles = -1;
        

        result = 0.0;         // VERY IMPORTANT
        resultReady = false;  // VERY IMPORTANT
        loadedBytes = null; 
        finishedCycle = -1;

    }

    
    @Override
    public String toString() {
        return "StationEntry{" +
                "tag='" + tag + '\'' +
                ", op='" + op + '\'' +
                ", busy=" + busy +
                ", Vj=" + Vj +
                ", Vk=" + Vk +
                ", Qj='" + Qj + '\'' +
                ", Qk='" + Qk + '\'' +
                ", A=" + A +
                ", dest='" + dest + '\'' +
                ", rem=" + remainingCycles +
                ", issueOrder=" + issueOrder +
                ", resultReady=" + resultReady +
                ", result=" + result +
                '}';
    }
}
