package stations;

import core.CDB;
import instructions.Instruction;

/**
 * Parent class for all reservation stations/buffers.
 * All specific stations extend this class.
 */
public abstract class ReservationStation {

    protected StationEntry[] entries;
    protected int size;
    protected String name;  // e.g., "FPAdd", "FPLoad", etc.


    public ReservationStation(String name, int size) {
        this.name = name;
        this.size = size;
        this.entries = new StationEntry[size];

        for (int i = 0; i < size; i++) {
            entries[i] = new StationEntry();
        }
    }

    /**
     * Returns index of first free entry (busy == false), or returns -1 if none is free.
     */
    public int getFreeEntryIndex() {
        for (int i = 0; i < size; i++) {
            if (!entries[i].busy)
                return i;
        }
        return -1;
    }

    /**
     * Assigns an instruction to a reservation station entry.
     * Returns the index of the entry, or -1 if no free entry.
     *
     * Child classes may call this to avoid repeating boilerplate.
     */
    public int issue(Instruction instr, int issueOrder) {
        int idx = getFreeEntryIndex();
        if (idx == -1)
            return -1; // station full

        StationEntry e = entries[idx];
        
     // DEFENSIVE: ensure we are not reusing a slot that still has a recent finishedCycle
        if (e.busy) {
            System.out.println("BUG: issuing into busy entry! station=" + name + " idx=" + idx + " tag=" + e.tag);
            Thread.dumpStack();
        }
        
        e.clear();             // ensure previous values are removed
        e.busy = true;
        e.instruction = instr;
        e.op = instr.opcode;
        e.issueOrder = issueOrder;

        // Tag = station name + entry index
        e.tag = name + "_" + idx;

        // Vj, Vk, Qj, Qk, EA are filled by the IssueUnit AFTER this call

        return idx;
    }

    /**
     * Called each cycle by TomasuloEngine.
     * Decrements execution counters for active entries.
     */
    public void stepExecution() {
        for (StationEntry e : entries) {
            if (e.busy && e.remainingCycles > 0) {
                int before = e.remainingCycles;
                e.remainingCycles--;
                int after = e.remainingCycles;
                System.out.println("DEBUG: " + name + " stepExecution: tag=" + e.tag +
                                   " op=" + e.op + " remCycles " + before + " -> " + after);
            }
        }
    }

    /**
     * Returns the entry that has just finished execution.
     * A finished entry is:
     * - busy == true
     * - remainingCycles == 0
     * - instruction != null
     * - op not empty
     */
    public StationEntry getCompletedEntry() {
        for (StationEntry e : entries) {
            if (e.busy &&
                e.remainingCycles == 0 &&
                e.instruction != null &&
                !e.op.isEmpty()) {

                return e;
            }
        }
        return null;
    }

    /**
     * Receive broadcast from CDB and update Vj/Vk accordingly.
     */
    public void onCDB(CDB b) {
        for (StationEntry e : entries) {
            if (!e.busy) continue;

            boolean isLoad = false;
            boolean isStore = false;

            if (e.instruction != null) {
                String op = e.op.toUpperCase();
                isLoad =
                        op.startsWith("L.") ||
                        op.equals("LW") || op.equals("LD") || op.equals("L.D") || op.equals("L.S");

                isStore =
                        op.startsWith("S.") ||
                        op.equals("SW") || op.equals("SD") || op.equals("S.D") || op.equals("S.S");
            }

            // ---------- Update Vj ----------
            if (e.Qj.equals(b.tag)) {
                e.Vj = b.value;
                e.Qj = "";
            }

            // ---------- Update Vk ----------
            // In STORE instructions : Vj is the *value* to be stored, NEVER used for address.
            if (e.Qk.equals(b.tag)) {
                e.Vk = b.value;
                e.Qk = "";
            }
        }
    }

    /**
     * After write-back, DO NOT remove the entry.
     * Instead, free it by clearing fields → busy = false.
     * This matches project requirement.
     */
    public void freeEntry(StationEntry e) {
    	System.out.println("DEBUG: ReservationStation.freeEntry() called on station=" + name +
                " entryTag=" + e.tag + " op=" + e.op + " remCycles=" + e.remainingCycles);
    	// Keep existing behavior, but we want the trace from clear() too.
    	
        e.clear();
    }

    public StationEntry[] getEntries() {
        return entries;
    }

    public String getName() {
        return name;
    }
    
    public void debugPrint(String title) {
        System.out.println("[" + title + "]  (size=" + size + ")");

        for (int i = 0; i < entries.length; i++) {
            StationEntry e = entries[i];

            if (!e.busy) {
                System.out.println("  Entry " + i + ": busy = " + e.busy); 
                continue;
            }

            System.out.println("  Entry " + i + ":");
            System.out.println("     busy=" + e.busy);
            System.out.println("     tag=" + e.tag + "   op=" + e.op + "   issued in cycle#" + e.issueCycle);
            System.out.println("     Vj=" + e.Vj + "   Vk=" + e.Vk);
            System.out.println("     Qj=" + e.Qj + "   Qk=" + e.Qk);
            System.out.println("     dest=" + e.dest + "   A=" + e.A);
            System.out.println("     remCycles=" + e.remainingCycles + "   resultReady=" + e.resultReady);
        }
    }

}
