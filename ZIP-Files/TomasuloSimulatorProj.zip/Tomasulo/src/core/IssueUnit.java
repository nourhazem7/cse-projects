package core;

import instructions.Instruction;
import memory.Addressing;
import registers.FPRegisterFile;
import registers.RegisterFile;
import registers.RegisterStatus;
import stations.*;
import utils.Config;

//import utils.Config;

/**
 * IssueUnit v2 - uses separate integer and FP register files.
 * Expects InstructionQueue.nextIssueOrder() to provide unique global issue orders.
 *
 * Adapt this to your actual Instruction fields if they differ.
 */
public class IssueUnit { 

    private final InstructionQueue instrQueue; // your queue class
    private final RegisterFile intRegFile;
    private final FPRegisterFile fpRegFile;
    private final RegisterStatus regStatus;    // mapping reg -> producer tag
    private final FPAddStation fpAdd;
    private final FPMultStation fpMult;
    private final IntStation intStation;
    private final FPLoadBuffer fpLoad;
    private final FPStoreBuffer fpStore;
    private final IntLoadBuffer intLoad;
    private final IntStoreBuffer intStore;
    private final Config cfg;
    
    
    private int currentCycle;

    public void setCurrentCycle(int c) {
        this.currentCycle = c;
    }


    public IssueUnit(InstructionQueue q,
                     RegisterFile intRegFile,
                     FPRegisterFile fpRegFile,
                     RegisterStatus rs,
                     FPAddStation fpAdd,
                     FPMultStation fpMult,
                     IntStation intStation,
                     FPLoadBuffer fpLoad,
                     FPStoreBuffer fpStore,
                     IntLoadBuffer intLoad,
                     IntStoreBuffer intStore,
                     Config cfg) {
        this.instrQueue = q;
        this.intRegFile = intRegFile;
        this.fpRegFile = fpRegFile;
        this.regStatus = rs;
        this.fpAdd = fpAdd;
        this.fpMult = fpMult;
        this.intStation = intStation;
        this.fpLoad = fpLoad;
        this.fpStore = fpStore;
        this.intLoad = intLoad;
        this.intStore = intStore;
        this.cfg = cfg;
    }
 
    /**
     * Try to issue ONE instruction from the head of the instruction queue.
     * Returns true if an instruction was issued, false if nothing was issued (stall or empty).
     */
    public boolean issueOne() {
        if (instrQueue == null || instrQueue.isEmpty()) return false;

        Instruction instr = instrQueue.peekNext(); 
        String op = instr.opcode.toUpperCase().trim();

        try {
            switch (op) {
                case "ADD.D":
                case "SUB.D":
                    return issueToFPAdd(instr);

                case "MUL.D":
                case "DIV.D":
                    return issueToFPMult(instr);

                case "DADDI":
                case "DSUBI":
                    return issueToIntStation(instr);

                case "LW":
                case "LD":
                case "L.S":
                case "L.D":
                    return issueLoad(instr);

                case "SW":
                case "SD":
                case "S.S":
                case "S.D":
                    return issueStore(instr);

                case "BEQ":
                case "BNE":
                    return issueBranch(instr);

                default:
                    System.err.println("Unknown opcode in IssueUnit: " + op);
                    return false;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    private boolean issueToFPAdd(Instruction instr) {
        instr.issueOrder = instrQueue.nextIssueOrder();
        int idx = fpAdd.issue(instr, instr.issueOrder);
        if (idx < 0) return false;

        StationEntry e = fpAdd.getEntries()[idx];
        
        // Tracking the cycle number
        e.issueCycle = currentCycle;


        // operand 1
        String qj = regStatus.getTag(instr.rs);
        if (qj == null || qj.isEmpty()) {
            e.Vj = fpRegFile.getFP(instr.rs);
            e.Qj = "";
        } else {
            e.Qj = qj;
        }

        // operand 2
        String qk = regStatus.getTag(instr.rt);
        if (qk == null || qk.isEmpty()) {
            e.Vk = fpRegFile.getFP(instr.rt);
            e.Qk = "";
        } else {
            e.Qk = qk;
        }

        e.dest = instr.rd;
        regStatus.setTag(instr.rd, e.tag);

        instrQueue.advancePC();
        return true;
    }

    private boolean issueToFPMult(Instruction instr) {
        instr.issueOrder = instrQueue.nextIssueOrder();
        int idx = fpMult.issue(instr, instr.issueOrder);
        if (idx < 0) return false;

        StationEntry e = fpMult.getEntries()[idx];
        
        // Tracking the cycle number
        e.issueCycle = currentCycle;

        String qj = regStatus.getTag(instr.rs);
        if (qj == null || qj.isEmpty()) {
            e.Vj = fpRegFile.getFP(instr.rs);
            e.Qj = "";
        } else {
            e.Qj = qj;
        }

        String qk = regStatus.getTag(instr.rt);
        if (qk == null || qk.isEmpty()) {
            e.Vk = fpRegFile.getFP(instr.rt);
            e.Qk = "";
        } else {
            e.Qk = qk;
        }

        e.dest = instr.rd;
        regStatus.setTag(instr.rd, e.tag);

        instrQueue.advancePC();
        return true;
    }

    private boolean issueToIntStation(Instruction instr) {
        instr.issueOrder = instrQueue.nextIssueOrder();
        int idx = intStation.issue(instr, instr.issueOrder);
        if (idx < 0) return false;

        StationEntry e = intStation.getEntries()[idx];
        
        // Tracking the cycle number
        e.issueCycle = currentCycle;

        String qj = regStatus.getTag(instr.rs);
        if (qj == null || qj.isEmpty()) {
            e.Vj = intRegFile.getInt(instr.rs);
            e.Qj = "";
        } else {
            e.Qj = qj;
        }

        String qk = regStatus.getTag(instr.rt);
        if (qk == null || qk.isEmpty()) {
            e.Vk = intRegFile.getInt(instr.rt);
            e.Qk = "";
        } else {
            e.Qk = qk;
        }

        e.dest = instr.rd;
        regStatus.setTag(instr.rd, e.tag);

        instrQueue.advancePC();
        return true;
    }

    private boolean issueLoad(Instruction instr) {
    	instr.issueOrder = instrQueue.nextIssueOrder();
    	
    	// Check if base register is ready
        String baseTag = regStatus.getTag(instr.rs);
        if (baseTag != null && !baseTag.isEmpty()) {
            // Base not ready, stall instruction
            return false;
        }
    	
        // compute EA using base register value + immediate offset
        int base = intRegFile.getInt(instr.rs); // base register is integer (R register) even for FP loads per MIPS convention
        int EA = Addressing.computeEffectiveAddress(base, instr.imm);

        // address clash rule: check store buffers for conflicting addresses
        if (fpStore.hasActiveStoreWithAddress(EA) || intStore.hasActiveStoreWithAddress(EA)) {
            return false; // stall load until conflicting stores clear
        }

        int idx;
        StationEntry e;
        boolean isFP = instr.isFloat || instr.opcode.toUpperCase().contains("L.D") || instr.opcode.toUpperCase().contains("L.S");
        
        if (isFP) {
            idx = fpLoad.issueLoad(instr, EA, instr.issueOrder);
            if (idx < 0) return false;
            e = fpLoad.getEntries()[idx];      
        } else {
            idx = intLoad.issueLoad(instr, EA, instr.issueOrder);
            if (idx < 0) return false;
            e = intLoad.getEntries()[idx];
        }
        
        // Tracking the cycle number
        e.issueCycle = currentCycle;
        
        // set destination tracking & register status
        e.dest = instr.rd;
        regStatus.setTag(instr.rd, e.tag);  
        
        // Since base is ready, we can directly compute EA
        e.Vj = base;
        e.Qj = "";
        e.A = EA;
        
        instrQueue.advancePC();
        return true;
    }

    private boolean issueStore(Instruction instr) {
    	instr.issueOrder = instrQueue.nextIssueOrder();
    	
        // For store we require that base and value are ready
        String baseTag = regStatus.getTag(instr.rs);
        String valueTag = regStatus.getTag(instr.rd); // name of register that is holding value to store

        //if base not ready, stall.
        if (baseTag != null && !baseTag.isEmpty()) {
            return false;
        }

        int base = intRegFile.getInt(instr.rs);
        int EA = Addressing.computeEffectiveAddress(base, instr.imm);

        // store conflict check: both load and store buffers must not contain the same address active
        if (fpStore.hasActiveStoreWithAddress(EA) || fpLoad.hasActiveLoadWithAddress(EA)
                || intStore.hasActiveStoreWithAddress(EA) || intLoad.hasActiveLoadWithAddress(EA)) {
            return false; // stall store
        }

        StationEntry e;
        int idx;
        boolean isFP = instr.isFloat || instr.opcode.toUpperCase().contains("S.D") || instr.opcode.toUpperCase().contains("S.S");

        if (isFP) {
            idx = fpStore.issueStore(instr, EA, instr.issueOrder);
            if (idx < 0) return false;
            e = fpStore.getEntries()[idx]; 
            
            // Tracking the cycle number
            e.issueCycle = currentCycle;

            // set store value waiting
            if (valueTag == null || valueTag.isEmpty()) {
                e.Vj = fpRegFile.getFP(instr.rd);
                e.Qj = "";
            } else {
                e.Qj = valueTag;
            }
        } else {
            idx = intStore.issueStore(instr, EA, instr.issueOrder);
            if (idx < 0) return false; 
            e = intStore.getEntries()[idx];
            
            // Tracking the cycle number
            e.issueCycle = currentCycle;

            if (valueTag == null || valueTag.isEmpty()) {
                e.Vj = intRegFile.getInt(instr.rt);
                e.Qj = "";
            } else {
                e.Qj = valueTag;
            }
        }
        
        // Base is ready, so we can set Vk directly
        e.Vk = base;
        e.Qk = "";
        e.A = EA;

        instrQueue.advancePC();
        return true;
    }

    private boolean issueBranch(Instruction instr) {
        // treat branch as an integer operation
        instr.issueOrder = instrQueue.nextIssueOrder();
        int idx = intStation.issue(instr, instr.issueOrder);
        if (idx < 0) return false;

        StationEntry e = intStation.getEntries()[idx];
        
        // Tracking the cycle number
        e.issueCycle = currentCycle;

        String qj = regStatus.getTag(instr.rs);
        if (qj == null || qj.isEmpty()) {
            e.Vj = intRegFile.getInt(instr.rs);
            e.Qj = "";
        } else {
            e.Qj = qj;
        }

        String qk = regStatus.getTag(instr.rt);
        if (qk == null || qk.isEmpty()) {
            e.Vk = intRegFile.getInt(instr.rt);
            e.Qk = "";
        } else {
            e.Qk = qk;
        }

        instrQueue.advancePC();
        return true;
    }
}
