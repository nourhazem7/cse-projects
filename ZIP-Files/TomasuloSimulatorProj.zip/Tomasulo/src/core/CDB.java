package core;

/**
 * CDB: simple broadcast object used to update reservation stations when a value is written.
 * Fields:
 *  - tag: the producer tag (e.g., "FPAdd_0_5")
 *  - value: the numeric value broadcast (double used to support FP & integer values)
 *  - issueOrder: the global issue order of the producing instruction (useful for arbitration/tiebreak)
 */
public class CDB {
    public final String tag;
    public final double value;
    public final int issueOrder; // optional

    public CDB(String tag, double value, int issueOrder) {
        this.tag = tag;
        this.value = value;
        this.issueOrder = issueOrder;
    }

    @Override
    public String toString() {
        return "CDB{tag=" + tag + ", value=" + value + ", issueOrder=" + issueOrder + "}";
    }
}
