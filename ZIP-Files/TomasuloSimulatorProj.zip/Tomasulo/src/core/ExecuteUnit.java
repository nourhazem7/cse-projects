package core;

import memory.Cache;
import registers.FPRegisterFile;
import registers.RegisterFile;
import stations.*;
import utils.Config;

import java.nio.ByteBuffer;

/**
 * ExecuteUnit: schedules ready entries to start executing.
 *
 * Key fixes:
 * - Use remainingCycles == -1 to mean "not started".
 * - When starting a LOAD, set remainingCycles = cyclesTaken and store raw bytes in e.loadedBytes.
 *   Do NOT set e.result or e.resultReady at start.
 * - computeAluResultsForCompletedEntries() computes ALU results only (ignores loads/stores).
 * - Provide a public helper decodeLoadedBytes(...) to decode raw bytes to numeric value.
 */
public class ExecuteUnit {

    private final FPAddStation fpAdd;
    private final FPMultStation fpMult;
    private final IntStation intStation;
    private final FPLoadBuffer fpLoad;
    private final FPStoreBuffer fpStore;
    private final IntLoadBuffer intLoad;
    private final IntStoreBuffer intStore;

    private final RegisterFile intRegFile;
    private final FPRegisterFile fpRegFile;
    private final Cache cache;
    private final Config cfg;
    
    private int currentCycle = 0;

    public ExecuteUnit(FPAddStation fpAdd, FPMultStation fpMult, IntStation intStation,
                       FPLoadBuffer fpLoad, FPStoreBuffer fpStore,
                       IntLoadBuffer intLoad, IntStoreBuffer intStore,
                       RegisterFile intRegFile, FPRegisterFile fpRegFile,
                       Cache cache, Config cfg) {
        this.fpAdd = fpAdd;
        this.fpMult = fpMult;
        this.intStation = intStation;
        this.fpLoad = fpLoad;
        this.fpStore = fpStore;
        this.intLoad = intLoad;
        this.intStore = intStore;
        this.intRegFile = intRegFile;
        this.fpRegFile = fpRegFile;
        this.cache = cache;
        this.cfg = cfg;
    }

    /**
     * Called every cycle to attempt to start execution for ready entries.
     * Note: start only when remainingCycles == -1 (not started).
     */
    public void startReadyEntries() {
        // ALU FP Add
        startReadyInStation(fpAdd);

        // ALU FP Multiply
        startReadyInStation(fpMult);

        // Integer ALU
        startReadyInStation(intStation);

        // Loads (FP and Int)
        startReadyLoads(fpLoad, true);
        startReadyLoads(intLoad, false);

        // Stores (FP and Int)
        startReadyStores(fpStore, true);
        startReadyStores(intStore, false);
    }

    // Generic ALU starting logic: start only if not started yet (-1) and operands ready
    private void startReadyInStation(ReservationStation station) {
        for (StationEntry e : station.getEntries()) {
            if (!e.busy) continue;
            
            //DO NOT allow execution same cycle as issue
            if (e.issueCycle == currentCycle)
                continue;
             
            // Start execution only if not started (-1) and operands ready
            if (e.remainingCycles == -1 && (e.Qj == null || e.Qj.isEmpty()) && (e.Qk == null || e.Qk.isEmpty())) {
                int latency = getLatencyForOp(e.op);
                if (latency <= 0) latency = 1;
                e.remainingCycles = latency;
            }
        }
    }

    /**
     * Start ready loads: compute the memory-access latency (using cache) and store the raw bytes
     * in e.loadedBytes so decoding can happen only when the entry completes (remainingCycles -> 0).
     */
    private void startReadyLoads(ReservationStation loadBuf, boolean isFP) {
        for (StationEntry e : loadBuf.getEntries()) {
            if (!e.busy) continue;
            
            //DO NOT allow execution same cycle as issue
            if (e.issueCycle == currentCycle)
                continue;
            
            // Only start if not started yet (-1) and address (Qj) ready
            if (e.remainingCycles == -1 && (e.Qj == null || e.Qj.isEmpty())) {
                int addr = e.A;
                int bytes = (e.instruction != null && e.instruction.byteSize > 0)
                        ? e.instruction.byteSize
                        : 4;

                // Query cache to know latency and get raw bytes (we store them but do not decode yet)
                Cache.CacheResult res = cache.readBytesAccurate(addr, bytes);

                e.loadedBytes = res.data;        // raw block(s) bytes — decode later when completed
                e.remainingCycles = res.cyclesTaken;

                // IMPORTANT: do NOT set e.result or e.resultReady here
            }
        }
    }

    private void startReadyStores(ReservationStation storeBuf, boolean isFP) {
        for (StationEntry e : storeBuf.getEntries()) {
            if (!e.busy) continue;
             
            //DO NOT allow execution same cycle as issue
            if (e.issueCycle == currentCycle)
                continue;

            // Start store execution only if not started (-1) and value ready (Qj empty)
            if (e.remainingCycles == -1 && (e.Qj == null || e.Qj.isEmpty())) {
                int addr = e.A;
                int bytes = (e.instruction != null && e.instruction.byteSize > 0)
                        ? e.instruction.byteSize
                        : 4;

                // For stores we convert the store value (assumed stored in e.Vj) to bytes now to compute latency.
                byte[] data = numberToBytes((long) e.Vj, bytes);

                // Query cache to know write latency (this method should not actually commit the write permanently)
                Cache.CacheResult res = cache.probeWriteBytes(addr, data);
                
                e.remainingCycles = res.cyclesTaken;
                e.loadedBytes = data; // stash data for commit later
                e.resultReady = true; // signals ALU finished for STORES


                // Do NOT commit the store now. Actual write is done by TomasuloEngine when the store wins arbitration.
            }
        }
    }

    /**
     * Compute ALU results for entries that finished execution this cycle.
     * NOTE: do NOT touch loads or stores here (loads are decoded/broadcast by TomasuloEngine).
     */
    public void computeAluResultsForCompletedEntries() {
        processAluStation(fpAdd, true);
        processAluStation(fpMult, true);
        processAluStation(intStation, false);

        // For store buffers we can prepare result (payload) at completion if desired:
        processCompletedStores(fpStore, true);
        processCompletedStores(intStore, false);
    }

    private void processAluStation(ReservationStation station, boolean isFPStation) {
        for (StationEntry e : station.getEntries()) {
            if (!e.busy || e.instruction == null) continue;

            // Only process if finished (remainingCycles == 0) and not processed already
            if (e.remainingCycles == 0 && !e.resultReady) {
                String op = e.op == null ? e.instruction.opcode : e.op;
                if (op == null) continue;
                op = op.toUpperCase().trim();

                // Skip load/store ops here
                if (isLoadOp(op) || isStoreOp(op)) continue;

                // Integer immediates (DADDI / DSUBI / ADDI / SUBI)
                if (op.equals("DADDI") || op.equals("DSUBI")) {
                    long a = (long) e.Vj;
                    long imm = (e.instruction != null) ? e.instruction.imm : 0;
                    long r = (op.equals("DADDI")) ? (a + imm) : (a - imm);
                    e.result = (double) r;
                    e.resultReady = true;
                    continue;
                }
                if (op.equals("ADDI") || op.equals("SUBI")) {
                    int a = (int) e.Vj;
                    int imm = (e.instruction != null) ? e.instruction.imm : 0;
                    int r = (op.equals("ADDI")) ? (a + imm) : (a - imm);
                    e.result = (double) r;
                    e.resultReady = true;
                    continue;
                }

                // Integer register-register
                if (op.equals("ADD") || op.equals("SUB")) {
                    int a = (int) e.Vj;
                    int b = (int) e.Vk;
                    int r = op.equals("ADD") ? (a + b) : (a - b);
                    e.result = (double) r;
                    e.resultReady = true;
                    continue;
                }

                // FP ALU ops (.S or .D)
                if (op.startsWith("ADD.") || op.startsWith("SUB.") ||
                    op.startsWith("MUL.") || op.startsWith("DIV.")) {

                    boolean isDouble = op.endsWith(".D");
                    double A = e.Vj;
                    double B = e.Vk;
                    double R = 0.0;

                    if (op.startsWith("ADD")) R = A + B;
                    else if (op.startsWith("SUB")) R = A - B;
                    else if (op.startsWith("MUL")) R = A * B;
                    else R = A / B;

                    if (!isDouble) {
                        float rf = (float) R;
                        e.result = (double) rf;
                    } else {
                        e.result = R;
                    }
                    e.resultReady = true;
                    continue;
                }

                if (op.equals("BEQ") || op.equals("BNE")) {
                    double a = e.Vj;  // rs value
                    double b = e.Vk;  // rt value

                    boolean taken =
                            (op.equals("BEQ") && a == b) ||
                            (op.equals("BNE") && a != b);

                    e.result = taken ? 1.0 : 0.0;
                    e.resultReady = true;
                    continue;
                }

            }
        }
    }

    private void processCompletedStores(ReservationStation storeBuf, boolean isFP) {
        for (StationEntry e : storeBuf.getEntries()) {
            if (!e.busy || e.instruction == null) continue;
            if (e.remainingCycles == 0 && !e.resultReady) {
                // Prepare payload for commit — store payload is in e.Vj
                e.result = e.Vj;
                e.resultReady = true;
            }
        }
    }

    private int getLatencyForOp(String op) {
        if (op == null) return 1;
        String s = op.toUpperCase();
        switch (s) {
            case "ADD.D":
            case "ADD.S":
                return cfg.fpAddLatency;
            case "SUB.D":
            case "SUB.S":
                return cfg.fpSubLatency;
            case "MUL.D":
            case "MUL.S":
                return cfg.fpMulLatency;
            case "DIV.D":
            case "DIV.S":
                return cfg.fpDivLatency;
            case "ADDI":
            case "DADDI":
            case "ADD":
                return cfg.intAddLatency;
            case "SUBI":
            case "DSUBI":
            case "SUB":
                return cfg.intSubLatency;
            case "BEQ":
            case "BNE":
                return 1;
            default:
                return 1;
        }
    }

    // helper: decode raw bytes read by cache into numeric value (public for TomasuloEngine)
    public double decodeLoadedBytes(byte[] data, int bytes) {
        return bytesToNumber(data, bytes); 
    }

    private double bytesToNumber(byte[] data, int bytes) {
    	long val = 0;
        for (int i = 0; i < bytes; i++) {
            val |= ((long)(data[i] & 0xFF)) << (8 * i);
        }
        return (double) val;
    }
 
    private byte[] numberToBytes(long value, int bytes) {
        byte[] result = new byte[bytes];
        for (int i = 0; i < bytes; i++) {
            result[i] = (byte)((value >> (8 * i)) & 0xFF);
        }
        return result;
    }

    private boolean isLoadOp(String op) {
        if (op == null) return false;
        op = op.toUpperCase();
        return op.equals("L.D") || op.equals("L.S") || op.equals("LW") || op.startsWith("L.");
    }

    private boolean isStoreOp(String op) {
        if (op == null) return false;
        op = op.toUpperCase();
        return op.equals("S.D") || op.equals("S.S") || op.equals("SW") || op.startsWith("S.");
    }
    
    public void setCurrentCycle(int cycle) {
        this.currentCycle = cycle;
    }
}
