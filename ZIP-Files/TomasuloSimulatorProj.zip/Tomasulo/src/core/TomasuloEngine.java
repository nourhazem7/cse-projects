package core;

import memory.Cache;
import memory.Memory;
import registers.FPRegisterFile;
import registers.RegisterFile;
import registers.RegisterStatus;
import stations.*;
import utils.Config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * TomasuloEngine with detailed debug printing.
 */
public class TomasuloEngine {

    private final InstructionQueue instrQueue;
    private final IssueUnit issueUnit;
    private final ExecuteUnit executeUnit;
    private final RegisterFile intRegFile;
    private final FPRegisterFile fpRegFile;
    private final RegisterStatus regStatus;
    private final Cache cache;
    private final Memory memory;
    private final Config cfg;

    private final FPAddStation fpAdd;
    private final FPMultStation fpMult;
    private final IntStation intSt;
    private final FPLoadBuffer fpLoad;
    private final FPStoreBuffer fpStore;
    private final IntLoadBuffer intLoad;
    private final IntStoreBuffer intStore;

    private int cycle = 0;

    // Debug toggles
    private boolean printRS = true;
    private boolean printRegisters = true;
    private boolean printRegisterStatus = true;
    private boolean printCache = true;
    private boolean printMemory = true;
    
    private byte[] previousMemorySnapshot;
    
    private String lastCdbMessage = "";
    public String getLastCdbMessage() {
        return lastCdbMessage;
    }
    
    private StationEntry lastWinnerThisCycle = null;
    public StationEntry getLastCDBWinner() {
        return lastWinnerThisCycle;
    }



    public TomasuloEngine(InstructionQueue instrQueue,
                          IssueUnit issueUnit,
                          ExecuteUnit executeUnit,
                          RegisterFile intRegFile,
                          FPRegisterFile fpRegFile,
                          RegisterStatus regStatus,
                          FPAddStation fpAdd,
                          FPMultStation fpMult,
                          IntStation intSt,
                          FPLoadBuffer fpLoad,
                          FPStoreBuffer fpStore,
                          IntLoadBuffer intLoad,
                          IntStoreBuffer intStore,
                          Cache cache,
                          Memory memory,
                          Config cfg) {
        this.instrQueue = instrQueue;
        this.issueUnit = issueUnit;
        this.executeUnit = executeUnit;
        this.intRegFile = intRegFile;
        this.fpRegFile = fpRegFile;
        this.regStatus = regStatus;
        this.fpAdd = fpAdd;
        this.fpMult = fpMult;
        this.intSt = intSt;
        this.fpLoad = fpLoad;
        this.fpStore = fpStore;
        this.intLoad = intLoad;
        this.intStore = intStore;
        this.cache = cache;
        this.memory = memory;
        this.cfg = cfg;
        
        this.previousMemorySnapshot = Arrays.copyOf(memory.mem, memory.mem.length);
    }
    
    /*
    private List<Integer> getMemoryChangesSinceLastCycle() {
        List<Integer> changed = new ArrayList<>();

        for (int i = 0; i < memory.mem.length; i++) {
            if (memory.mem[i] != previousMemorySnapshot[i]) {
                changed.add(i);
            }
        }
        return changed;
    }
    
    private void printMemoryChanges(int cycle) {
        List<Integer> changed = getMemoryChangesSinceLastCycle();

        if (!changed.isEmpty()) {
            System.out.println("=== Memory Changes in Cycle " + cycle + " ===");
            for (int addr : changed) {
                System.out.println("mem[" + addr + "] = " + memory.mem[addr]);
            }
        }

        // update snapshot since this is now the reference for next cycle
        System.arraycopy(memory.mem, 0, previousMemorySnapshot, 0, memory.mem.length);
    }
    
    
    */
    
    
  //=====================================================================================================================//

    
    /**
     * Expose reservation station entry arrays for the GUI.
     */
    public stations.StationEntry[] getFpAddEntries() { return fpAdd.getEntries(); }
    public stations.StationEntry[] getFpMultEntries() { return fpMult.getEntries(); }
    public stations.StationEntry[] getIntStationEntries() { return intSt.getEntries(); }
    public stations.StationEntry[] getFpLoadEntries() { return fpLoad.getEntries(); }
    public stations.StationEntry[] getFpStoreEntries() { return fpStore.getEntries(); }
    public stations.StationEntry[] getIntLoadEntries() { return intLoad.getEntries(); }
    public stations.StationEntry[] getIntStoreEntries() { return intStore.getEntries(); }

    /** Register / cache / memory getters for GUI */
    public registers.RegisterFile getIntRegisterFile() { return intRegFile; }
    public registers.FPRegisterFile getFpRegisterFile() { return fpRegFile; }
    public memory.Cache getCacheObject() { return cache; }
    public memory.Memory getMemoryObject() { return memory; }

    /**
     * Return a list of (addr, value) pairs that changed since last cycle and
     * advance the internal snapshot so the GUI can call this every step.
     */
    public java.util.List<java.util.Map.Entry<Integer,Integer>> getMemoryChangesAndAdvanceSnapshot() {
        java.util.List<java.util.Map.Entry<Integer,Integer>> changed = new java.util.ArrayList<>();
        for (int i = 0; i < memory.mem.length; i++) {
            if (memory.mem[i] != previousMemorySnapshot[i]) {
                int val = memory.mem[i] & 0xFF;
                changed.add(new java.util.AbstractMap.SimpleEntry<>(i, val));
            }
        }
        // update snapshot
        System.arraycopy(memory.mem, 0, previousMemorySnapshot, 0, memory.mem.length);
        return changed;
    }

    
    /**
     * Initialize the memory snapshot (used by the GUI to detect changes).
     * Call this once before the first cycle.
     */
    public void initializeMemorySnapshot() {
        System.arraycopy(memory.mem, 0, previousMemorySnapshot, 0, memory.mem.length);
    }

//=====================================================================================================================//

    /**
     * Run one cycle.
     */
    public void stepCycle() {
        cycle++;
        lastCdbMessage = "";
        executeUnit.setCurrentCycle(cycle);
        issueUnit.setCurrentCycle(cycle);

        System.out.println("\n==================== CYCLE " + cycle + " ====================");

        // 1) Issue at most one instruction
        issueUnit.issueOne();

        // 2) Start execution for ready entries
        executeUnit.startReadyEntries();

        // 3) Decrement timers
        fpAdd.stepExecution();
        fpMult.stepExecution();
        intSt.stepExecution();
        fpLoad.stepExecution();
        fpStore.stepExecution();
        intLoad.stepExecution();
        intStore.stepExecution();
        
        // 3.a) Mark entries that just reached remainingCycles == 0 as finished THIS cycle
        markFinishedEntries();

        // 3.b) Compute ALU results (finished entries)
        // but broadcast will still be delayed to a later cycle by the collect filter.
        executeUnit.computeAluResultsForCompletedEntries();

        // 4) Collect the completed instructions (AKA finished execution instructions)
        lastWinnerThisCycle = null;
        List<StationEntry> completed = collectAllCompletedEntries();
        StationEntry winner = arbitrateAndPick(completed);

        if (winner != null) {
        	lastWinnerThisCycle = winner;
            handleWinnerBroadcastOrStoreCommit(winner);
        }

        // 5) Debug printing
        if (printRS) printAllReservationStations();
        if (printRegisters) printRegisterFiles();
        if (printRegisterStatus) printRegStatus();
        if (printCache) printCacheState();
        //if (printMemory) printMemoryChanges(cycle);
    }

//--------------------------------------------------------------------------------------------------------------------//
//--------------------------------------------------------------------------------------------------------------------//
    /**
     * Mark entries that reached remainingCycles == 0 during stepExecution.
     * We set finishedCycle so we can ensure the CDB broadcast happens earliest in the cycle after they finished.
     */
    private void markFinishedEntries() {
        markFinishedIn(fpAdd);
        markFinishedIn(fpMult);
        markFinishedIn(intSt);
        markFinishedIn(fpLoad);
        markFinishedIn(fpStore);
        markFinishedIn(intLoad);
        markFinishedIn(intStore);
    }

    private void markFinishedIn(ReservationStation rs) {
        for (StationEntry e : rs.getEntries()) {
            if (!e.busy) continue;
            if (e.remainingCycles == 0 && e.finishedCycle == -1) {
                e.finishedCycle = cycle; // record the cycle when it finished
            }
        }
    }


    // -----------------------------------------------------
    // Collect completed entries
    // -----------------------------------------------------

    private List<StationEntry> collectAllCompletedEntries() {
        List<StationEntry> list = new ArrayList<>();
        addCompletedFrom(fpAdd, list);
        addCompletedFrom(fpMult, list);
        addCompletedFrom(intSt, list);
        addCompletedFrom(fpLoad, list);
        addCompletedFrom(fpStore, list);
        addCompletedFrom(intLoad, list);
        addCompletedFrom(intStore, list);
        return list;
    }

    private void addCompletedFrom(ReservationStation rs, List<StationEntry> list) {
        for (StationEntry e : rs.getEntries()) {
        	// must be busy, finished (remainingCycles == 0), have an op,
            // and must have finished in a previous cycle (finishedCycle < cycle).
        	if (e.busy && e.remainingCycles == 0 && e.op != null && !e.op.isEmpty()
                    && e.finishedCycle != -1 && e.finishedCycle < cycle) {
                list.add(e);
            }
        }
    }

    // -----------------------------------------------------
    // Arbitration
    // -----------------------------------------------------

    private StationEntry arbitrateAndPick(List<StationEntry> candidates) {
        if (candidates.isEmpty()) return null;

        StationEntry best = null;
        int bestDependents = -1;

        for (StationEntry c : candidates) {
            int dep = countDependents(c.tag);
            if (dep > bestDependents) {
                bestDependents = dep;
                best = c;
            } else if (dep == bestDependents && best != null) {
                if (c.issueOrder < best.issueOrder) best = c;
            }
        }
        return best;
    }

    private int countDependents(String tag) {
        return countDependentsIn(fpAdd, tag)
             + countDependentsIn(fpMult, tag)
             + countDependentsIn(intSt, tag)
             + countDependentsIn(fpLoad, tag)
             + countDependentsIn(fpStore, tag)
             + countDependentsIn(intLoad, tag)
             + countDependentsIn(intStore, tag);
    }

    private int countDependentsIn(ReservationStation rs, String tag) {
        int c = 0;
        for (StationEntry e : rs.getEntries()) {
            if (!e.busy) continue;
            if (tag.equals(e.Qj)) c++;
            if (tag.equals(e.Qk)) c++;
        }
        return c;
    }

    // -----------------------------------------------------
    // Winner handling
    // -----------------------------------------------------

    private boolean isStoreOp(String op) {
        if (op == null) return false;
        op = op.toUpperCase();
        return op.equals("SW") || op.equals("SD") || op.startsWith("S.");
    }
    
    private boolean isLoadOp(String op) {
        if (op == null) return false;
        op = op.toUpperCase();
        return op.equals("L.D") || op.equals("L.S") || op.equals("LW") || op.startsWith("L.");
    }

    private void handleWinnerBroadcastOrStoreCommit(StationEntry winner) {
        System.out.println(" → CDB winner: " + winner.tag + " (" + winner.op + ")");
        lastCdbMessage = "→ CDB winner: " + winner.tag + " (" + winner.op + ")";


        if (isStoreOp(winner.op)) {
            // STORE commit to memory
        	byte[] storeData = winner.loadedBytes;     // bytes prepared earlier
            cache.writeBytes(winner.A, storeData);     // REAL write-through
            freeEntry(winner);
            return;
        }

        // If it's a LOAD, decode its loadedBytes now into a numeric result
        double value;
        if (isLoadOp(winner.op)) {
            // decode raw bytes (ExecuteUnit helper)
            value = executeUnit.decodeLoadedBytes(winner.loadedBytes, winner.instruction.byteSize);
            winner.result = value;
            winner.resultReady = true;
        } 
        else {
            // ALU or store payload (ALU should have computed e.result earlier)
            value = winner.resultReady ? winner.result : winner.Vj;
            
            System.out.println("DEBUG: raw winner.op='" + winner.op + "'");
            System.out.println("DEBUG: instr.op='" + winner.instruction.opcode + "'");

            String opNorm = winner.instruction.opcode.trim().toUpperCase();
            if(opNorm.equals("BNE") || opNorm.equals("BEQ")) {
            	System.out.println("Branch " + winner.tag + " decided to jump to idx=" + winner.instruction.imm + " (result=" + winner.result + ")");
            	if(winner.result == 1) {
            		System.out.println("Branch " + winner.tag + " decided to jump to idx=" + winner.instruction.imm + " (result=" + winner.result + ")");
            		instrQueue.jumpToIndex(winner.instruction.imm);
            	}
            }
        }

        CDB cdb = new CDB(winner.tag, value, winner.issueOrder);

        fpAdd.onCDB(cdb);
        fpMult.onCDB(cdb);
        intSt.onCDB(cdb);
        fpLoad.onCDB(cdb);
        fpStore.onCDB(cdb);
        intLoad.onCDB(cdb);
        intStore.onCDB(cdb);

        // Register update
        if (winner.dest != null && !winner.dest.isEmpty()) {
            String pending = regStatus.getTag(winner.dest);
            if (pending != null && pending.equals(winner.tag)) {
                if (winner.dest.startsWith("F"))
                    fpRegFile.setFP(winner.dest, value);
                else
                    intRegFile.setInt(winner.dest, (int) value);
                regStatus.clearTag(winner.dest);
            }
        }

        freeEntry(winner);
    }

    private void freeEntry(StationEntry e) {
    	 System.out.println("DEBUG: TomasuloEngine.freeEntry() called for tag=" + e.tag + " op=" + e.op +
                 " remCycles=" + e.remainingCycles + " cycle=" + cycle);
    	 
        clearFrom(fpAdd, e);
        clearFrom(fpMult, e);
        clearFrom(intSt, e);
        clearFrom(fpLoad, e);
        clearFrom(fpStore, e);
        clearFrom(intLoad, e);
        clearFrom(intStore, e);
    }

    private void clearFrom(ReservationStation rs, StationEntry e) {
        for (StationEntry ent : rs.getEntries()) {
            if (ent == e) {
                rs.freeEntry(ent);
                return;
            }
        }
    }

    // -----------------------------------------------------
    // Debug Printing
    // -----------------------------------------------------

    private void printAllReservationStations() {
        System.out.println("\n--- Reservation Stations ---");
        fpAdd.debugPrint("FP ADD");
        fpMult.debugPrint("FP MULT");
        intSt.debugPrint("INT");
        fpLoad.debugPrint("FP LOAD");
        fpStore.debugPrint("FP STORE");
        intLoad.debugPrint("INT LOAD");
        intStore.debugPrint("INT STORE");
    }

    private void printRegisterFiles() {
        System.out.println("\n--- Register File (INT) ---");
        intRegFile.debugPrint();

        System.out.println("\n--- Register File (FP) ---");
        fpRegFile.debugPrint();
    }

    private void printRegStatus() {
        System.out.println("\n--- Register Status ---");
        regStatus.debugPrint();
    }

    private void printCacheState() {
        System.out.println("\n--- Cache Content ---");
        cache.debugPrint();
    }

    /**
     * Memory printing in PURE DECIMAL form.
     */
    private void printMemoryFull() {
        System.out.println("\n=========== MEMORY DUMP ===========");
        int size = memory.size();
        for (int addr = 0; addr < size; addr++) {
            byte b = memory.readBytes(addr, 1)[0];
            int val = b & 0xFF;
            System.out.println("[" + addr + "] : " + val);
        }
        System.out.println("===================================");
    }

    private byte[] longToBytes(long v, int bytes) {
        byte[] out = new byte[bytes];
        for (int i = 0; i < bytes; i++)
            out[i] = (byte) ((v >> (8 * i)) & 0xFF);
        return out;
    }

    public int getCycle() {
        return cycle;
    }
    
    public boolean hasBusyStations() {
        return hasBusy(fpAdd)
            || hasBusy(fpMult)
            || hasBusy(intSt)
            || hasBusy(fpLoad)
            || hasBusy(fpStore)
            || hasBusy(intLoad)
            || hasBusy(intStore);
    }

    private boolean hasBusy(ReservationStation rs) {
        for (StationEntry e : rs.getEntries()) {
            if (e.busy) return true;
        }
        return false;
    }

    public boolean isFinished() {
        return instrQueue.isEmpty() && !hasBusyStations();
    }
    
    public RegisterStatus getRegisterStatus() {
        return this.regStatus;
    }


}
