package core;

import instructions.Instruction;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class InstructionQueue {

    private final List<Instruction> instrMemory = new ArrayList<>();
    private int pc = 0;  // current instruction pointer
    private int globalIssueCounter = 1;

    public InstructionQueue() {}

    public boolean isEmpty() {
        return pc >= instrMemory.size();
    }

    public Instruction peekNext() {
        if (isEmpty()) return null;
        return instrMemory.get(pc);
    }

    public void advancePC() {
        pc++;
    }

    public void jumpToIndex(int idx) {
        if (idx < 0 || idx >= instrMemory.size())
            throw new IllegalArgumentException("Invalid instruction index: " + idx);
        pc = idx;
    }

    public int nextIssueOrder() {
        return globalIssueCounter++;
    }

    public void clear() {
        instrMemory.clear();
        pc = 0;
        globalIssueCounter = 0;
    }

    public List<Instruction> loadFromFile(String filepath) throws Exception {
        BufferedReader br = new BufferedReader(new FileReader(filepath));
        String line;
        int ln = 0;
        while ((line = br.readLine()) != null) {
            ln++;
            Instruction instr = instructions.InstructionParser.parseLine(line);
            if (instr != null) {
                instr.lineNumber = ln;
                instrMemory.add(instr);
            }
        }
        br.close();
        return instrMemory;
    }

    public int size() {
        return instrMemory.size();
    }
}
